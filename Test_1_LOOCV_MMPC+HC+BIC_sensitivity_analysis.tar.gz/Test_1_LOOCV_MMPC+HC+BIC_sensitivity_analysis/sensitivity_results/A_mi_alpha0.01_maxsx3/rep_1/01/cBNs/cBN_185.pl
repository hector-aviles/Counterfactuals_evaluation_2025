%%% Exogenous variables

0.1638991::u_action(change_to_left); 0.1722017::u_action(change_to_right); 0.4060066::u_action(cruise); 0.2557401::u_action(keep); 0.0012300::u_action(swerve_left); 0.0009225::u_action(swerve_right)
action(V) :- u_action(V).

0.5280853::u1.
curr_lane :- u1.

0.6133678::u2.
free_E :- u2, \+ curr_lane, \+ latent_collision.

0.9358974::u3.
free_E :- u3, curr_lane, \+ latent_collision.

0.4409283::u4.
free_E :- u4, \+ curr_lane, latent_collision.

0.5405553::u5.
free_E :- u5, curr_lane, latent_collision.

0.4883721::u6.
free_NE :- u6, action(change_to_left), \+ curr_lane.

0.5078717::u7.
free_NE :- u7, action(change_to_right), \+ curr_lane.

0.4680773::u8.
free_NE :- u8, action(cruise), \+ curr_lane.

0.1129083::u9.
free_NE :- u9, action(keep), \+ curr_lane.

0.8750000::u10.
free_NE :- u10, action(swerve_left), \+ curr_lane.

0.5000000::u11.
free_NE :- u11, action(swerve_right), \+ curr_lane.

0.5052894::u12.
free_NE :- u12, action(change_to_left), curr_lane.

0.5404255::u13.
free_NE :- u13, action(change_to_right), curr_lane.

0.8376761::u14.
free_NE :- u14, action(cruise), curr_lane.

0.0038106::u15.
free_NE :- u15, action(keep), curr_lane.

0.9990010::u16.
free_NE :- u16, action(swerve_left), curr_lane.

0.9444444::u17.
free_NE :- u17, action(swerve_right), curr_lane.

0.5115697::u18.
free_NW :- u18, action(change_to_left).

0.5410714::u19.
free_NW :- u19, action(change_to_right).

0.5167887::u20.
free_NW :- u20, action(cruise).

0.0338677::u21.
free_NW :- u21, action(keep).

0.9990010::u22.
free_NW :- u22, action(swerve_left).

0.6111111::u23.
free_NW :- u23, action(swerve_right).

0.7763158::u24.
free_SE :- u24, \+ curr_lane, \+ free_SW, \+ latent_collision.

0.9723618::u25.
free_SE :- u25, curr_lane, \+ free_SW, \+ latent_collision.

0.3841941::u26.
free_SE :- u26, \+ curr_lane, free_SW, \+ latent_collision.

0.7817067::u27.
free_SE :- u27, curr_lane, free_SW, \+ latent_collision.

0.5103093::u28.
free_SE :- u28, \+ curr_lane, \+ free_SW, latent_collision.

0.5077011::u29.
free_SE :- u29, curr_lane, \+ free_SW, latent_collision.

0.4921799::u30.
free_SE :- u30, \+ curr_lane, free_SW, latent_collision.

0.4690265::u31.
free_SE :- u31, curr_lane, free_SW, latent_collision.

0.5297061::u32.
free_SW :- u32, action(change_to_left).

0.6032738::u33.
free_SW :- u33, action(change_to_right).

0.5925271::u34.
free_SW :- u34, action(cruise).

0.9761523::u35.
free_SW :- u35, action(keep).

0.9583333::u36.
free_SW :- u36, action(swerve_left).

0.6666667::u37.
free_SW :- u37, action(swerve_right).

0.5062539::u38.
free_W :- u38, action(change_to_left).

0.5755952::u39.
free_W :- u39, action(change_to_right).

0.7202727::u40.
free_W :- u40, action(cruise).

0.9220441::u41.
free_W :- u41, action(keep).

0.9583333::u42.
free_W :- u42, action(swerve_left).

0.5555556::u43.
free_W :- u43, action(swerve_right).

0.6832177::u44.
latent_collision :- u44, \+ free_W.

0.2610667::u45.
latent_collision :- u45, free_W.

