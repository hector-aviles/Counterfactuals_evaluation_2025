%%% Exogenous variables

0.1692512::u_action(change_to_left); 0.1700701::u_action(change_to_right); 0.4044219::u_action(cruise); 0.2539536::u_action(keep); 0.0017913::u_action(swerve_left); 0.0005118::u_action(swerve_right)
action(V) :- u_action(V).

0.5305799::u1.
curr_lane :- u1.

0.6194527::u2.
free_E :- u2, \+ curr_lane, \+ latent_collision.

0.9338592::u3.
free_E :- u3, curr_lane, \+ latent_collision.

0.4614772::u4.
free_E :- u4, \+ curr_lane, latent_collision.

0.5327152::u5.
free_E :- u5, curr_lane, latent_collision.

0.4867150::u6.
free_NE :- u6, action(change_to_left), \+ curr_lane.

0.4978672::u7.
free_NE :- u7, action(change_to_right), \+ curr_lane.

0.4876429::u8.
free_NE :- u8, action(cruise), \+ curr_lane.

0.1082964::u9.
free_NE :- u9, action(keep), \+ curr_lane.

0.8333333::u10.
free_NE :- u10, action(swerve_left), \+ curr_lane.

0.5000000::u11.
free_NE :- u11, action(swerve_right), \+ curr_lane.

0.4839491::u12.
free_NE :- u12, action(change_to_left), curr_lane.

0.5398335::u13.
free_NE :- u13, action(change_to_right), curr_lane.

0.8370256::u14.
free_NE :- u14, action(cruise), curr_lane.

0.0033259::u15.
free_NE :- u15, action(keep), curr_lane.

0.9310345::u16.
free_NE :- u16, action(swerve_left), curr_lane.

0.7000000::u17.
free_NE :- u17, action(swerve_right), curr_lane.

0.5019655::u18.
free_NW :- u18, action(change_to_left).

0.5425820::u19.
free_NW :- u19, action(change_to_right).

0.5256897::u20.
free_NW :- u20, action(cruise).

0.0330512::u21.
free_NW :- u21, action(keep).

0.9990010::u22.
free_NW :- u22, action(swerve_left).

0.9000000::u23.
free_NW :- u23, action(swerve_right).

0.7321429::u24.
free_SE :- u24, \+ curr_lane, \+ free_SW, \+ latent_collision.

0.9716860::u25.
free_SE :- u25, curr_lane, \+ free_SW, \+ latent_collision.

0.3937207::u26.
free_SE :- u26, \+ curr_lane, free_SW, \+ latent_collision.

0.7772823::u27.
free_SE :- u27, curr_lane, free_SW, \+ latent_collision.

0.5194878::u28.
free_SE :- u28, \+ curr_lane, \+ free_SW, latent_collision.

0.5211429::u29.
free_SE :- u29, curr_lane, \+ free_SW, latent_collision.

0.5111789::u30.
free_SE :- u30, \+ curr_lane, free_SW, latent_collision.

0.5209877::u31.
free_SE :- u31, curr_lane, free_SW, latent_collision.

0.5349259::u32.
free_SW :- u32, action(change_to_left).

0.5777912::u33.
free_SW :- u33, action(change_to_right).

0.6107315::u34.
free_SW :- u34, action(cruise).

0.9721886::u35.
free_SW :- u35, action(keep).

0.9714286::u36.
free_SW :- u36, action(swerve_left).

0.9000000::u37.
free_SW :- u37, action(swerve_right).

0.5034775::u38.
free_W :- u38, action(change_to_left).

0.5862173::u39.
free_W :- u39, action(change_to_right).

0.7195647::u40.
free_W :- u40, action(cruise).

0.9195889::u41.
free_W :- u41, action(keep).

0.9990010::u42.
free_W :- u42, action(swerve_left).

0.9000000::u43.
free_W :- u43, action(swerve_right).

0.6840050::u44.
latent_collision :- u44, \+ free_W.

0.2650654::u45.
latent_collision :- u45, free_W.

