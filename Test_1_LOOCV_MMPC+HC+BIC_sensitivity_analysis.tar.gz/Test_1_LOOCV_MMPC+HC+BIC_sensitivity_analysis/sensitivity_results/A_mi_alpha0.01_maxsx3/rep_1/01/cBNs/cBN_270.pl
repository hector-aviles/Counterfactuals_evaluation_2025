%%% Exogenous variables

0.1682490::u_action(change_to_left); 0.1696498::u_action(change_to_right); 0.4007782::u_action(cruise); 0.2589883::u_action(keep); 0.0014008::u_action(swerve_left); 0.0009339::u_action(swerve_right)
action(V) :- u_action(V).

0.5260182::u1.
curr_lane :- u1.

0.6233910::u2.
free_E :- u2, \+ curr_lane, \+ latent_collision.

0.9362101::u3.
free_E :- u3, curr_lane, \+ latent_collision.

0.4510546::u4.
free_E :- u4, \+ curr_lane, latent_collision.

0.5161635::u5.
free_E :- u5, curr_lane, latent_collision.

0.4799011::u6.
free_NE :- u6, action(change_to_left), \+ curr_lane.

0.5213936::u7.
free_NE :- u7, action(change_to_right), \+ curr_lane.

0.4807339::u8.
free_NE :- u8, action(cruise), \+ curr_lane.

0.1214331::u9.
free_NE :- u9, action(keep), \+ curr_lane.

0.7500000::u10.
free_NE :- u10, action(swerve_left), \+ curr_lane.

0.5000000::u11.
free_NE :- u11, action(swerve_right), \+ curr_lane.

0.4760148::u12.
free_NE :- u12, action(change_to_left), curr_lane.

0.5146879::u13.
free_NE :- u13, action(change_to_right), curr_lane.

0.8272000::u14.
free_NE :- u14, action(cruise), curr_lane.

0.0054407::u15.
free_NE :- u15, action(keep), curr_lane.

0.8260870::u16.
free_NE :- u16, action(swerve_left), curr_lane.

0.9444444::u17.
free_NE :- u17, action(swerve_right), curr_lane.

0.5013876::u18.
free_NW :- u18, action(change_to_left).

0.5620795::u19.
free_NW :- u19, action(change_to_right).

0.5509385::u20.
free_NW :- u20, action(cruise).

0.0294471::u21.
free_NW :- u21, action(keep).

0.9990010::u22.
free_NW :- u22, action(swerve_left).

0.8888889::u23.
free_NW :- u23, action(swerve_right).

0.3579102::u24.
free_SE :- u24, \+ curr_lane, \+ free_E, \+ latent_collision.

0.9877451::u25.
free_SE :- u25, curr_lane, \+ free_E, \+ latent_collision.

0.4646018::u26.
free_SE :- u26, \+ curr_lane, free_E, \+ latent_collision.

0.8261523::u27.
free_SE :- u27, curr_lane, free_E, \+ latent_collision.

0.4935961::u28.
free_SE :- u28, \+ curr_lane, \+ free_E, latent_collision.

0.4732192::u29.
free_SE :- u29, curr_lane, \+ free_E, latent_collision.

0.5077938::u30.
free_SE :- u30, \+ curr_lane, free_E, latent_collision.

0.4865424::u31.
free_SE :- u31, curr_lane, free_E, latent_collision.

0.5174221::u32.
free_SW :- u32, action(change_to_left).

0.5935780::u33.
free_SW :- u33, action(change_to_right).

0.6284790::u34.
free_SW :- u34, action(cruise).

0.9771635::u35.
free_SW :- u35, action(keep).

0.8888889::u36.
free_SW :- u36, action(swerve_left).

0.9444444::u37.
free_SW :- u37, action(swerve_right).

0.5132962::u38.
free_W :- u38, action(change_to_left), \+ free_NW.

0.5586592::u39.
free_W :- u39, action(change_to_right), \+ free_NW.

0.7229749::u40.
free_W :- u40, action(cruise), \+ free_NW.

0.9370485::u41.
free_W :- u41, action(keep), \+ free_NW.

0.5000000::u42.
free_W :- u42, action(swerve_left), \+ free_NW.

0.9990010::u43.
free_W :- u43, action(swerve_right), \+ free_NW.

0.5227552::u44.
free_W :- u44, action(change_to_left), free_NW.

0.6099021::u45.
free_W :- u45, action(change_to_right), free_NW.

0.7709117::u46.
free_W :- u46, action(cruise), free_NW.

0.4421769::u47.
free_W :- u47, action(keep), free_NW.

0.9629630::u48.
free_W :- u48, action(swerve_left), free_NW.

0.9375000::u49.
free_W :- u49, action(swerve_right), free_NW.

0.7109032::u50.
latent_collision :- u50, \+ free_W.

0.2648525::u51.
latent_collision :- u51, free_W.

