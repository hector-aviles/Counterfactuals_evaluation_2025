%%% Exogenous variables

0.1699032::u_action(change_to_left); 0.1669826::u_action(change_to_right); 0.4031357::u_action(cruise); 0.2573141::u_action(keep); 0.0015371::u_action(swerve_left); 0.0011272::u_action(swerve_right)
action(V) :- u_action(V).

0.5351745::u1.
curr_lane :- u1.

0.6097786::u2.
free_E :- u2, \+ curr_lane, \+ latent_collision.

0.9319356::u3.
free_E :- u3, curr_lane, \+ latent_collision.

0.4515334::u4.
free_E :- u4, \+ curr_lane, latent_collision.

0.5156614::u5.
free_E :- u5, curr_lane, latent_collision.

0.4828623::u6.
free_NE :- u6, action(change_to_left), \+ curr_lane.

0.5055811::u7.
free_NE :- u7, action(change_to_right), \+ curr_lane.

0.4664417::u8.
free_NE :- u8, action(cruise), \+ curr_lane.

0.1126673::u9.
free_NE :- u9, action(keep), \+ curr_lane.

0.8333333::u10.
free_NE :- u10, action(swerve_left), \+ curr_lane.

0.5000000::u11.
free_NE :- u11, action(swerve_right), \+ curr_lane.

0.4942529::u12.
free_NE :- u12, action(change_to_left), curr_lane.

0.5230415::u13.
free_NE :- u13, action(change_to_right), curr_lane.

0.8277254::u14.
free_NE :- u14, action(cruise), curr_lane.

0.0022112::u15.
free_NE :- u15, action(keep), curr_lane.

0.8333333::u16.
free_NE :- u16, action(swerve_left), curr_lane.

0.8181818::u17.
free_NE :- u17, action(swerve_right), curr_lane.

0.4969843::u18.
free_NW :- u18, action(change_to_left).

0.5418840::u19.
free_NW :- u19, action(change_to_right).

0.5339349::u20.
free_NW :- u20, action(cruise).

0.0322581::u21.
free_NW :- u21, action(keep).

0.9990010::u22.
free_NW :- u22, action(swerve_left).

0.6818182::u23.
free_NW :- u23, action(swerve_right).

0.8466899::u24.
free_SE :- u24, \+ curr_lane, \+ free_SW, \+ latent_collision.

0.9649273::u25.
free_SE :- u25, curr_lane, \+ free_SW, \+ latent_collision.

0.4009351::u26.
free_SE :- u26, \+ curr_lane, free_SW, \+ latent_collision.

0.7846371::u27.
free_SE :- u27, curr_lane, free_SW, \+ latent_collision.

0.5221591::u28.
free_SE :- u28, \+ curr_lane, \+ free_SW, latent_collision.

0.4960589::u29.
free_SE :- u29, curr_lane, \+ free_SW, latent_collision.

0.5116279::u30.
free_SE :- u30, \+ curr_lane, free_SW, latent_collision.

0.5168367::u31.
free_SE :- u31, curr_lane, free_SW, latent_collision.

0.5162847::u32.
free_SW :- u32, action(change_to_left).

0.5648972::u33.
free_SW :- u33, action(change_to_right).

0.6018048::u34.
free_SW :- u34, action(cruise).

0.9741139::u35.
free_SW :- u35, action(keep).

0.9666667::u36.
free_SW :- u36, action(swerve_left).

0.9090909::u37.
free_SW :- u37, action(swerve_right).

0.5075392::u38.
free_W :- u38, action(change_to_left).

0.5615219::u39.
free_W :- u39, action(change_to_right).

0.7178444::u40.
free_W :- u40, action(cruise).

0.9245321::u41.
free_W :- u41, action(keep).

0.9990010::u42.
free_W :- u42, action(swerve_left).

0.7727273::u43.
free_W :- u43, action(swerve_right).

0.6853159::u44.
latent_collision :- u44, \+ free_W.

0.2622193::u45.
latent_collision :- u45, free_W.

