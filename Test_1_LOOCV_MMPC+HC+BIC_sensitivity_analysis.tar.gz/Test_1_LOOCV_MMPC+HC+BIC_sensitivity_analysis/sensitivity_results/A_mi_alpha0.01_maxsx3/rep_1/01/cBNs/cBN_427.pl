%%% Exogenous variables

0.1678780::u_action(change_to_left); 0.1719726::u_action(change_to_right); 0.4006551::u_action(cruise); 0.2569864::u_action(keep); 0.0015867::u_action(swerve_left); 0.0009213::u_action(swerve_right)
action(V) :- u_action(V).

0.5283550::u1.
curr_lane :- u1.

0.6091848::u2.
free_E :- u2, \+ curr_lane, \+ latent_collision.

0.9406393::u3.
free_E :- u3, curr_lane, \+ latent_collision.

0.4518851::u4.
free_E :- u4, \+ curr_lane, latent_collision.

0.5259792::u5.
free_E :- u5, curr_lane, latent_collision.

0.4754491::u6.
free_NE :- u6, action(change_to_left), \+ curr_lane.

0.5020971::u7.
free_NE :- u7, action(change_to_right), \+ curr_lane.

0.4812894::u8.
free_NE :- u8, action(cruise), \+ curr_lane.

0.1176656::u9.
free_NE :- u9, action(keep), \+ curr_lane.

0.5714286::u10.
free_NE :- u10, action(swerve_left), \+ curr_lane.

0.5000000::u11.
free_NE :- u11, action(swerve_right), \+ curr_lane.

0.4875776::u12.
free_NE :- u12, action(change_to_left), curr_lane.

0.5239503::u13.
free_NE :- u13, action(change_to_right), curr_lane.

0.8350556::u14.
free_NE :- u14, action(cruise), curr_lane.

0.0037817::u15.
free_NE :- u15, action(keep), curr_lane.

0.9990010::u16.
free_NE :- u16, action(swerve_left), curr_lane.

0.8333333::u17.
free_NE :- u17, action(swerve_right), curr_lane.

0.5112805::u18.
free_NW :- u18, action(change_to_left).

0.5568452::u19.
free_NW :- u19, action(change_to_right).

0.5273378::u20.
free_NW :- u20, action(cruise).

0.0322645::u21.
free_NW :- u21, action(keep).

0.9990010::u22.
free_NW :- u22, action(swerve_left).

0.8333333::u23.
free_NW :- u23, action(swerve_right).

0.3374233::u24.
free_SE :- u24, \+ curr_lane, \+ free_E, \+ latent_collision.

0.9820513::u25.
free_SE :- u25, curr_lane, \+ free_E, \+ latent_collision.

0.4638208::u26.
free_SE :- u26, \+ curr_lane, free_E, \+ latent_collision.

0.8456311::u27.
free_SE :- u27, curr_lane, free_E, \+ latent_collision.

0.4896585::u28.
free_SE :- u28, \+ curr_lane, \+ free_E, latent_collision.

0.5238898::u29.
free_SE :- u29, curr_lane, \+ free_E, latent_collision.

0.4994166::u30.
free_SE :- u30, \+ curr_lane, free_E, latent_collision.

0.5263425::u31.
free_SE :- u31, curr_lane, free_E, latent_collision.

0.5213415::u32.
free_SW :- u32, action(change_to_left).

0.5741071::u33.
free_SW :- u33, action(change_to_right).

0.6088401::u34.
free_SW :- u34, action(cruise).

0.9759012::u35.
free_SW :- u35, action(keep).

0.9990010::u36.
free_SW :- u36, action(swerve_left).

0.9990010::u37.
free_SW :- u37, action(swerve_right).

0.5164634::u38.
free_W :- u38, action(change_to_left).

0.5830357::u39.
free_W :- u39, action(change_to_right).

0.7203628::u40.
free_W :- u40, action(cruise).

0.9197371::u41.
free_W :- u41, action(keep).

0.9990010::u42.
free_W :- u42, action(swerve_left).

0.8888889::u43.
free_W :- u43, action(swerve_right).

0.6769396::u44.
latent_collision :- u44, \+ free_W.

0.2699721::u45.
latent_collision :- u45, free_W.

