%%% Exogenous variables

0.1685849::u_action(change_to_left); 0.1728497::u_action(change_to_right); 0.4096187::u_action(cruise); 0.2467886::u_action(keep); 0.0012332::u_action(swerve_left); 0.0009249::u_action(swerve_right)
action(V) :- u_action(V).

0.5283116::u1.
curr_lane :- u1.

0.6112782::u2.
free_E :- u2, \+ curr_lane, \+ latent_collision.

0.9362519::u3.
free_E :- u3, curr_lane, \+ latent_collision.

0.4479275::u4.
free_E :- u4, \+ curr_lane, latent_collision.

0.5201485::u5.
free_E :- u5, curr_lane, latent_collision.

0.4790875::u6.
free_NE :- u6, action(change_to_left), \+ curr_lane, \+ free_E.

0.5091533::u7.
free_NE :- u7, action(change_to_right), \+ curr_lane, \+ free_E.

0.5183164::u8.
free_NE :- u8, action(cruise), \+ curr_lane, \+ free_E.

0.2577813::u9.
free_NE :- u9, action(keep), \+ curr_lane, \+ free_E.

0.5000000::u10.
free_NE :- u10, action(swerve_left), \+ curr_lane, \+ free_E.

0.5000000::u11.
free_NE :- u11, action(swerve_right), \+ curr_lane, \+ free_E.

0.4848901::u12.
free_NE :- u12, action(change_to_left), curr_lane, \+ free_E.

0.5083227::u13.
free_NE :- u13, action(change_to_right), curr_lane, \+ free_E.

0.1955307::u14.
free_NE :- u14, action(cruise), curr_lane, \+ free_E.

0.0009990::u15.
free_NE :- u15, action(keep), curr_lane, \+ free_E.

0.5000000::u16.
free_NE :- u16, action(swerve_left), curr_lane, \+ free_E.

0.5000000::u17.
free_NE :- u17, action(swerve_right), curr_lane, \+ free_E.

0.4762443::u18.
free_NE :- u18, action(change_to_left), \+ curr_lane, free_E.

0.4961735::u19.
free_NE :- u19, action(change_to_right), \+ curr_lane, free_E.

0.4403485::u20.
free_NE :- u20, action(cruise), \+ curr_lane, free_E.

0.0087912::u21.
free_NE :- u21, action(keep), \+ curr_lane, free_E.

0.9990010::u22.
free_NE :- u22, action(swerve_left), \+ curr_lane, free_E.

0.5000000::u23.
free_NE :- u23, action(swerve_right), \+ curr_lane, free_E.

0.5011364::u24.
free_NE :- u24, action(change_to_left), curr_lane, free_E.

0.5351351::u25.
free_NE :- u25, action(change_to_right), curr_lane, free_E.

0.9047210::u26.
free_NE :- u26, action(cruise), curr_lane, free_E.

0.0045132::u27.
free_NE :- u27, action(keep), curr_lane, free_E.

0.8260870::u28.
free_NE :- u28, action(swerve_left), curr_lane, free_E.

0.8333333::u29.
free_NE :- u29, action(swerve_right), curr_lane, free_E.

0.5028955::u30.
free_NW :- u30, action(change_to_left).

0.5558859::u31.
free_NW :- u31, action(change_to_right).

0.5164325::u32.
free_NW :- u32, action(cruise).

0.0204039::u33.
free_NW :- u33, action(keep).

0.9166667::u34.
free_NW :- u34, action(swerve_left).

0.5555556::u35.
free_NW :- u35, action(swerve_right).

0.7903226::u36.
free_SE :- u36, \+ curr_lane, \+ free_SW, \+ latent_collision.

0.9727155::u37.
free_SE :- u37, curr_lane, \+ free_SW, \+ latent_collision.

0.3940120::u38.
free_SE :- u38, \+ curr_lane, free_SW, \+ latent_collision.

0.7888598::u39.
free_SE :- u39, curr_lane, free_SW, \+ latent_collision.

0.5074380::u40.
free_SE :- u40, \+ curr_lane, \+ free_SW, latent_collision.

0.5064935::u41.
free_SE :- u41, curr_lane, \+ free_SW, latent_collision.

0.5061125::u42.
free_SE :- u42, \+ curr_lane, free_SW, latent_collision.

0.4883595::u43.
free_SE :- u43, curr_lane, free_SW, latent_collision.

0.5099055::u44.
free_SW :- u44, action(change_to_left).

0.5642093::u45.
free_SW :- u45, action(change_to_right).

0.6031109::u46.
free_SW :- u46, action(cruise).

0.9756402::u47.
free_SW :- u47, action(keep).

0.9583333::u48.
free_SW :- u48, action(swerve_left).

0.8333333::u49.
free_SW :- u49, action(swerve_right).

0.5138677::u50.
free_W :- u50, action(change_to_left).

0.5850178::u51.
free_W :- u51, action(change_to_right).

0.7163823::u52.
free_W :- u52, action(cruise).

0.9306683::u53.
free_W :- u53, action(keep).

0.9583333::u54.
free_W :- u54, action(swerve_left).

0.8333333::u55.
free_W :- u55, action(swerve_right).

0.6856325::u56.
latent_collision :- u56, \+ free_W.

0.2739134::u57.
latent_collision :- u57, free_W.

