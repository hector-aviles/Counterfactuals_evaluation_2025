%%% Exogenous variables

0.1688258::u_action(change_to_left); 0.1680578::u_action(change_to_right); 0.4080086::u_action(cruise); 0.2530596::u_action(keep); 0.0010241::u_action(swerve_left); 0.0010241::u_action(swerve_right)
action(V) :- u_action(V).

0.5334631::u1.
curr_lane :- u1.

0.6193804::u2.
free_E :- u2, \+ curr_lane, \+ latent_collision.

0.9353916::u3.
free_E :- u3, curr_lane, \+ latent_collision.

0.4582133::u4.
free_E :- u4, \+ curr_lane, latent_collision.

0.5158814::u5.
free_E :- u5, curr_lane, latent_collision.

0.4820669::u6.
free_NE :- u6, action(change_to_left), \+ curr_lane.

0.4950617::u7.
free_NE :- u7, action(change_to_right), \+ curr_lane.

0.4798682::u8.
free_NE :- u8, action(cruise), \+ curr_lane.

0.1100032::u9.
free_NE :- u9, action(keep), \+ curr_lane.

0.9990010::u10.
free_NE :- u10, action(swerve_left), \+ curr_lane.

0.5000000::u11.
free_NE :- u11, action(swerve_right), \+ curr_lane.

0.5006053::u12.
free_NE :- u12, action(change_to_left), curr_lane.

0.5114320::u13.
free_NE :- u13, action(change_to_right), curr_lane.

0.8326967::u14.
free_NE :- u14, action(cruise), curr_lane.

0.0021822::u15.
free_NE :- u15, action(keep), curr_lane.

0.8666667::u16.
free_NE :- u16, action(swerve_left), curr_lane.

0.9000000::u17.
free_NE :- u17, action(swerve_right), curr_lane.

0.5144070::u18.
free_NW :- u18, action(change_to_left).

0.5432663::u19.
free_NW :- u19, action(change_to_right).

0.5168173::u20.
free_NW :- u20, action(cruise).

0.0303521::u21.
free_NW :- u21, action(keep).

0.8500000::u22.
free_NW :- u22, action(swerve_left).

0.8500000::u23.
free_NW :- u23, action(swerve_right).

0.3513648::u24.
free_SE :- u24, \+ curr_lane, \+ free_E, \+ latent_collision.

0.9813520::u25.
free_SE :- u25, curr_lane, \+ free_E, \+ latent_collision.

0.4644709::u26.
free_SE :- u26, \+ curr_lane, free_E, \+ latent_collision.

0.8518757::u27.
free_SE :- u27, curr_lane, free_E, \+ latent_collision.

0.4874275::u28.
free_SE :- u28, \+ curr_lane, \+ free_E, latent_collision.

0.4920722::u29.
free_SE :- u29, curr_lane, \+ free_E, latent_collision.

0.5214408::u30.
free_SE :- u30, \+ curr_lane, free_E, latent_collision.

0.5105182::u31.
free_SE :- u31, curr_lane, free_E, latent_collision.

0.5204732::u32.
free_SW :- u32, action(change_to_left).

0.5886654::u33.
free_SW :- u33, action(change_to_right).

0.6071787::u34.
free_SW :- u34, action(cruise).

0.9757183::u35.
free_SW :- u35, action(keep).

0.9000000::u36.
free_SW :- u36, action(swerve_left).

0.9990010::u37.
free_SW :- u37, action(swerve_right).

0.5171768::u38.
free_W :- u38, action(change_to_left), \+ free_NW.

0.5310207::u39.
free_W :- u39, action(change_to_right), \+ free_NW.

0.6670130::u40.
free_W :- u40, action(cruise), \+ free_NW.

0.9424040::u41.
free_W :- u41, action(keep), \+ free_NW.

0.3333333::u42.
free_W :- u42, action(swerve_left), \+ free_NW.

0.9990010::u43.
free_W :- u43, action(swerve_right), \+ free_NW.

0.5271226::u44.
free_W :- u44, action(change_to_left), free_NW.

0.6163769::u45.
free_W :- u45, action(change_to_right), free_NW.

0.7581350::u46.
free_W :- u46, action(cruise), free_NW.

0.3866667::u47.
free_W :- u47, action(keep), free_NW.

0.9990010::u48.
free_W :- u48, action(swerve_left), free_NW.

0.9990010::u49.
free_W :- u49, action(swerve_right), free_NW.

0.6793226::u50.
latent_collision :- u50, \+ free_W.

0.2718586::u51.
latent_collision :- u51, free_W.

