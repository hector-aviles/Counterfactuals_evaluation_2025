%%% Exogenous variables

0.1692001::u_action(change_to_left); 0.1722197::u_action(change_to_right); 0.4058038::u_action(cruise); 0.2503199::u_action(keep); 0.0014842::u_action(swerve_left); 0.0009724::u_action(swerve_right)
action(V) :- u_action(V).

0.3656478::u1.
curr_lane :- u1, \+ free_SE.

0.6480375::u2.
curr_lane :- u2, free_SE.

0.5992086::u3.
free_E :- u3, \+ curr_lane, \+ latent_collision.

0.9388897::u4.
free_E :- u4, curr_lane, \+ latent_collision.

0.4401800::u5.
free_E :- u5, \+ curr_lane, latent_collision.

0.5391621::u6.
free_E :- u6, curr_lane, latent_collision.

0.4811665::u7.
free_NE :- u7, action(change_to_left), \+ curr_lane.

0.4815710::u8.
free_NE :- u8, action(change_to_right), \+ curr_lane.

0.4766320::u9.
free_NE :- u9, action(cruise), \+ curr_lane.

0.1128039::u10.
free_NE :- u10, action(keep), \+ curr_lane.

0.6666667::u11.
free_NE :- u11, action(swerve_left), \+ curr_lane.

0.5000000::u12.
free_NE :- u12, action(swerve_right), \+ curr_lane.

0.5078313::u13.
free_NE :- u13, action(change_to_left), curr_lane.

0.5181287::u14.
free_NE :- u14, action(change_to_right), curr_lane.

0.8356583::u15.
free_NE :- u15, action(cruise), curr_lane.

0.0033223::u16.
free_NE :- u16, action(keep), curr_lane.

0.8076923::u17.
free_NE :- u17, action(swerve_left), curr_lane.

0.8947368::u18.
free_NE :- u18, action(swerve_right), curr_lane.

0.4996975::u19.
free_NW :- u19, action(change_to_left).

0.5545319::u20.
free_NW :- u20, action(change_to_right).

0.5257914::u21.
free_NW :- u21, action(cruise).

0.0288285::u22.
free_NW :- u22, action(keep).

0.9990010::u23.
free_NW :- u23, action(swerve_left).

0.8421053::u24.
free_NW :- u24, action(swerve_right).

0.9570945::u25.
free_SE :- u25, \+ free_SW, \+ latent_collision.

0.5694849::u26.
free_SE :- u26, free_SW, \+ latent_collision.

0.5151106::u27.
free_SE :- u27, \+ free_SW, latent_collision.

0.5093231::u28.
free_SE :- u28, free_SW, latent_collision.

0.5069570::u29.
free_SW :- u29, action(change_to_left).

0.5720654::u30.
free_SW :- u30, action(change_to_right).

0.6002018::u31.
free_SW :- u31, action(cruise).

0.9754651::u32.
free_SW :- u32, action(keep).

0.9990010::u33.
free_SW :- u33, action(swerve_left).

0.8421053::u34.
free_SW :- u34, action(swerve_right).

0.5356711::u35.
free_W :- u35, action(change_to_left), \+ free_NW.

0.5330220::u36.
free_W :- u36, action(change_to_right), \+ free_NW.

0.6619681::u37.
free_W :- u37, action(cruise), \+ free_NW.

0.9370526::u38.
free_W :- u38, action(keep), \+ free_NW.

0.5000000::u39.
free_W :- u39, action(swerve_left), \+ free_NW.

0.3333333::u40.
free_W :- u40, action(swerve_right), \+ free_NW.

0.5169492::u41.
free_W :- u41, action(change_to_left), free_NW.

0.6200429::u42.
free_W :- u42, action(change_to_right), free_NW.

0.7637323::u43.
free_W :- u43, action(cruise), free_NW.

0.4539007::u44.
free_W :- u44, action(keep), free_NW.

0.9990010::u45.
free_W :- u45, action(swerve_left), free_NW.

0.9990010::u46.
free_W :- u46, action(swerve_right), free_NW.

0.6817615::u47.
latent_collision :- u47, \+ free_W.

0.2725772::u48.
latent_collision :- u48, free_W.

