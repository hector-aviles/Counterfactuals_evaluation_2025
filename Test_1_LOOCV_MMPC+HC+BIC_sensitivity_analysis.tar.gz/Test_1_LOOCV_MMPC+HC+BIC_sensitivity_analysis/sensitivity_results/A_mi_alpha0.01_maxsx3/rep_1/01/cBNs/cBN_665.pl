%%% Exogenous variables

0.1693594::u_action(change_to_left); 0.1680259::u_action(change_to_right); 0.4085244::u_action(cruise); 0.2515259::u_action(keep); 0.0016926::u_action(swerve_left); 0.0008719::u_action(swerve_right)
action(V) :- u_action(V).

0.5233626::u1.
curr_lane :- u1.

0.6089850::u2.
free_E :- u2, \+ curr_lane, \+ latent_collision.

0.9363525::u3.
free_E :- u3, curr_lane, \+ latent_collision.

0.4456746::u4.
free_E :- u4, \+ curr_lane, latent_collision.

0.5338059::u5.
free_E :- u5, curr_lane, latent_collision.

0.5083285::u6.
free_NE :- u6, action(change_to_left), \+ curr_lane.

0.5105985::u7.
free_NE :- u7, action(change_to_right), \+ curr_lane.

0.4992801::u8.
free_NE :- u8, action(cruise), \+ curr_lane.

0.1112868::u9.
free_NE :- u9, action(keep), \+ curr_lane.

0.5000000::u10.
free_NE :- u10, action(swerve_left), \+ curr_lane.

0.9990010::u11.
free_NE :- u11, action(swerve_right), \+ curr_lane.

0.5169763::u12.
free_NE :- u12, action(change_to_left), curr_lane.

0.5364833::u13.
free_NE :- u13, action(change_to_right), curr_lane.

0.8411413::u14.
free_NE :- u14, action(cruise), curr_lane.

0.0034463::u15.
free_NE :- u15, action(keep), curr_lane.

0.8148148::u16.
free_NE :- u16, action(swerve_left), curr_lane.

0.7500000::u17.
free_NE :- u17, action(swerve_right), curr_lane.

0.5042399::u18.
free_NW :- u18, action(change_to_left).

0.5509768::u19.
free_NW :- u19, action(change_to_right).

0.5345888::u20.
free_NW :- u20, action(cruise).

0.0314029::u21.
free_NW :- u21, action(keep).

0.9393939::u22.
free_NW :- u22, action(swerve_left).

0.8235294::u23.
free_NW :- u23, action(swerve_right).

0.3371158::u24.
free_SE :- u24, \+ curr_lane, \+ free_E, \+ latent_collision.

0.9807692::u25.
free_SE :- u25, curr_lane, \+ free_E, \+ latent_collision.

0.4757134::u26.
free_SE :- u26, \+ curr_lane, free_E, \+ latent_collision.

0.8424837::u27.
free_SE :- u27, curr_lane, free_E, \+ latent_collision.

0.5006967::u28.
free_SE :- u28, \+ curr_lane, \+ free_E, latent_collision.

0.4818713::u29.
free_SE :- u29, curr_lane, \+ free_E, latent_collision.

0.5332178::u30.
free_SE :- u30, \+ curr_lane, free_E, latent_collision.

0.5173647::u31.
free_SE :- u31, curr_lane, free_E, latent_collision.

0.5039370::u32.
free_SW :- u32, action(change_to_left).

0.5674603::u33.
free_SW :- u33, action(change_to_right).

0.6001255::u34.
free_SW :- u34, action(cruise).

0.9751223::u35.
free_SW :- u35, action(keep).

0.9696970::u36.
free_SW :- u36, action(swerve_left).

0.9411765::u37.
free_SW :- u37, action(swerve_right).

0.5155773::u38.
free_W :- u38, action(change_to_left), \+ free_NW.

0.5526852::u39.
free_W :- u39, action(change_to_right), \+ free_NW.

0.6636094::u40.
free_W :- u40, action(cruise), \+ free_NW.

0.9446316::u41.
free_W :- u41, action(keep), \+ free_NW.

0.5000000::u42.
free_W :- u42, action(swerve_left), \+ free_NW.

0.6666667::u43.
free_W :- u43, action(swerve_right), \+ free_NW.

0.5231231::u44.
free_W :- u44, action(change_to_left), free_NW.

0.6188366::u45.
free_W :- u45, action(change_to_right), free_NW.

0.7698450::u46.
free_W :- u46, action(cruise), free_NW.

0.4090909::u47.
free_W :- u47, action(keep), free_NW.

0.9990010::u48.
free_W :- u48, action(swerve_left), free_NW.

0.9990010::u49.
free_W :- u49, action(swerve_right), free_NW.

0.6841914::u50.
latent_collision :- u50, \+ free_W.

0.2702239::u51.
latent_collision :- u51, free_W.

