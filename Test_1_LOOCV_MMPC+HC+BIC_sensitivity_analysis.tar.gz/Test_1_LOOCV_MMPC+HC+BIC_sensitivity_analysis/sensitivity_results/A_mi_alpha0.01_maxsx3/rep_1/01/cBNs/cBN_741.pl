%%% Exogenous variables

0.1683315::u_action(change_to_left); 0.1667435::u_action(change_to_right); 0.4084832::u_action(cruise); 0.2538804::u_action(keep); 0.0017417::u_action(swerve_left); 0.0008196::u_action(swerve_right)
action(V) :- u_action(V).

0.5371139::u1.
curr_lane :- u1.

0.6117779::u2.
free_E :- u2, \+ curr_lane, \+ latent_collision.

0.9356325::u3.
free_E :- u3, curr_lane, \+ latent_collision.

0.4565335::u4.
free_E :- u4, \+ curr_lane, latent_collision.

0.5255455::u5.
free_E :- u5, curr_lane, latent_collision.

0.4978593::u6.
free_NE :- u6, action(change_to_left), \+ curr_lane.

0.5182161::u7.
free_NE :- u7, action(change_to_right), \+ curr_lane.

0.4799563::u8.
free_NE :- u8, action(cruise), \+ curr_lane.

0.1098757::u9.
free_NE :- u9, action(keep), \+ curr_lane.

0.5714286::u10.
free_NE :- u10, action(swerve_left), \+ curr_lane.

0.5000000::u11.
free_NE :- u11, action(swerve_right), \+ curr_lane.

0.5051484::u12.
free_NE :- u12, action(change_to_left), curr_lane.

0.5327721::u13.
free_NE :- u13, action(change_to_right), curr_lane.

0.8307839::u14.
free_NE :- u14, action(cruise), curr_lane.

0.0042150::u15.
free_NE :- u15, action(keep), curr_lane.

0.9990010::u16.
free_NE :- u16, action(swerve_left), curr_lane.

0.8750000::u17.
free_NE :- u17, action(swerve_right), curr_lane.

0.5170420::u18.
free_NW :- u18, action(change_to_left).

0.5385561::u19.
free_NW :- u19, action(change_to_right).

0.5229496::u20.
free_NW :- u20, action(cruise).

0.0288539::u21.
free_NW :- u21, action(keep).

0.9990010::u22.
free_NW :- u22, action(swerve_left).

0.6875000::u23.
free_NW :- u23, action(swerve_right).

0.8006993::u24.
free_SE :- u24, \+ curr_lane, \+ free_SW, \+ latent_collision.

0.9709898::u25.
free_SE :- u25, curr_lane, \+ free_SW, \+ latent_collision.

0.4088387::u26.
free_SE :- u26, \+ curr_lane, free_SW, \+ latent_collision.

0.7812001::u27.
free_SE :- u27, curr_lane, free_SW, \+ latent_collision.

0.5141243::u28.
free_SE :- u28, \+ curr_lane, \+ free_SW, latent_collision.

0.5069716::u29.
free_SE :- u29, curr_lane, \+ free_SW, latent_collision.

0.5144778::u30.
free_SE :- u30, \+ curr_lane, free_SW, latent_collision.

0.4966921::u31.
free_SE :- u31, curr_lane, free_SW, latent_collision.

0.5085210::u32.
free_SW :- u32, action(change_to_left).

0.5932412::u33.
free_SW :- u33, action(change_to_right).

0.6078505::u34.
free_SW :- u34, action(cruise).

0.9747780::u35.
free_SW :- u35, action(keep).

0.9705882::u36.
free_SW :- u36, action(swerve_left).

0.9375000::u37.
free_SW :- u37, action(swerve_right).

0.5106512::u38.
free_W :- u38, action(change_to_left).

0.5904762::u39.
free_W :- u39, action(change_to_right).

0.7098069::u40.
free_W :- u40, action(cruise).

0.9192897::u41.
free_W :- u41, action(keep).

0.9990010::u42.
free_W :- u42, action(swerve_left).

0.9375000::u43.
free_W :- u43, action(swerve_right).

0.6787482::u44.
latent_collision :- u44, \+ free_W.

0.2613054::u45.
latent_collision :- u45, free_W.

