%%% Exogenous variables

0.1684384::u_action(change_to_left); 0.1700817::u_action(change_to_right); 0.4052791::u_action(cruise); 0.2529143::u_action(keep); 0.0022082::u_action(swerve_left); 0.0010784::u_action(swerve_right)
action(V) :- u_action(V).

0.5353566::u1.
curr_lane :- u1.

0.6148496::u2.
free_E :- u2, \+ curr_lane, \+ latent_collision.

0.9384218::u3.
free_E :- u3, curr_lane, \+ latent_collision.

0.4699571::u4.
free_E :- u4, \+ curr_lane, latent_collision.

0.5272869::u5.
free_E :- u5, curr_lane, latent_collision.

0.4830508::u6.
free_NE :- u6, action(change_to_left), \+ curr_lane.

0.4846743::u7.
free_NE :- u7, action(change_to_right), \+ curr_lane.

0.4792766::u8.
free_NE :- u8, action(cruise), \+ curr_lane.

0.1206189::u9.
free_NE :- u9, action(keep), \+ curr_lane.

0.6666667::u10.
free_NE :- u10, action(swerve_left), \+ curr_lane.

0.5000000::u11.
free_NE :- u11, action(swerve_right), \+ curr_lane.

0.5049140::u12.
free_NE :- u12, action(change_to_left), curr_lane.

0.5486827::u13.
free_NE :- u13, action(change_to_right), curr_lane.

0.8318060::u14.
free_NE :- u14, action(cruise), curr_lane.

0.0039818::u15.
free_NE :- u15, action(keep), curr_lane.

0.8529412::u16.
free_NE :- u16, action(swerve_left), curr_lane.

0.8095238::u17.
free_NE :- u17, action(swerve_right), curr_lane.

0.5012195::u18.
free_NW :- u18, action(change_to_left).

0.5443841::u19.
free_NW :- u19, action(change_to_right).

0.5295236::u20.
free_NW :- u20, action(cruise).

0.0316751::u21.
free_NW :- u21, action(keep).

0.9534884::u22.
free_NW :- u22, action(swerve_left).

0.7142857::u23.
free_NW :- u23, action(swerve_right).

0.3265007::u24.
free_SE :- u24, \+ curr_lane, \+ free_E, \+ latent_collision.

0.9827160::u25.
free_SE :- u25, curr_lane, \+ free_E, \+ latent_collision.

0.4695812::u26.
free_SE :- u26, \+ curr_lane, free_E, \+ latent_collision.

0.8376539::u27.
free_SE :- u27, curr_lane, free_E, \+ latent_collision.

0.4863360::u28.
free_SE :- u28, \+ curr_lane, \+ free_E, latent_collision.

0.5024739::u29.
free_SE :- u29, curr_lane, \+ free_E, latent_collision.

0.5313927::u30.
free_SE :- u30, \+ curr_lane, free_E, latent_collision.

0.5012321::u31.
free_SE :- u31, curr_lane, free_E, latent_collision.

0.5277439::u32.
free_SW :- u32, action(change_to_left).

0.5733696::u33.
free_SW :- u33, action(change_to_right).

0.5997212::u34.
free_SW :- u34, action(cruise).

0.9782741::u35.
free_SW :- u35, action(keep).

0.9767442::u36.
free_SW :- u36, action(swerve_left).

0.8095238::u37.
free_SW :- u37, action(swerve_right).

0.5070122::u38.
free_W :- u38, action(change_to_left).

0.5682367::u39.
free_W :- u39, action(change_to_right).

0.7245312::u40.
free_W :- u40, action(cruise).

0.9230457::u41.
free_W :- u41, action(keep).

0.9534884::u42.
free_W :- u42, action(swerve_left).

0.8095238::u43.
free_W :- u43, action(swerve_right).

0.6851588::u44.
latent_collision :- u44, \+ free_W.

0.2693445::u45.
latent_collision :- u45, free_W.

