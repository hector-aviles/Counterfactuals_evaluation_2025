%%% Exogenous variables

0.1675208::u_action(change_to_left); 0.1710054::u_action(change_to_right); 0.4031977::u_action(cruise); 0.2558163::u_action(keep); 0.0017423::u_action(swerve_left); 0.0007174::u_action(swerve_right)
action(V) :- u_action(V).

0.5238290::u1.
curr_lane :- u1.

0.6083712::u2.
free_E :- u2, \+ curr_lane, \+ latent_collision.

0.9379449::u3.
free_E :- u3, curr_lane, \+ latent_collision.

0.4421912::u4.
free_E :- u4, \+ curr_lane, latent_collision.

0.5276596::u5.
free_E :- u5, curr_lane, latent_collision.

0.4814815::u6.
free_NE :- u6, action(change_to_left), \+ curr_lane.

0.5018072::u7.
free_NE :- u7, action(change_to_right), \+ curr_lane.

0.4898771::u8.
free_NE :- u8, action(cruise), \+ curr_lane.

0.1173358::u9.
free_NE :- u9, action(keep), \+ curr_lane.

0.6666667::u10.
free_NE :- u10, action(swerve_left), \+ curr_lane.

0.5000000::u11.
free_NE :- u11, action(swerve_right), \+ curr_lane.

0.4919852::u12.
free_NE :- u12, action(change_to_left), curr_lane.

0.5152057::u13.
free_NE :- u13, action(change_to_right), curr_lane.

0.8316347::u14.
free_NE :- u14, action(cruise), curr_lane.

0.0022485::u15.
free_NE :- u15, action(keep), curr_lane.

0.9285714::u16.
free_NE :- u16, action(swerve_left), curr_lane.

0.8571429::u17.
free_NE :- u17, action(swerve_right), curr_lane.

0.5218721::u18.
free_NW :- u18, action(change_to_left).

0.5501948::u19.
free_NW :- u19, action(change_to_right).

0.5285968::u20.
free_NW :- u20, action(cruise).

0.0294471::u21.
free_NW :- u21, action(keep).

0.9705882::u22.
free_NW :- u22, action(swerve_left).

0.8571429::u23.
free_NW :- u23, action(swerve_right).

0.3499071::u24.
free_SE :- u24, \+ curr_lane, \+ free_E, \+ latent_collision.

0.9775561::u25.
free_SE :- u25, curr_lane, \+ free_E, \+ latent_collision.

0.4663476::u26.
free_SE :- u26, \+ curr_lane, free_E, \+ latent_collision.

0.8350107::u27.
free_SE :- u27, curr_lane, free_E, \+ latent_collision.

0.5047214::u28.
free_SE :- u28, \+ curr_lane, \+ free_E, latent_collision.

0.4740991::u29.
free_SE :- u29, curr_lane, \+ free_E, latent_collision.

0.4627755::u30.
free_SE :- u30, \+ curr_lane, free_E, latent_collision.

0.5126008::u31.
free_SE :- u31, curr_lane, free_E, latent_collision.

0.5148363::u32.
free_SW :- u32, action(change_to_left).

0.5894516::u33.
free_SW :- u33, action(change_to_right).

0.6042196::u34.
free_SW :- u34, action(cruise).

0.9737580::u35.
free_SW :- u35, action(keep).

0.9990010::u36.
free_SW :- u36, action(swerve_left).

0.9285714::u37.
free_SW :- u37, action(swerve_right).

0.5212603::u38.
free_W :- u38, action(change_to_left).

0.5795625::u39.
free_W :- u39, action(change_to_right).

0.7145399::u40.
free_W :- u40, action(cruise).

0.9256811::u41.
free_W :- u41, action(keep).

0.9705882::u42.
free_W :- u42, action(swerve_left).

0.9285714::u43.
free_W :- u43, action(swerve_right).

0.6839091::u44.
latent_collision :- u44, \+ free_W.

0.2682559::u45.
latent_collision :- u45, free_W.

