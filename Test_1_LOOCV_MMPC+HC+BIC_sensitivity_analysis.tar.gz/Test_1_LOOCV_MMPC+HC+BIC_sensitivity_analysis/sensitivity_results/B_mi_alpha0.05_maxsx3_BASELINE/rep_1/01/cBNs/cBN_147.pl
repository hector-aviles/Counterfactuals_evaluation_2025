%%% Exogenous variables

0.1702880::u_action(change_to_left); 0.1740289::u_action(change_to_right); 0.4000717::u_action(cruise); 0.2527929::u_action(keep); 0.0021523::u_action(swerve_left); 0.0006662::u_action(swerve_right)
action(V) :- u_action(V).

0.3632166::u1.
curr_lane :- u1, \+ free_SE.

0.6451310::u2.
curr_lane :- u2, free_SE.

0.6138447::u3.
free_E :- u3, \+ curr_lane, \+ latent_collision.

0.9390747::u4.
free_E :- u4, curr_lane, \+ latent_collision.

0.4415034::u5.
free_E :- u5, \+ curr_lane, latent_collision.

0.5281104::u6.
free_E :- u6, curr_lane, latent_collision.

0.5130332::u7.
free_NE :- u7, action(change_to_left), \+ curr_lane, \+ free_E.

0.5017964::u8.
free_NE :- u8, action(change_to_right), \+ curr_lane, \+ free_E.

0.4971797::u9.
free_NE :- u9, action(cruise), \+ curr_lane, \+ free_E.

0.2709832::u10.
free_NE :- u10, action(keep), \+ curr_lane, \+ free_E.

0.9990010::u11.
free_NE :- u11, action(swerve_left), \+ curr_lane, \+ free_E.

0.5000000::u12.
free_NE :- u12, action(swerve_right), \+ curr_lane, \+ free_E.

0.5047619::u13.
free_NE :- u13, action(change_to_left), curr_lane, \+ free_E.

0.5255474::u14.
free_NE :- u14, action(change_to_right), curr_lane, \+ free_E.

0.2117400::u15.
free_NE :- u15, action(cruise), curr_lane, \+ free_E.

0.0009990::u16.
free_NE :- u16, action(keep), curr_lane, \+ free_E.

0.5000000::u17.
free_NE :- u17, action(swerve_left), curr_lane, \+ free_E.

0.5000000::u18.
free_NE :- u18, action(swerve_right), curr_lane, \+ free_E.

0.4598802::u19.
free_NE :- u19, action(change_to_left), \+ curr_lane, free_E.

0.4532828::u20.
free_NE :- u20, action(change_to_right), \+ curr_lane, free_E.

0.4433357::u21.
free_NE :- u21, action(cruise), \+ curr_lane, free_E.

0.0167627::u22.
free_NE :- u22, action(keep), \+ curr_lane, free_E.

0.7000000::u23.
free_NE :- u23, action(swerve_left), \+ curr_lane, free_E.

0.5000000::u24.
free_NE :- u24, action(swerve_right), \+ curr_lane, free_E.

0.4895490::u25.
free_NE :- u25, action(change_to_left), curr_lane, free_E.

0.5607181::u26.
free_NE :- u26, action(change_to_right), curr_lane, free_E.

0.9058899::u27.
free_NE :- u27, action(cruise), curr_lane, free_E.

0.0050157::u28.
free_NE :- u28, action(keep), curr_lane, free_E.

0.8620690::u29.
free_NE :- u29, action(swerve_left), curr_lane, free_E.

0.8461538::u30.
free_NE :- u30, action(swerve_right), curr_lane, free_E.

0.5257298::u31.
free_NW :- u31, action(change_to_left).

0.5368080::u32.
free_NW :- u32, action(change_to_right).

0.5302933::u33.
free_NW :- u33, action(cruise).

0.0300020::u34.
free_NW :- u34, action(keep).

0.9523810::u35.
free_NW :- u35, action(swerve_left).

0.6923077::u36.
free_NW :- u36, action(swerve_right).

0.9540274::u37.
free_SE :- u37, \+ free_SW, \+ latent_collision.

0.5742820::u38.
free_SE :- u38, free_SW, \+ latent_collision.

0.5243969::u39.
free_SE :- u39, \+ free_SW, latent_collision.

0.4969789::u40.
free_SE :- u40, free_SW, latent_collision.

0.5109841::u41.
free_SW :- u41, action(change_to_left).

0.5697880::u42.
free_SW :- u42, action(change_to_right).

0.6077879::u43.
free_SW :- u43, action(cruise).

0.9738496::u44.
free_SW :- u44, action(keep).

0.9761905::u45.
free_SW :- u45, action(swerve_left).

0.8461538::u46.
free_SW :- u46, action(swerve_right).

0.5437817::u47.
free_W :- u47, action(change_to_left), \+ free_NW.

0.5422759::u48.
free_W :- u48, action(change_to_right), \+ free_NW.

0.6716662::u49.
free_W :- u49, action(cruise), \+ free_NW.

0.9404389::u50.
free_W :- u50, action(keep), \+ free_NW.

0.9990010::u51.
free_W :- u51, action(swerve_left), \+ free_NW.

0.7500000::u52.
free_W :- u52, action(swerve_right), \+ free_NW.

0.4939897::u53.
free_W :- u53, action(change_to_left), free_NW.

0.6275370::u54.
free_W :- u54, action(change_to_right), free_NW.

0.7690821::u55.
free_W :- u55, action(cruise), free_NW.

0.4121622::u56.
free_W :- u56, action(keep), free_NW.

0.9750000::u57.
free_W :- u57, action(swerve_left), free_NW.

0.9990010::u58.
free_W :- u58, action(swerve_right), free_NW.

0.6790101::u59.
latent_collision :- u59, \+ free_W.

0.2762198::u60.
latent_collision :- u60, free_W.

