%%% Exogenous variables

0.1686926::u_action(change_to_left); 0.1705391::u_action(change_to_right); 0.4084731::u_action(cruise); 0.2497820::u_action(keep); 0.0016413::u_action(swerve_left); 0.0008719::u_action(swerve_right)
action(V) :- u_action(V).

0.5252603::u1.
curr_lane :- u1.

0.5977674::u2.
free_E :- u2, \+ curr_lane, \+ latent_collision.

0.9385277::u3.
free_E :- u3, curr_lane, \+ latent_collision.

0.4529760::u4.
free_E :- u4, \+ curr_lane, latent_collision.

0.5447242::u5.
free_E :- u5, curr_lane, latent_collision.

0.4911557::u6.
free_NE :- u6, action(change_to_left), \+ curr_lane.

0.4963459::u7.
free_NE :- u7, action(change_to_right), \+ curr_lane.

0.4839732::u8.
free_NE :- u8, action(cruise), \+ curr_lane.

0.1184896::u9.
free_NE :- u9, action(keep), \+ curr_lane.

0.4285714::u10.
free_NE :- u10, action(swerve_left), \+ curr_lane.

0.5000000::u11.
free_NE :- u11, action(swerve_right), \+ curr_lane.

0.5065913::u12.
free_NE :- u12, action(change_to_left), curr_lane.

0.5151515::u13.
free_NE :- u13, action(change_to_right), curr_lane.

0.8312195::u14.
free_NE :- u14, action(cruise), curr_lane.

0.0033370::u15.
free_NE :- u15, action(keep), curr_lane.

0.9200000::u16.
free_NE :- u16, action(swerve_left), curr_lane.

0.8823529::u17.
free_NE :- u17, action(swerve_right), curr_lane.

0.5241715::u18.
free_NW :- u18, action(change_to_left).

0.5530827::u19.
free_NW :- u19, action(change_to_right).

0.5302612::u20.
free_NW :- u20, action(cruise).

0.0293634::u21.
free_NW :- u21, action(keep).

0.9375000::u22.
free_NW :- u22, action(swerve_left).

0.8823529::u23.
free_NW :- u23, action(swerve_right).

0.7770035::u24.
free_SE :- u24, \+ curr_lane, \+ free_SW, \+ latent_collision.

0.9696837::u25.
free_SE :- u25, curr_lane, \+ free_SW, \+ latent_collision.

0.4091981::u26.
free_SE :- u26, \+ curr_lane, free_SW, \+ latent_collision.

0.7924840::u27.
free_SE :- u27, curr_lane, free_SW, \+ latent_collision.

0.5248152::u28.
free_SE :- u28, \+ curr_lane, \+ free_SW, latent_collision.

0.4918494::u29.
free_SE :- u29, curr_lane, \+ free_SW, latent_collision.

0.4952189::u30.
free_SE :- u30, \+ curr_lane, free_SW, latent_collision.

0.4895141::u31.
free_SE :- u31, curr_lane, free_SW, latent_collision.

0.5059289::u32.
free_SW :- u32, action(change_to_left).

0.5807519::u33.
free_SW :- u33, action(change_to_right).

0.6106228::u34.
free_SW :- u34, action(cruise).

0.9770021::u35.
free_SW :- u35, action(keep).

0.9990010::u36.
free_SW :- u36, action(swerve_left).

0.7647059::u37.
free_SW :- u37, action(swerve_right).

0.5065369::u38.
free_W :- u38, action(change_to_left).

0.5672180::u39.
free_W :- u39, action(change_to_right).

0.7144651::u40.
free_W :- u40, action(cruise).

0.9324435::u41.
free_W :- u41, action(keep).

0.9687500::u42.
free_W :- u42, action(swerve_left).

0.9990010::u43.
free_W :- u43, action(swerve_right).

0.6909636::u44.
latent_collision :- u44, \+ free_W.

0.2675150::u45.
latent_collision :- u45, free_W.

