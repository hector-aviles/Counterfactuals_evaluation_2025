%%% Exogenous variables

0.1728685::u_action(change_to_left); 0.1663770::u_action(change_to_right); 0.4070742::u_action(cruise); 0.2511756::u_action(keep); 0.0013801::u_action(swerve_left); 0.0011245::u_action(swerve_right)
action(V) :- u_action(V).

0.5349622::u1.
curr_lane :- u1.

0.5969093::u2.
free_E :- u2, \+ curr_lane, \+ latent_collision.

0.9347498::u3.
free_E :- u3, curr_lane, \+ latent_collision.

0.4459351::u4.
free_E :- u4, \+ curr_lane, latent_collision.

0.5381201::u5.
free_E :- u5, curr_lane, latent_collision.

0.4746571::u6.
free_NE :- u6, action(change_to_left), \+ curr_lane.

0.5012674::u7.
free_NE :- u7, action(change_to_right), \+ curr_lane.

0.4842375::u8.
free_NE :- u8, action(cruise), \+ curr_lane.

0.1211829::u9.
free_NE :- u9, action(keep), \+ curr_lane.

0.7500000::u10.
free_NE :- u10, action(swerve_left), \+ curr_lane.

0.5000000::u11.
free_NE :- u11, action(swerve_right), \+ curr_lane.

0.4991202::u12.
free_NE :- u12, action(change_to_left), curr_lane.

0.5253429::u13.
free_NE :- u13, action(change_to_right), curr_lane.

0.8342246::u14.
free_NE :- u14, action(cruise), curr_lane.

0.0049917::u15.
free_NE :- u15, action(keep), curr_lane.

0.9130435::u16.
free_NE :- u16, action(swerve_left), curr_lane.

0.9090909::u17.
free_NE :- u17, action(swerve_right), curr_lane.

0.5038439::u18.
free_NW :- u18, action(change_to_left).

0.5351767::u19.
free_NW :- u19, action(change_to_right).

0.5306379::u20.
free_NW :- u20, action(cruise).

0.0370370::u21.
free_NW :- u21, action(keep).

0.9259259::u22.
free_NW :- u22, action(swerve_left).

0.7727273::u23.
free_NW :- u23, action(swerve_right).

0.3593533::u24.
free_SE :- u24, \+ curr_lane, \+ free_E, \+ latent_collision.

0.9930716::u25.
free_SE :- u25, curr_lane, \+ free_E, \+ latent_collision.

0.4713038::u26.
free_SE :- u26, \+ curr_lane, free_E, \+ latent_collision.

0.8481380::u27.
free_SE :- u27, curr_lane, free_E, \+ latent_collision.

0.4871671::u28.
free_SE :- u28, \+ curr_lane, \+ free_E, latent_collision.

0.5076314::u29.
free_SE :- u29, curr_lane, \+ free_E, latent_collision.

0.5078219::u30.
free_SE :- u30, \+ curr_lane, free_E, latent_collision.

0.5138282::u31.
free_SE :- u31, curr_lane, free_E, latent_collision.

0.5201064::u32.
free_SW :- u32, action(change_to_left).

0.5680492::u33.
free_SW :- u33, action(change_to_right).

0.6037167::u34.
free_SW :- u34, action(cruise).

0.9770045::u35.
free_SW :- u35, action(keep).

0.9629630::u36.
free_SW :- u36, action(swerve_left).

0.8636364::u37.
free_SW :- u37, action(swerve_right).

0.5056180::u38.
free_W :- u38, action(change_to_left).

0.5711214::u39.
free_W :- u39, action(change_to_right).

0.7189854::u40.
free_W :- u40, action(cruise).

0.9275539::u41.
free_W :- u41, action(keep).

0.9990010::u42.
free_W :- u42, action(swerve_left).

0.9545455::u43.
free_W :- u43, action(swerve_right).

0.6830302::u44.
latent_collision :- u44, \+ free_W.

0.2653766::u45.
latent_collision :- u45, free_W.

