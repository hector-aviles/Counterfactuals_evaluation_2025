%%% Exogenous variables

0.1662396::u_action(change_to_left); 0.1744389::u_action(change_to_right); 0.4067336::u_action(cruise); 0.2499231::u_action(keep); 0.0017936::u_action(swerve_left); 0.0008712::u_action(swerve_right)
action(V) :- u_action(V).

0.3526181::u1.
curr_lane :- u1, \+ free_SE.

0.6483225::u2.
curr_lane :- u2, free_SE.

0.6087772::u3.
free_E :- u3, \+ curr_lane, \+ latent_collision.

0.9371886::u4.
free_E :- u4, curr_lane, \+ latent_collision.

0.4490380::u5.
free_E :- u5, \+ curr_lane, latent_collision.

0.5119849::u6.
free_E :- u6, curr_lane, latent_collision.

0.5270108::u7.
free_NE :- u7, action(change_to_left), \+ curr_lane, \+ free_E.

0.4782097::u8.
free_NE :- u8, action(change_to_right), \+ curr_lane, \+ free_E.

0.5134921::u9.
free_NE :- u9, action(cruise), \+ curr_lane, \+ free_E.

0.2646593::u10.
free_NE :- u10, action(keep), \+ curr_lane, \+ free_E.

0.9990010::u11.
free_NE :- u11, action(swerve_left), \+ curr_lane, \+ free_E.

0.5000000::u12.
free_NE :- u12, action(swerve_right), \+ curr_lane, \+ free_E.

0.4829545::u13.
free_NE :- u13, action(change_to_left), curr_lane, \+ free_E.

0.4904988::u14.
free_NE :- u14, action(change_to_right), curr_lane, \+ free_E.

0.1867220::u15.
free_NE :- u15, action(cruise), curr_lane, \+ free_E.

0.0009990::u16.
free_NE :- u16, action(keep), curr_lane, \+ free_E.

0.5000000::u17.
free_NE :- u17, action(swerve_left), curr_lane, \+ free_E.

0.5000000::u18.
free_NE :- u18, action(swerve_right), curr_lane, \+ free_E.

0.4729242::u19.
free_NE :- u19, action(change_to_left), \+ curr_lane, free_E.

0.4780600::u20.
free_NE :- u20, action(change_to_right), \+ curr_lane, free_E.

0.4151329::u21.
free_NE :- u21, action(cruise), \+ curr_lane, free_E.

0.0110865::u22.
free_NE :- u22, action(keep), \+ curr_lane, free_E.

0.9990010::u23.
free_NE :- u23, action(swerve_left), \+ curr_lane, free_E.

0.5000000::u24.
free_NE :- u24, action(swerve_right), \+ curr_lane, free_E.

0.5353881::u25.
free_NE :- u25, action(change_to_left), curr_lane, free_E.

0.5548996::u26.
free_NE :- u26, action(change_to_right), curr_lane, free_E.

0.9033418::u27.
free_NE :- u27, action(cruise), curr_lane, free_E.

0.0043451::u28.
free_NE :- u28, action(keep), curr_lane, free_E.

0.8620690::u29.
free_NE :- u29, action(swerve_left), curr_lane, free_E.

0.8823529::u30.
free_NE :- u30, action(swerve_right), curr_lane, free_E.

0.5095561::u31.
free_NW :- u31, action(change_to_left).

0.5514101::u32.
free_NW :- u32, action(change_to_right).

0.5289152::u33.
free_NW :- u33, action(cruise).

0.0330121::u34.
free_NW :- u34, action(keep).

0.9990010::u35.
free_NW :- u35, action(swerve_left).

0.8235294::u36.
free_NW :- u36, action(swerve_right).

0.9504950::u37.
free_SE :- u37, \+ free_SW, \+ latent_collision.

0.5696792::u38.
free_SE :- u38, free_SW, \+ latent_collision.

0.5255515::u39.
free_SE :- u39, \+ free_SW, latent_collision.

0.4909502::u40.
free_SE :- u40, free_SW, latent_collision.

0.5292848::u41.
free_SW :- u41, action(change_to_left).

0.5819624::u42.
free_SW :- u42, action(change_to_right).

0.5936752::u43.
free_SW :- u43, action(cruise).

0.9735493::u44.
free_SW :- u44, action(keep).

0.9142857::u45.
free_SW :- u45, action(swerve_left).

0.9411765::u46.
free_SW :- u46, action(swerve_right).

0.5216845::u47.
free_W :- u47, action(change_to_left), \+ free_NW.

0.5396202::u48.
free_W :- u48, action(change_to_right), \+ free_NW.

0.6659535::u49.
free_W :- u49, action(cruise), \+ free_NW.

0.9412638::u50.
free_W :- u50, action(keep), \+ free_NW.

0.5000000::u51.
free_W :- u51, action(swerve_left), \+ free_NW.

0.6666667::u52.
free_W :- u52, action(swerve_right), \+ free_NW.

0.5196612::u53.
free_W :- u53, action(change_to_left), free_NW.

0.6046883::u54.
free_W :- u54, action(change_to_right), free_NW.

0.7620295::u55.
free_W :- u55, action(cruise), free_NW.

0.4223602::u56.
free_W :- u56, action(keep), free_NW.

0.9714286::u57.
free_W :- u57, action(swerve_left), free_NW.

0.9990010::u58.
free_W :- u58, action(swerve_right), free_NW.

0.6745552::u59.
latent_collision :- u59, \+ free_W.

0.2711962::u60.
latent_collision :- u60, free_W.

