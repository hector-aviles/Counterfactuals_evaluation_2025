%%% Exogenous variables

0.1683919::u_action(change_to_left); 0.1709029::u_action(change_to_right); 0.4083735::u_action(cruise); 0.2501281::u_action(keep); 0.0013836::u_action(swerve_left); 0.0008199::u_action(swerve_right)
action(V) :- u_action(V).

0.5300297::u1.
curr_lane :- u1.

0.6111633::u2.
free_E :- u2, \+ curr_lane, \+ latent_collision.

0.9379154::u3.
free_E :- u3, curr_lane, \+ latent_collision.

0.4400000::u4.
free_E :- u4, \+ curr_lane, latent_collision.

0.5192049::u5.
free_E :- u5, curr_lane, latent_collision.

0.4700704::u6.
free_NE :- u6, action(change_to_left), \+ curr_lane.

0.5048368::u7.
free_NE :- u7, action(change_to_right), \+ curr_lane.

0.4894327::u8.
free_NE :- u8, action(cruise), \+ curr_lane.

0.1118611::u9.
free_NE :- u9, action(keep), \+ curr_lane.

0.2500000::u10.
free_NE :- u10, action(swerve_left), \+ curr_lane.

0.9990010::u11.
free_NE :- u11, action(swerve_right), \+ curr_lane.

0.5063211::u12.
free_NE :- u12, action(change_to_left), curr_lane.

0.5478882::u13.
free_NE :- u13, action(change_to_right), curr_lane.

0.8385812::u14.
free_NE :- u14, action(cruise), curr_lane.

0.0033898::u15.
free_NE :- u15, action(keep), curr_lane.

0.9565217::u16.
free_NE :- u16, action(swerve_left), curr_lane.

0.7333333::u17.
free_NE :- u17, action(swerve_right), curr_lane.

0.5109556::u18.
free_NW :- u18, action(change_to_left).

0.5511244::u19.
free_NW :- u19, action(change_to_right).

0.5291756::u20.
free_NW :- u20, action(cruise).

0.0327802::u21.
free_NW :- u21, action(keep).

0.9990010::u22.
free_NW :- u22, action(swerve_left).

0.7500000::u23.
free_NW :- u23, action(swerve_right).

0.3455776::u24.
free_SE :- u24, \+ curr_lane, \+ free_E, \+ latent_collision.

0.9781022::u25.
free_SE :- u25, curr_lane, \+ free_E, \+ latent_collision.

0.4732472::u26.
free_SE :- u26, \+ curr_lane, free_E, \+ latent_collision.

0.8440973::u27.
free_SE :- u27, curr_lane, free_E, \+ latent_collision.

0.4907236::u28.
free_SE :- u28, \+ curr_lane, \+ free_E, latent_collision.

0.4994413::u29.
free_SE :- u29, curr_lane, \+ free_E, latent_collision.

0.4864227::u30.
free_SE :- u30, \+ curr_lane, free_E, latent_collision.

0.5519917::u31.
free_SE :- u31, curr_lane, free_E, latent_collision.

0.5273889::u32.
free_SW :- u32, action(change_to_left).

0.5952024::u33.
free_SW :- u33, action(change_to_right).

0.6027105::u34.
free_SW :- u34, action(cruise).

0.9801270::u35.
free_SW :- u35, action(keep).

0.9990010::u36.
free_SW :- u36, action(swerve_left).

0.8750000::u37.
free_SW :- u37, action(swerve_right).

0.5139988::u38.
free_W :- u38, action(change_to_left).

0.5901049::u39.
free_W :- u39, action(change_to_right).

0.7200402::u40.
free_W :- u40, action(cruise).

0.9248105::u41.
free_W :- u41, action(keep).

0.9990010::u42.
free_W :- u42, action(swerve_left).

0.9375000::u43.
free_W :- u43, action(swerve_right).

0.6722991::u44.
latent_collision :- u44, \+ free_W.

0.2747473::u45.
latent_collision :- u45, free_W.

