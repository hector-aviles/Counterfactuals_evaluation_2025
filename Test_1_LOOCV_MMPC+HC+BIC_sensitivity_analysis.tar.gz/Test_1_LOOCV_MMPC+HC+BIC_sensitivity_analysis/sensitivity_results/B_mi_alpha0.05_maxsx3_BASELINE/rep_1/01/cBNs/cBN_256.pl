%%% Exogenous variables

0.1722845::u_action(change_to_left); 0.1662214::u_action(change_to_right); 0.4047374::u_action(cruise); 0.2539307::u_action(keep); 0.0020039::u_action(swerve_left); 0.0008221::u_action(swerve_right)
action(V) :- u_action(V).

0.5230706::u1.
curr_lane :- u1.

0.5372764::u2.
free_E :- u2, \+ curr_lane.

0.7897839::u3.
free_E :- u3, curr_lane.

0.4722222::u4.
free_NE :- u4, action(change_to_left), \+ curr_lane.

0.4870988::u5.
free_NE :- u5, action(change_to_right), \+ curr_lane.

0.4832727::u6.
free_NE :- u6, action(cruise), \+ curr_lane.

0.1191302::u7.
free_NE :- u7, action(keep), \+ curr_lane.

0.8333333::u8.
free_NE :- u8, action(swerve_left), \+ curr_lane.

0.5000000::u9.
free_NE :- u9, action(swerve_right), \+ curr_lane.

0.4896161::u10.
free_NE :- u10, action(change_to_left), curr_lane.

0.5425273::u11.
free_NE :- u11, action(change_to_right), curr_lane.

0.8375268::u12.
free_NE :- u12, action(cruise), curr_lane.

0.0005653::u13.
free_NE :- u13, action(keep), curr_lane.

0.8787879::u14.
free_NE :- u14, action(swerve_left), curr_lane.

0.7500000::u15.
free_NE :- u15, action(swerve_right), curr_lane.

0.5073069::u16.
free_NW :- u16, action(change_to_left).

0.5496136::u17.
free_NW :- u17, action(change_to_right).

0.5249460::u18.
free_NW :- u18, action(cruise).

0.0198300::u19.
free_NW :- u19, action(keep).

0.9230769::u20.
free_NW :- u20, action(swerve_left).

0.7500000::u21.
free_NW :- u21, action(swerve_right).

0.4583064::u22.
free_SE :- u22, \+ curr_lane.

0.7270138::u23.
free_SE :- u23, curr_lane.

0.5276989::u24.
free_SW :- u24, action(change_to_left), \+ free_SE.

0.6132404::u25.
free_SW :- u25, action(change_to_right), \+ free_SE.

0.7652495::u26.
free_SW :- u26, action(cruise), \+ free_SE.

0.9976096::u27.
free_SW :- u27, action(keep), \+ free_SE.

0.9990010::u28.
free_SW :- u28, action(swerve_left), \+ free_SE.

0.9990010::u29.
free_SW :- u29, action(swerve_right), \+ free_SE.

0.5100257::u30.
free_SW :- u30, action(change_to_left), free_SE.

0.5161930::u31.
free_SW :- u31, action(change_to_right), free_SE.

0.5410467::u32.
free_SW :- u32, action(cruise), free_SE.

0.9498355::u33.
free_SW :- u33, action(keep), free_SE.

0.9990010::u34.
free_SW :- u34, action(swerve_left), free_SE.

0.9990010::u35.
free_SW :- u35, action(swerve_right), free_SE.

0.5213242::u36.
free_W :- u36, action(change_to_left).

0.5777434::u37.
free_W :- u37, action(change_to_right).

0.7248953::u38.
free_W :- u38, action(cruise).

0.9312019::u39.
free_W :- u39, action(keep).

0.9487179::u40.
free_W :- u40, action(swerve_left).

0.8750000::u41.
free_W :- u41, action(swerve_right).

0.9822485::u42.
latent_collision :- u42, \+ free_E, \+ free_SW, \+ free_W.

0.5707102::u43.
latent_collision :- u43, free_E, \+ free_SW, \+ free_W.

0.9459459::u44.
latent_collision :- u44, \+ free_E, free_SW, \+ free_W.

0.4717295::u45.
latent_collision :- u45, free_E, free_SW, \+ free_W.

0.8481625::u46.
latent_collision :- u46, \+ free_E, \+ free_SW, free_W.

0.3263757::u47.
latent_collision :- u47, free_E, \+ free_SW, free_W.

0.2899819::u48.
latent_collision :- u48, \+ free_E, free_SW, free_W.

0.1514935::u49.
latent_collision :- u49, free_E, free_SW, free_W.

