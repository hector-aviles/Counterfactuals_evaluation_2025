%%% Exogenous variables

0.1704593::u_action(change_to_left); 0.1669784::u_action(change_to_right); 0.4124065::u_action(cruise); 0.2471945::u_action(keep); 0.0017664::u_action(swerve_left); 0.0011949::u_action(swerve_right)
action(V) :- u_action(V).

0.6853699::u1.
free_E :- u1.

0.3832156::u2.
curr_lane :- u2, \+ free_E, \+ free_NE.

0.4583843::u3.
curr_lane :- u3, free_E, \+ free_NE.

0.3631003::u4.
curr_lane :- u4, \+ free_E, free_NE.

0.7764423::u5.
curr_lane :- u5, free_E, free_NE.

0.5065789::u6.
free_NE :- u6, action(change_to_left), \+ free_E.

0.4945055::u7.
free_NE :- u7, action(change_to_right), \+ free_E.

0.4176136::u8.
free_NE :- u8, action(cruise), \+ free_E.

0.0846216::u9.
free_NE :- u9, action(keep), \+ free_E.

0.5000000::u10.
free_NE :- u10, action(swerve_left), \+ free_E.

0.5000000::u11.
free_NE :- u11, action(swerve_right), \+ free_E.

0.4843839::u12.
free_NE :- u12, action(change_to_left), free_E.

0.5194961::u13.
free_NE :- u13, action(change_to_right), free_E.

0.7858530::u14.
free_NE :- u14, action(cruise), free_E.

0.0087844::u15.
free_NE :- u15, action(keep), free_E.

0.8235294::u16.
free_NE :- u16, action(swerve_left), free_E.

0.9990010::u17.
free_NE :- u17, action(swerve_right), free_E.

0.5220969::u18.
free_NW :- u18, action(change_to_left).

0.5382701::u19.
free_NW :- u19, action(change_to_right).

0.5233056::u20.
free_NW :- u20, action(cruise).

0.0294241::u21.
free_NW :- u21, action(keep).

0.9117647::u22.
free_NW :- u22, action(swerve_left).

0.8695652::u23.
free_NW :- u23, action(swerve_right).

0.7517241::u24.
free_SE :- u24, \+ curr_lane, \+ free_SW, \+ latent_collision.

0.9732874::u25.
free_SE :- u25, curr_lane, \+ free_SW, \+ latent_collision.

0.4159072::u26.
free_SE :- u26, \+ curr_lane, free_SW, \+ latent_collision.

0.7899023::u27.
free_SE :- u27, curr_lane, free_SW, \+ latent_collision.

0.5088203::u28.
free_SE :- u28, \+ curr_lane, \+ free_SW, latent_collision.

0.5076087::u29.
free_SE :- u29, curr_lane, \+ free_SW, latent_collision.

0.5156998::u30.
free_SE :- u30, \+ curr_lane, free_SW, latent_collision.

0.5161780::u31.
free_SE :- u31, curr_lane, free_SW, latent_collision.

0.5108199::u32.
free_SW :- u32, action(change_to_left).

0.5790292::u33.
free_SW :- u33, action(change_to_right).

0.5981356::u34.
free_SW :- u34, action(cruise).

0.9760404::u35.
free_SW :- u35, action(keep).

0.9411765::u36.
free_SW :- u36, action(swerve_left).

0.9565217::u37.
free_SW :- u37, action(swerve_right).

0.5254496::u38.
free_W :- u38, action(change_to_left).

0.5647169::u39.
free_W :- u39, action(change_to_right).

0.7107584::u40.
free_W :- u40, action(cruise).

0.9251786::u41.
free_W :- u41, action(keep).

0.9990010::u42.
free_W :- u42, action(swerve_left).

0.8695652::u43.
free_W :- u43, action(swerve_right).

0.9666344::u44.
latent_collision :- u44, \+ free_E, \+ free_W.

0.5258256::u45.
latent_collision :- u45, free_E, \+ free_W.

0.4475928::u46.
latent_collision :- u46, \+ free_E, free_W.

0.1931806::u47.
latent_collision :- u47, free_E, free_W.

