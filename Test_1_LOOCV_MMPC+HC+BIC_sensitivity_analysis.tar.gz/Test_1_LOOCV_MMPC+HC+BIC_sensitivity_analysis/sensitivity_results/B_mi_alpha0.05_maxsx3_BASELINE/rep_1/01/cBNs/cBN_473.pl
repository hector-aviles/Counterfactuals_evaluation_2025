%%% Exogenous variables

0.1647610::u_action(change_to_left); 0.1700659::u_action(change_to_right); 0.4092501::u_action(cruise); 0.2536053::u_action(keep); 0.0016481::u_action(swerve_left); 0.0006696::u_action(swerve_right)
action(V) :- u_action(V).

0.5298723::u1.
curr_lane :- u1.

0.6147283::u2.
free_E :- u2, \+ curr_lane, \+ latent_collision.

0.9343635::u3.
free_E :- u3, curr_lane, \+ latent_collision.

0.4551780::u4.
free_E :- u4, \+ curr_lane, latent_collision.

0.5151919::u5.
free_E :- u5, curr_lane, latent_collision.

0.4838107::u6.
free_NE :- u6, action(change_to_left), \+ curr_lane.

0.5057962::u7.
free_NE :- u7, action(change_to_right), \+ curr_lane.

0.4918860::u8.
free_NE :- u8, action(cruise), \+ curr_lane.

0.1128304::u9.
free_NE :- u9, action(keep), \+ curr_lane.

0.8571429::u10.
free_NE :- u10, action(swerve_left), \+ curr_lane.

0.9990010::u11.
free_NE :- u11, action(swerve_right), \+ curr_lane.

0.5335844::u12.
free_NE :- u12, action(change_to_left), curr_lane.

0.5225496::u13.
free_NE :- u13, action(change_to_right), curr_lane.

0.8424512::u14.
free_NE :- u14, action(cruise), curr_lane.

0.0038419::u15.
free_NE :- u15, action(keep), curr_lane.

0.8000000::u16.
free_NE :- u16, action(swerve_left), curr_lane.

0.8333333::u17.
free_NE :- u17, action(swerve_right), curr_lane.

0.4945295::u18.
free_NW :- u18, action(change_to_left).

0.5484555::u19.
free_NW :- u19, action(change_to_right).

0.5298263::u20.
free_NW :- u20, action(cruise).

0.0243704::u21.
free_NW :- u21, action(keep).

0.9687500::u22.
free_NW :- u22, action(swerve_left).

0.6923077::u23.
free_NW :- u23, action(swerve_right).

0.3423207::u24.
free_SE :- u24, \+ curr_lane, \+ free_E, \+ latent_collision.

0.9813520::u25.
free_SE :- u25, curr_lane, \+ free_E, \+ latent_collision.

0.4665057::u26.
free_SE :- u26, \+ curr_lane, free_E, \+ latent_collision.

0.8329785::u27.
free_SE :- u27, curr_lane, free_E, \+ latent_collision.

0.5088409::u28.
free_SE :- u28, \+ curr_lane, \+ free_E, latent_collision.

0.4870808::u29.
free_SE :- u29, curr_lane, \+ free_E, latent_collision.

0.5185185::u30.
free_SE :- u30, \+ curr_lane, free_E, latent_collision.

0.5002587::u31.
free_SE :- u31, curr_lane, free_E, latent_collision.

0.5357924::u32.
free_SW :- u32, action(change_to_left).

0.5929740::u33.
free_SW :- u33, action(change_to_right).

0.6081047::u34.
free_SW :- u34, action(cruise).

0.9798944::u35.
free_SW :- u35, action(keep).

0.9687500::u36.
free_SW :- u36, action(swerve_left).

0.9230769::u37.
free_SW :- u37, action(swerve_right).

0.5009276::u38.
free_W :- u38, action(change_to_left), \+ free_NW.

0.5459423::u39.
free_W :- u39, action(change_to_right), \+ free_NW.

0.6854925::u40.
free_W :- u40, action(cruise), \+ free_NW.

0.9356786::u41.
free_W :- u41, action(keep), \+ free_NW.

0.9990010::u42.
free_W :- u42, action(swerve_left), \+ free_NW.

0.2500000::u43.
free_W :- u43, action(swerve_right), \+ free_NW.

0.4981037::u44.
free_W :- u44, action(change_to_left), free_NW.

0.6118167::u45.
free_W :- u45, action(change_to_right), free_NW.

0.7653207::u46.
free_W :- u46, action(cruise), free_NW.

0.2916667::u47.
free_W :- u47, action(keep), free_NW.

0.9990010::u48.
free_W :- u48, action(swerve_left), free_NW.

0.9990010::u49.
free_W :- u49, action(swerve_right), free_NW.

0.6785779::u50.
latent_collision :- u50, \+ free_W.

0.2687568::u51.
latent_collision :- u51, free_W.

