%%% Exogenous variables

0.1669398::u_action(change_to_left); 0.1660180::u_action(change_to_right); 0.4066469::u_action(cruise); 0.2577325::u_action(keep); 0.0014850::u_action(swerve_left); 0.0011778::u_action(swerve_right)
action(V) :- u_action(V).

0.3578369::u1.
curr_lane :- u1, \+ free_SE.

0.6416368::u2.
curr_lane :- u2, free_SE.

0.6190564::u3.
free_E :- u3, \+ curr_lane, \+ latent_collision.

0.9305409::u4.
free_E :- u4, curr_lane, \+ latent_collision.

0.4432206::u5.
free_E :- u5, \+ curr_lane, latent_collision.

0.5191941::u6.
free_E :- u6, curr_lane, latent_collision.

0.4611680::u7.
free_NE :- u7, action(change_to_left), \+ curr_lane.

0.5112641::u8.
free_NE :- u8, action(change_to_right), \+ curr_lane.

0.4996423::u9.
free_NE :- u9, action(cruise), \+ curr_lane.

0.1150555::u10.
free_NE :- u10, action(keep), \+ curr_lane.

0.1250000::u11.
free_NE :- u11, action(swerve_left), \+ curr_lane.

0.5000000::u12.
free_NE :- u12, action(swerve_right), \+ curr_lane.

0.4903064::u13.
free_NE :- u13, action(change_to_left), curr_lane.

0.5206813::u14.
free_NE :- u14, action(change_to_right), curr_lane.

0.8349854::u15.
free_NE :- u15, action(cruise), curr_lane.

0.0047923::u16.
free_NE :- u16, action(keep), curr_lane.

0.9990010::u17.
free_NE :- u17, action(swerve_left), curr_lane.

0.9130435::u18.
free_NE :- u18, action(swerve_right), curr_lane.

0.5150307::u19.
free_NW :- u19, action(change_to_left).

0.5462677::u20.
free_NW :- u20, action(change_to_right).

0.5238635::u21.
free_NW :- u21, action(cruise).

0.0300020::u22.
free_NW :- u22, action(keep).

0.9990010::u23.
free_NW :- u23, action(swerve_left).

0.6956522::u24.
free_NW :- u24, action(swerve_right).

0.9564387::u25.
free_SE :- u25, \+ free_SW, \+ latent_collision.

0.5718833::u26.
free_SE :- u26, free_SW, \+ latent_collision.

0.5236448::u27.
free_SE :- u27, \+ free_SW, latent_collision.

0.4970134::u28.
free_SE :- u28, free_SW, latent_collision.

0.5343558::u29.
free_SW :- u29, action(change_to_left).

0.5817397::u30.
free_SW :- u30, action(change_to_right).

0.6106284::u31.
free_SW :- u31, action(cruise).

0.9765547::u32.
free_SW :- u32, action(keep).

0.9990010::u33.
free_SW :- u33, action(swerve_left).

0.9565217::u34.
free_SW :- u34, action(swerve_right).

0.5053763::u35.
free_W :- u35, action(change_to_left), \+ free_NW.

0.5350102::u36.
free_W :- u36, action(change_to_right), \+ free_NW.

0.6606718::u37.
free_W :- u37, action(cruise), \+ free_NW.

0.9365014::u38.
free_W :- u38, action(keep), \+ free_NW.

0.5000000::u39.
free_W :- u39, action(swerve_left), \+ free_NW.

0.5714286::u40.
free_W :- u40, action(swerve_right), \+ free_NW.

0.5348422::u41.
free_W :- u41, action(change_to_left), free_NW.

0.6007905::u42.
free_W :- u42, action(change_to_right), free_NW.

0.7670673::u43.
free_W :- u43, action(cruise), free_NW.

0.4569536::u44.
free_W :- u44, action(keep), free_NW.

0.9990010::u45.
free_W :- u45, action(swerve_left), free_NW.

0.9990010::u46.
free_W :- u46, action(swerve_right), free_NW.

0.6739868::u47.
latent_collision :- u47, \+ free_W.

0.2664608::u48.
latent_collision :- u48, free_W.

