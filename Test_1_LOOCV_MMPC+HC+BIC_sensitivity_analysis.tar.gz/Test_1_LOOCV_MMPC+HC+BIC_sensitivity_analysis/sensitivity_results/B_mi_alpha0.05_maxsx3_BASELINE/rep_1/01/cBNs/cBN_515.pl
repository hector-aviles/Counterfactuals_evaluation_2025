%%% Exogenous variables

0.1689556::u_action(change_to_left); 0.1661884::u_action(change_to_right); 0.4065799::u_action(cruise); 0.2555601::u_action(keep); 0.0016398::u_action(swerve_left); 0.0010762::u_action(swerve_right)
action(V) :- u_action(V).

0.5332582::u1.
curr_lane :- u1.

0.6266392::u2.
free_E :- u2, \+ curr_lane, \+ latent_collision.

0.9379300::u3.
free_E :- u3, curr_lane, \+ latent_collision.

0.4801061::u4.
free_E :- u4, \+ curr_lane, latent_collision.

0.5196237::u5.
free_E :- u5, curr_lane, latent_collision.

0.4575412::u6.
free_NE :- u6, action(change_to_left), \+ curr_lane, \+ free_E.

0.4862745::u7.
free_NE :- u7, action(change_to_right), \+ curr_lane, \+ free_E.

0.5229041::u8.
free_NE :- u8, action(cruise), \+ curr_lane, \+ free_E.

0.2600644::u9.
free_NE :- u9, action(keep), \+ curr_lane, \+ free_E.

0.5000000::u10.
free_NE :- u10, action(swerve_left), \+ curr_lane, \+ free_E.

0.5000000::u11.
free_NE :- u11, action(swerve_right), \+ curr_lane, \+ free_E.

0.4885387::u12.
free_NE :- u12, action(change_to_left), curr_lane, \+ free_E.

0.5228426::u13.
free_NE :- u13, action(change_to_right), curr_lane, \+ free_E.

0.2141561::u14.
free_NE :- u14, action(cruise), curr_lane, \+ free_E.

0.0009990::u15.
free_NE :- u15, action(keep), curr_lane, \+ free_E.

0.5000000::u16.
free_NE :- u16, action(swerve_left), curr_lane, \+ free_E.

0.5000000::u17.
free_NE :- u17, action(swerve_right), curr_lane, \+ free_E.

0.4591398::u18.
free_NE :- u18, action(change_to_left), \+ curr_lane, free_E.

0.4525000::u19.
free_NE :- u19, action(change_to_right), \+ curr_lane, free_E.

0.4395161::u20.
free_NE :- u20, action(cruise), \+ curr_lane, free_E.

0.0139535::u21.
free_NE :- u21, action(keep), \+ curr_lane, free_E.

0.9990010::u22.
free_NE :- u22, action(swerve_left), \+ curr_lane, free_E.

0.5000000::u23.
free_NE :- u23, action(swerve_right), \+ curr_lane, free_E.

0.4750000::u24.
free_NE :- u24, action(change_to_left), curr_lane, free_E.

0.5674157::u25.
free_NE :- u25, action(change_to_right), curr_lane, free_E.

0.9067117::u26.
free_NE :- u26, action(cruise), curr_lane, free_E.

0.0036474::u27.
free_NE :- u27, action(keep), curr_lane, free_E.

0.9333333::u28.
free_NE :- u28, action(swerve_left), curr_lane, free_E.

0.8571429::u29.
free_NE :- u29, action(swerve_right), curr_lane, free_E.

0.5250227::u30.
free_NW :- u30, action(change_to_left).

0.5488745::u31.
free_NW :- u31, action(change_to_right).

0.5253340::u32.
free_NW :- u32, action(cruise).

0.0288751::u33.
free_NW :- u33, action(keep).

0.9375000::u34.
free_NW :- u34, action(swerve_left).

0.8571429::u35.
free_NW :- u35, action(swerve_right).

0.7813620::u36.
free_SE :- u36, \+ curr_lane, \+ free_SW, \+ latent_collision.

0.9725557::u37.
free_SE :- u37, curr_lane, \+ free_SW, \+ latent_collision.

0.4067998::u38.
free_SE :- u38, \+ curr_lane, free_SW, \+ latent_collision.

0.7962793::u39.
free_SE :- u39, curr_lane, free_SW, \+ latent_collision.

0.5364314::u40.
free_SE :- u40, \+ curr_lane, \+ free_SW, latent_collision.

0.5008329::u41.
free_SE :- u41, curr_lane, \+ free_SW, latent_collision.

0.5076468::u42.
free_SE :- u42, \+ curr_lane, free_SW, latent_collision.

0.5106826::u43.
free_SE :- u43, curr_lane, free_SW, latent_collision.

0.5298756::u44.
free_SW :- u44, action(change_to_left).

0.5784767::u45.
free_SW :- u45, action(change_to_right).

0.6087724::u46.
free_SW :- u46, action(cruise).

0.9735312::u47.
free_SW :- u47, action(keep).

0.9990010::u48.
free_SW :- u48, action(swerve_left).

0.9047619::u49.
free_SW :- u49, action(swerve_right).

0.5229885::u50.
free_W :- u50, action(change_to_left), \+ free_NW.

0.5276828::u51.
free_W :- u51, action(change_to_right), \+ free_NW.

0.6640998::u52.
free_W :- u52, action(cruise), \+ free_NW.

0.9376420::u53.
free_W :- u53, action(keep), \+ free_NW.

0.5000000::u54.
free_W :- u54, action(swerve_left), \+ free_NW.

0.3333333::u55.
free_W :- u55, action(swerve_right), \+ free_NW.

0.5395725::u56.
free_W :- u56, action(change_to_left), free_NW.

0.6168539::u57.
free_W :- u57, action(change_to_right), free_NW.

0.7617562::u58.
free_W :- u58, action(cruise), free_NW.

0.4444444::u59.
free_W :- u59, action(keep), free_NW.

0.9990010::u60.
free_W :- u60, action(swerve_left), free_NW.

0.9444444::u61.
free_W :- u61, action(swerve_right), free_NW.

0.6687646::u62.
latent_collision :- u62, \+ free_W.

0.2702645::u63.
latent_collision :- u63, free_W.

