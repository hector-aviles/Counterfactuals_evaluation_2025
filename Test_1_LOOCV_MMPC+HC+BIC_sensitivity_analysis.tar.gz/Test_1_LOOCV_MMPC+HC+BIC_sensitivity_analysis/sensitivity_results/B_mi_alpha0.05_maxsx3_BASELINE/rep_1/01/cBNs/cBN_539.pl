%%% Exogenous variables

0.1703905::u_action(change_to_left); 0.1677257::u_action(change_to_right); 0.4102696::u_action(cruise); 0.2499231::u_action(keep); 0.0010249::u_action(swerve_left); 0.0006662::u_action(swerve_right)
action(V) :- u_action(V).

0.5323870::u1.
curr_lane :- u1.

0.5940649::u2.
free_E :- u2, \+ curr_lane, \+ latent_collision.

0.9328930::u3.
free_E :- u3, curr_lane, \+ latent_collision.

0.4637643::u4.
free_E :- u4, \+ curr_lane, latent_collision.

0.5284335::u5.
free_E :- u5, curr_lane, latent_collision.

0.4886988::u6.
free_NE :- u6, action(change_to_left), \+ curr_lane.

0.4728972::u7.
free_NE :- u7, action(change_to_right), \+ curr_lane.

0.4785714::u8.
free_NE :- u8, action(cruise), \+ curr_lane.

0.1268657::u9.
free_NE :- u9, action(keep), \+ curr_lane.

0.9990010::u10.
free_NE :- u10, action(swerve_left), \+ curr_lane.

0.5000000::u11.
free_NE :- u11, action(swerve_right), \+ curr_lane.

0.5177725::u12.
free_NE :- u12, action(change_to_left), curr_lane.

0.5365707::u13.
free_NE :- u13, action(change_to_right), curr_lane.

0.8415290::u14.
free_NE :- u14, action(cruise), curr_lane.

0.0044568::u15.
free_NE :- u15, action(keep), curr_lane.

0.8947368::u16.
free_NE :- u16, action(swerve_left), curr_lane.

0.9990010::u17.
free_NE :- u17, action(swerve_right), curr_lane.

0.5218045::u18.
free_NW :- u18, action(change_to_left).

0.5334555::u19.
free_NW :- u19, action(change_to_right).

0.5282288::u20.
free_NW :- u20, action(cruise).

0.0311667::u21.
free_NW :- u21, action(keep).

0.9990010::u22.
free_NW :- u22, action(swerve_left).

0.6153846::u23.
free_NW :- u23, action(swerve_right).

0.3489655::u24.
free_SE :- u24, \+ curr_lane, \+ free_E, \+ latent_collision.

0.9731544::u25.
free_SE :- u25, curr_lane, \+ free_E, \+ latent_collision.

0.4791078::u26.
free_SE :- u26, \+ curr_lane, free_E, \+ latent_collision.

0.8474413::u27.
free_SE :- u27, curr_lane, free_E, \+ latent_collision.

0.4891089::u28.
free_SE :- u28, \+ curr_lane, \+ free_E, latent_collision.

0.4903299::u29.
free_SE :- u29, curr_lane, \+ free_E, latent_collision.

0.5174585::u30.
free_SE :- u30, \+ curr_lane, free_E, latent_collision.

0.5172589::u31.
free_SE :- u31, curr_lane, free_E, latent_collision.

0.5034586::u32.
free_SW :- u32, action(change_to_left).

0.5783685::u33.
free_SW :- u33, action(change_to_right).

0.5994254::u34.
free_SW :- u34, action(cruise).

0.9700636::u35.
free_SW :- u35, action(keep).

0.9990010::u36.
free_SW :- u36, action(swerve_left).

0.9230769::u37.
free_SW :- u37, action(swerve_right).

0.5144654::u38.
free_W :- u38, action(change_to_left), \+ free_NW.

0.5481336::u39.
free_W :- u39, action(change_to_right), \+ free_NW.

0.6767276::u40.
free_W :- u40, action(cruise), \+ free_NW.

0.9358730::u41.
free_W :- u41, action(keep), \+ free_NW.

0.5000000::u42.
free_W :- u42, action(swerve_left), \+ free_NW.

0.6000000::u43.
free_W :- u43, action(swerve_right), \+ free_NW.

0.5273775::u44.
free_W :- u44, action(change_to_left), free_NW.

0.6071019::u45.
free_W :- u45, action(change_to_right), free_NW.

0.7765429::u46.
free_W :- u46, action(cruise), free_NW.

0.4539474::u47.
free_W :- u47, action(keep), free_NW.

0.9990010::u48.
free_W :- u48, action(swerve_left), free_NW.

0.9990010::u49.
free_W :- u49, action(swerve_right), free_NW.

0.6794640::u50.
latent_collision :- u50, \+ free_W.

0.2675100::u51.
latent_collision :- u51, free_W.

