%%% Exogenous variables

0.1710917::u_action(change_to_left); 0.1698104::u_action(change_to_right); 0.4059969::u_action(cruise); 0.2507945::u_action(keep); 0.0015889::u_action(swerve_left); 0.0007176::u_action(swerve_right)
action(V) :- u_action(V).

0.5374167::u1.
curr_lane :- u1.

0.6055680::u2.
free_E :- u2, \+ curr_lane, \+ latent_collision.

0.9364548::u3.
free_E :- u3, curr_lane, \+ latent_collision.

0.4530357::u4.
free_E :- u4, \+ curr_lane, latent_collision.

0.5305861::u5.
free_E :- u5, curr_lane, latent_collision.

0.4911747::u6.
free_NE :- u6, action(change_to_left), \+ curr_lane.

0.4936629::u7.
free_NE :- u7, action(change_to_right), \+ curr_lane.

0.4843356::u8.
free_NE :- u8, action(cruise), \+ curr_lane.

0.1178028::u9.
free_NE :- u9, action(keep), \+ curr_lane.

0.8000000::u10.
free_NE :- u10, action(swerve_left), \+ curr_lane.

0.5000000::u11.
free_NE :- u11, action(swerve_right), \+ curr_lane.

0.4920354::u12.
free_NE :- u12, action(change_to_left), curr_lane.

0.5221902::u13.
free_NE :- u13, action(change_to_right), curr_lane.

0.8322317::u14.
free_NE :- u14, action(cruise), curr_lane.

0.0037413::u15.
free_NE :- u15, action(keep), curr_lane.

0.8461538::u16.
free_NE :- u16, action(swerve_left), curr_lane.

0.9990010::u17.
free_NE :- u17, action(swerve_right), curr_lane.

0.5035950::u18.
free_NW :- u18, action(change_to_left).

0.5384848::u19.
free_NW :- u19, action(change_to_right).

0.5397046::u20.
free_NW :- u20, action(cruise).

0.0306560::u21.
free_NW :- u21, action(keep).

0.9677419::u22.
free_NW :- u22, action(swerve_left).

0.7142857::u23.
free_NW :- u23, action(swerve_right).

0.3524396::u24.
free_SE :- u24, \+ curr_lane, \+ free_E, \+ latent_collision.

0.9856459::u25.
free_SE :- u25, curr_lane, \+ free_E, \+ latent_collision.

0.4714594::u26.
free_SE :- u26, \+ curr_lane, free_E, \+ latent_collision.

0.8370130::u27.
free_SE :- u27, curr_lane, free_E, \+ latent_collision.

0.4897959::u28.
free_SE :- u28, \+ curr_lane, \+ free_E, latent_collision.

0.5163577::u29.
free_SE :- u29, curr_lane, \+ free_E, latent_collision.

0.5156250::u30.
free_SE :- u30, \+ curr_lane, free_E, latent_collision.

0.5229137::u31.
free_SE :- u31, curr_lane, free_E, latent_collision.

0.5161774::u32.
free_SW :- u32, action(change_to_left).

0.5777241::u33.
free_SW :- u33, action(change_to_right).

0.5972731::u34.
free_SW :- u34, action(cruise).

0.9777233::u35.
free_SW :- u35, action(keep).

0.9677419::u36.
free_SW :- u36, action(swerve_left).

0.9285714::u37.
free_SW :- u37, action(swerve_right).

0.5116836::u38.
free_W :- u38, action(change_to_left).

0.5683670::u39.
free_W :- u39, action(change_to_right).

0.7252872::u40.
free_W :- u40, action(cruise).

0.9182506::u41.
free_W :- u41, action(keep).

0.9677419::u42.
free_W :- u42, action(swerve_left).

0.8571429::u43.
free_W :- u43, action(swerve_right).

0.6900160::u44.
latent_collision :- u44, \+ free_W.

0.2659505::u45.
latent_collision :- u45, free_W.

