%%% Exogenous variables

0.1669058::u_action(change_to_left); 0.1696218::u_action(change_to_right); 0.4039151::u_action(cruise); 0.2572512::u_action(keep); 0.0011786::u_action(swerve_left); 0.0011274::u_action(swerve_right)
action(V) :- u_action(V).

0.5360254::u1.
curr_lane :- u1.

0.6042553::u2.
free_E :- u2, \+ curr_lane, \+ latent_collision.

0.9351949::u3.
free_E :- u3, curr_lane, \+ latent_collision.

0.4362839::u4.
free_E :- u4, \+ curr_lane, latent_collision.

0.5458411::u5.
free_E :- u5, curr_lane, latent_collision.

0.5070165::u6.
free_NE :- u6, action(change_to_left), \+ curr_lane.

0.5094697::u7.
free_NE :- u7, action(change_to_right), \+ curr_lane.

0.4714929::u8.
free_NE :- u8, action(cruise), \+ curr_lane.

0.1050633::u9.
free_NE :- u9, action(keep), \+ curr_lane.

0.9990010::u10.
free_NE :- u10, action(swerve_left), \+ curr_lane.

0.9990010::u11.
free_NE :- u11, action(swerve_right), \+ curr_lane.

0.5173053::u12.
free_NE :- u12, action(change_to_left), curr_lane.

0.5225956::u13.
free_NE :- u13, action(change_to_right), curr_lane.

0.8425997::u14.
free_NE :- u14, action(cruise), curr_lane.

0.0026882::u15.
free_NE :- u15, action(keep), curr_lane.

0.9473684::u16.
free_NE :- u16, action(swerve_left), curr_lane.

0.7142857::u17.
free_NE :- u17, action(swerve_right), curr_lane.

0.4906356::u18.
free_NW :- u18, action(change_to_left).

0.5456193::u19.
free_NW :- u19, action(change_to_right).

0.5338747::u20.
free_NW :- u20, action(cruise).

0.0296813::u21.
free_NW :- u21, action(keep).

0.9565217::u22.
free_NW :- u22, action(swerve_left).

0.7727273::u23.
free_NW :- u23, action(swerve_right).

0.7728814::u24.
free_SE :- u24, \+ curr_lane, \+ free_SW, \+ latent_collision.

0.9657334::u25.
free_SE :- u25, curr_lane, \+ free_SW, \+ latent_collision.

0.3925636::u26.
free_SE :- u26, \+ curr_lane, free_SW, \+ latent_collision.

0.7806691::u27.
free_SE :- u27, curr_lane, free_SW, \+ latent_collision.

0.5166950::u28.
free_SE :- u28, \+ curr_lane, \+ free_SW, latent_collision.

0.5134189::u29.
free_SE :- u29, curr_lane, \+ free_SW, latent_collision.

0.4973433::u30.
free_SE :- u30, \+ curr_lane, free_SW, latent_collision.

0.5109810::u31.
free_SE :- u31, curr_lane, free_SW, latent_collision.

0.5333129::u32.
free_SW :- u32, action(change_to_left).

0.5833837::u33.
free_SW :- u33, action(change_to_right).

0.6022583::u34.
free_SW :- u34, action(cruise).

0.9733068::u35.
free_SW :- u35, action(keep).

0.9990010::u36.
free_SW :- u36, action(swerve_left).

0.9545455::u37.
free_SW :- u37, action(swerve_right).

0.5117541::u38.
free_W :- u38, action(change_to_left), \+ free_NW.

0.5299202::u39.
free_W :- u39, action(change_to_right), \+ free_NW.

0.6548721::u40.
free_W :- u40, action(cruise), \+ free_NW.

0.9414905::u41.
free_W :- u41, action(keep), \+ free_NW.

0.9990010::u42.
free_W :- u42, action(swerve_left), \+ free_NW.

0.8000000::u43.
free_W :- u43, action(swerve_right), \+ free_NW.

0.5125156::u44.
free_W :- u44, action(change_to_left), free_NW.

0.6229236::u45.
free_W :- u45, action(change_to_right), free_NW.

0.7623574::u46.
free_W :- u46, action(cruise), free_NW.

0.4161074::u47.
free_W :- u47, action(keep), free_NW.

0.9990010::u48.
free_W :- u48, action(swerve_left), free_NW.

0.9990010::u49.
free_W :- u49, action(swerve_right), free_NW.

0.6607334::u50.
latent_collision :- u50, \+ free_W.

0.2662637::u51.
latent_collision :- u51, free_W.

