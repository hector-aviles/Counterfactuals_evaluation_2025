%%% Exogenous variables

0.1723410::u_action(change_to_left); 0.1706928::u_action(change_to_right); 0.4033994::u_action(cruise); 0.2507340::u_action(keep); 0.0019572::u_action(swerve_left); 0.0008756::u_action(swerve_right)
action(V) :- u_action(V).

0.5365954::u1.
curr_lane :- u1.

0.6235654::u2.
free_E :- u2, \+ curr_lane, \+ latent_collision.

0.9330384::u3.
free_E :- u3, curr_lane, \+ latent_collision.

0.4521093::u4.
free_E :- u4, \+ curr_lane, latent_collision.

0.5313309::u5.
free_E :- u5, curr_lane, latent_collision.

0.4780573::u6.
free_NE :- u6, action(change_to_left), \+ curr_lane.

0.4897304::u7.
free_NE :- u7, action(change_to_right), \+ curr_lane.

0.4776445::u8.
free_NE :- u8, action(cruise), \+ curr_lane.

0.0861663::u9.
free_NE :- u9, action(keep), \+ curr_lane.

0.7500000::u10.
free_NE :- u10, action(swerve_left), \+ curr_lane.

0.5000000::u11.
free_NE :- u11, action(swerve_right), \+ curr_lane.

0.4691509::u12.
free_NE :- u12, action(change_to_left), curr_lane.

0.5182232::u13.
free_NE :- u13, action(change_to_right), curr_lane.

0.8240504::u14.
free_NE :- u14, action(cruise), curr_lane.

0.0042172::u15.
free_NE :- u15, action(keep), curr_lane.

0.9000000::u16.
free_NE :- u16, action(swerve_left), curr_lane.

0.8823529::u17.
free_NE :- u17, action(swerve_right), curr_lane.

0.5179319::u18.
free_NW :- u18, action(change_to_left).

0.5392275::u19.
free_NW :- u19, action(change_to_right).

0.5286006::u20.
free_NW :- u20, action(cruise).

0.0320460::u21.
free_NW :- u21, action(keep).

0.9990010::u22.
free_NW :- u22, action(swerve_left).

0.8235294::u23.
free_NW :- u23, action(swerve_right).

0.3450203::u24.
free_SE :- u24, \+ curr_lane, \+ free_E, \+ latent_collision.

0.9908884::u25.
free_SE :- u25, curr_lane, \+ free_E, \+ latent_collision.

0.4671779::u26.
free_SE :- u26, \+ curr_lane, free_E, \+ latent_collision.

0.8417525::u27.
free_SE :- u27, curr_lane, free_E, \+ latent_collision.

0.4760291::u28.
free_SE :- u28, \+ curr_lane, \+ free_E, latent_collision.

0.5000000::u29.
free_SE :- u29, curr_lane, \+ free_E, latent_collision.

0.4982394::u30.
free_SE :- u30, \+ curr_lane, free_E, latent_collision.

0.5185185::u31.
free_SE :- u31, curr_lane, free_E, latent_collision.

0.5083682::u32.
free_SW :- u32, action(change_to_left).

0.5630658::u33.
free_SW :- u33, action(change_to_right).

0.6026558::u34.
free_SW :- u34, action(cruise).

0.9749384::u35.
free_SW :- u35, action(keep).

0.9990010::u36.
free_SW :- u36, action(swerve_left).

0.8823529::u37.
free_SW :- u37, action(swerve_right).

0.5015499::u38.
free_W :- u38, action(change_to_left), \+ free_NW.

0.5232482::u39.
free_W :- u39, action(change_to_right), \+ free_NW.

0.6660347::u40.
free_W :- u40, action(cruise), \+ free_NW.

0.9376061::u41.
free_W :- u41, action(keep), \+ free_NW.

0.5000000::u42.
free_W :- u42, action(swerve_left), \+ free_NW.

0.6666667::u43.
free_W :- u43, action(swerve_right), \+ free_NW.

0.5164455::u44.
free_W :- u44, action(change_to_left), free_NW.

0.6004477::u45.
free_W :- u45, action(change_to_right), free_NW.

0.7666667::u46.
free_W :- u46, action(cruise), free_NW.

0.5256410::u47.
free_W :- u47, action(keep), free_NW.

0.9990010::u48.
free_W :- u48, action(swerve_left), free_NW.

0.9990010::u49.
free_W :- u49, action(swerve_right), free_NW.

0.6896674::u50.
latent_collision :- u50, \+ free_W.

0.2712345::u51.
latent_collision :- u51, free_W.

