%%% Exogenous variables

0.1646962::u_action(change_to_left); 0.1678182::u_action(change_to_right); 0.4108706::u_action(cruise); 0.2542607::u_action(keep); 0.0013307::u_action(swerve_left); 0.0010236::u_action(swerve_right)
action(V) :- u_action(V).

0.5377450::u1.
curr_lane :- u1.

0.6034127::u2.
free_E :- u2, \+ curr_lane, \+ latent_collision.

0.9408002::u3.
free_E :- u3, curr_lane, \+ latent_collision.

0.4571506::u4.
free_E :- u4, \+ curr_lane, latent_collision.

0.5322410::u5.
free_E :- u5, curr_lane, latent_collision.

0.4810811::u6.
free_NE :- u6, action(change_to_left), \+ curr_lane, \+ free_E.

0.4912935::u7.
free_NE :- u7, action(change_to_right), \+ curr_lane, \+ free_E.

0.5459459::u8.
free_NE :- u8, action(cruise), \+ curr_lane, \+ free_E.

0.2346064::u9.
free_NE :- u9, action(keep), \+ curr_lane, \+ free_E.

0.9990010::u10.
free_NE :- u10, action(swerve_left), \+ curr_lane, \+ free_E.

0.5000000::u11.
free_NE :- u11, action(swerve_right), \+ curr_lane, \+ free_E.

0.4780142::u12.
free_NE :- u12, action(change_to_left), curr_lane, \+ free_E.

0.4974490::u13.
free_NE :- u13, action(change_to_right), curr_lane, \+ free_E.

0.2083333::u14.
free_NE :- u14, action(cruise), curr_lane, \+ free_E.

0.0009990::u15.
free_NE :- u15, action(keep), curr_lane, \+ free_E.

0.5000000::u16.
free_NE :- u16, action(swerve_left), curr_lane, \+ free_E.

0.5000000::u17.
free_NE :- u17, action(swerve_right), curr_lane, \+ free_E.

0.4525547::u18.
free_NE :- u18, action(change_to_left), \+ curr_lane, free_E.

0.4640199::u19.
free_NE :- u19, action(change_to_right), \+ curr_lane, free_E.

0.4460784::u20.
free_NE :- u20, action(cruise), \+ curr_lane, free_E.

0.0129800::u21.
free_NE :- u21, action(keep), \+ curr_lane, free_E.

0.7500000::u22.
free_NE :- u22, action(swerve_left), \+ curr_lane, free_E.

0.5000000::u23.
free_NE :- u23, action(swerve_right), \+ curr_lane, free_E.

0.4616193::u24.
free_NE :- u24, action(change_to_left), curr_lane, free_E.

0.5672316::u25.
free_NE :- u25, action(change_to_right), curr_lane, free_E.

0.9041866::u26.
free_NE :- u26, action(cruise), curr_lane, free_E.

0.0090307::u27.
free_NE :- u27, action(keep), curr_lane, free_E.

0.9047619::u28.
free_NE :- u28, action(swerve_left), curr_lane, free_E.

0.8500000::u29.
free_NE :- u29, action(swerve_right), curr_lane, free_E.

0.5024860::u30.
free_NW :- u30, action(change_to_left).

0.5330894::u31.
free_NW :- u31, action(change_to_right).

0.5174390::u32.
free_NW :- u32, action(cruise).

0.0320048::u33.
free_NW :- u33, action(keep).

0.9990010::u34.
free_NW :- u34, action(swerve_left).

0.8000000::u35.
free_NW :- u35, action(swerve_right).

0.7867647::u36.
free_SE :- u36, \+ curr_lane, \+ free_SW, \+ latent_collision.

0.9697723::u37.
free_SE :- u37, curr_lane, \+ free_SW, \+ latent_collision.

0.3839162::u38.
free_SE :- u38, \+ curr_lane, free_SW, \+ latent_collision.

0.7734448::u39.
free_SE :- u39, curr_lane, free_SW, \+ latent_collision.

0.5424986::u40.
free_SE :- u40, \+ curr_lane, \+ free_SW, latent_collision.

0.5153889::u41.
free_SE :- u41, curr_lane, \+ free_SW, latent_collision.

0.4897225::u42.
free_SE :- u42, \+ curr_lane, free_SW, latent_collision.

0.5182774::u43.
free_SE :- u43, curr_lane, free_SW, latent_collision.

0.5270354::u44.
free_SW :- u44, action(change_to_left).

0.5806648::u45.
free_SW :- u45, action(change_to_right).

0.5996512::u46.
free_SW :- u46, action(cruise).

0.9766506::u47.
free_SW :- u47, action(keep).

0.9990010::u48.
free_SW :- u48, action(swerve_left).

0.9990010::u49.
free_SW :- u49, action(swerve_right).

0.5267247::u50.
free_W :- u50, action(change_to_left).

0.5678561::u51.
free_W :- u51, action(change_to_right).

0.7209766::u52.
free_W :- u52, action(cruise).

0.9241143::u53.
free_W :- u53, action(keep).

0.9990010::u54.
free_W :- u54, action(swerve_left).

0.9500000::u55.
free_W :- u55, action(swerve_right).

0.6756027::u56.
latent_collision :- u56, \+ free_W.

0.2666476::u57.
latent_collision :- u57, free_W.

