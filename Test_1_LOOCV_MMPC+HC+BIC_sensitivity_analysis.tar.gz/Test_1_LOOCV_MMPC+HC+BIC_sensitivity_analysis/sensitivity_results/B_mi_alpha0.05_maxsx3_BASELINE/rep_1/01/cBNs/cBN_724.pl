%%% Exogenous variables

0.1680827::u_action(change_to_left); 0.1691575::u_action(change_to_right); 0.4082301::u_action(cruise); 0.2525335::u_action(keep); 0.0013307::u_action(swerve_left); 0.0006654::u_action(swerve_right)
action(V) :- u_action(V).

0.5343945::u1.
curr_lane :- u1.

0.6134251::u2.
free_E :- u2, \+ curr_lane, \+ latent_collision.

0.9411052::u3.
free_E :- u3, curr_lane, \+ latent_collision.

0.4339876::u4.
free_E :- u4, \+ curr_lane, latent_collision.

0.5315433::u5.
free_E :- u5, curr_lane, latent_collision.

0.4813702::u6.
free_NE :- u6, action(change_to_left), \+ curr_lane.

0.4993781::u7.
free_NE :- u7, action(change_to_right), \+ curr_lane.

0.4764028::u8.
free_NE :- u8, action(cruise), \+ curr_lane.

0.1156550::u9.
free_NE :- u9, action(keep), \+ curr_lane.

0.5000000::u10.
free_NE :- u10, action(swerve_left), \+ curr_lane.

0.5000000::u11.
free_NE :- u11, action(swerve_right), \+ curr_lane.

0.5037037::u12.
free_NE :- u12, action(change_to_left), curr_lane.

0.5415439::u13.
free_NE :- u13, action(change_to_right), curr_lane.

0.8315989::u14.
free_NE :- u14, action(cruise), curr_lane.

0.0038803::u15.
free_NE :- u15, action(keep), curr_lane.

0.9990010::u16.
free_NE :- u16, action(swerve_left), curr_lane.

0.7692308::u17.
free_NE :- u17, action(swerve_right), curr_lane.

0.5033496::u18.
free_NW :- u18, action(change_to_left).

0.5440242::u19.
free_NW :- u19, action(change_to_right).

0.5332247::u20.
free_NW :- u20, action(cruise).

0.0304013::u21.
free_NW :- u21, action(keep).

0.9990010::u22.
free_NW :- u22, action(swerve_left).

0.9230769::u23.
free_NW :- u23, action(swerve_right).

0.7861842::u24.
free_SE :- u24, \+ curr_lane, \+ free_SW, \+ latent_collision.

0.9709840::u25.
free_SE :- u25, curr_lane, \+ free_SW, \+ latent_collision.

0.4006701::u26.
free_SE :- u26, \+ curr_lane, free_SW, \+ latent_collision.

0.7735983::u27.
free_SE :- u27, curr_lane, free_SW, \+ latent_collision.

0.4973089::u28.
free_SE :- u28, \+ curr_lane, \+ free_SW, latent_collision.

0.5046189::u29.
free_SE :- u29, curr_lane, \+ free_SW, latent_collision.

0.5303600::u30.
free_SE :- u30, \+ curr_lane, free_SW, latent_collision.

0.5099810::u31.
free_SE :- u31, curr_lane, free_SW, latent_collision.

0.5066991::u32.
free_SW :- u32, action(change_to_left).

0.5866868::u33.
free_SW :- u33, action(change_to_right).

0.6030592::u34.
free_SW :- u34, action(cruise).

0.9756790::u35.
free_SW :- u35, action(keep).

0.9990010::u36.
free_SW :- u36, action(swerve_left).

0.9990010::u37.
free_SW :- u37, action(swerve_right).

0.5370938::u38.
free_W :- u38, action(change_to_left), \+ free_NW.

0.5155939::u39.
free_W :- u39, action(change_to_right), \+ free_NW.

0.6551168::u40.
free_W :- u40, action(cruise), \+ free_NW.

0.9368729::u41.
free_W :- u41, action(keep), \+ free_NW.

0.5000000::u42.
free_W :- u42, action(swerve_left), \+ free_NW.

0.9990010::u43.
free_W :- u43, action(swerve_right), \+ free_NW.

0.5238959::u44.
free_W :- u44, action(change_to_left), free_NW.

0.6117909::u45.
free_W :- u45, action(change_to_right), free_NW.

0.7604044::u46.
free_W :- u46, action(cruise), free_NW.

0.4266667::u47.
free_W :- u47, action(keep), free_NW.

0.9990010::u48.
free_W :- u48, action(swerve_left), free_NW.

0.9990010::u49.
free_W :- u49, action(swerve_right), free_NW.

0.6733793::u50.
latent_collision :- u50, \+ free_W.

0.2697269::u51.
latent_collision :- u51, free_W.

