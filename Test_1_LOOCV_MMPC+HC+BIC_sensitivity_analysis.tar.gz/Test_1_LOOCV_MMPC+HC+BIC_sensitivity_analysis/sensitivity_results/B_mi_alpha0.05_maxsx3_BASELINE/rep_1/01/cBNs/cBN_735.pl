%%% Exogenous variables

0.1655663::u_action(change_to_left); 0.1690977::u_action(change_to_right); 0.4129178::u_action(cruise); 0.2503199::u_action(keep); 0.0012283::u_action(swerve_left); 0.0008701::u_action(swerve_right)
action(V) :- u_action(V).

0.5404064::u1.
curr_lane :- u1.

0.6104312::u2.
free_E :- u2, \+ curr_lane, \+ latent_collision.

0.9396396::u3.
free_E :- u3, curr_lane, \+ latent_collision.

0.4516217::u4.
free_E :- u4, \+ curr_lane, latent_collision.

0.5147474::u5.
free_E :- u5, curr_lane, latent_collision.

0.5006321::u6.
free_NE :- u6, action(change_to_left), \+ curr_lane, \+ free_E.

0.5006386::u7.
free_NE :- u7, action(change_to_right), \+ curr_lane, \+ free_E.

0.5187850::u8.
free_NE :- u8, action(cruise), \+ curr_lane, \+ free_E.

0.2496013::u9.
free_NE :- u9, action(keep), \+ curr_lane, \+ free_E.

0.5000000::u10.
free_NE :- u10, action(swerve_left), \+ curr_lane, \+ free_E.

0.5000000::u11.
free_NE :- u11, action(swerve_right), \+ curr_lane, \+ free_E.

0.5032938::u12.
free_NE :- u12, action(change_to_left), curr_lane, \+ free_E.

0.5157385::u13.
free_NE :- u13, action(change_to_right), curr_lane, \+ free_E.

0.2171533::u14.
free_NE :- u14, action(cruise), curr_lane, \+ free_E.

0.0009990::u15.
free_NE :- u15, action(keep), curr_lane, \+ free_E.

0.5000000::u16.
free_NE :- u16, action(swerve_left), curr_lane, \+ free_E.

0.5000000::u17.
free_NE :- u17, action(swerve_right), curr_lane, \+ free_E.

0.4761290::u18.
free_NE :- u18, action(change_to_left), \+ curr_lane, free_E.

0.4471338::u19.
free_NE :- u19, action(change_to_right), \+ curr_lane, free_E.

0.4335989::u20.
free_NE :- u20, action(cruise), \+ curr_lane, free_E.

0.0070999::u21.
free_NE :- u21, action(keep), \+ curr_lane, free_E.

0.9990010::u22.
free_NE :- u22, action(swerve_left), \+ curr_lane, free_E.

0.5000000::u23.
free_NE :- u23, action(swerve_right), \+ curr_lane, free_E.

0.4912088::u24.
free_NE :- u24, action(change_to_left), curr_lane, free_E.

0.5736264::u25.
free_NE :- u25, action(change_to_right), curr_lane, free_E.

0.9027924::u26.
free_NE :- u26, action(cruise), curr_lane, free_E.

0.0042553::u27.
free_NE :- u27, action(keep), curr_lane, free_E.

0.9500000::u28.
free_NE :- u28, action(swerve_left), curr_lane, free_E.

0.8235294::u29.
free_NE :- u29, action(swerve_right), curr_lane, free_E.

0.5069552::u30.
free_NW :- u30, action(change_to_left).

0.5375303::u31.
free_NW :- u31, action(change_to_right).

0.5327219::u32.
free_NW :- u32, action(cruise).

0.0280106::u33.
free_NW :- u33, action(keep).

0.9990010::u34.
free_NW :- u34, action(swerve_left).

0.5882353::u35.
free_NW :- u35, action(swerve_right).

0.7607973::u36.
free_SE :- u36, \+ curr_lane, \+ free_SW, \+ latent_collision.

0.9742845::u37.
free_SE :- u37, curr_lane, \+ free_SW, \+ latent_collision.

0.3932136::u38.
free_SE :- u38, \+ curr_lane, free_SW, \+ latent_collision.

0.7811250::u39.
free_SE :- u39, curr_lane, free_SW, \+ latent_collision.

0.4909400::u40.
free_SE :- u40, \+ curr_lane, \+ free_SW, latent_collision.

0.4944000::u41.
free_SE :- u41, curr_lane, \+ free_SW, latent_collision.

0.4892275::u42.
free_SE :- u42, \+ curr_lane, free_SW, latent_collision.

0.4985178::u43.
free_SE :- u43, curr_lane, free_SW, latent_collision.

0.5094281::u44.
free_SW :- u44, action(change_to_left).

0.5674939::u45.
free_SW :- u45, action(change_to_right).

0.6002727::u46.
free_SW :- u46, action(cruise).

0.9775097::u47.
free_SW :- u47, action(keep).

0.9990010::u48.
free_SW :- u48, action(swerve_left).

0.8823529::u49.
free_SW :- u49, action(swerve_right).

0.5128527::u50.
free_W :- u50, action(change_to_left), \+ free_NW.

0.5418848::u51.
free_W :- u51, action(change_to_right), \+ free_NW.

0.6639257::u52.
free_W :- u52, action(cruise), \+ free_NW.

0.9326883::u53.
free_W :- u53, action(keep), \+ free_NW.

0.5000000::u54.
free_W :- u54, action(swerve_left), \+ free_NW.

0.4285714::u55.
free_W :- u55, action(swerve_right), \+ free_NW.

0.5189024::u56.
free_W :- u56, action(change_to_left), free_NW.

0.6092342::u57.
free_W :- u57, action(change_to_right), free_NW.

0.7543043::u58.
free_W :- u58, action(cruise), free_NW.

0.4014599::u59.
free_W :- u59, action(keep), free_NW.

0.9990010::u60.
free_W :- u60, action(swerve_left), free_NW.

0.9990010::u61.
free_W :- u61, action(swerve_right), free_NW.

0.6674284::u62.
latent_collision :- u62, \+ free_W.

0.2722744::u63.
latent_collision :- u63, free_W.

