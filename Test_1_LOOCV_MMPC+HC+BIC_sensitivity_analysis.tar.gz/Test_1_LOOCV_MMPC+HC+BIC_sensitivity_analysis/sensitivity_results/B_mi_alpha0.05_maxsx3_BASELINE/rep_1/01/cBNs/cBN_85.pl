%%% Exogenous variables

0.1684518::u_action(change_to_left); 0.1652744::u_action(change_to_right); 0.4095731::u_action(cruise); 0.2538820::u_action(keep); 0.0017937::u_action(swerve_left); 0.0010250::u_action(swerve_right)
action(V) :- u_action(V).

0.5345155::u1.
curr_lane :- u1.

0.6079703::u2.
free_E :- u2, \+ curr_lane, \+ latent_collision.

0.9341489::u3.
free_E :- u3, curr_lane, \+ latent_collision.

0.4441432::u4.
free_E :- u4, \+ curr_lane, latent_collision.

0.5379365::u5.
free_E :- u5, curr_lane, latent_collision.

0.4942319::u6.
free_NE :- u6, action(change_to_left), \+ curr_lane.

0.4990228::u7.
free_NE :- u7, action(change_to_right), \+ curr_lane.

0.4751441::u8.
free_NE :- u8, action(cruise), \+ curr_lane.

0.1096857::u9.
free_NE :- u9, action(keep), \+ curr_lane.

0.7142857::u10.
free_NE :- u10, action(swerve_left), \+ curr_lane.

0.5000000::u11.
free_NE :- u11, action(swerve_right), \+ curr_lane.

0.4792683::u12.
free_NE :- u12, action(change_to_left), curr_lane.

0.5325444::u13.
free_NE :- u13, action(change_to_right), curr_lane.

0.8287960::u14.
free_NE :- u14, action(cruise), curr_lane.

0.0027233::u15.
free_NE :- u15, action(keep), curr_lane.

0.9990010::u16.
free_NE :- u16, action(swerve_left), curr_lane.

0.9000000::u17.
free_NE :- u17, action(swerve_right), curr_lane.

0.5159720::u18.
free_NW :- u18, action(change_to_left).

0.5469767::u19.
free_NW :- u19, action(change_to_right).

0.5267768::u20.
free_NW :- u20, action(cruise).

0.0316916::u21.
free_NW :- u21, action(keep).

0.9990010::u22.
free_NW :- u22, action(swerve_left).

0.8000000::u23.
free_NW :- u23, action(swerve_right).

0.7884058::u24.
free_SE :- u24, \+ curr_lane, \+ free_SW, \+ latent_collision.

0.9716738::u25.
free_SE :- u25, curr_lane, \+ free_SW, \+ latent_collision.

0.3974257::u26.
free_SE :- u26, \+ curr_lane, free_SW, \+ latent_collision.

0.7723141::u27.
free_SE :- u27, curr_lane, free_SW, \+ latent_collision.

0.5197481::u28.
free_SE :- u28, \+ curr_lane, \+ free_SW, latent_collision.

0.4906065::u29.
free_SE :- u29, curr_lane, \+ free_SW, latent_collision.

0.4878928::u30.
free_SE :- u30, \+ curr_lane, free_SW, latent_collision.

0.5015416::u31.
free_SE :- u31, curr_lane, free_SW, latent_collision.

0.5217524::u32.
free_SW :- u32, action(change_to_left).

0.5655814::u33.
free_SW :- u33, action(change_to_right).

0.6021021::u34.
free_SW :- u34, action(cruise).

0.9743642::u35.
free_SW :- u35, action(keep).

0.9714286::u36.
free_SW :- u36, action(swerve_left).

0.8000000::u37.
free_SW :- u37, action(swerve_right).

0.5016733::u38.
free_W :- u38, action(change_to_left).

0.5779845::u39.
free_W :- u39, action(change_to_right).

0.7150901::u40.
free_W :- u40, action(cruise).

0.9263222::u41.
free_W :- u41, action(keep).

0.9714286::u42.
free_W :- u42, action(swerve_left).

0.9500000::u43.
free_W :- u43, action(swerve_right).

0.6852738::u44.
latent_collision :- u44, \+ free_W.

0.2617159::u45.
latent_collision :- u45, free_W.

