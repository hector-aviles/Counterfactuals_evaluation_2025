%%% Exogenous variables

0.1702068::u_action(change_to_left); 0.1719617::u_action(change_to_right); 0.4102063::u_action(cruise); 0.2452530::u_action(keep); 0.0014983::u_action(swerve_left); 0.0008739::u_action(swerve_right)
action(V) :- u_action(V).

0.6080313::u1.
free_SE :- u1.

0.6741448::u2.
free_SW :- u2.

0.7079310::u3.
free_W :- u3.

0.3897170::u4.
latent_collision :- u4.

0.4253714::u5.
curr_lane :- u5, action(change_to_left), \+ free_E, \+ free_NE, \+ free_SE.

0.4991270::u6.
curr_lane :- u6, action(change_to_right), \+ free_E, \+ free_NE, \+ free_SE.

0.4297515::u7.
curr_lane :- u7, action(cruise), \+ free_E, \+ free_NE, \+ free_SE.

0.0017574::u8.
curr_lane :- u8, action(keep), \+ free_E, \+ free_NE, \+ free_SE.

0.0009990::u9.
curr_lane :- u9, action(swerve_left), \+ free_E, \+ free_NE, \+ free_SE.

0.5000000::u10.
curr_lane :- u10, action(swerve_right), \+ free_E, \+ free_NE, \+ free_SE.

0.4267497::u11.
curr_lane :- u11, action(change_to_left), free_E, \+ free_NE, \+ free_SE.

0.4927316::u12.
curr_lane :- u12, action(change_to_right), free_E, \+ free_NE, \+ free_SE.

0.4609022::u13.
curr_lane :- u13, action(cruise), free_E, \+ free_NE, \+ free_SE.

0.2213219::u14.
curr_lane :- u14, action(keep), free_E, \+ free_NE, \+ free_SE.

0.6000000::u15.
curr_lane :- u15, action(swerve_left), free_E, \+ free_NE, \+ free_SE.

0.9990010::u16.
curr_lane :- u16, action(swerve_right), free_E, \+ free_NE, \+ free_SE.

0.4663421::u17.
curr_lane :- u17, action(change_to_left), \+ free_E, free_NE, \+ free_SE.

0.5247018::u18.
curr_lane :- u18, action(change_to_right), \+ free_E, free_NE, \+ free_SE.

0.0085475::u19.
curr_lane :- u19, action(cruise), \+ free_E, free_NE, \+ free_SE.

0.0009990::u20.
curr_lane :- u20, action(keep), \+ free_E, free_NE, \+ free_SE.

0.0009990::u21.
curr_lane :- u21, action(swerve_left), \+ free_E, free_NE, \+ free_SE.

0.5000000::u22.
curr_lane :- u22, action(swerve_right), \+ free_E, free_NE, \+ free_SE.

0.4308786::u23.
curr_lane :- u23, action(change_to_left), free_E, free_NE, \+ free_SE.

0.4439320::u24.
curr_lane :- u24, action(change_to_right), free_E, free_NE, \+ free_SE.

0.7761501::u25.
curr_lane :- u25, action(cruise), free_E, free_NE, \+ free_SE.

0.0278351::u26.
curr_lane :- u26, action(keep), free_E, free_NE, \+ free_SE.

0.4098361::u27.
curr_lane :- u27, action(swerve_left), free_E, free_NE, \+ free_SE.

0.9990010::u28.
curr_lane :- u28, action(swerve_right), free_E, free_NE, \+ free_SE.

0.5035117::u29.
curr_lane :- u29, action(change_to_left), \+ free_E, \+ free_NE, free_SE.

0.4997003::u30.
curr_lane :- u30, action(change_to_right), \+ free_E, \+ free_NE, free_SE.

0.3798552::u31.
curr_lane :- u31, action(cruise), \+ free_E, \+ free_NE, free_SE.

0.4220186::u32.
curr_lane :- u32, action(keep), \+ free_E, \+ free_NE, free_SE.

0.5375000::u33.
curr_lane :- u33, action(swerve_left), \+ free_E, \+ free_NE, free_SE.

0.9990010::u34.
curr_lane :- u34, action(swerve_right), \+ free_E, \+ free_NE, free_SE.

0.5592922::u35.
curr_lane :- u35, action(change_to_left), free_E, \+ free_NE, free_SE.

0.4989908::u36.
curr_lane :- u36, action(change_to_right), free_E, \+ free_NE, free_SE.

0.3061766::u37.
curr_lane :- u37, action(cruise), free_E, \+ free_NE, free_SE.

0.6692434::u38.
curr_lane :- u38, action(keep), free_E, \+ free_NE, free_SE.

0.7711864::u39.
curr_lane :- u39, action(swerve_left), free_E, \+ free_NE, free_SE.

0.9990010::u40.
curr_lane :- u40, action(swerve_right), free_E, \+ free_NE, free_SE.

0.5102650::u41.
curr_lane :- u41, action(change_to_left), \+ free_E, free_NE, free_SE.

0.4978274::u42.
curr_lane :- u42, action(change_to_right), \+ free_E, free_NE, free_SE.

0.2793332::u43.
curr_lane :- u43, action(cruise), \+ free_E, free_NE, free_SE.

0.0005701::u44.
curr_lane :- u44, action(keep), \+ free_E, free_NE, free_SE.

0.4000000::u45.
curr_lane :- u45, action(swerve_left), \+ free_E, free_NE, free_SE.

0.9990010::u46.
curr_lane :- u46, action(swerve_right), \+ free_E, free_NE, free_SE.

0.5846458::u47.
curr_lane :- u47, action(change_to_left), free_E, free_NE, free_SE.

0.7904688::u48.
curr_lane :- u48, action(change_to_right), free_E, free_NE, free_SE.

0.8855181::u49.
curr_lane :- u49, action(cruise), free_E, free_NE, free_SE.

0.6290909::u50.
curr_lane :- u50, action(keep), free_E, free_NE, free_SE.

0.8684321::u51.
curr_lane :- u51, action(swerve_left), free_E, free_NE, free_SE.

0.9911439::u52.
curr_lane :- u52, action(swerve_right), free_E, free_NE, free_SE.

0.5367564::u53.
free_E :- u53, action(change_to_left).

0.5192692::u54.
free_E :- u54, action(change_to_right).

0.7788353::u55.
free_E :- u55, action(cruise).

0.7428241::u56.
free_E :- u56, action(keep).

0.9504161::u57.
free_E :- u57, action(swerve_left).

0.9958383::u58.
free_E :- u58, action(swerve_right).

0.4827817::u59.
free_NE :- u59, action(change_to_left), \+ free_E, \+ free_NW.

0.4850111::u60.
free_NE :- u60, action(change_to_right), \+ free_E, \+ free_NW.

0.3694124::u61.
free_NE :- u61, action(cruise), \+ free_E, \+ free_NW.

0.0728923::u62.
free_NE :- u62, action(keep), \+ free_E, \+ free_NW.

0.2222222::u63.
free_NE :- u63, action(swerve_left), \+ free_E, \+ free_NW.

0.5000000::u64.
free_NE :- u64, action(swerve_right), \+ free_E, \+ free_NW.

0.4855181::u65.
free_NE :- u65, action(change_to_left), free_E, \+ free_NW.

0.4125924::u66.
free_NE :- u66, action(change_to_right), free_E, \+ free_NW.

0.8462179::u67.
free_NE :- u67, action(cruise), free_E, \+ free_NW.

0.0061063::u68.
free_NE :- u68, action(keep), free_E, \+ free_NW.

0.2065217::u69.
free_NE :- u69, action(swerve_left), free_E, \+ free_NW.

0.7040498::u70.
free_NE :- u70, action(swerve_right), free_E, \+ free_NW.

0.4935549::u71.
free_NE :- u71, action(change_to_left), \+ free_E, free_NW.

0.5072758::u72.
free_NE :- u72, action(change_to_right), \+ free_E, free_NW.

0.4696755::u73.
free_NE :- u73, action(cruise), \+ free_E, free_NW.

0.0997680::u74.
free_NE :- u74, action(keep), \+ free_E, free_NW.

0.3134328::u75.
free_NE :- u75, action(swerve_left), \+ free_E, free_NW.

0.0009990::u76.
free_NE :- u76, action(swerve_right), \+ free_E, free_NW.

0.4781939::u77.
free_NE :- u77, action(change_to_left), free_E, free_NW.

0.6011106::u78.
free_NE :- u78, action(change_to_right), free_E, free_NW.

0.7367193::u79.
free_NE :- u79, action(cruise), free_E, free_NW.

0.0649682::u80.
free_NE :- u80, action(keep), free_E, free_NW.

0.9139298::u81.
free_NE :- u81, action(swerve_left), free_E, free_NW.

0.8936484::u82.
free_NE :- u82, action(swerve_right), free_E, free_NW.

0.4881660::u83.
free_NW :- u83, action(change_to_left), \+ free_E.

0.5104859::u84.
free_NW :- u84, action(change_to_right), \+ free_E.

0.6129821::u85.
free_NW :- u85, action(cruise), \+ free_E.

0.0035501::u86.
free_NW :- u86, action(keep), \+ free_E.

0.9370629::u87.
free_NW :- u87, action(swerve_left), \+ free_E.

0.1428571::u88.
free_NW :- u88, action(swerve_right), \+ free_E.

0.5313449::u89.
free_NW :- u89, action(change_to_left), free_E.

0.5877702::u90.
free_NW :- u90, action(change_to_right), free_E.

0.5075690::u91.
free_NW :- u91, action(cruise), free_E.

0.0435434::u92.
free_NW :- u92, action(keep), free_E.

0.9664356::u93.
free_NW :- u93, action(swerve_left), free_E.

0.8083582::u94.
free_NW :- u94, action(swerve_right), free_E.

