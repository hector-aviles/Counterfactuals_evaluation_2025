%%% Exogenous variables

0.1680363::u_action(change_to_left); 0.1701679::u_action(change_to_right); 0.4056299::u_action(cruise); 0.2538250::u_action(keep); 0.0014792::u_action(swerve_left); 0.0008617::u_action(swerve_right)
action(V) :- u_action(V).

0.5955606::u1.
free_SE :- u1.

0.6782990::u2.
free_SW :- u2.

0.7163726::u3.
free_W :- u3.

0.3858009::u4.
latent_collision :- u4.

0.4290690::u5.
curr_lane :- u5, action(change_to_left), \+ free_SE.

0.4759146::u6.
curr_lane :- u6, action(change_to_right), \+ free_SE.

0.4936839::u7.
curr_lane :- u7, action(cruise), \+ free_SE.

0.1371449::u8.
curr_lane :- u8, action(keep), \+ free_SE.

0.3478261::u9.
curr_lane :- u9, action(swerve_left), \+ free_SE.

0.9990010::u10.
curr_lane :- u10, action(swerve_right), \+ free_SE.

0.5364317::u11.
curr_lane :- u11, action(change_to_left), free_SE.

0.5482130::u12.
curr_lane :- u12, action(change_to_right), free_SE.

0.7121084::u13.
curr_lane :- u13, action(cruise), free_SE.

0.5994072::u14.
curr_lane :- u14, action(keep), free_SE.

0.8492593::u15.
curr_lane :- u15, action(swerve_left), free_SE.

0.9924338::u16.
curr_lane :- u16, action(swerve_right), free_SE.

0.5043413::u17.
free_E :- u17, action(change_to_left), \+ curr_lane, \+ free_SE.

0.5660704::u18.
free_E :- u18, action(change_to_right), \+ curr_lane, \+ free_SE.

0.3945553::u19.
free_E :- u19, action(cruise), \+ curr_lane, \+ free_SE.

0.5650123::u20.
free_E :- u20, action(keep), \+ curr_lane, \+ free_SE.

0.5166667::u21.
free_E :- u21, action(swerve_left), \+ curr_lane, \+ free_SE.

0.5000000::u22.
free_E :- u22, action(swerve_right), \+ curr_lane, \+ free_SE.

0.5037311::u23.
free_E :- u23, action(change_to_left), curr_lane, \+ free_SE.

0.5387510::u24.
free_E :- u24, action(change_to_right), curr_lane, \+ free_SE.

0.8049256::u25.
free_E :- u25, action(cruise), curr_lane, \+ free_SE.

0.9964359::u26.
free_E :- u26, action(keep), curr_lane, \+ free_SE.

0.9990010::u27.
free_E :- u27, action(swerve_left), curr_lane, \+ free_SE.

0.9990010::u28.
free_E :- u28, action(swerve_right), curr_lane, \+ free_SE.

0.5195513::u29.
free_E :- u29, action(change_to_left), \+ curr_lane, free_SE.

0.3987491::u30.
free_E :- u30, action(change_to_right), \+ curr_lane, free_SE.

0.6285863::u31.
free_E :- u31, action(cruise), \+ curr_lane, free_SE.

0.6576114::u32.
free_E :- u32, action(keep), \+ curr_lane, free_SE.

0.9017199::u33.
free_E :- u33, action(swerve_left), \+ curr_lane, free_SE.

0.9990010::u34.
free_E :- u34, action(swerve_right), \+ curr_lane, free_SE.

0.5984599::u35.
free_E :- u35, action(change_to_left), curr_lane, free_SE.

0.5376402::u36.
free_E :- u36, action(change_to_right), curr_lane, free_SE.

0.9300497::u37.
free_E :- u37, action(cruise), curr_lane, free_SE.

0.8883249::u38.
free_E :- u38, action(keep), curr_lane, free_SE.

0.9803751::u39.
free_E :- u39, action(swerve_left), curr_lane, free_SE.

0.9968234::u40.
free_E :- u40, action(swerve_right), curr_lane, free_SE.

0.4984550::u41.
free_NE :- u41, action(change_to_left), \+ curr_lane, \+ free_E, \+ free_NW.

0.5109658::u42.
free_NE :- u42, action(change_to_right), \+ curr_lane, \+ free_E, \+ free_NW.

0.4959404::u43.
free_NE :- u43, action(cruise), \+ curr_lane, \+ free_E, \+ free_NW.

0.2608158::u44.
free_NE :- u44, action(keep), \+ curr_lane, \+ free_E, \+ free_NW.

0.2000000::u45.
free_NE :- u45, action(swerve_left), \+ curr_lane, \+ free_E, \+ free_NW.

0.5000000::u46.
free_NE :- u46, action(swerve_right), \+ curr_lane, \+ free_E, \+ free_NW.

0.5326232::u47.
free_NE :- u47, action(change_to_left), curr_lane, \+ free_E, \+ free_NW.

0.5338554::u48.
free_NE :- u48, action(change_to_right), curr_lane, \+ free_E, \+ free_NW.

0.2712591::u49.
free_NE :- u49, action(cruise), curr_lane, \+ free_E, \+ free_NW.

0.0001866::u50.
free_NE :- u50, action(keep), curr_lane, \+ free_E, \+ free_NW.

0.2500000::u51.
free_NE :- u51, action(swerve_left), curr_lane, \+ free_E, \+ free_NW.

0.7500000::u52.
free_NE :- u52, action(swerve_right), curr_lane, \+ free_E, \+ free_NW.

0.4986296::u53.
free_NE :- u53, action(change_to_left), \+ curr_lane, free_E, \+ free_NW.

0.2403254::u54.
free_NE :- u54, action(change_to_right), \+ curr_lane, free_E, \+ free_NW.

0.4867473::u55.
free_NE :- u55, action(cruise), \+ curr_lane, free_E, \+ free_NW.

0.0101315::u56.
free_NE :- u56, action(keep), \+ curr_lane, free_E, \+ free_NW.

0.0009990::u57.
free_NE :- u57, action(swerve_left), \+ curr_lane, free_E, \+ free_NW.

0.5000000::u58.
free_NE :- u58, action(swerve_right), \+ curr_lane, free_E, \+ free_NW.

0.4730829::u59.
free_NE :- u59, action(change_to_left), curr_lane, free_E, \+ free_NW.

0.5236923::u60.
free_NE :- u60, action(change_to_right), curr_lane, free_E, \+ free_NW.

0.9077450::u61.
free_NE :- u61, action(cruise), curr_lane, free_E, \+ free_NW.

0.0011034::u62.
free_NE :- u62, action(keep), curr_lane, free_E, \+ free_NW.

0.2345679::u63.
free_NE :- u63, action(swerve_left), curr_lane, free_E, \+ free_NW.

0.7040498::u64.
free_NE :- u64, action(swerve_right), curr_lane, free_E, \+ free_NW.

0.4880493::u65.
free_NE :- u65, action(change_to_left), \+ curr_lane, \+ free_E, free_NW.

0.5108938::u66.
free_NE :- u66, action(change_to_right), \+ curr_lane, \+ free_E, free_NW.

0.5515636::u67.
free_NE :- u67, action(cruise), \+ curr_lane, \+ free_E, free_NW.

0.3980583::u68.
free_NE :- u68, action(keep), \+ curr_lane, \+ free_E, free_NW.

0.4408602::u69.
free_NE :- u69, action(swerve_left), \+ curr_lane, \+ free_E, free_NW.

0.5000000::u70.
free_NE :- u70, action(swerve_right), \+ curr_lane, \+ free_E, free_NW.

0.5005357::u71.
free_NE :- u71, action(change_to_left), curr_lane, \+ free_E, free_NW.

0.5035950::u72.
free_NE :- u72, action(change_to_right), curr_lane, \+ free_E, free_NW.

0.2034470::u73.
free_NE :- u73, action(cruise), curr_lane, \+ free_E, free_NW.

0.0060976::u74.
free_NE :- u74, action(keep), curr_lane, \+ free_E, free_NW.

0.0243902::u75.
free_NE :- u75, action(swerve_left), curr_lane, \+ free_E, free_NW.

0.0009990::u76.
free_NE :- u76, action(swerve_right), curr_lane, \+ free_E, free_NW.

0.4523846::u77.
free_NE :- u77, action(change_to_left), \+ curr_lane, free_E, free_NW.

0.6213505::u78.
free_NE :- u78, action(change_to_right), \+ curr_lane, free_E, free_NW.

0.4187729::u79.
free_NE :- u79, action(cruise), \+ curr_lane, free_E, free_NW.

0.4561598::u80.
free_NE :- u80, action(keep), \+ curr_lane, free_E, free_NW.

0.8349282::u81.
free_NE :- u81, action(swerve_left), \+ curr_lane, free_E, free_NW.

0.9990010::u82.
free_NE :- u82, action(swerve_right), \+ curr_lane, free_E, free_NW.

0.5026690::u83.
free_NE :- u83, action(change_to_left), curr_lane, free_E, free_NW.

0.5784618::u84.
free_NE :- u84, action(change_to_right), curr_lane, free_E, free_NW.

0.8929230::u85.
free_NE :- u85, action(cruise), curr_lane, free_E, free_NW.

0.0404371::u86.
free_NE :- u86, action(keep), curr_lane, free_E, free_NW.

0.9287315::u87.
free_NE :- u87, action(swerve_left), curr_lane, free_E, free_NW.

0.8926975::u88.
free_NE :- u88, action(swerve_right), curr_lane, free_E, free_NW.

0.4938415::u89.
free_NW :- u89, action(change_to_left), \+ free_SW.

0.4969470::u90.
free_NW :- u90, action(change_to_right), \+ free_SW.

0.4429892::u91.
free_NW :- u91, action(cruise), \+ free_SW.

0.4179080::u92.
free_NW :- u92, action(keep), \+ free_SW.

0.7738095::u93.
free_NW :- u93, action(swerve_left), \+ free_SW.

0.5360000::u94.
free_NW :- u94, action(swerve_right), \+ free_SW.

0.5278387::u95.
free_NW :- u95, action(change_to_left), free_SW.

0.5880376::u96.
free_NW :- u96, action(change_to_right), free_SW.

0.5876038::u97.
free_NW :- u97, action(cruise), free_SW.

0.0220042::u98.
free_NW :- u98, action(keep), free_SW.

0.9707143::u99.
free_NW :- u99, action(swerve_left), free_SW.

0.8282958::u100.
free_NW :- u100, action(swerve_right), free_SW.

