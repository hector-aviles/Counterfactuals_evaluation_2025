%%% Exogenous variables

0.1680513::u_action(change_to_left); 0.1699444::u_action(change_to_right); 0.4051937::u_action(cruise); 0.2544779::u_action(keep); 0.0014503::u_action(swerve_left); 0.0008825::u_action(swerve_right)
action(V) :- u_action(V).

0.5994861::u1.
free_SE :- u1.

0.6824269::u2.
free_SW :- u2.

0.7157891::u3.
free_W :- u3.

0.3858237::u4.
latent_collision :- u4.

0.4186941::u5.
curr_lane :- u5, action(change_to_left), \+ free_SE.

0.4692812::u6.
curr_lane :- u6, action(change_to_right), \+ free_SE.

0.4873813::u7.
curr_lane :- u7, action(cruise), \+ free_SE.

0.1369278::u8.
curr_lane :- u8, action(keep), \+ free_SE.

0.3684211::u9.
curr_lane :- u9, action(swerve_left), \+ free_SE.

0.9990010::u10.
curr_lane :- u10, action(swerve_right), \+ free_SE.

0.5409888::u11.
curr_lane :- u11, action(change_to_left), free_SE.

0.5571718::u12.
curr_lane :- u12, action(change_to_right), free_SE.

0.7125472::u13.
curr_lane :- u13, action(cruise), free_SE.

0.6033025::u14.
curr_lane :- u14, action(keep), free_SE.

0.8507576::u15.
curr_lane :- u15, action(swerve_left), free_SE.

0.9938575::u16.
curr_lane :- u16, action(swerve_right), free_SE.

0.5049456::u17.
free_E :- u17, action(change_to_left), \+ curr_lane, \+ free_SE.

0.5665100::u18.
free_E :- u18, action(change_to_right), \+ curr_lane, \+ free_SE.

0.3974076::u19.
free_E :- u19, action(cruise), \+ curr_lane, \+ free_SE.

0.5643695::u20.
free_E :- u20, action(keep), \+ curr_lane, \+ free_SE.

0.5166667::u21.
free_E :- u21, action(swerve_left), \+ curr_lane, \+ free_SE.

0.5000000::u22.
free_E :- u22, action(swerve_right), \+ curr_lane, \+ free_SE.

0.5269019::u23.
free_E :- u23, action(change_to_left), curr_lane, \+ free_SE.

0.5542718::u24.
free_E :- u24, action(change_to_right), curr_lane, \+ free_SE.

0.8230660::u25.
free_E :- u25, action(cruise), curr_lane, \+ free_SE.

0.9964666::u26.
free_E :- u26, action(keep), curr_lane, \+ free_SE.

0.9990010::u27.
free_E :- u27, action(swerve_left), curr_lane, \+ free_SE.

0.9990010::u28.
free_E :- u28, action(swerve_right), curr_lane, \+ free_SE.

0.5222145::u29.
free_E :- u29, action(change_to_left), \+ curr_lane, free_SE.

0.3977544::u30.
free_E :- u30, action(change_to_right), \+ curr_lane, free_SE.

0.6265278::u31.
free_E :- u31, action(cruise), \+ curr_lane, free_SE.

0.6594266::u32.
free_E :- u32, action(keep), \+ curr_lane, free_SE.

0.8832487::u33.
free_E :- u33, action(swerve_left), \+ curr_lane, free_SE.

0.9990010::u34.
free_E :- u34, action(swerve_right), \+ curr_lane, free_SE.

0.5842964::u35.
free_E :- u35, action(change_to_left), curr_lane, free_SE.

0.5228195::u36.
free_E :- u36, action(change_to_right), curr_lane, free_SE.

0.9251188::u37.
free_E :- u37, action(cruise), curr_lane, free_SE.

0.8784467::u38.
free_E :- u38, action(keep), curr_lane, free_SE.

0.9795191::u39.
free_E :- u39, action(swerve_left), curr_lane, free_SE.

0.9962917::u40.
free_E :- u40, action(swerve_right), curr_lane, free_SE.

0.5011427::u41.
free_NE :- u41, action(change_to_left), \+ curr_lane, \+ free_E, \+ free_NW.

0.5129352::u42.
free_NE :- u42, action(change_to_right), \+ curr_lane, \+ free_E, \+ free_NW.

0.4982100::u43.
free_NE :- u43, action(cruise), \+ curr_lane, \+ free_E, \+ free_NW.

0.2600260::u44.
free_NE :- u44, action(keep), \+ curr_lane, \+ free_E, \+ free_NW.

0.2000000::u45.
free_NE :- u45, action(swerve_left), \+ curr_lane, \+ free_E, \+ free_NW.

0.5000000::u46.
free_NE :- u46, action(swerve_right), \+ curr_lane, \+ free_E, \+ free_NW.

0.5339381::u47.
free_NE :- u47, action(change_to_left), curr_lane, \+ free_E, \+ free_NW.

0.5296633::u48.
free_NE :- u48, action(change_to_right), curr_lane, \+ free_E, \+ free_NW.

0.2712784::u49.
free_NE :- u49, action(cruise), curr_lane, \+ free_E, \+ free_NW.

0.0001129::u50.
free_NE :- u50, action(keep), curr_lane, \+ free_E, \+ free_NW.

0.9990010::u51.
free_NE :- u51, action(swerve_left), curr_lane, \+ free_E, \+ free_NW.

0.6666667::u52.
free_NE :- u52, action(swerve_right), curr_lane, \+ free_E, \+ free_NW.

0.4943295::u53.
free_NE :- u53, action(change_to_left), \+ curr_lane, free_E, \+ free_NW.

0.2412325::u54.
free_NE :- u54, action(change_to_right), \+ curr_lane, free_E, \+ free_NW.

0.4903341::u55.
free_NE :- u55, action(cruise), \+ curr_lane, free_E, \+ free_NW.

0.0099876::u56.
free_NE :- u56, action(keep), \+ curr_lane, free_E, \+ free_NW.

0.0009990::u57.
free_NE :- u57, action(swerve_left), \+ curr_lane, free_E, \+ free_NW.

0.5000000::u58.
free_NE :- u58, action(swerve_right), \+ curr_lane, free_E, \+ free_NW.

0.4695219::u59.
free_NE :- u59, action(change_to_left), curr_lane, free_E, \+ free_NW.

0.5230385::u60.
free_NE :- u60, action(change_to_right), curr_lane, free_E, \+ free_NW.

0.9076270::u61.
free_NE :- u61, action(cruise), curr_lane, free_E, \+ free_NW.

0.0009751::u62.
free_NE :- u62, action(keep), curr_lane, free_E, \+ free_NW.

0.2340426::u63.
free_NE :- u63, action(swerve_left), curr_lane, free_E, \+ free_NW.

0.6628571::u64.
free_NE :- u64, action(swerve_right), curr_lane, free_E, \+ free_NW.

0.4902027::u65.
free_NE :- u65, action(change_to_left), \+ curr_lane, \+ free_E, free_NW.

0.5094581::u66.
free_NE :- u66, action(change_to_right), \+ curr_lane, \+ free_E, free_NW.

0.5519965::u67.
free_NE :- u67, action(cruise), \+ curr_lane, \+ free_E, free_NW.

0.3214286::u68.
free_NE :- u68, action(keep), \+ curr_lane, \+ free_E, free_NW.

0.4255319::u69.
free_NE :- u69, action(swerve_left), \+ curr_lane, \+ free_E, free_NW.

0.5000000::u70.
free_NE :- u70, action(swerve_right), \+ curr_lane, \+ free_E, free_NW.

0.5001230::u71.
free_NE :- u71, action(change_to_left), curr_lane, \+ free_E, free_NW.

0.5031341::u72.
free_NE :- u72, action(change_to_right), curr_lane, \+ free_E, free_NW.

0.2012915::u73.
free_NE :- u73, action(cruise), curr_lane, \+ free_E, free_NW.

0.0119760::u74.
free_NE :- u74, action(keep), curr_lane, \+ free_E, free_NW.

0.0454545::u75.
free_NE :- u75, action(swerve_left), curr_lane, \+ free_E, free_NW.

0.5000000::u76.
free_NE :- u76, action(swerve_right), curr_lane, \+ free_E, free_NW.

0.4469123::u77.
free_NE :- u77, action(change_to_left), \+ curr_lane, free_E, free_NW.

0.6217925::u78.
free_NE :- u78, action(change_to_right), \+ curr_lane, free_E, free_NW.

0.4192163::u79.
free_NE :- u79, action(cruise), \+ curr_lane, free_E, free_NW.

0.4496788::u80.
free_NE :- u80, action(keep), \+ curr_lane, free_E, free_NW.

0.8040201::u81.
free_NE :- u81, action(swerve_left), \+ curr_lane, free_E, free_NW.

0.9990010::u82.
free_NE :- u82, action(swerve_right), \+ curr_lane, free_E, free_NW.

0.5016136::u83.
free_NE :- u83, action(change_to_left), curr_lane, free_E, free_NW.

0.5809316::u84.
free_NE :- u84, action(change_to_right), curr_lane, free_E, free_NW.

0.8940073::u85.
free_NE :- u85, action(cruise), curr_lane, free_E, free_NW.

0.0372872::u86.
free_NE :- u86, action(keep), curr_lane, free_E, free_NW.

0.9319853::u87.
free_NE :- u87, action(swerve_left), curr_lane, free_E, free_NW.

0.8997050::u88.
free_NE :- u88, action(swerve_right), curr_lane, free_E, free_NW.

0.5013011::u89.
free_NW :- u89, action(change_to_left), \+ free_SW.

0.5089544::u90.
free_NW :- u90, action(change_to_right), \+ free_SW.

0.4463667::u91.
free_NW :- u91, action(cruise), \+ free_SW.

0.4200497::u92.
free_NW :- u92, action(keep), \+ free_SW.

0.8095238::u93.
free_NW :- u93, action(swerve_left), \+ free_SW.

0.4927536::u94.
free_NW :- u94, action(swerve_right), \+ free_SW.

0.5188678::u95.
free_NW :- u95, action(change_to_left), free_SW.

0.5779757::u96.
free_NW :- u96, action(change_to_right), free_SW.

0.5845668::u97.
free_NW :- u97, action(cruise), free_SW.

0.0217209::u98.
free_NW :- u98, action(keep), free_SW.

0.9628551::u99.
free_NW :- u99, action(swerve_left), free_SW.

0.8194444::u100.
free_NW :- u100, action(swerve_right), free_SW.

