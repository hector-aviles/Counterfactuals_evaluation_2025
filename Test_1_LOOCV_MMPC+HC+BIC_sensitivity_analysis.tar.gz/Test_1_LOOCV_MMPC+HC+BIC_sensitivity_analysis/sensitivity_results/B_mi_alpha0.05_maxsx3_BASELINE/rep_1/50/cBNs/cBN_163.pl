%%% Exogenous variables

0.1683276::u_action(change_to_left); 0.1703998::u_action(change_to_right); 0.4052678::u_action(cruise); 0.2536763::u_action(keep); 0.0014710::u_action(swerve_left); 0.0008576::u_action(swerve_right)
action(V) :- u_action(V).

0.5951600::u1.
free_SE :- u1.

0.6777513::u2.
free_SW :- u2.

0.7164357::u3.
free_W :- u3.

0.3858912::u4.
latent_collision :- u4.

0.4292018::u5.
curr_lane :- u5, action(change_to_left), \+ free_SE.

0.4749198::u6.
curr_lane :- u6, action(change_to_right), \+ free_SE.

0.4940568::u7.
curr_lane :- u7, action(cruise), \+ free_SE.

0.1374105::u8.
curr_lane :- u8, action(keep), \+ free_SE.

0.3404255::u9.
curr_lane :- u9, action(swerve_left), \+ free_SE.

0.9990010::u10.
curr_lane :- u10, action(swerve_right), \+ free_SE.

0.5362436::u11.
curr_lane :- u11, action(change_to_left), free_SE.

0.5490979::u12.
curr_lane :- u12, action(change_to_right), free_SE.

0.7131974::u13.
curr_lane :- u13, action(cruise), free_SE.

0.6004101::u14.
curr_lane :- u14, action(keep), free_SE.

0.8470149::u15.
curr_lane :- u15, action(swerve_left), free_SE.

0.9936387::u16.
curr_lane :- u16, action(swerve_right), free_SE.

0.5068349::u17.
free_E :- u17, action(change_to_left), \+ curr_lane, \+ free_SE.

0.5672739::u18.
free_E :- u18, action(change_to_right), \+ curr_lane, \+ free_SE.

0.3948994::u19.
free_E :- u19, action(cruise), \+ curr_lane, \+ free_SE.

0.5638867::u20.
free_E :- u20, action(keep), \+ curr_lane, \+ free_SE.

0.5645161::u21.
free_E :- u21, action(swerve_left), \+ curr_lane, \+ free_SE.

0.5000000::u22.
free_E :- u22, action(swerve_right), \+ curr_lane, \+ free_SE.

0.5036718::u23.
free_E :- u23, action(change_to_left), curr_lane, \+ free_SE.

0.5395812::u24.
free_E :- u24, action(change_to_right), curr_lane, \+ free_SE.

0.8058579::u25.
free_E :- u25, action(cruise), curr_lane, \+ free_SE.

0.9962997::u26.
free_E :- u26, action(keep), curr_lane, \+ free_SE.

0.9990010::u27.
free_E :- u27, action(swerve_left), curr_lane, \+ free_SE.

0.9990010::u28.
free_E :- u28, action(swerve_right), curr_lane, \+ free_SE.

0.5215500::u29.
free_E :- u29, action(change_to_left), \+ curr_lane, free_SE.

0.3996110::u30.
free_E :- u30, action(change_to_right), \+ curr_lane, free_SE.

0.6283655::u31.
free_E :- u31, action(cruise), \+ curr_lane, free_SE.

0.6598446::u32.
free_E :- u32, action(keep), \+ curr_lane, free_SE.

0.9268293::u33.
free_E :- u33, action(swerve_left), \+ curr_lane, free_SE.

0.9990010::u34.
free_E :- u34, action(swerve_right), \+ curr_lane, free_SE.

0.5991391::u35.
free_E :- u35, action(change_to_left), curr_lane, free_SE.

0.5377470::u36.
free_E :- u36, action(change_to_right), curr_lane, free_SE.

0.9303438::u37.
free_E :- u37, action(cruise), curr_lane, free_SE.

0.8878647::u38.
free_E :- u38, action(keep), curr_lane, free_SE.

0.9744493::u39.
free_E :- u39, action(swerve_left), curr_lane, free_SE.

0.9961588::u40.
free_E :- u40, action(swerve_right), curr_lane, free_SE.

0.4966702::u41.
free_NE :- u41, action(change_to_left), \+ curr_lane, \+ free_E, \+ free_NW.

0.5048596::u42.
free_NE :- u42, action(change_to_right), \+ curr_lane, \+ free_E, \+ free_NW.

0.4946261::u43.
free_NE :- u43, action(cruise), \+ curr_lane, \+ free_E, \+ free_NW.

0.2626885::u44.
free_NE :- u44, action(keep), \+ curr_lane, \+ free_E, \+ free_NW.

0.5000000::u45.
free_NE :- u45, action(swerve_left), \+ curr_lane, \+ free_E, \+ free_NW.

0.5000000::u46.
free_NE :- u46, action(swerve_right), \+ curr_lane, \+ free_E, \+ free_NW.

0.5337561::u47.
free_NE :- u47, action(change_to_left), curr_lane, \+ free_E, \+ free_NW.

0.5296093::u48.
free_NE :- u48, action(change_to_right), curr_lane, \+ free_E, \+ free_NW.

0.2743200::u49.
free_NE :- u49, action(cruise), curr_lane, \+ free_E, \+ free_NW.

0.0002478::u50.
free_NE :- u50, action(keep), curr_lane, \+ free_E, \+ free_NW.

0.0009990::u51.
free_NE :- u51, action(swerve_left), curr_lane, \+ free_E, \+ free_NW.

0.5000000::u52.
free_NE :- u52, action(swerve_right), curr_lane, \+ free_E, \+ free_NW.

0.4982728::u53.
free_NE :- u53, action(change_to_left), \+ curr_lane, free_E, \+ free_NW.

0.2354764::u54.
free_NE :- u54, action(change_to_right), \+ curr_lane, free_E, \+ free_NW.

0.4833432::u55.
free_NE :- u55, action(cruise), \+ curr_lane, free_E, \+ free_NW.

0.0106485::u56.
free_NE :- u56, action(keep), \+ curr_lane, free_E, \+ free_NW.

0.0009990::u57.
free_NE :- u57, action(swerve_left), \+ curr_lane, free_E, \+ free_NW.

0.5000000::u58.
free_NE :- u58, action(swerve_right), \+ curr_lane, free_E, \+ free_NW.

0.4740324::u59.
free_NE :- u59, action(change_to_left), curr_lane, free_E, \+ free_NW.

0.5285701::u60.
free_NE :- u60, action(change_to_right), curr_lane, free_E, \+ free_NW.

0.9076452::u61.
free_NE :- u61, action(cruise), curr_lane, free_E, \+ free_NW.

0.0011104::u62.
free_NE :- u62, action(keep), curr_lane, free_E, \+ free_NW.

0.2068966::u63.
free_NE :- u63, action(swerve_left), curr_lane, free_E, \+ free_NW.

0.7236842::u64.
free_NE :- u64, action(swerve_right), curr_lane, free_E, \+ free_NW.

0.4871944::u65.
free_NE :- u65, action(change_to_left), \+ curr_lane, \+ free_E, free_NW.

0.5131271::u66.
free_NE :- u66, action(change_to_right), \+ curr_lane, \+ free_E, free_NW.

0.5541661::u67.
free_NE :- u67, action(cruise), \+ curr_lane, \+ free_E, free_NW.

0.4210526::u68.
free_NE :- u68, action(keep), \+ curr_lane, \+ free_E, free_NW.

0.5000000::u69.
free_NE :- u69, action(swerve_left), \+ curr_lane, \+ free_E, free_NW.

0.5000000::u70.
free_NE :- u70, action(swerve_right), \+ curr_lane, \+ free_E, free_NW.

0.5065982::u71.
free_NE :- u71, action(change_to_left), curr_lane, \+ free_E, free_NW.

0.5039917::u72.
free_NE :- u72, action(change_to_right), curr_lane, \+ free_E, free_NW.

0.2025266::u73.
free_NE :- u73, action(cruise), curr_lane, \+ free_E, free_NW.

0.0009990::u74.
free_NE :- u74, action(keep), curr_lane, \+ free_E, free_NW.

0.0009990::u75.
free_NE :- u75, action(swerve_left), curr_lane, \+ free_E, free_NW.

0.0009990::u76.
free_NE :- u76, action(swerve_right), curr_lane, \+ free_E, free_NW.

0.4523256::u77.
free_NE :- u77, action(change_to_left), \+ curr_lane, free_E, free_NW.

0.6232331::u78.
free_NE :- u78, action(change_to_right), \+ curr_lane, free_E, free_NW.

0.4188142::u79.
free_NE :- u79, action(cruise), \+ curr_lane, free_E, free_NW.

0.4649123::u80.
free_NE :- u80, action(keep), \+ curr_lane, free_E, free_NW.

0.8181818::u81.
free_NE :- u81, action(swerve_left), \+ curr_lane, free_E, free_NW.

0.9990010::u82.
free_NE :- u82, action(swerve_right), \+ curr_lane, free_E, free_NW.

0.5029514::u83.
free_NE :- u83, action(change_to_left), curr_lane, free_E, free_NW.

0.5775049::u84.
free_NE :- u84, action(change_to_right), curr_lane, free_E, free_NW.

0.8921961::u85.
free_NE :- u85, action(cruise), curr_lane, free_E, free_NW.

0.0381415::u86.
free_NE :- u86, action(keep), curr_lane, free_E, free_NW.

0.9341749::u87.
free_NE :- u87, action(swerve_left), curr_lane, free_E, free_NW.

0.9023669::u88.
free_NE :- u88, action(swerve_right), curr_lane, free_E, free_NW.

0.4940854::u89.
free_NW :- u89, action(change_to_left), \+ free_SW.

0.4966405::u90.
free_NW :- u90, action(change_to_right), \+ free_SW.

0.4438132::u91.
free_NW :- u91, action(cruise), \+ free_SW.

0.4156372::u92.
free_NW :- u92, action(keep), \+ free_SW.

0.7837838::u93.
free_NW :- u93, action(swerve_left), \+ free_SW.

0.5588235::u94.
free_NW :- u94, action(swerve_right), \+ free_SW.

0.5278040::u95.
free_NW :- u95, action(change_to_left), free_SW.

0.5899997::u96.
free_NW :- u96, action(change_to_right), free_SW.

0.5881161::u97.
free_NW :- u97, action(cruise), free_SW.

0.0221157::u98.
free_NW :- u98, action(keep), free_SW.

0.9806729::u99.
free_NW :- u99, action(swerve_left), free_SW.

0.8385417::u100.
free_NW :- u100, action(swerve_right), free_SW.

