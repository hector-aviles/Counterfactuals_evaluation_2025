%%% Exogenous variables

0.1682593::u_action(change_to_left); 0.1700100::u_action(change_to_right); 0.4049409::u_action(cruise); 0.2544805::u_action(keep); 0.0014698::u_action(swerve_left); 0.0008395::u_action(swerve_right)
action(V) :- u_action(V).

0.5960011::u1.
free_SE :- u1.

0.6783396::u2.
free_SW :- u2.

0.7155836::u3.
free_W :- u3.

0.3855234::u4.
latent_collision :- u4.

0.4271774::u5.
curr_lane :- u5, action(change_to_left), \+ free_SE.

0.4747371::u6.
curr_lane :- u6, action(change_to_right), \+ free_SE.

0.4920064::u7.
curr_lane :- u7, action(cruise), \+ free_SE.

0.1371909::u8.
curr_lane :- u8, action(keep), \+ free_SE.

0.3678161::u9.
curr_lane :- u9, action(swerve_left), \+ free_SE.

0.9990010::u10.
curr_lane :- u10, action(swerve_right), \+ free_SE.

0.5363235::u11.
curr_lane :- u11, action(change_to_left), free_SE.

0.5477331::u12.
curr_lane :- u12, action(change_to_right), free_SE.

0.7121463::u13.
curr_lane :- u13, action(cruise), free_SE.

0.6025300::u14.
curr_lane :- u14, action(keep), free_SE.

0.8530067::u15.
curr_lane :- u15, action(swerve_left), free_SE.

0.9935149::u16.
curr_lane :- u16, action(swerve_right), free_SE.

0.5062841::u17.
free_E :- u17, action(change_to_left), \+ curr_lane, \+ free_SE.

0.5694566::u18.
free_E :- u18, action(change_to_right), \+ curr_lane, \+ free_SE.

0.3931301::u19.
free_E :- u19, action(cruise), \+ curr_lane, \+ free_SE.

0.5652386::u20.
free_E :- u20, action(keep), \+ curr_lane, \+ free_SE.

0.4545455::u21.
free_E :- u21, action(swerve_left), \+ curr_lane, \+ free_SE.

0.5000000::u22.
free_E :- u22, action(swerve_right), \+ curr_lane, \+ free_SE.

0.5035550::u23.
free_E :- u23, action(change_to_left), curr_lane, \+ free_SE.

0.5380104::u24.
free_E :- u24, action(change_to_right), curr_lane, \+ free_SE.

0.8048046::u25.
free_E :- u25, action(cruise), curr_lane, \+ free_SE.

0.9965864::u26.
free_E :- u26, action(keep), curr_lane, \+ free_SE.

0.9990010::u27.
free_E :- u27, action(swerve_left), curr_lane, \+ free_SE.

0.9990010::u28.
free_E :- u28, action(swerve_right), curr_lane, \+ free_SE.

0.5209782::u29.
free_E :- u29, action(change_to_left), \+ curr_lane, free_SE.

0.3993392::u30.
free_E :- u30, action(change_to_right), \+ curr_lane, free_SE.

0.6272227::u31.
free_E :- u31, action(cruise), \+ curr_lane, free_SE.

0.6564692::u32.
free_E :- u32, action(keep), \+ curr_lane, free_SE.

0.8939394::u33.
free_E :- u33, action(swerve_left), \+ curr_lane, free_SE.

0.9990010::u34.
free_E :- u34, action(swerve_right), \+ curr_lane, free_SE.

0.5988697::u35.
free_E :- u35, action(change_to_left), curr_lane, free_SE.

0.5394446::u36.
free_E :- u36, action(change_to_right), curr_lane, free_SE.

0.9302584::u37.
free_E :- u37, action(cruise), curr_lane, free_SE.

0.8783725::u38.
free_E :- u38, action(keep), curr_lane, free_SE.

0.9808529::u39.
free_E :- u39, action(swerve_left), curr_lane, free_SE.

0.9973890::u40.
free_E :- u40, action(swerve_right), curr_lane, free_SE.

0.4982491::u41.
free_NE :- u41, action(change_to_left), \+ curr_lane, \+ free_E, \+ free_NW.

0.5102270::u42.
free_NE :- u42, action(change_to_right), \+ curr_lane, \+ free_E, \+ free_NW.

0.4933716::u43.
free_NE :- u43, action(cruise), \+ curr_lane, \+ free_E, \+ free_NW.

0.2623928::u44.
free_NE :- u44, action(keep), \+ curr_lane, \+ free_E, \+ free_NW.

0.0009990::u45.
free_NE :- u45, action(swerve_left), \+ curr_lane, \+ free_E, \+ free_NW.

0.5000000::u46.
free_NE :- u46, action(swerve_right), \+ curr_lane, \+ free_E, \+ free_NW.

0.4997000::u47.
free_NE :- u47, action(change_to_left), curr_lane, \+ free_E, \+ free_NW.

0.5004499::u48.
free_NE :- u48, action(change_to_right), curr_lane, \+ free_E, \+ free_NW.

0.2484839::u49.
free_NE :- u49, action(cruise), curr_lane, \+ free_E, \+ free_NW.

0.0002249::u50.
free_NE :- u50, action(keep), curr_lane, \+ free_E, \+ free_NW.

0.5000000::u51.
free_NE :- u51, action(swerve_left), curr_lane, \+ free_E, \+ free_NW.

0.9990010::u52.
free_NE :- u52, action(swerve_right), curr_lane, \+ free_E, \+ free_NW.

0.4997273::u53.
free_NE :- u53, action(change_to_left), \+ curr_lane, free_E, \+ free_NW.

0.2409810::u54.
free_NE :- u54, action(change_to_right), \+ curr_lane, free_E, \+ free_NW.

0.4941535::u55.
free_NE :- u55, action(cruise), \+ curr_lane, free_E, \+ free_NW.

0.0101925::u56.
free_NE :- u56, action(keep), \+ curr_lane, free_E, \+ free_NW.

0.0009990::u57.
free_NE :- u57, action(swerve_left), \+ curr_lane, free_E, \+ free_NW.

0.5000000::u58.
free_NE :- u58, action(swerve_right), \+ curr_lane, free_E, \+ free_NW.

0.4720676::u59.
free_NE :- u59, action(change_to_left), curr_lane, free_E, \+ free_NW.

0.5230155::u60.
free_NE :- u60, action(change_to_right), curr_lane, free_E, \+ free_NW.

0.9069010::u61.
free_NE :- u61, action(cruise), curr_lane, free_E, \+ free_NW.

0.0010168::u62.
free_NE :- u62, action(keep), curr_lane, free_E, \+ free_NW.

0.1891892::u63.
free_NE :- u63, action(swerve_left), curr_lane, free_E, \+ free_NW.

0.7115385::u64.
free_NE :- u64, action(swerve_right), curr_lane, free_E, \+ free_NW.

0.4909563::u65.
free_NE :- u65, action(change_to_left), \+ curr_lane, \+ free_E, free_NW.

0.5098990::u66.
free_NE :- u66, action(change_to_right), \+ curr_lane, \+ free_E, free_NW.

0.5519752::u67.
free_NE :- u67, action(cruise), \+ curr_lane, \+ free_E, free_NW.

0.4081633::u68.
free_NE :- u68, action(keep), \+ curr_lane, \+ free_E, free_NW.

0.5306122::u69.
free_NE :- u69, action(swerve_left), \+ curr_lane, \+ free_E, free_NW.

0.5000000::u70.
free_NE :- u70, action(swerve_right), \+ curr_lane, \+ free_E, free_NW.

0.5443046::u71.
free_NE :- u71, action(change_to_left), curr_lane, \+ free_E, free_NW.

0.5343536::u72.
free_NE :- u72, action(change_to_right), curr_lane, \+ free_E, free_NW.

0.2269754::u73.
free_NE :- u73, action(cruise), curr_lane, \+ free_E, free_NW.

0.0157480::u74.
free_NE :- u74, action(keep), curr_lane, \+ free_E, free_NW.

0.0500000::u75.
free_NE :- u75, action(swerve_left), curr_lane, \+ free_E, free_NW.

0.5000000::u76.
free_NE :- u76, action(swerve_right), curr_lane, \+ free_E, free_NW.

0.4510924::u77.
free_NE :- u77, action(change_to_left), \+ curr_lane, free_E, free_NW.

0.6253220::u78.
free_NE :- u78, action(change_to_right), \+ curr_lane, free_E, free_NW.

0.4168159::u79.
free_NE :- u79, action(cruise), \+ curr_lane, free_E, free_NW.

0.4454545::u80.
free_NE :- u80, action(keep), \+ curr_lane, free_E, free_NW.

0.8214286::u81.
free_NE :- u81, action(swerve_left), \+ curr_lane, free_E, free_NW.

0.9990010::u82.
free_NE :- u82, action(swerve_right), \+ curr_lane, free_E, free_NW.

0.5017718::u83.
free_NE :- u83, action(change_to_left), curr_lane, free_E, free_NW.

0.5784721::u84.
free_NE :- u84, action(change_to_right), curr_lane, free_E, free_NW.

0.8938728::u85.
free_NE :- u85, action(cruise), curr_lane, free_E, free_NW.

0.0376180::u86.
free_NE :- u86, action(keep), curr_lane, free_E, free_NW.

0.9304813::u87.
free_NE :- u87, action(swerve_left), curr_lane, free_E, free_NW.

0.8948171::u88.
free_NE :- u88, action(swerve_right), curr_lane, free_E, free_NW.

0.4951657::u89.
free_NW :- u89, action(change_to_left), \+ free_SW.

0.4977427::u90.
free_NW :- u90, action(change_to_right), \+ free_SW.

0.4425206::u91.
free_NW :- u91, action(cruise), \+ free_SW.

0.4212407::u92.
free_NW :- u92, action(keep), \+ free_SW.

0.7368421::u93.
free_NW :- u93, action(swerve_left), \+ free_SW.

0.5873016::u94.
free_NW :- u94, action(swerve_right), \+ free_SW.

0.5131850::u95.
free_NW :- u95, action(change_to_left), free_SW.

0.5738313::u96.
free_NW :- u96, action(change_to_right), free_SW.

0.5834743::u97.
free_NW :- u97, action(cruise), free_SW.

0.0215845::u98.
free_NW :- u98, action(keep), free_SW.

0.9734957::u99.
free_NW :- u99, action(swerve_left), free_SW.

0.8253968::u100.
free_NW :- u100, action(swerve_right), free_SW.

