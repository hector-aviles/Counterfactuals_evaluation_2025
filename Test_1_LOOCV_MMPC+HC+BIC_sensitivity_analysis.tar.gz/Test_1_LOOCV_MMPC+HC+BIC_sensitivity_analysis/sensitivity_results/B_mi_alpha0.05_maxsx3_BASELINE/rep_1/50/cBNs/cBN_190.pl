%%% Exogenous variables

0.1682857::u_action(change_to_left); 0.1694843::u_action(change_to_right); 0.4056088::u_action(cruise); 0.2542720::u_action(keep); 0.0014801::u_action(swerve_left); 0.0008690::u_action(swerve_right)
action(V) :- u_action(V).

0.5989596::u1.
free_SE :- u1.

0.6808177::u2.
free_SW :- u2.

0.7148436::u3.
free_W :- u3.

0.3865276::u4.
latent_collision :- u4.

0.4174366::u5.
curr_lane :- u5, action(change_to_left), \+ free_SE.

0.4682643::u6.
curr_lane :- u6, action(change_to_right), \+ free_SE.

0.4935893::u7.
curr_lane :- u7, action(cruise), \+ free_SE.

0.1367765::u8.
curr_lane :- u8, action(keep), \+ free_SE.

0.4042553::u9.
curr_lane :- u9, action(swerve_left), \+ free_SE.

0.9990010::u10.
curr_lane :- u10, action(swerve_right), \+ free_SE.

0.5414344::u11.
curr_lane :- u11, action(change_to_left), free_SE.

0.5539264::u12.
curr_lane :- u12, action(change_to_right), free_SE.

0.7136043::u13.
curr_lane :- u13, action(cruise), free_SE.

0.6034509::u14.
curr_lane :- u14, action(keep), free_SE.

0.8491124::u15.
curr_lane :- u15, action(swerve_left), free_SE.

0.9950249::u16.
curr_lane :- u16, action(swerve_right), free_SE.

0.5055106::u17.
free_E :- u17, action(change_to_left), \+ curr_lane, \+ free_SE.

0.5670797::u18.
free_E :- u18, action(change_to_right), \+ curr_lane, \+ free_SE.

0.3948131::u19.
free_E :- u19, action(cruise), \+ curr_lane, \+ free_SE.

0.5638264::u20.
free_E :- u20, action(keep), \+ curr_lane, \+ free_SE.

0.5892857::u21.
free_E :- u21, action(swerve_left), \+ curr_lane, \+ free_SE.

0.5000000::u22.
free_E :- u22, action(swerve_right), \+ curr_lane, \+ free_SE.

0.5244185::u23.
free_E :- u23, action(change_to_left), curr_lane, \+ free_SE.

0.5563728::u24.
free_E :- u24, action(change_to_right), curr_lane, \+ free_SE.

0.8038686::u25.
free_E :- u25, action(cruise), curr_lane, \+ free_SE.

0.9965688::u26.
free_E :- u26, action(keep), curr_lane, \+ free_SE.

0.9990010::u27.
free_E :- u27, action(swerve_left), curr_lane, \+ free_SE.

0.9990010::u28.
free_E :- u28, action(swerve_right), curr_lane, \+ free_SE.

0.5202529::u29.
free_E :- u29, action(change_to_left), \+ curr_lane, free_SE.

0.3950101::u30.
free_E :- u30, action(change_to_right), \+ curr_lane, free_SE.

0.6289865::u31.
free_E :- u31, action(cruise), \+ curr_lane, free_SE.

0.6586233::u32.
free_E :- u32, action(keep), \+ curr_lane, free_SE.

0.9215686::u33.
free_E :- u33, action(swerve_left), \+ curr_lane, free_SE.

0.9990010::u34.
free_E :- u34, action(swerve_right), \+ curr_lane, free_SE.

0.5859323::u35.
free_E :- u35, action(change_to_left), curr_lane, free_SE.

0.5221224::u36.
free_E :- u36, action(change_to_right), curr_lane, free_SE.

0.9251466::u37.
free_E :- u37, action(cruise), curr_lane, free_SE.

0.8781301::u38.
free_E :- u38, action(keep), curr_lane, free_SE.

0.9808362::u39.
free_E :- u39, action(swerve_left), curr_lane, free_SE.

0.9987500::u40.
free_E :- u40, action(swerve_right), curr_lane, free_SE.

0.4952722::u41.
free_NE :- u41, action(change_to_left), \+ curr_lane, \+ free_E, \+ free_NW.

0.5138159::u42.
free_NE :- u42, action(change_to_right), \+ curr_lane, \+ free_E, \+ free_NW.

0.5016224::u43.
free_NE :- u43, action(cruise), \+ curr_lane, \+ free_E, \+ free_NW.

0.2605844::u44.
free_NE :- u44, action(keep), \+ curr_lane, \+ free_E, \+ free_NW.

0.5000000::u45.
free_NE :- u45, action(swerve_left), \+ curr_lane, \+ free_E, \+ free_NW.

0.5000000::u46.
free_NE :- u46, action(swerve_right), \+ curr_lane, \+ free_E, \+ free_NW.

0.4655862::u47.
free_NE :- u47, action(change_to_left), curr_lane, \+ free_E, \+ free_NW.

0.4707631::u48.
free_NE :- u48, action(change_to_right), curr_lane, \+ free_E, \+ free_NW.

0.2419355::u49.
free_NE :- u49, action(cruise), curr_lane, \+ free_E, \+ free_NW.

0.0002246::u50.
free_NE :- u50, action(keep), curr_lane, \+ free_E, \+ free_NW.

0.0009990::u51.
free_NE :- u51, action(swerve_left), curr_lane, \+ free_E, \+ free_NW.

0.9990010::u52.
free_NE :- u52, action(swerve_right), curr_lane, \+ free_E, \+ free_NW.

0.4956698::u53.
free_NE :- u53, action(change_to_left), \+ curr_lane, free_E, \+ free_NW.

0.2431347::u54.
free_NE :- u54, action(change_to_right), \+ curr_lane, free_E, \+ free_NW.

0.4908149::u55.
free_NE :- u55, action(cruise), \+ curr_lane, free_E, \+ free_NW.

0.0099475::u56.
free_NE :- u56, action(keep), \+ curr_lane, free_E, \+ free_NW.

0.0009990::u57.
free_NE :- u57, action(swerve_left), \+ curr_lane, free_E, \+ free_NW.

0.5000000::u58.
free_NE :- u58, action(swerve_right), \+ curr_lane, free_E, \+ free_NW.

0.4698953::u59.
free_NE :- u59, action(change_to_left), curr_lane, free_E, \+ free_NW.

0.5253276::u60.
free_NE :- u60, action(change_to_right), curr_lane, free_E, \+ free_NW.

0.9077550::u61.
free_NE :- u61, action(cruise), curr_lane, free_E, \+ free_NW.

0.0009744::u62.
free_NE :- u62, action(keep), curr_lane, free_E, \+ free_NW.

0.2142857::u63.
free_NE :- u63, action(swerve_left), curr_lane, free_E, \+ free_NW.

0.7218935::u64.
free_NE :- u64, action(swerve_right), curr_lane, free_E, \+ free_NW.

0.4865267::u65.
free_NE :- u65, action(change_to_left), \+ curr_lane, \+ free_E, free_NW.

0.5089750::u66.
free_NE :- u66, action(change_to_right), \+ curr_lane, \+ free_E, free_NW.

0.5512547::u67.
free_NE :- u67, action(cruise), \+ curr_lane, \+ free_E, free_NW.

0.4615385::u68.
free_NE :- u68, action(keep), \+ curr_lane, \+ free_E, free_NW.

0.4054054::u69.
free_NE :- u69, action(swerve_left), \+ curr_lane, \+ free_E, free_NW.

0.5000000::u70.
free_NE :- u70, action(swerve_right), \+ curr_lane, \+ free_E, free_NW.

0.5052154::u71.
free_NE :- u71, action(change_to_left), curr_lane, \+ free_E, free_NW.

0.5023023::u72.
free_NE :- u72, action(change_to_right), curr_lane, \+ free_E, free_NW.

0.2018970::u73.
free_NE :- u73, action(cruise), curr_lane, \+ free_E, free_NW.

0.0112360::u74.
free_NE :- u74, action(keep), curr_lane, \+ free_E, free_NW.

0.0500000::u75.
free_NE :- u75, action(swerve_left), curr_lane, \+ free_E, free_NW.

0.5000000::u76.
free_NE :- u76, action(swerve_right), curr_lane, \+ free_E, free_NW.

0.4492002::u77.
free_NE :- u77, action(change_to_left), \+ curr_lane, free_E, free_NW.

0.6241220::u78.
free_NE :- u78, action(change_to_right), \+ curr_lane, free_E, free_NW.

0.4190352::u79.
free_NE :- u79, action(cruise), \+ curr_lane, free_E, free_NW.

0.4346847::u80.
free_NE :- u80, action(keep), \+ curr_lane, free_E, free_NW.

0.8598131::u81.
free_NE :- u81, action(swerve_left), \+ curr_lane, free_E, free_NW.

0.9990010::u82.
free_NE :- u82, action(swerve_right), \+ curr_lane, free_E, free_NW.

0.5035088::u83.
free_NE :- u83, action(change_to_left), curr_lane, free_E, free_NW.

0.5801488::u84.
free_NE :- u84, action(change_to_right), curr_lane, free_E, free_NW.

0.8931816::u85.
free_NE :- u85, action(cruise), curr_lane, free_E, free_NW.

0.0431476::u86.
free_NE :- u86, action(keep), curr_lane, free_E, free_NW.

0.9251337::u87.
free_NE :- u87, action(swerve_left), curr_lane, free_E, free_NW.

0.8918519::u88.
free_NE :- u88, action(swerve_right), curr_lane, free_E, free_NW.

0.5008138::u89.
free_NW :- u89, action(change_to_left), \+ free_SW.

0.5081214::u90.
free_NW :- u90, action(change_to_right), \+ free_SW.

0.4416266::u91.
free_NW :- u91, action(cruise), \+ free_SW.

0.4205988::u92.
free_NW :- u92, action(keep), \+ free_SW.

0.7843137::u93.
free_NW :- u93, action(swerve_left), \+ free_SW.

0.5245902::u94.
free_NW :- u94, action(swerve_right), \+ free_SW.

0.5206516::u95.
free_NW :- u95, action(change_to_left), free_SW.

0.5826905::u96.
free_NW :- u96, action(change_to_right), free_SW.

0.5842479::u97.
free_NW :- u97, action(cruise), free_SW.

0.0219598::u98.
free_NW :- u98, action(keep), free_SW.

0.9698925::u99.
free_NW :- u99, action(swerve_left), free_SW.

0.8210660::u100.
free_NW :- u100, action(swerve_right), free_SW.

