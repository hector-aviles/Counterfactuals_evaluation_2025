%%% Exogenous variables

0.1689301::u_action(change_to_left); 0.1694177::u_action(change_to_right); 0.4058875::u_action(cruise); 0.2533593::u_action(keep); 0.0015335::u_action(swerve_left); 0.0008720::u_action(swerve_right)
action(V) :- u_action(V).

0.5985023::u1.
free_SE :- u1.

0.6802685::u2.
free_SW :- u2.

0.7128463::u3.
free_W :- u3.

0.3871087::u4.
latent_collision :- u4.

0.4288876::u5.
curr_lane :- u5, action(change_to_left), \+ free_SE.

0.4688609::u6.
curr_lane :- u6, action(change_to_right), \+ free_SE.

0.4942894::u7.
curr_lane :- u7, action(cruise), \+ free_SE.

0.1361290::u8.
curr_lane :- u8, action(keep), \+ free_SE.

0.3700000::u9.
curr_lane :- u9, action(swerve_left), \+ free_SE.

0.9990010::u10.
curr_lane :- u10, action(swerve_right), \+ free_SE.

0.5409164::u11.
curr_lane :- u11, action(change_to_left), free_SE.

0.5557643::u12.
curr_lane :- u12, action(change_to_right), free_SE.

0.7126843::u13.
curr_lane :- u13, action(cruise), free_SE.

0.6010746::u14.
curr_lane :- u14, action(keep), free_SE.

0.8528571::u15.
curr_lane :- u15, action(swerve_left), free_SE.

0.9913473::u16.
curr_lane :- u16, action(swerve_right), free_SE.

0.5017904::u17.
free_E :- u17, action(change_to_left), \+ curr_lane, \+ free_SE.

0.5655089::u18.
free_E :- u18, action(change_to_right), \+ curr_lane, \+ free_SE.

0.3949208::u19.
free_E :- u19, action(cruise), \+ curr_lane, \+ free_SE.

0.5646558::u20.
free_E :- u20, action(keep), \+ curr_lane, \+ free_SE.

0.4761905::u21.
free_E :- u21, action(swerve_left), \+ curr_lane, \+ free_SE.

0.5000000::u22.
free_E :- u22, action(swerve_right), \+ curr_lane, \+ free_SE.

0.5056826::u23.
free_E :- u23, action(change_to_left), curr_lane, \+ free_SE.

0.5564888::u24.
free_E :- u24, action(change_to_right), curr_lane, \+ free_SE.

0.8066539::u25.
free_E :- u25, action(cruise), curr_lane, \+ free_SE.

0.9962553::u26.
free_E :- u26, action(keep), curr_lane, \+ free_SE.

0.9990010::u27.
free_E :- u27, action(swerve_left), curr_lane, \+ free_SE.

0.9990010::u28.
free_E :- u28, action(swerve_right), curr_lane, \+ free_SE.

0.5191366::u29.
free_E :- u29, action(change_to_left), \+ curr_lane, free_SE.

0.4009055::u30.
free_E :- u30, action(change_to_right), \+ curr_lane, free_SE.

0.6275072::u31.
free_E :- u31, action(cruise), \+ curr_lane, free_SE.

0.6582071::u32.
free_E :- u32, action(keep), \+ curr_lane, free_SE.

0.9029126::u33.
free_E :- u33, action(swerve_left), \+ curr_lane, free_SE.

0.9990010::u34.
free_E :- u34, action(swerve_right), \+ curr_lane, free_SE.

0.5835714::u35.
free_E :- u35, action(change_to_left), curr_lane, free_SE.

0.5209152::u36.
free_E :- u36, action(change_to_right), curr_lane, free_SE.

0.9242995::u37.
free_E :- u37, action(cruise), curr_lane, free_SE.

0.8771429::u38.
free_E :- u38, action(keep), curr_lane, free_SE.

0.9782245::u39.
free_E :- u39, action(swerve_left), curr_lane, free_SE.

0.9937656::u40.
free_E :- u40, action(swerve_right), curr_lane, free_SE.

0.5027728::u41.
free_NE :- u41, action(change_to_left), \+ curr_lane, \+ free_E, \+ free_NW.

0.5109432::u42.
free_NE :- u42, action(change_to_right), \+ curr_lane, \+ free_E, \+ free_NW.

0.4946614::u43.
free_NE :- u43, action(cruise), \+ curr_lane, \+ free_E, \+ free_NW.

0.2615132::u44.
free_NE :- u44, action(keep), \+ curr_lane, \+ free_E, \+ free_NW.

0.0009990::u45.
free_NE :- u45, action(swerve_left), \+ curr_lane, \+ free_E, \+ free_NW.

0.5000000::u46.
free_NE :- u46, action(swerve_right), \+ curr_lane, \+ free_E, \+ free_NW.

0.5017082::u47.
free_NE :- u47, action(change_to_left), curr_lane, \+ free_E, \+ free_NW.

0.5012525::u48.
free_NE :- u48, action(change_to_right), curr_lane, \+ free_E, \+ free_NW.

0.2515504::u49.
free_NE :- u49, action(cruise), curr_lane, \+ free_E, \+ free_NW.

0.0009990::u50.
free_NE :- u50, action(keep), curr_lane, \+ free_E, \+ free_NW.

0.9990010::u51.
free_NE :- u51, action(swerve_left), curr_lane, \+ free_E, \+ free_NW.

0.6000000::u52.
free_NE :- u52, action(swerve_right), curr_lane, \+ free_E, \+ free_NW.

0.4985813::u53.
free_NE :- u53, action(change_to_left), \+ curr_lane, free_E, \+ free_NW.

0.2427995::u54.
free_NE :- u54, action(change_to_right), \+ curr_lane, free_E, \+ free_NW.

0.4900692::u55.
free_NE :- u55, action(cruise), \+ curr_lane, free_E, \+ free_NW.

0.0100656::u56.
free_NE :- u56, action(keep), \+ curr_lane, free_E, \+ free_NW.

0.0009990::u57.
free_NE :- u57, action(swerve_left), \+ curr_lane, free_E, \+ free_NW.

0.5000000::u58.
free_NE :- u58, action(swerve_right), \+ curr_lane, free_E, \+ free_NW.

0.4712437::u59.
free_NE :- u59, action(change_to_left), curr_lane, free_E, \+ free_NW.

0.5209819::u60.
free_NE :- u60, action(change_to_right), curr_lane, free_E, \+ free_NW.

0.9080147::u61.
free_NE :- u61, action(cruise), curr_lane, free_E, \+ free_NW.

0.0011164::u62.
free_NE :- u62, action(keep), curr_lane, free_E, \+ free_NW.

0.2000000::u63.
free_NE :- u63, action(swerve_left), curr_lane, free_E, \+ free_NW.

0.7048193::u64.
free_NE :- u64, action(swerve_right), curr_lane, free_E, \+ free_NW.

0.4882415::u65.
free_NE :- u65, action(change_to_left), \+ curr_lane, \+ free_E, free_NW.

0.5138712::u66.
free_NE :- u66, action(change_to_right), \+ curr_lane, \+ free_E, free_NW.

0.5499439::u67.
free_NE :- u67, action(cruise), \+ curr_lane, \+ free_E, free_NW.

0.4400000::u68.
free_NE :- u68, action(keep), \+ curr_lane, \+ free_E, free_NW.

0.4600000::u69.
free_NE :- u69, action(swerve_left), \+ curr_lane, \+ free_E, free_NW.

0.5000000::u70.
free_NE :- u70, action(swerve_right), \+ curr_lane, \+ free_E, free_NW.

0.4976179::u71.
free_NE :- u71, action(change_to_left), curr_lane, \+ free_E, free_NW.

0.4681616::u72.
free_NE :- u72, action(change_to_right), curr_lane, \+ free_E, free_NW.

0.2054969::u73.
free_NE :- u73, action(cruise), curr_lane, \+ free_E, free_NW.

0.0120482::u74.
free_NE :- u74, action(keep), curr_lane, \+ free_E, free_NW.

0.0400000::u75.
free_NE :- u75, action(swerve_left), curr_lane, \+ free_E, free_NW.

0.5000000::u76.
free_NE :- u76, action(swerve_right), curr_lane, \+ free_E, free_NW.

0.4528103::u77.
free_NE :- u77, action(change_to_left), \+ curr_lane, free_E, free_NW.

0.6219979::u78.
free_NE :- u78, action(change_to_right), \+ curr_lane, free_E, free_NW.

0.4174047::u79.
free_NE :- u79, action(cruise), \+ curr_lane, free_E, free_NW.

0.4291939::u80.
free_NE :- u80, action(keep), \+ curr_lane, free_E, free_NW.

0.8238095::u81.
free_NE :- u81, action(swerve_left), \+ curr_lane, free_E, free_NW.

0.9990010::u82.
free_NE :- u82, action(swerve_right), \+ curr_lane, free_E, free_NW.

0.5013581::u83.
free_NE :- u83, action(change_to_left), curr_lane, free_E, free_NW.

0.5813104::u84.
free_NE :- u84, action(change_to_right), curr_lane, free_E, free_NW.

0.8919107::u85.
free_NE :- u85, action(cruise), curr_lane, free_E, free_NW.

0.0395804::u86.
free_NE :- u86, action(keep), curr_lane, free_E, free_NW.

0.9316239::u87.
free_NE :- u87, action(swerve_left), curr_lane, free_E, free_NW.

0.9066667::u88.
free_NE :- u88, action(swerve_right), curr_lane, free_E, free_NW.

0.4945279::u89.
free_NW :- u89, action(change_to_left), \+ free_SW.

0.4876119::u90.
free_NW :- u90, action(change_to_right), \+ free_SW.

0.4432497::u91.
free_NW :- u91, action(cruise), \+ free_SW.

0.4179990::u92.
free_NW :- u92, action(keep), \+ free_SW.

0.8780488::u93.
free_NW :- u93, action(swerve_left), \+ free_SW.

0.5428571::u94.
free_NW :- u94, action(swerve_right), \+ free_SW.

0.5197085::u95.
free_NW :- u95, action(change_to_left), free_SW.

0.5805040::u96.
free_NW :- u96, action(change_to_right), free_SW.

0.5847798::u97.
free_NW :- u97, action(cruise), free_SW.

0.0218767::u98.
free_NW :- u98, action(keep), free_SW.

0.9725840::u99.
free_NW :- u99, action(swerve_left), free_SW.

0.8224777::u100.
free_NW :- u100, action(swerve_right), free_SW.

