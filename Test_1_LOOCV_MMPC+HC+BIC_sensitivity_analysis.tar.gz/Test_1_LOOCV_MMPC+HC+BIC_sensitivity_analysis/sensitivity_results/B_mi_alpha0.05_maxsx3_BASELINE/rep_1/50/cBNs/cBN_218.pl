%%% Exogenous variables

0.1683286::u_action(change_to_left); 0.1700546::u_action(change_to_right); 0.4050699::u_action(cruise); 0.2542378::u_action(keep); 0.0014708::u_action(swerve_left); 0.0008384::u_action(swerve_right)
action(V) :- u_action(V).

0.5994224::u1.
free_SE :- u1.

0.6821574::u2.
free_SW :- u2.

0.7157329::u3.
free_W :- u3.

0.3854651::u4.
latent_collision :- u4.

0.4181316::u5.
curr_lane :- u5, action(change_to_left), \+ free_SE.

0.4682420::u6.
curr_lane :- u6, action(change_to_right), \+ free_SE.

0.4890657::u7.
curr_lane :- u7, action(cruise), \+ free_SE.

0.1360530::u8.
curr_lane :- u8, action(keep), \+ free_SE.

0.4111111::u9.
curr_lane :- u9, action(swerve_left), \+ free_SE.

0.9990010::u10.
curr_lane :- u10, action(swerve_right), \+ free_SE.

0.5445729::u11.
curr_lane :- u11, action(change_to_left), free_SE.

0.5541481::u12.
curr_lane :- u12, action(change_to_right), free_SE.

0.7146382::u13.
curr_lane :- u13, action(cruise), free_SE.

0.6011636::u14.
curr_lane :- u14, action(keep), free_SE.

0.8520446::u15.
curr_lane :- u15, action(swerve_left), free_SE.

0.9895969::u16.
curr_lane :- u16, action(swerve_right), free_SE.

0.5024972::u17.
free_E :- u17, action(change_to_left), \+ curr_lane, \+ free_SE.

0.5670700::u18.
free_E :- u18, action(change_to_right), \+ curr_lane, \+ free_SE.

0.3971942::u19.
free_E :- u19, action(cruise), \+ curr_lane, \+ free_SE.

0.5657488::u20.
free_E :- u20, action(keep), \+ curr_lane, \+ free_SE.

0.6226415::u21.
free_E :- u21, action(swerve_left), \+ curr_lane, \+ free_SE.

0.5000000::u22.
free_E :- u22, action(swerve_right), \+ curr_lane, \+ free_SE.

0.4821818::u23.
free_E :- u23, action(change_to_left), curr_lane, \+ free_SE.

0.5249375::u24.
free_E :- u24, action(change_to_right), curr_lane, \+ free_SE.

0.8008123::u25.
free_E :- u25, action(cruise), curr_lane, \+ free_SE.

0.9957307::u26.
free_E :- u26, action(keep), curr_lane, \+ free_SE.

0.9990010::u27.
free_E :- u27, action(swerve_left), curr_lane, \+ free_SE.

0.9990010::u28.
free_E :- u28, action(swerve_right), curr_lane, \+ free_SE.

0.5187615::u29.
free_E :- u29, action(change_to_left), \+ curr_lane, free_SE.

0.4009173::u30.
free_E :- u30, action(change_to_right), \+ curr_lane, free_SE.

0.6286698::u31.
free_E :- u31, action(cruise), \+ curr_lane, free_SE.

0.6562244::u32.
free_E :- u32, action(keep), \+ curr_lane, free_SE.

0.9246231::u33.
free_E :- u33, action(swerve_left), \+ curr_lane, free_SE.

0.9990010::u34.
free_E :- u34, action(swerve_right), \+ curr_lane, free_SE.

0.5828744::u35.
free_E :- u35, action(change_to_left), curr_lane, free_SE.

0.5230028::u36.
free_E :- u36, action(change_to_right), curr_lane, free_SE.

0.9249005::u37.
free_E :- u37, action(cruise), curr_lane, free_SE.

0.8773108::u38.
free_E :- u38, action(keep), curr_lane, free_SE.

0.9825480::u39.
free_E :- u39, action(swerve_left), curr_lane, free_SE.

0.9960578::u40.
free_E :- u40, action(swerve_right), curr_lane, free_SE.

0.5006465::u41.
free_NE :- u41, action(change_to_left), \+ curr_lane, \+ free_E, \+ free_NW.

0.5105711::u42.
free_NE :- u42, action(change_to_right), \+ curr_lane, \+ free_E, \+ free_NW.

0.4934919::u43.
free_NE :- u43, action(cruise), \+ curr_lane, \+ free_E, \+ free_NW.

0.2600990::u44.
free_NE :- u44, action(keep), \+ curr_lane, \+ free_E, \+ free_NW.

0.0009990::u45.
free_NE :- u45, action(swerve_left), \+ curr_lane, \+ free_E, \+ free_NW.

0.5000000::u46.
free_NE :- u46, action(swerve_right), \+ curr_lane, \+ free_E, \+ free_NW.

0.4982668::u47.
free_NE :- u47, action(change_to_left), curr_lane, \+ free_E, \+ free_NW.

0.5002258::u48.
free_NE :- u48, action(change_to_right), curr_lane, \+ free_E, \+ free_NW.

0.2429125::u49.
free_NE :- u49, action(cruise), curr_lane, \+ free_E, \+ free_NW.

0.0002239::u50.
free_NE :- u50, action(keep), curr_lane, \+ free_E, \+ free_NW.

0.3333333::u51.
free_NE :- u51, action(swerve_left), curr_lane, \+ free_E, \+ free_NW.

0.5000000::u52.
free_NE :- u52, action(swerve_right), curr_lane, \+ free_E, \+ free_NW.

0.4997504::u53.
free_NE :- u53, action(change_to_left), \+ curr_lane, free_E, \+ free_NW.

0.2430991::u54.
free_NE :- u54, action(change_to_right), \+ curr_lane, free_E, \+ free_NW.

0.4902655::u55.
free_NE :- u55, action(cruise), \+ curr_lane, free_E, \+ free_NW.

0.0102586::u56.
free_NE :- u56, action(keep), \+ curr_lane, free_E, \+ free_NW.

0.0009990::u57.
free_NE :- u57, action(swerve_left), \+ curr_lane, free_E, \+ free_NW.

0.5000000::u58.
free_NE :- u58, action(swerve_right), \+ curr_lane, free_E, \+ free_NW.

0.5045036::u59.
free_NE :- u59, action(change_to_left), curr_lane, free_E, \+ free_NW.

0.5554896::u60.
free_NE :- u60, action(change_to_right), curr_lane, free_E, \+ free_NW.

0.9170133::u61.
free_NE :- u61, action(cruise), curr_lane, free_E, \+ free_NW.

0.0009417::u62.
free_NE :- u62, action(keep), curr_lane, free_E, \+ free_NW.

0.2285714::u63.
free_NE :- u63, action(swerve_left), curr_lane, free_E, \+ free_NW.

0.6964286::u64.
free_NE :- u64, action(swerve_right), curr_lane, free_E, \+ free_NW.

0.4870096::u65.
free_NE :- u65, action(change_to_left), \+ curr_lane, \+ free_E, free_NW.

0.5082843::u66.
free_NE :- u66, action(change_to_right), \+ curr_lane, \+ free_E, free_NW.

0.5507343::u67.
free_NE :- u67, action(cruise), \+ curr_lane, \+ free_E, free_NW.

0.4354839::u68.
free_NE :- u68, action(keep), \+ curr_lane, \+ free_E, free_NW.

0.4705882::u69.
free_NE :- u69, action(swerve_left), \+ curr_lane, \+ free_E, free_NW.

0.5000000::u70.
free_NE :- u70, action(swerve_right), \+ curr_lane, \+ free_E, free_NW.

0.4999389::u71.
free_NE :- u71, action(change_to_left), curr_lane, \+ free_E, free_NW.

0.5033534::u72.
free_NE :- u72, action(change_to_right), curr_lane, \+ free_E, free_NW.

0.2086736::u73.
free_NE :- u73, action(cruise), curr_lane, \+ free_E, free_NW.

0.0119760::u74.
free_NE :- u74, action(keep), curr_lane, \+ free_E, free_NW.

0.0588235::u75.
free_NE :- u75, action(swerve_left), curr_lane, \+ free_E, free_NW.

0.0009990::u76.
free_NE :- u76, action(swerve_right), curr_lane, \+ free_E, free_NW.

0.4535365::u77.
free_NE :- u77, action(change_to_left), \+ curr_lane, free_E, free_NW.

0.6199784::u78.
free_NE :- u78, action(change_to_right), \+ curr_lane, free_E, free_NW.

0.4215705::u79.
free_NE :- u79, action(cruise), \+ curr_lane, free_E, free_NW.

0.4643629::u80.
free_NE :- u80, action(keep), \+ curr_lane, free_E, free_NW.

0.8232558::u81.
free_NE :- u81, action(swerve_left), \+ curr_lane, free_E, free_NW.

0.9990010::u82.
free_NE :- u82, action(swerve_right), \+ curr_lane, free_E, free_NW.

0.5026647::u83.
free_NE :- u83, action(change_to_left), curr_lane, free_E, free_NW.

0.5751393::u84.
free_NE :- u84, action(change_to_right), curr_lane, free_E, free_NW.

0.8922617::u85.
free_NE :- u85, action(cruise), curr_lane, free_E, free_NW.

0.0399337::u86.
free_NE :- u86, action(keep), curr_lane, free_E, free_NW.

0.9273050::u87.
free_NE :- u87, action(swerve_left), curr_lane, free_E, free_NW.

0.8920188::u88.
free_NE :- u88, action(swerve_right), curr_lane, free_E, free_NW.

0.5025981::u89.
free_NW :- u89, action(change_to_left), \+ free_SW.

0.5053121::u90.
free_NW :- u90, action(change_to_right), \+ free_SW.

0.4466016::u91.
free_NW :- u91, action(cruise), \+ free_SW.

0.4180434::u92.
free_NW :- u92, action(keep), \+ free_SW.

0.7560976::u93.
free_NW :- u93, action(swerve_left), \+ free_SW.

0.5588235::u94.
free_NW :- u94, action(swerve_right), \+ free_SW.

0.5185673::u95.
free_NW :- u95, action(change_to_left), free_SW.

0.5824168::u96.
free_NW :- u96, action(change_to_right), free_SW.

0.5841412::u97.
free_NW :- u97, action(cruise), free_SW.

0.0221100::u98.
free_NW :- u98, action(keep), free_SW.

0.9777618::u99.
free_NW :- u99, action(swerve_left), free_SW.

0.8133333::u100.
free_NW :- u100, action(swerve_right), free_SW.

