%%% Exogenous variables

0.1700741::u_action(change_to_left); 0.1724336::u_action(change_to_right); 0.3970110::u_action(cruise); 0.2580896::u_action(keep); 0.0015378::u_action(swerve_left); 0.0008540::u_action(swerve_right)
action(V) :- u_action(V).

0.5907824::u1.
free_SE :- u1.

0.6917609::u2.
free_SW :- u2.

0.7246443::u3.
free_W :- u3.

0.3918270::u4.
latent_collision :- u4.

0.4291418::u5.
curr_lane :- u5, action(change_to_left), \+ free_SE.

0.4767452::u6.
curr_lane :- u6, action(change_to_right), \+ free_SE.

0.4932726::u7.
curr_lane :- u7, action(cruise), \+ free_SE.

0.1374454::u8.
curr_lane :- u8, action(keep), \+ free_SE.

0.3529412::u9.
curr_lane :- u9, action(swerve_left), \+ free_SE.

0.9990010::u10.
curr_lane :- u10, action(swerve_right), \+ free_SE.

0.5368107::u11.
curr_lane :- u11, action(change_to_left), free_SE.

0.5489859::u12.
curr_lane :- u12, action(change_to_right), free_SE.

0.6995312::u13.
curr_lane :- u13, action(cruise), free_SE.

0.6014107::u14.
curr_lane :- u14, action(keep), free_SE.

0.8507246::u15.
curr_lane :- u15, action(swerve_left), free_SE.

0.9961390::u16.
curr_lane :- u16, action(swerve_right), free_SE.

0.5053930::u17.
free_E :- u17, action(change_to_left), \+ curr_lane, \+ free_SE.

0.5648503::u18.
free_E :- u18, action(change_to_right), \+ curr_lane, \+ free_SE.

0.3953828::u19.
free_E :- u19, action(cruise), \+ curr_lane, \+ free_SE.

0.5650783::u20.
free_E :- u20, action(keep), \+ curr_lane, \+ free_SE.

0.4696970::u21.
free_E :- u21, action(swerve_left), \+ curr_lane, \+ free_SE.

0.5000000::u22.
free_E :- u22, action(swerve_right), \+ curr_lane, \+ free_SE.

0.5034887::u23.
free_E :- u23, action(change_to_left), curr_lane, \+ free_SE.

0.5377963::u24.
free_E :- u24, action(change_to_right), curr_lane, \+ free_SE.

0.8037498::u25.
free_E :- u25, action(cruise), curr_lane, \+ free_SE.

0.9963074::u26.
free_E :- u26, action(keep), curr_lane, \+ free_SE.

0.9990010::u27.
free_E :- u27, action(swerve_left), curr_lane, \+ free_SE.

0.9990010::u28.
free_E :- u28, action(swerve_right), curr_lane, \+ free_SE.

0.5221428::u29.
free_E :- u29, action(change_to_left), \+ curr_lane, free_SE.

0.4011785::u30.
free_E :- u30, action(change_to_right), \+ curr_lane, free_SE.

0.6278084::u31.
free_E :- u31, action(cruise), \+ curr_lane, free_SE.

0.6575012::u32.
free_E :- u32, action(keep), \+ curr_lane, free_SE.

0.9077670::u33.
free_E :- u33, action(swerve_left), \+ curr_lane, free_SE.

0.9990010::u34.
free_E :- u34, action(swerve_right), \+ curr_lane, free_SE.

0.5710327::u35.
free_E :- u35, action(change_to_left), curr_lane, free_SE.

0.5064548::u36.
free_E :- u36, action(change_to_right), curr_lane, free_SE.

0.9195381::u37.
free_E :- u37, action(cruise), curr_lane, free_SE.

0.8768152::u38.
free_E :- u38, action(keep), curr_lane, free_SE.

0.9804089::u39.
free_E :- u39, action(swerve_left), curr_lane, free_SE.

0.9909561::u40.
free_E :- u40, action(swerve_right), curr_lane, free_SE.

0.4993511::u41.
free_NE :- u41, action(change_to_left), \+ curr_lane, \+ free_E, \+ free_NW.

0.5089247::u42.
free_NE :- u42, action(change_to_right), \+ curr_lane, \+ free_E, \+ free_NW.

0.4944243::u43.
free_NE :- u43, action(cruise), \+ curr_lane, \+ free_E, \+ free_NW.

0.2598415::u44.
free_NE :- u44, action(keep), \+ curr_lane, \+ free_E, \+ free_NW.

0.2000000::u45.
free_NE :- u45, action(swerve_left), \+ curr_lane, \+ free_E, \+ free_NW.

0.5000000::u46.
free_NE :- u46, action(swerve_right), \+ curr_lane, \+ free_E, \+ free_NW.

0.4994774::u47.
free_NE :- u47, action(change_to_left), curr_lane, \+ free_E, \+ free_NW.

0.5039921::u48.
free_NE :- u48, action(change_to_right), curr_lane, \+ free_E, \+ free_NW.

0.2458522::u49.
free_NE :- u49, action(cruise), curr_lane, \+ free_E, \+ free_NW.

0.0001112::u50.
free_NE :- u50, action(keep), curr_lane, \+ free_E, \+ free_NW.

0.5000000::u51.
free_NE :- u51, action(swerve_left), curr_lane, \+ free_E, \+ free_NW.

0.5000000::u52.
free_NE :- u52, action(swerve_right), curr_lane, \+ free_E, \+ free_NW.

0.5011397::u53.
free_NE :- u53, action(change_to_left), \+ curr_lane, free_E, \+ free_NW.

0.2365035::u54.
free_NE :- u54, action(change_to_right), \+ curr_lane, free_E, \+ free_NW.

0.4911093::u55.
free_NE :- u55, action(cruise), \+ curr_lane, free_E, \+ free_NW.

0.0104245::u56.
free_NE :- u56, action(keep), \+ curr_lane, free_E, \+ free_NW.

0.0009990::u57.
free_NE :- u57, action(swerve_left), \+ curr_lane, free_E, \+ free_NW.

0.5000000::u58.
free_NE :- u58, action(swerve_right), \+ curr_lane, free_E, \+ free_NW.

0.4416236::u59.
free_NE :- u59, action(change_to_left), curr_lane, free_E, \+ free_NW.

0.4949104::u60.
free_NE :- u60, action(change_to_right), curr_lane, free_E, \+ free_NW.

0.8968562::u61.
free_NE :- u61, action(cruise), curr_lane, free_E, \+ free_NW.

0.0010842::u62.
free_NE :- u62, action(keep), curr_lane, free_E, \+ free_NW.

0.2200000::u63.
free_NE :- u63, action(swerve_left), curr_lane, free_E, \+ free_NW.

0.6896552::u64.
free_NE :- u64, action(swerve_right), curr_lane, free_E, \+ free_NW.

0.4836531::u65.
free_NE :- u65, action(change_to_left), \+ curr_lane, \+ free_E, free_NW.

0.5121116::u66.
free_NE :- u66, action(change_to_right), \+ curr_lane, \+ free_E, free_NW.

0.5486471::u67.
free_NE :- u67, action(cruise), \+ curr_lane, \+ free_E, free_NW.

0.4137931::u68.
free_NE :- u68, action(keep), \+ curr_lane, \+ free_E, free_NW.

0.5306122::u69.
free_NE :- u69, action(swerve_left), \+ curr_lane, \+ free_E, free_NW.

0.5000000::u70.
free_NE :- u70, action(swerve_right), \+ curr_lane, \+ free_E, free_NW.

0.4992392::u71.
free_NE :- u71, action(change_to_left), curr_lane, \+ free_E, free_NW.

0.5045740::u72.
free_NE :- u72, action(change_to_right), curr_lane, \+ free_E, free_NW.

0.2025831::u73.
free_NE :- u73, action(cruise), curr_lane, \+ free_E, free_NW.

0.0009990::u74.
free_NE :- u74, action(keep), curr_lane, \+ free_E, free_NW.

0.0009990::u75.
free_NE :- u75, action(swerve_left), curr_lane, \+ free_E, free_NW.

0.0009990::u76.
free_NE :- u76, action(swerve_right), curr_lane, \+ free_E, free_NW.

0.4523705::u77.
free_NE :- u77, action(change_to_left), \+ curr_lane, free_E, free_NW.

0.6231531::u78.
free_NE :- u78, action(change_to_right), \+ curr_lane, free_E, free_NW.

0.4183918::u79.
free_NE :- u79, action(cruise), \+ curr_lane, free_E, free_NW.

0.4395604::u80.
free_NE :- u80, action(keep), \+ curr_lane, free_E, free_NW.

0.8232558::u81.
free_NE :- u81, action(swerve_left), \+ curr_lane, free_E, free_NW.

0.9990010::u82.
free_NE :- u82, action(swerve_right), \+ curr_lane, free_E, free_NW.

0.5004154::u83.
free_NE :- u83, action(change_to_left), curr_lane, free_E, free_NW.

0.5751007::u84.
free_NE :- u84, action(change_to_right), curr_lane, free_E, free_NW.

0.8925085::u85.
free_NE :- u85, action(cruise), curr_lane, free_E, free_NW.

0.0420819::u86.
free_NE :- u86, action(keep), curr_lane, free_E, free_NW.

0.9182058::u87.
free_NE :- u87, action(swerve_left), curr_lane, free_E, free_NW.

0.8997006::u88.
free_NE :- u88, action(swerve_right), curr_lane, free_E, free_NW.

0.5022793::u89.
free_NW :- u89, action(change_to_left), \+ free_SW.

0.5068285::u90.
free_NW :- u90, action(change_to_right), \+ free_SW.

0.4829841::u91.
free_NW :- u91, action(cruise), \+ free_SW.

0.4161085::u92.
free_NW :- u92, action(keep), \+ free_SW.

0.8541667::u93.
free_NW :- u93, action(swerve_left), \+ free_SW.

0.7647059::u94.
free_NW :- u94, action(swerve_right), \+ free_SW.

0.5202823::u95.
free_NW :- u95, action(change_to_left), free_SW.

0.5809128::u96.
free_NW :- u96, action(change_to_right), free_SW.

0.5842552::u97.
free_NW :- u97, action(cruise), free_SW.

0.0222814::u98.
free_NW :- u98, action(keep), free_SW.

0.9630404::u99.
free_NW :- u99, action(swerve_left), free_SW.

0.8187579::u100.
free_NW :- u100, action(swerve_right), free_SW.

