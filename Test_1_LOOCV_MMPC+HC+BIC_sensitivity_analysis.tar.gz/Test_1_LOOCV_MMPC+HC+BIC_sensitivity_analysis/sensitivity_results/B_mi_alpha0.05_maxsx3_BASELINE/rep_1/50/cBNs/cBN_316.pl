%%% Exogenous variables

0.1699522::u_action(change_to_left); 0.1719046::u_action(change_to_right); 0.4105430::u_action(cruise); 0.2452104::u_action(keep); 0.0015056::u_action(swerve_left); 0.0008842::u_action(swerve_right)
action(V) :- u_action(V).

0.6085706::u1.
free_SE :- u1.

0.6740960::u2.
free_SW :- u2.

0.7082635::u3.
free_W :- u3.

0.3892796::u4.
latent_collision :- u4.

0.4235287::u5.
curr_lane :- u5, action(change_to_left), \+ free_E, \+ free_NE, \+ free_SE.

0.4994003::u6.
curr_lane :- u6, action(change_to_right), \+ free_E, \+ free_NE, \+ free_SE.

0.4297485::u7.
curr_lane :- u7, action(cruise), \+ free_E, \+ free_NE, \+ free_SE.

0.0019649::u8.
curr_lane :- u8, action(keep), \+ free_E, \+ free_NE, \+ free_SE.

0.0009990::u9.
curr_lane :- u9, action(swerve_left), \+ free_E, \+ free_NE, \+ free_SE.

0.5000000::u10.
curr_lane :- u10, action(swerve_right), \+ free_E, \+ free_NE, \+ free_SE.

0.4237092::u11.
curr_lane :- u11, action(change_to_left), free_E, \+ free_NE, \+ free_SE.

0.4911237::u12.
curr_lane :- u12, action(change_to_right), free_E, \+ free_NE, \+ free_SE.

0.4595996::u13.
curr_lane :- u13, action(cruise), free_E, \+ free_NE, \+ free_SE.

0.2213716::u14.
curr_lane :- u14, action(keep), free_E, \+ free_NE, \+ free_SE.

0.5200000::u15.
curr_lane :- u15, action(swerve_left), free_E, \+ free_NE, \+ free_SE.

0.9990010::u16.
curr_lane :- u16, action(swerve_right), free_E, \+ free_NE, \+ free_SE.

0.4673748::u17.
curr_lane :- u17, action(change_to_left), \+ free_E, free_NE, \+ free_SE.

0.5227142::u18.
curr_lane :- u18, action(change_to_right), \+ free_E, free_NE, \+ free_SE.

0.0088364::u19.
curr_lane :- u19, action(cruise), \+ free_E, free_NE, \+ free_SE.

0.0009990::u20.
curr_lane :- u20, action(keep), \+ free_E, free_NE, \+ free_SE.

0.0009990::u21.
curr_lane :- u21, action(swerve_left), \+ free_E, free_NE, \+ free_SE.

0.5000000::u22.
curr_lane :- u22, action(swerve_right), \+ free_E, free_NE, \+ free_SE.

0.4320380::u23.
curr_lane :- u23, action(change_to_left), free_E, free_NE, \+ free_SE.

0.4433277::u24.
curr_lane :- u24, action(change_to_right), free_E, free_NE, \+ free_SE.

0.7779056::u25.
curr_lane :- u25, action(cruise), free_E, free_NE, \+ free_SE.

0.0233794::u26.
curr_lane :- u26, action(keep), free_E, free_NE, \+ free_SE.

0.3870968::u27.
curr_lane :- u27, action(swerve_left), free_E, free_NE, \+ free_SE.

0.9990010::u28.
curr_lane :- u28, action(swerve_right), free_E, free_NE, \+ free_SE.

0.5006565::u29.
curr_lane :- u29, action(change_to_left), \+ free_E, \+ free_NE, free_SE.

0.5022404::u30.
curr_lane :- u30, action(change_to_right), \+ free_E, \+ free_NE, free_SE.

0.3768546::u31.
curr_lane :- u31, action(cruise), \+ free_E, \+ free_NE, free_SE.

0.4212109::u32.
curr_lane :- u32, action(keep), \+ free_E, \+ free_NE, free_SE.

0.5000000::u33.
curr_lane :- u33, action(swerve_left), \+ free_E, \+ free_NE, free_SE.

0.9990010::u34.
curr_lane :- u34, action(swerve_right), \+ free_E, \+ free_NE, free_SE.

0.5547712::u35.
curr_lane :- u35, action(change_to_left), free_E, \+ free_NE, free_SE.

0.5004624::u36.
curr_lane :- u36, action(change_to_right), free_E, \+ free_NE, free_SE.

0.3059287::u37.
curr_lane :- u37, action(cruise), free_E, \+ free_NE, free_SE.

0.6685026::u38.
curr_lane :- u38, action(keep), free_E, \+ free_NE, free_SE.

0.8113208::u39.
curr_lane :- u39, action(swerve_left), free_E, \+ free_NE, free_SE.

0.9990010::u40.
curr_lane :- u40, action(swerve_right), free_E, \+ free_NE, free_SE.

0.5090162::u41.
curr_lane :- u41, action(change_to_left), \+ free_E, free_NE, free_SE.

0.5008369::u42.
curr_lane :- u42, action(change_to_right), \+ free_E, free_NE, free_SE.

0.2768904::u43.
curr_lane :- u43, action(cruise), \+ free_E, free_NE, free_SE.

0.0004570::u44.
curr_lane :- u44, action(keep), \+ free_E, free_NE, free_SE.

0.6666667::u45.
curr_lane :- u45, action(swerve_left), \+ free_E, free_NE, free_SE.

0.5000000::u46.
curr_lane :- u46, action(swerve_right), \+ free_E, free_NE, free_SE.

0.5869959::u47.
curr_lane :- u47, action(change_to_left), free_E, free_NE, free_SE.

0.7849983::u48.
curr_lane :- u48, action(change_to_right), free_E, free_NE, free_SE.

0.8855293::u49.
curr_lane :- u49, action(cruise), free_E, free_NE, free_SE.

0.6192308::u50.
curr_lane :- u50, action(keep), free_E, free_NE, free_SE.

0.8683775::u51.
curr_lane :- u51, action(swerve_left), free_E, free_NE, free_SE.

0.9911374::u52.
curr_lane :- u52, action(swerve_right), free_E, free_NE, free_SE.

0.5118342::u53.
free_E :- u53, action(change_to_left), \+ free_SE.

0.5638288::u54.
free_E :- u54, action(change_to_right), \+ free_SE.

0.6081347::u55.
free_E :- u55, action(cruise), \+ free_SE.

0.6899993::u56.
free_E :- u56, action(keep), \+ free_SE.

0.5957447::u57.
free_E :- u57, action(swerve_left), \+ free_SE.

0.9990010::u58.
free_E :- u58, action(swerve_right), \+ free_SE.

0.5525604::u59.
free_E :- u59, action(change_to_left), free_SE.

0.4656915::u60.
free_E :- u60, action(change_to_right), free_SE.

0.8404448::u61.
free_E :- u61, action(cruise), free_SE.

0.7878835::u62.
free_E :- u62, action(keep), free_SE.

0.9697417::u63.
free_E :- u63, action(swerve_left), free_SE.

0.9974937::u64.
free_E :- u64, action(swerve_right), free_SE.

0.4850646::u65.
free_NE :- u65, action(change_to_left), \+ free_E, \+ free_NW.

0.4853717::u66.
free_NE :- u66, action(change_to_right), \+ free_E, \+ free_NW.

0.3690664::u67.
free_NE :- u67, action(cruise), \+ free_E, \+ free_NW.

0.0722431::u68.
free_NE :- u68, action(keep), \+ free_E, \+ free_NW.

0.4000000::u69.
free_NE :- u69, action(swerve_left), \+ free_E, \+ free_NW.

0.0009990::u70.
free_NE :- u70, action(swerve_right), \+ free_E, \+ free_NW.

0.4866384::u71.
free_NE :- u71, action(change_to_left), free_E, \+ free_NW.

0.4101006::u72.
free_NE :- u72, action(change_to_right), free_E, \+ free_NW.

0.8466006::u73.
free_NE :- u73, action(cruise), free_E, \+ free_NW.

0.0059206::u74.
free_NE :- u74, action(keep), free_E, \+ free_NW.

0.2127660::u75.
free_NE :- u75, action(swerve_left), free_E, \+ free_NW.

0.7161290::u76.
free_NE :- u76, action(swerve_right), free_E, \+ free_NW.

0.4927127::u77.
free_NE :- u77, action(change_to_left), \+ free_E, free_NW.

0.5065480::u78.
free_NE :- u78, action(change_to_right), \+ free_E, free_NW.

0.4717930::u79.
free_NE :- u79, action(cruise), \+ free_E, free_NW.

0.0934579::u80.
free_NE :- u80, action(keep), \+ free_E, free_NW.

0.3378378::u81.
free_NE :- u81, action(swerve_left), \+ free_E, free_NW.

0.5000000::u82.
free_NE :- u82, action(swerve_right), \+ free_E, free_NW.

0.4800766::u83.
free_NE :- u83, action(change_to_left), free_E, free_NW.

0.6002932::u84.
free_NE :- u84, action(change_to_right), free_E, free_NW.

0.7374246::u85.
free_NE :- u85, action(cruise), free_E, free_NW.

0.0618354::u86.
free_NE :- u86, action(keep), free_E, free_NW.

0.9289494::u87.
free_NE :- u87, action(swerve_left), free_E, free_NW.

0.8818444::u88.
free_NE :- u88, action(swerve_right), free_E, free_NW.

0.4919324::u89.
free_NW :- u89, action(change_to_left), \+ free_SW.

0.4965808::u90.
free_NW :- u90, action(change_to_right), \+ free_SW.

0.4427732::u91.
free_NW :- u91, action(cruise), \+ free_SW.

0.4180697::u92.
free_NW :- u92, action(keep), \+ free_SW.

0.7812500::u93.
free_NW :- u93, action(swerve_left), \+ free_SW.

0.5901639::u94.
free_NW :- u94, action(swerve_right), \+ free_SW.

0.5297293::u95.
free_NW :- u95, action(change_to_left), free_SW.

0.5898342::u96.
free_NW :- u96, action(change_to_right), free_SW.

0.5897692::u97.
free_NW :- u97, action(cruise), free_SW.

0.0231442::u98.
free_NW :- u98, action(keep), free_SW.

0.9682428::u99.
free_NW :- u99, action(swerve_left), free_SW.

0.8329114::u100.
free_NW :- u100, action(swerve_right), free_SW.

