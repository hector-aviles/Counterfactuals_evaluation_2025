%%% Exogenous variables

0.1676299::u_action(change_to_left); 0.1696486::u_action(change_to_right); 0.4065799::u_action(cruise); 0.2538577::u_action(keep); 0.0014464::u_action(swerve_left); 0.0008374::u_action(swerve_right)
action(V) :- u_action(V).

0.5993706::u1.
free_SE :- u1.

0.6781072::u2.
free_SW :- u2.

0.7119364::u3.
free_W :- u3.

0.3863369::u4.
latent_collision :- u4.

0.4185881::u5.
curr_lane :- u5, action(change_to_left), \+ free_SE.

0.4675163::u6.
curr_lane :- u6, action(change_to_right), \+ free_SE.

0.4930718::u7.
curr_lane :- u7, action(cruise), \+ free_SE.

0.1370121::u8.
curr_lane :- u8, action(keep), \+ free_SE.

0.3440860::u9.
curr_lane :- u9, action(swerve_left), \+ free_SE.

0.9990010::u10.
curr_lane :- u10, action(swerve_right), \+ free_SE.

0.5432494::u11.
curr_lane :- u11, action(change_to_left), free_SE.

0.5569200::u12.
curr_lane :- u12, action(change_to_right), free_SE.

0.7140050::u13.
curr_lane :- u13, action(cruise), free_SE.

0.6006530::u14.
curr_lane :- u14, action(keep), free_SE.

0.8560606::u15.
curr_lane :- u15, action(swerve_left), free_SE.

0.9935065::u16.
curr_lane :- u16, action(swerve_right), free_SE.

0.5022086::u17.
free_E :- u17, action(change_to_left), \+ curr_lane, \+ free_SE.

0.5649654::u18.
free_E :- u18, action(change_to_right), \+ curr_lane, \+ free_SE.

0.3915513::u19.
free_E :- u19, action(cruise), \+ curr_lane, \+ free_SE.

0.5649114::u20.
free_E :- u20, action(keep), \+ curr_lane, \+ free_SE.

0.4754098::u21.
free_E :- u21, action(swerve_left), \+ curr_lane, \+ free_SE.

0.5000000::u22.
free_E :- u22, action(swerve_right), \+ curr_lane, \+ free_SE.

0.5251551::u23.
free_E :- u23, action(change_to_left), curr_lane, \+ free_SE.

0.5548775::u24.
free_E :- u24, action(change_to_right), curr_lane, \+ free_SE.

0.8058778::u25.
free_E :- u25, action(cruise), curr_lane, \+ free_SE.

0.9965100::u26.
free_E :- u26, action(keep), curr_lane, \+ free_SE.

0.9990010::u27.
free_E :- u27, action(swerve_left), curr_lane, \+ free_SE.

0.9990010::u28.
free_E :- u28, action(swerve_right), curr_lane, \+ free_SE.

0.5189332::u29.
free_E :- u29, action(change_to_left), \+ curr_lane, free_SE.

0.3981921::u30.
free_E :- u30, action(change_to_right), \+ curr_lane, free_SE.

0.6263445::u31.
free_E :- u31, action(cruise), \+ curr_lane, free_SE.

0.6562423::u32.
free_E :- u32, action(keep), \+ curr_lane, free_SE.

0.8842105::u33.
free_E :- u33, action(swerve_left), \+ curr_lane, free_SE.

0.9990010::u34.
free_E :- u34, action(swerve_right), \+ curr_lane, free_SE.

0.5857834::u35.
free_E :- u35, action(change_to_left), curr_lane, free_SE.

0.5191427::u36.
free_E :- u36, action(change_to_right), curr_lane, free_SE.

0.9246834::u37.
free_E :- u37, action(cruise), curr_lane, free_SE.

0.8793928::u38.
free_E :- u38, action(keep), curr_lane, free_SE.

0.9814159::u39.
free_E :- u39, action(swerve_left), curr_lane, free_SE.

0.9947712::u40.
free_E :- u40, action(swerve_right), curr_lane, free_SE.

0.4983551::u41.
free_NE :- u41, action(change_to_left), \+ curr_lane, \+ free_E, \+ free_NW.

0.5124227::u42.
free_NE :- u42, action(change_to_right), \+ curr_lane, \+ free_E, \+ free_NW.

0.4957182::u43.
free_NE :- u43, action(cruise), \+ curr_lane, \+ free_E, \+ free_NW.

0.2604361::u44.
free_NE :- u44, action(keep), \+ curr_lane, \+ free_E, \+ free_NW.

0.2500000::u45.
free_NE :- u45, action(swerve_left), \+ curr_lane, \+ free_E, \+ free_NW.

0.5000000::u46.
free_NE :- u46, action(swerve_right), \+ curr_lane, \+ free_E, \+ free_NW.

0.4675283::u47.
free_NE :- u47, action(change_to_left), curr_lane, \+ free_E, \+ free_NW.

0.4661871::u48.
free_NE :- u48, action(change_to_right), curr_lane, \+ free_E, \+ free_NW.

0.2411037::u49.
free_NE :- u49, action(cruise), curr_lane, \+ free_E, \+ free_NW.

0.0002278::u50.
free_NE :- u50, action(keep), curr_lane, \+ free_E, \+ free_NW.

0.3333333::u51.
free_NE :- u51, action(swerve_left), curr_lane, \+ free_E, \+ free_NW.

0.3333333::u52.
free_NE :- u52, action(swerve_right), curr_lane, \+ free_E, \+ free_NW.

0.5020277::u53.
free_NE :- u53, action(change_to_left), \+ curr_lane, free_E, \+ free_NW.

0.2417393::u54.
free_NE :- u54, action(change_to_right), \+ curr_lane, free_E, \+ free_NW.

0.4847835::u55.
free_NE :- u55, action(cruise), \+ curr_lane, free_E, \+ free_NW.

0.0100081::u56.
free_NE :- u56, action(keep), \+ curr_lane, free_E, \+ free_NW.

0.0009990::u57.
free_NE :- u57, action(swerve_left), \+ curr_lane, free_E, \+ free_NW.

0.5000000::u58.
free_NE :- u58, action(swerve_right), \+ curr_lane, free_E, \+ free_NW.

0.4764996::u59.
free_NE :- u59, action(change_to_left), curr_lane, free_E, \+ free_NW.

0.5229708::u60.
free_NE :- u60, action(change_to_right), curr_lane, free_E, \+ free_NW.

0.9068583::u61.
free_NE :- u61, action(cruise), curr_lane, free_E, \+ free_NW.

0.0010572::u62.
free_NE :- u62, action(keep), curr_lane, free_E, \+ free_NW.

0.2222222::u63.
free_NE :- u63, action(swerve_left), curr_lane, free_E, \+ free_NW.

0.7207792::u64.
free_NE :- u64, action(swerve_right), curr_lane, free_E, \+ free_NW.

0.4864449::u65.
free_NE :- u65, action(change_to_left), \+ curr_lane, \+ free_E, free_NW.

0.5082064::u66.
free_NE :- u66, action(change_to_right), \+ curr_lane, \+ free_E, free_NW.

0.5517116::u67.
free_NE :- u67, action(cruise), \+ curr_lane, \+ free_E, free_NW.

0.3720930::u68.
free_NE :- u68, action(keep), \+ curr_lane, \+ free_E, free_NW.

0.4800000::u69.
free_NE :- u69, action(swerve_left), \+ curr_lane, \+ free_E, free_NW.

0.5000000::u70.
free_NE :- u70, action(swerve_right), \+ curr_lane, \+ free_E, free_NW.

0.4989202::u71.
free_NE :- u71, action(change_to_left), curr_lane, \+ free_E, free_NW.

0.5037798::u72.
free_NE :- u72, action(change_to_right), curr_lane, \+ free_E, free_NW.

0.2027469::u73.
free_NE :- u73, action(cruise), curr_lane, \+ free_E, free_NW.

0.0064516::u74.
free_NE :- u74, action(keep), curr_lane, \+ free_E, free_NW.

0.0009990::u75.
free_NE :- u75, action(swerve_left), curr_lane, \+ free_E, free_NW.

0.0009990::u76.
free_NE :- u76, action(swerve_right), curr_lane, \+ free_E, free_NW.

0.4544133::u77.
free_NE :- u77, action(change_to_left), \+ curr_lane, free_E, free_NW.

0.6187392::u78.
free_NE :- u78, action(change_to_right), \+ curr_lane, free_E, free_NW.

0.4165074::u79.
free_NE :- u79, action(cruise), \+ curr_lane, free_E, free_NW.

0.4260486::u80.
free_NE :- u80, action(keep), \+ curr_lane, free_E, free_NW.

0.8272251::u81.
free_NE :- u81, action(swerve_left), \+ curr_lane, free_E, free_NW.

0.9990010::u82.
free_NE :- u82, action(swerve_right), \+ curr_lane, free_E, free_NW.

0.5005635::u83.
free_NE :- u83, action(change_to_left), curr_lane, free_E, free_NW.

0.5774067::u84.
free_NE :- u84, action(change_to_right), curr_lane, free_E, free_NW.

0.8924045::u85.
free_NE :- u85, action(cruise), curr_lane, free_E, free_NW.

0.0405956::u86.
free_NE :- u86, action(keep), curr_lane, free_E, free_NW.

0.9366516::u87.
free_NE :- u87, action(swerve_left), curr_lane, free_E, free_NW.

0.8961832::u88.
free_NE :- u88, action(swerve_right), curr_lane, free_E, free_NW.

0.4937897::u89.
free_NW :- u89, action(change_to_left), \+ free_SW.

0.4958969::u90.
free_NW :- u90, action(change_to_right), \+ free_SW.

0.4427330::u91.
free_NW :- u91, action(cruise), \+ free_SW.

0.4144071::u92.
free_NW :- u92, action(keep), \+ free_SW.

0.7428571::u93.
free_NW :- u93, action(swerve_left), \+ free_SW.

0.5438596::u94.
free_NW :- u94, action(swerve_right), \+ free_SW.

0.5271714::u95.
free_NW :- u95, action(change_to_left), free_SW.

0.5877019::u96.
free_NW :- u96, action(change_to_right), free_SW.

0.5848542::u97.
free_NW :- u97, action(cruise), free_SW.

0.0216359::u98.
free_NW :- u98, action(keep), free_SW.

0.9709724::u99.
free_NW :- u99, action(swerve_left), free_SW.

0.8278581::u100.
free_NW :- u100, action(swerve_right), free_SW.

