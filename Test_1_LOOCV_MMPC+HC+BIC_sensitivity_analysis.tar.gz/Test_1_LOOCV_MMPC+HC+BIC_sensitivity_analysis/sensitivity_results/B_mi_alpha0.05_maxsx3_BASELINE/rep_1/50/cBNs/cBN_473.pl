%%% Exogenous variables

0.1655442::u_action(change_to_left); 0.1709027::u_action(change_to_right); 0.4071223::u_action(cruise); 0.2540636::u_action(keep); 0.0015029::u_action(swerve_left); 0.0008642::u_action(swerve_right)
action(V) :- u_action(V).

0.5934009::u1.
free_SE :- u1.

0.6861313::u2.
free_SW :- u2.

0.7101876::u3.
free_W :- u3.

0.3886078::u4.
latent_collision :- u4.

0.4275968::u5.
curr_lane :- u5, action(change_to_left), \+ free_SE.

0.4760498::u6.
curr_lane :- u6, action(change_to_right), \+ free_SE.

0.4943679::u7.
curr_lane :- u7, action(cruise), \+ free_SE.

0.1371341::u8.
curr_lane :- u8, action(keep), \+ free_SE.

0.3586957::u9.
curr_lane :- u9, action(swerve_left), \+ free_SE.

0.9990010::u10.
curr_lane :- u10, action(swerve_right), \+ free_SE.

0.5190550::u11.
curr_lane :- u11, action(change_to_left), free_SE.

0.5462117::u12.
curr_lane :- u12, action(change_to_right), free_SE.

0.7124935::u13.
curr_lane :- u13, action(cruise), free_SE.

0.5971095::u14.
curr_lane :- u14, action(keep), free_SE.

0.8500366::u15.
curr_lane :- u15, action(swerve_left), free_SE.

0.9923664::u16.
curr_lane :- u16, action(swerve_right), free_SE.

0.5043410::u17.
free_E :- u17, action(change_to_left), \+ curr_lane, \+ free_SE.

0.5671564::u18.
free_E :- u18, action(change_to_right), \+ curr_lane, \+ free_SE.

0.3954023::u19.
free_E :- u19, action(cruise), \+ curr_lane, \+ free_SE.

0.5648932::u20.
free_E :- u20, action(keep), \+ curr_lane, \+ free_SE.

0.4745763::u21.
free_E :- u21, action(swerve_left), \+ curr_lane, \+ free_SE.

0.5000000::u22.
free_E :- u22, action(swerve_right), \+ curr_lane, \+ free_SE.

0.5023146::u23.
free_E :- u23, action(change_to_left), curr_lane, \+ free_SE.

0.5407362::u24.
free_E :- u24, action(change_to_right), curr_lane, \+ free_SE.

0.8054753::u25.
free_E :- u25, action(cruise), curr_lane, \+ free_SE.

0.9962354::u26.
free_E :- u26, action(keep), curr_lane, \+ free_SE.

0.9990010::u27.
free_E :- u27, action(swerve_left), curr_lane, \+ free_SE.

0.9990010::u28.
free_E :- u28, action(swerve_right), curr_lane, \+ free_SE.

0.5217735::u29.
free_E :- u29, action(change_to_left), \+ curr_lane, free_SE.

0.4009266::u30.
free_E :- u30, action(change_to_right), \+ curr_lane, free_SE.

0.6293942::u31.
free_E :- u31, action(cruise), \+ curr_lane, free_SE.

0.6583822::u32.
free_E :- u32, action(keep), \+ curr_lane, free_SE.

0.9024390::u33.
free_E :- u33, action(swerve_left), \+ curr_lane, free_SE.

0.9990010::u34.
free_E :- u34, action(swerve_right), \+ curr_lane, free_SE.

0.5432779::u35.
free_E :- u35, action(change_to_left), curr_lane, free_SE.

0.5069825::u36.
free_E :- u36, action(change_to_right), curr_lane, free_SE.

0.9237549::u37.
free_E :- u37, action(cruise), curr_lane, free_SE.

0.8753589::u38.
free_E :- u38, action(keep), curr_lane, free_SE.

0.9827883::u39.
free_E :- u39, action(swerve_left), curr_lane, free_SE.

0.9961538::u40.
free_E :- u40, action(swerve_right), curr_lane, free_SE.

0.4923891::u41.
free_NE :- u41, action(change_to_left), \+ curr_lane, \+ free_E, \+ free_NW.

0.5114426::u42.
free_NE :- u42, action(change_to_right), \+ curr_lane, \+ free_E, \+ free_NW.

0.4921564::u43.
free_NE :- u43, action(cruise), \+ curr_lane, \+ free_E, \+ free_NW.

0.2590869::u44.
free_NE :- u44, action(keep), \+ curr_lane, \+ free_E, \+ free_NW.

0.0009990::u45.
free_NE :- u45, action(swerve_left), \+ curr_lane, \+ free_E, \+ free_NW.

0.5000000::u46.
free_NE :- u46, action(swerve_right), \+ curr_lane, \+ free_E, \+ free_NW.

0.4947049::u47.
free_NE :- u47, action(change_to_left), curr_lane, \+ free_E, \+ free_NW.

0.5008013::u48.
free_NE :- u48, action(change_to_right), curr_lane, \+ free_E, \+ free_NW.

0.2481593::u49.
free_NE :- u49, action(cruise), curr_lane, \+ free_E, \+ free_NW.

0.0002250::u50.
free_NE :- u50, action(keep), curr_lane, \+ free_E, \+ free_NW.

0.5000000::u51.
free_NE :- u51, action(swerve_left), curr_lane, \+ free_E, \+ free_NW.

0.6666667::u52.
free_NE :- u52, action(swerve_right), curr_lane, \+ free_E, \+ free_NW.

0.5031929::u53.
free_NE :- u53, action(change_to_left), \+ curr_lane, free_E, \+ free_NW.

0.2432840::u54.
free_NE :- u54, action(change_to_right), \+ curr_lane, free_E, \+ free_NW.

0.4871422::u55.
free_NE :- u55, action(cruise), \+ curr_lane, free_E, \+ free_NW.

0.0097682::u56.
free_NE :- u56, action(keep), \+ curr_lane, free_E, \+ free_NW.

0.0009990::u57.
free_NE :- u57, action(swerve_left), \+ curr_lane, free_E, \+ free_NW.

0.5000000::u58.
free_NE :- u58, action(swerve_right), \+ curr_lane, free_E, \+ free_NW.

0.4725082::u59.
free_NE :- u59, action(change_to_left), curr_lane, free_E, \+ free_NW.

0.5250058::u60.
free_NE :- u60, action(change_to_right), curr_lane, free_E, \+ free_NW.

0.9071514::u61.
free_NE :- u61, action(cruise), curr_lane, free_E, \+ free_NW.

0.0011262::u62.
free_NE :- u62, action(keep), curr_lane, free_E, \+ free_NW.

0.2307692::u63.
free_NE :- u63, action(swerve_left), curr_lane, free_E, \+ free_NW.

0.7204969::u64.
free_NE :- u64, action(swerve_right), curr_lane, free_E, \+ free_NW.

0.4909652::u65.
free_NE :- u65, action(change_to_left), \+ curr_lane, \+ free_E, free_NW.

0.5100049::u66.
free_NE :- u66, action(change_to_right), \+ curr_lane, \+ free_E, free_NW.

0.5523716::u67.
free_NE :- u67, action(cruise), \+ curr_lane, \+ free_E, free_NW.

0.3333333::u68.
free_NE :- u68, action(keep), \+ curr_lane, \+ free_E, free_NW.

0.4081633::u69.
free_NE :- u69, action(swerve_left), \+ curr_lane, \+ free_E, free_NW.

0.5000000::u70.
free_NE :- u70, action(swerve_right), \+ curr_lane, \+ free_E, free_NW.

0.4974167::u71.
free_NE :- u71, action(change_to_left), curr_lane, \+ free_E, free_NW.

0.5030650::u72.
free_NE :- u72, action(change_to_right), curr_lane, \+ free_E, free_NW.

0.2038935::u73.
free_NE :- u73, action(cruise), curr_lane, \+ free_E, free_NW.

0.0009990::u74.
free_NE :- u74, action(keep), curr_lane, \+ free_E, free_NW.

0.0009990::u75.
free_NE :- u75, action(swerve_left), curr_lane, \+ free_E, free_NW.

0.5000000::u76.
free_NE :- u76, action(swerve_right), curr_lane, \+ free_E, free_NW.

0.4515055::u77.
free_NE :- u77, action(change_to_left), \+ curr_lane, free_E, free_NW.

0.6192464::u78.
free_NE :- u78, action(change_to_right), \+ curr_lane, free_E, free_NW.

0.4183749::u79.
free_NE :- u79, action(cruise), \+ curr_lane, free_E, free_NW.

0.4502262::u80.
free_NE :- u80, action(keep), \+ curr_lane, free_E, free_NW.

0.8039216::u81.
free_NE :- u81, action(swerve_left), \+ curr_lane, free_E, free_NW.

0.9990010::u82.
free_NE :- u82, action(swerve_right), \+ curr_lane, free_E, free_NW.

0.6193389::u83.
free_NE :- u83, action(change_to_left), curr_lane, free_E, free_NW.

0.6084170::u84.
free_NE :- u84, action(change_to_right), curr_lane, free_E, free_NW.

0.9042411::u85.
free_NE :- u85, action(cruise), curr_lane, free_E, free_NW.

0.0502969::u86.
free_NE :- u86, action(keep), curr_lane, free_E, free_NW.

0.9454225::u87.
free_NE :- u87, action(swerve_left), curr_lane, free_E, free_NW.

0.8759342::u88.
free_NE :- u88, action(swerve_right), curr_lane, free_E, free_NW.

0.4626521::u89.
free_NW :- u89, action(change_to_left), \+ free_SW.

0.4869706::u90.
free_NW :- u90, action(change_to_right), \+ free_SW.

0.4380626::u91.
free_NW :- u91, action(cruise), \+ free_SW.

0.2214349::u92.
free_NW :- u92, action(keep), \+ free_SW.

0.5555556::u93.
free_NW :- u93, action(swerve_left), \+ free_SW.

0.5000000::u94.
free_NW :- u94, action(swerve_right), \+ free_SW.

0.5201517::u95.
free_NW :- u95, action(change_to_left), free_SW.

0.5811054::u96.
free_NW :- u96, action(change_to_right), free_SW.

0.5854691::u97.
free_NW :- u97, action(cruise), free_SW.

0.0222566::u98.
free_NW :- u98, action(keep), free_SW.

0.9720670::u99.
free_NW :- u99, action(swerve_left), free_SW.

0.8271447::u100.
free_NW :- u100, action(swerve_right), free_SW.

