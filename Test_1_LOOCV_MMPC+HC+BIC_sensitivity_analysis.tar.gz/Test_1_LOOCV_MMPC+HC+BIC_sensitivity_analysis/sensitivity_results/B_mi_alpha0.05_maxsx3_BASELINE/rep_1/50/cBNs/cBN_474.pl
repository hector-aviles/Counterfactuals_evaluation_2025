%%% Exogenous variables

0.1682191::u_action(change_to_left); 0.1702857::u_action(change_to_right); 0.4058852::u_action(cruise); 0.2533091::u_action(keep); 0.0014562::u_action(swerve_left); 0.0008447::u_action(swerve_right)
action(V) :- u_action(V).

0.5949637::u1.
free_SE :- u1.

0.6775708::u2.
free_SW :- u2.

0.7178457::u3.
free_W :- u3.

0.3858181::u4.
latent_collision :- u4.

0.4289122::u5.
curr_lane :- u5, action(change_to_left), \+ free_SE.

0.4756627::u6.
curr_lane :- u6, action(change_to_right), \+ free_SE.

0.4924269::u7.
curr_lane :- u7, action(cruise), \+ free_SE.

0.1367712::u8.
curr_lane :- u8, action(keep), \+ free_SE.

0.3191489::u9.
curr_lane :- u9, action(swerve_left), \+ free_SE.

0.9990010::u10.
curr_lane :- u10, action(swerve_right), \+ free_SE.

0.5356277::u11.
curr_lane :- u11, action(change_to_left), free_SE.

0.5493717::u12.
curr_lane :- u12, action(change_to_right), free_SE.

0.7122336::u13.
curr_lane :- u13, action(cruise), free_SE.

0.5955555::u14.
curr_lane :- u14, action(keep), free_SE.

0.8510960::u15.
curr_lane :- u15, action(swerve_left), free_SE.

0.9974326::u16.
curr_lane :- u16, action(swerve_right), free_SE.

0.5007863::u17.
free_E :- u17, action(change_to_left), \+ curr_lane, \+ free_SE.

0.5664630::u18.
free_E :- u18, action(change_to_right), \+ curr_lane, \+ free_SE.

0.3936549::u19.
free_E :- u19, action(cruise), \+ curr_lane, \+ free_SE.

0.5652122::u20.
free_E :- u20, action(keep), \+ curr_lane, \+ free_SE.

0.4218750::u21.
free_E :- u21, action(swerve_left), \+ curr_lane, \+ free_SE.

0.5000000::u22.
free_E :- u22, action(swerve_right), \+ curr_lane, \+ free_SE.

0.5041549::u23.
free_E :- u23, action(change_to_left), curr_lane, \+ free_SE.

0.5367474::u24.
free_E :- u24, action(change_to_right), curr_lane, \+ free_SE.

0.8063517::u25.
free_E :- u25, action(cruise), curr_lane, \+ free_SE.

0.9964031::u26.
free_E :- u26, action(keep), curr_lane, \+ free_SE.

0.9990010::u27.
free_E :- u27, action(swerve_left), curr_lane, \+ free_SE.

0.9990010::u28.
free_E :- u28, action(swerve_right), curr_lane, \+ free_SE.

0.5220987::u29.
free_E :- u29, action(change_to_left), \+ curr_lane, free_SE.

0.3993810::u30.
free_E :- u30, action(change_to_right), \+ curr_lane, free_SE.

0.6289372::u31.
free_E :- u31, action(cruise), \+ curr_lane, free_SE.

0.6576220::u32.
free_E :- u32, action(keep), \+ curr_lane, free_SE.

0.9441624::u33.
free_E :- u33, action(swerve_left), \+ curr_lane, free_SE.

0.9990010::u34.
free_E :- u34, action(swerve_right), \+ curr_lane, free_SE.

0.5749288::u35.
free_E :- u35, action(change_to_left), curr_lane, free_SE.

0.5080190::u36.
free_E :- u36, action(change_to_right), curr_lane, free_SE.

0.9234210::u37.
free_E :- u37, action(cruise), curr_lane, free_SE.

0.8762806::u38.
free_E :- u38, action(keep), curr_lane, free_SE.

0.9804618::u39.
free_E :- u39, action(swerve_left), curr_lane, free_SE.

0.9935650::u40.
free_E :- u40, action(swerve_right), curr_lane, free_SE.

0.4945493::u41.
free_NE :- u41, action(change_to_left), \+ curr_lane, \+ free_E, \+ free_NW.

0.5064225::u42.
free_NE :- u42, action(change_to_right), \+ curr_lane, \+ free_E, \+ free_NW.

0.4965569::u43.
free_NE :- u43, action(cruise), \+ curr_lane, \+ free_E, \+ free_NW.

0.2616128::u44.
free_NE :- u44, action(keep), \+ curr_lane, \+ free_E, \+ free_NW.

0.0009990::u45.
free_NE :- u45, action(swerve_left), \+ curr_lane, \+ free_E, \+ free_NW.

0.5000000::u46.
free_NE :- u46, action(swerve_right), \+ curr_lane, \+ free_E, \+ free_NW.

0.4997243::u47.
free_NE :- u47, action(change_to_left), curr_lane, \+ free_E, \+ free_NW.

0.4995513::u48.
free_NE :- u48, action(change_to_right), curr_lane, \+ free_E, \+ free_NW.

0.2458371::u49.
free_NE :- u49, action(cruise), curr_lane, \+ free_E, \+ free_NW.

0.0002278::u50.
free_NE :- u50, action(keep), curr_lane, \+ free_E, \+ free_NW.

0.0009990::u51.
free_NE :- u51, action(swerve_left), curr_lane, \+ free_E, \+ free_NW.

0.5000000::u52.
free_NE :- u52, action(swerve_right), curr_lane, \+ free_E, \+ free_NW.

0.5011420::u53.
free_NE :- u53, action(change_to_left), \+ curr_lane, free_E, \+ free_NW.

0.2379050::u54.
free_NE :- u54, action(change_to_right), \+ curr_lane, free_E, \+ free_NW.

0.4872457::u55.
free_NE :- u55, action(cruise), \+ curr_lane, free_E, \+ free_NW.

0.0104418::u56.
free_NE :- u56, action(keep), \+ curr_lane, free_E, \+ free_NW.

0.0009990::u57.
free_NE :- u57, action(swerve_left), \+ curr_lane, free_E, \+ free_NW.

0.5000000::u58.
free_NE :- u58, action(swerve_right), \+ curr_lane, free_E, \+ free_NW.

0.4723762::u59.
free_NE :- u59, action(change_to_left), curr_lane, free_E, \+ free_NW.

0.5231381::u60.
free_NE :- u60, action(change_to_right), curr_lane, free_E, \+ free_NW.

0.9075525::u61.
free_NE :- u61, action(cruise), curr_lane, free_E, \+ free_NW.

0.0011481::u62.
free_NE :- u62, action(keep), curr_lane, free_E, \+ free_NW.

0.2790698::u63.
free_NE :- u63, action(swerve_left), curr_lane, free_E, \+ free_NW.

0.7204969::u64.
free_NE :- u64, action(swerve_right), curr_lane, free_E, \+ free_NW.

0.4885728::u65.
free_NE :- u65, action(change_to_left), \+ curr_lane, \+ free_E, free_NW.

0.5066588::u66.
free_NE :- u66, action(change_to_right), \+ curr_lane, \+ free_E, free_NW.

0.5517452::u67.
free_NE :- u67, action(cruise), \+ curr_lane, \+ free_E, free_NW.

0.3409091::u68.
free_NE :- u68, action(keep), \+ curr_lane, \+ free_E, free_NW.

0.5217391::u69.
free_NE :- u69, action(swerve_left), \+ curr_lane, \+ free_E, free_NW.

0.5000000::u70.
free_NE :- u70, action(swerve_right), \+ curr_lane, \+ free_E, free_NW.

0.5022460::u71.
free_NE :- u71, action(change_to_left), curr_lane, \+ free_E, free_NW.

0.5041138::u72.
free_NE :- u72, action(change_to_right), curr_lane, \+ free_E, free_NW.

0.2046048::u73.
free_NE :- u73, action(cruise), curr_lane, \+ free_E, free_NW.

0.0063291::u74.
free_NE :- u74, action(keep), curr_lane, \+ free_E, free_NW.

0.0476190::u75.
free_NE :- u75, action(swerve_left), curr_lane, \+ free_E, free_NW.

0.0009990::u76.
free_NE :- u76, action(swerve_right), curr_lane, \+ free_E, free_NW.

0.4538631::u77.
free_NE :- u77, action(change_to_left), \+ curr_lane, free_E, free_NW.

0.6180444::u78.
free_NE :- u78, action(change_to_right), \+ curr_lane, free_E, free_NW.

0.4200276::u79.
free_NE :- u79, action(cruise), \+ curr_lane, free_E, free_NW.

0.4492099::u80.
free_NE :- u80, action(keep), \+ curr_lane, free_E, free_NW.

0.8067633::u81.
free_NE :- u81, action(swerve_left), \+ curr_lane, free_E, free_NW.

0.9990010::u82.
free_NE :- u82, action(swerve_right), \+ curr_lane, free_E, free_NW.

0.5343782::u83.
free_NE :- u83, action(change_to_left), curr_lane, free_E, free_NW.

0.6119476::u84.
free_NE :- u84, action(change_to_right), curr_lane, free_E, free_NW.

0.9089901::u85.
free_NE :- u85, action(cruise), curr_lane, free_E, free_NW.

0.0592016::u86.
free_NE :- u86, action(keep), curr_lane, free_E, free_NW.

0.9275894::u87.
free_NE :- u87, action(swerve_left), curr_lane, free_E, free_NW.

0.8914373::u88.
free_NE :- u88, action(swerve_right), curr_lane, free_E, free_NW.

0.4931505::u89.
free_NW :- u89, action(change_to_left), \+ free_SW.

0.4979888::u90.
free_NW :- u90, action(change_to_right), \+ free_SW.

0.4433836::u91.
free_NW :- u91, action(cruise), \+ free_SW.

0.4184514::u92.
free_NW :- u92, action(keep), \+ free_SW.

0.8857143::u93.
free_NW :- u93, action(swerve_left), \+ free_SW.

0.4814815::u94.
free_NW :- u94, action(swerve_right), \+ free_SW.

0.5110194::u95.
free_NW :- u95, action(change_to_left), free_SW.

0.5742558::u96.
free_NW :- u96, action(change_to_right), free_SW.

0.5807748::u97.
free_NW :- u97, action(cruise), free_SW.

0.0134763::u98.
free_NW :- u98, action(keep), free_SW.

0.9652677::u99.
free_NW :- u99, action(swerve_left), free_SW.

0.8216146::u100.
free_NW :- u100, action(swerve_right), free_SW.

