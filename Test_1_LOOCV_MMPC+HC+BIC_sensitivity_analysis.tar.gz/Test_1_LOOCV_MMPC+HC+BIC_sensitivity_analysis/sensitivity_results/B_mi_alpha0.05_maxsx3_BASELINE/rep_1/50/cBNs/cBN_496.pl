%%% Exogenous variables

0.1688104::u_action(change_to_left); 0.1699492::u_action(change_to_right); 0.4048254::u_action(cruise); 0.2540493::u_action(keep); 0.0014849::u_action(swerve_left); 0.0008807::u_action(swerve_right)
action(V) :- u_action(V).

0.5996684::u1.
free_SE :- u1.

0.6819978::u2.
free_SW :- u2.

0.7120213::u3.
free_W :- u3.

0.3875519::u4.
latent_collision :- u4.

0.4265383::u5.
curr_lane :- u5, action(change_to_left), \+ free_SE.

0.4679537::u6.
curr_lane :- u6, action(change_to_right), \+ free_SE.

0.4850373::u7.
curr_lane :- u7, action(cruise), \+ free_SE.

0.1367963::u8.
curr_lane :- u8, action(keep), \+ free_SE.

0.3292683::u9.
curr_lane :- u9, action(swerve_left), \+ free_SE.

0.9990010::u10.
curr_lane :- u10, action(swerve_right), \+ free_SE.

0.5437789::u11.
curr_lane :- u11, action(change_to_left), free_SE.

0.5554674::u12.
curr_lane :- u12, action(change_to_right), free_SE.

0.7140697::u13.
curr_lane :- u13, action(cruise), free_SE.

0.6018541::u14.
curr_lane :- u14, action(keep), free_SE.

0.8486842::u15.
curr_lane :- u15, action(swerve_left), free_SE.

0.9938499::u16.
curr_lane :- u16, action(swerve_right), free_SE.

0.5036944::u17.
free_E :- u17, action(change_to_left), \+ curr_lane, \+ free_SE.

0.5653296::u18.
free_E :- u18, action(change_to_right), \+ curr_lane, \+ free_SE.

0.3932184::u19.
free_E :- u19, action(cruise), \+ curr_lane, \+ free_SE.

0.5649626::u20.
free_E :- u20, action(keep), \+ curr_lane, \+ free_SE.

0.5636364::u21.
free_E :- u21, action(swerve_left), \+ curr_lane, \+ free_SE.

0.5000000::u22.
free_E :- u22, action(swerve_right), \+ curr_lane, \+ free_SE.

0.5043234::u23.
free_E :- u23, action(change_to_left), curr_lane, \+ free_SE.

0.5254057::u24.
free_E :- u24, action(change_to_right), curr_lane, \+ free_SE.

0.7993755::u25.
free_E :- u25, action(cruise), curr_lane, \+ free_SE.

0.9962214::u26.
free_E :- u26, action(keep), curr_lane, \+ free_SE.

0.9990010::u27.
free_E :- u27, action(swerve_left), curr_lane, \+ free_SE.

0.9990010::u28.
free_E :- u28, action(swerve_right), curr_lane, \+ free_SE.

0.5207739::u29.
free_E :- u29, action(change_to_left), \+ curr_lane, free_SE.

0.3963168::u30.
free_E :- u30, action(change_to_right), \+ curr_lane, free_SE.

0.6285601::u31.
free_E :- u31, action(cruise), \+ curr_lane, free_SE.

0.6595006::u32.
free_E :- u32, action(keep), \+ curr_lane, free_SE.

0.8985507::u33.
free_E :- u33, action(swerve_left), \+ curr_lane, free_SE.

0.9990010::u34.
free_E :- u34, action(swerve_right), \+ curr_lane, free_SE.

0.5837826::u35.
free_E :- u35, action(change_to_left), curr_lane, free_SE.

0.5228333::u36.
free_E :- u36, action(change_to_right), curr_lane, free_SE.

0.9241208::u37.
free_E :- u37, action(cruise), curr_lane, free_SE.

0.8779815::u38.
free_E :- u38, action(keep), curr_lane, free_SE.

0.9844961::u39.
free_E :- u39, action(swerve_left), curr_lane, free_SE.

0.9950495::u40.
free_E :- u40, action(swerve_right), curr_lane, free_SE.

0.4982304::u41.
free_NE :- u41, action(change_to_left), \+ curr_lane, \+ free_E, \+ free_NW.

0.5163167::u42.
free_NE :- u42, action(change_to_right), \+ curr_lane, \+ free_E, \+ free_NW.

0.4907618::u43.
free_NE :- u43, action(cruise), \+ curr_lane, \+ free_E, \+ free_NW.

0.2616224::u44.
free_NE :- u44, action(keep), \+ curr_lane, \+ free_E, \+ free_NW.

0.2500000::u45.
free_NE :- u45, action(swerve_left), \+ curr_lane, \+ free_E, \+ free_NW.

0.5000000::u46.
free_NE :- u46, action(swerve_right), \+ curr_lane, \+ free_E, \+ free_NW.

0.5015519::u47.
free_NE :- u47, action(change_to_left), curr_lane, \+ free_E, \+ free_NW.

0.5007004::u48.
free_NE :- u48, action(change_to_right), curr_lane, \+ free_E, \+ free_NW.

0.2461999::u49.
free_NE :- u49, action(cruise), curr_lane, \+ free_E, \+ free_NW.

0.0002251::u50.
free_NE :- u50, action(keep), curr_lane, \+ free_E, \+ free_NW.

0.0009990::u51.
free_NE :- u51, action(swerve_left), curr_lane, \+ free_E, \+ free_NW.

0.6666667::u52.
free_NE :- u52, action(swerve_right), curr_lane, \+ free_E, \+ free_NW.

0.5015271::u53.
free_NE :- u53, action(change_to_left), \+ curr_lane, free_E, \+ free_NW.

0.2374657::u54.
free_NE :- u54, action(change_to_right), \+ curr_lane, free_E, \+ free_NW.

0.4897504::u55.
free_NE :- u55, action(cruise), \+ curr_lane, free_E, \+ free_NW.

0.0099897::u56.
free_NE :- u56, action(keep), \+ curr_lane, free_E, \+ free_NW.

0.0009990::u57.
free_NE :- u57, action(swerve_left), \+ curr_lane, free_E, \+ free_NW.

0.5000000::u58.
free_NE :- u58, action(swerve_right), \+ curr_lane, free_E, \+ free_NW.

0.4738184::u59.
free_NE :- u59, action(change_to_left), curr_lane, free_E, \+ free_NW.

0.5224560::u60.
free_NE :- u60, action(change_to_right), curr_lane, free_E, \+ free_NW.

0.9076000::u61.
free_NE :- u61, action(cruise), curr_lane, free_E, \+ free_NW.

0.0011664::u62.
free_NE :- u62, action(keep), curr_lane, free_E, \+ free_NW.

0.2352941::u63.
free_NE :- u63, action(swerve_left), curr_lane, free_E, \+ free_NW.

0.6946108::u64.
free_NE :- u64, action(swerve_right), curr_lane, free_E, \+ free_NW.

0.4897653::u65.
free_NE :- u65, action(change_to_left), \+ curr_lane, \+ free_E, free_NW.

0.5142996::u66.
free_NE :- u66, action(change_to_right), \+ curr_lane, \+ free_E, free_NW.

0.5511332::u67.
free_NE :- u67, action(cruise), \+ curr_lane, \+ free_E, free_NW.

0.3469388::u68.
free_NE :- u68, action(keep), \+ curr_lane, \+ free_E, free_NW.

0.3170732::u69.
free_NE :- u69, action(swerve_left), \+ curr_lane, \+ free_E, free_NW.

0.5000000::u70.
free_NE :- u70, action(swerve_right), \+ curr_lane, \+ free_E, free_NW.

0.4969582::u71.
free_NE :- u71, action(change_to_left), curr_lane, \+ free_E, free_NW.

0.5024361::u72.
free_NE :- u72, action(change_to_right), curr_lane, \+ free_E, free_NW.

0.2040051::u73.
free_NE :- u73, action(cruise), curr_lane, \+ free_E, free_NW.

0.0121212::u74.
free_NE :- u74, action(keep), curr_lane, \+ free_E, free_NW.

0.0009990::u75.
free_NE :- u75, action(swerve_left), curr_lane, \+ free_E, free_NW.

0.0009990::u76.
free_NE :- u76, action(swerve_right), curr_lane, \+ free_E, free_NW.

0.4535739::u77.
free_NE :- u77, action(change_to_left), \+ curr_lane, free_E, free_NW.

0.6220780::u78.
free_NE :- u78, action(change_to_right), \+ curr_lane, free_E, free_NW.

0.4223272::u79.
free_NE :- u79, action(cruise), \+ curr_lane, free_E, free_NW.

0.4642857::u80.
free_NE :- u80, action(keep), \+ curr_lane, free_E, free_NW.

0.8767773::u81.
free_NE :- u81, action(swerve_left), \+ curr_lane, free_E, free_NW.

0.9990010::u82.
free_NE :- u82, action(swerve_right), \+ curr_lane, free_E, free_NW.

0.5058838::u83.
free_NE :- u83, action(change_to_left), curr_lane, free_E, free_NW.

0.5584169::u84.
free_NE :- u84, action(change_to_right), curr_lane, free_E, free_NW.

0.8906527::u85.
free_NE :- u85, action(cruise), curr_lane, free_E, free_NW.

0.0403675::u86.
free_NE :- u86, action(keep), curr_lane, free_E, free_NW.

0.9330986::u87.
free_NE :- u87, action(swerve_left), curr_lane, free_E, free_NW.

0.8932749::u88.
free_NE :- u88, action(swerve_right), curr_lane, free_E, free_NW.

0.4948166::u89.
free_NW :- u89, action(change_to_left), \+ free_SW.

0.4870592::u90.
free_NW :- u90, action(change_to_right), \+ free_SW.

0.4369946::u91.
free_NW :- u91, action(cruise), \+ free_SW.

0.4212963::u92.
free_NW :- u92, action(keep), \+ free_SW.

0.7500000::u93.
free_NW :- u93, action(swerve_left), \+ free_SW.

0.4400000::u94.
free_NW :- u94, action(swerve_right), \+ free_SW.

0.5191827::u95.
free_NW :- u95, action(change_to_left), free_SW.

0.5815688::u96.
free_NW :- u96, action(change_to_right), free_SW.

0.5853261::u97.
free_NW :- u97, action(cruise), free_SW.

0.0218905::u98.
free_NW :- u98, action(keep), free_SW.

0.9744681::u99.
free_NW :- u99, action(swerve_left), free_SW.

0.8246914::u100.
free_NW :- u100, action(swerve_right), free_SW.

