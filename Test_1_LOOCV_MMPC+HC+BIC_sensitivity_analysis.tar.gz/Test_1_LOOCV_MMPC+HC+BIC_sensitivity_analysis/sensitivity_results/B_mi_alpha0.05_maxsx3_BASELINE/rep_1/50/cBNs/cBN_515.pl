%%% Exogenous variables

0.1675778::u_action(change_to_left); 0.1703133::u_action(change_to_right); 0.4051496::u_action(cruise); 0.2546357::u_action(keep); 0.0014646::u_action(swerve_left); 0.0008589::u_action(swerve_right)
action(V) :- u_action(V).

0.5991079::u1.
free_SE :- u1.

0.6827641::u2.
free_SW :- u2.

0.7155093::u3.
free_W :- u3.

0.3853748::u4.
latent_collision :- u4.

0.4391233::u5.
curr_lane :- u5, action(change_to_left), \+ free_SE.

0.4825240::u6.
curr_lane :- u6, action(change_to_right), \+ free_SE.

0.4986840::u7.
curr_lane :- u7, action(cruise), \+ free_SE.

0.1367682::u8.
curr_lane :- u8, action(keep), \+ free_SE.

0.3333333::u9.
curr_lane :- u9, action(swerve_left), \+ free_SE.

0.9990010::u10.
curr_lane :- u10, action(swerve_right), \+ free_SE.

0.5419181::u11.
curr_lane :- u11, action(change_to_left), free_SE.

0.5544931::u12.
curr_lane :- u12, action(change_to_right), free_SE.

0.7139266::u13.
curr_lane :- u13, action(cruise), free_SE.

0.6016428::u14.
curr_lane :- u14, action(keep), free_SE.

0.8500739::u15.
curr_lane :- u15, action(swerve_left), free_SE.

0.9925000::u16.
curr_lane :- u16, action(swerve_right), free_SE.

0.5217281::u17.
free_E :- u17, action(change_to_left), \+ curr_lane, \+ free_SE.

0.5820154::u18.
free_E :- u18, action(change_to_right), \+ curr_lane, \+ free_SE.

0.4010271::u19.
free_E :- u19, action(cruise), \+ curr_lane, \+ free_SE.

0.5653651::u20.
free_E :- u20, action(keep), \+ curr_lane, \+ free_SE.

0.5800000::u21.
free_E :- u21, action(swerve_left), \+ curr_lane, \+ free_SE.

0.5000000::u22.
free_E :- u22, action(swerve_right), \+ curr_lane, \+ free_SE.

0.5056903::u23.
free_E :- u23, action(change_to_left), curr_lane, \+ free_SE.

0.5390066::u24.
free_E :- u24, action(change_to_right), curr_lane, \+ free_SE.

0.8048097::u25.
free_E :- u25, action(cruise), curr_lane, \+ free_SE.

0.9964560::u26.
free_E :- u26, action(keep), curr_lane, \+ free_SE.

0.9990010::u27.
free_E :- u27, action(swerve_left), curr_lane, \+ free_SE.

0.9990010::u28.
free_E :- u28, action(swerve_right), curr_lane, \+ free_SE.

0.5197356::u29.
free_E :- u29, action(change_to_left), \+ curr_lane, free_SE.

0.3974672::u30.
free_E :- u30, action(change_to_right), \+ curr_lane, free_SE.

0.6288118::u31.
free_E :- u31, action(cruise), \+ curr_lane, free_SE.

0.6610971::u32.
free_E :- u32, action(keep), \+ curr_lane, free_SE.

0.9162562::u33.
free_E :- u33, action(swerve_left), \+ curr_lane, free_SE.

0.9990010::u34.
free_E :- u34, action(swerve_right), \+ curr_lane, free_SE.

0.5843797::u35.
free_E :- u35, action(change_to_left), curr_lane, free_SE.

0.5214130::u36.
free_E :- u36, action(change_to_right), curr_lane, free_SE.

0.9242807::u37.
free_E :- u37, action(cruise), curr_lane, free_SE.

0.8794181::u38.
free_E :- u38, action(keep), curr_lane, free_SE.

0.9808862::u39.
free_E :- u39, action(swerve_left), curr_lane, free_SE.

0.9949622::u40.
free_E :- u40, action(swerve_right), curr_lane, free_SE.

0.4637720::u41.
free_NE :- u41, action(change_to_left), \+ curr_lane, \+ free_E, \+ free_NW.

0.4805479::u42.
free_NE :- u42, action(change_to_right), \+ curr_lane, \+ free_E, \+ free_NW.

0.4689977::u43.
free_NE :- u43, action(cruise), \+ curr_lane, \+ free_E, \+ free_NW.

0.2619702::u44.
free_NE :- u44, action(keep), \+ curr_lane, \+ free_E, \+ free_NW.

0.0009990::u45.
free_NE :- u45, action(swerve_left), \+ curr_lane, \+ free_E, \+ free_NW.

0.5000000::u46.
free_NE :- u46, action(swerve_right), \+ curr_lane, \+ free_E, \+ free_NW.

0.4954687::u47.
free_NE :- u47, action(change_to_left), curr_lane, \+ free_E, \+ free_NW.

0.5020345::u48.
free_NE :- u48, action(change_to_right), curr_lane, \+ free_E, \+ free_NW.

0.2498877::u49.
free_NE :- u49, action(cruise), curr_lane, \+ free_E, \+ free_NW.

0.0002276::u50.
free_NE :- u50, action(keep), curr_lane, \+ free_E, \+ free_NW.

0.0009990::u51.
free_NE :- u51, action(swerve_left), curr_lane, \+ free_E, \+ free_NW.

0.9990010::u52.
free_NE :- u52, action(swerve_right), curr_lane, \+ free_E, \+ free_NW.

0.4988708::u53.
free_NE :- u53, action(change_to_left), \+ curr_lane, free_E, \+ free_NW.

0.2412104::u54.
free_NE :- u54, action(change_to_right), \+ curr_lane, free_E, \+ free_NW.

0.4911011::u55.
free_NE :- u55, action(cruise), \+ curr_lane, free_E, \+ free_NW.

0.0098663::u56.
free_NE :- u56, action(keep), \+ curr_lane, free_E, \+ free_NW.

0.0009990::u57.
free_NE :- u57, action(swerve_left), \+ curr_lane, free_E, \+ free_NW.

0.5000000::u58.
free_NE :- u58, action(swerve_right), \+ curr_lane, free_E, \+ free_NW.

0.4751459::u59.
free_NE :- u59, action(change_to_left), curr_lane, free_E, \+ free_NW.

0.5251195::u60.
free_NE :- u60, action(change_to_right), curr_lane, free_E, \+ free_NW.

0.9084943::u61.
free_NE :- u61, action(cruise), curr_lane, free_E, \+ free_NW.

0.0010826::u62.
free_NE :- u62, action(keep), curr_lane, free_E, \+ free_NW.

0.2000000::u63.
free_NE :- u63, action(swerve_left), curr_lane, free_E, \+ free_NW.

0.7142857::u64.
free_NE :- u64, action(swerve_right), curr_lane, free_E, \+ free_NW.

0.4912587::u65.
free_NE :- u65, action(change_to_left), \+ curr_lane, \+ free_E, free_NW.

0.5124287::u66.
free_NE :- u66, action(change_to_right), \+ curr_lane, \+ free_E, free_NW.

0.5546734::u67.
free_NE :- u67, action(cruise), \+ curr_lane, \+ free_E, free_NW.

0.4680851::u68.
free_NE :- u68, action(keep), \+ curr_lane, \+ free_E, free_NW.

0.4444444::u69.
free_NE :- u69, action(swerve_left), \+ curr_lane, \+ free_E, free_NW.

0.5000000::u70.
free_NE :- u70, action(swerve_right), \+ curr_lane, \+ free_E, free_NW.

0.4966689::u71.
free_NE :- u71, action(change_to_left), curr_lane, \+ free_E, free_NW.

0.5013714::u72.
free_NE :- u72, action(change_to_right), curr_lane, \+ free_E, free_NW.

0.2015634::u73.
free_NE :- u73, action(cruise), curr_lane, \+ free_E, free_NW.

0.0119760::u74.
free_NE :- u74, action(keep), curr_lane, \+ free_E, free_NW.

0.0476190::u75.
free_NE :- u75, action(swerve_left), curr_lane, \+ free_E, free_NW.

0.0009990::u76.
free_NE :- u76, action(swerve_right), curr_lane, \+ free_E, free_NW.

0.4525458::u77.
free_NE :- u77, action(change_to_left), \+ curr_lane, free_E, free_NW.

0.6200694::u78.
free_NE :- u78, action(change_to_right), \+ curr_lane, free_E, free_NW.

0.4188510::u79.
free_NE :- u79, action(cruise), \+ curr_lane, free_E, free_NW.

0.4497817::u80.
free_NE :- u80, action(keep), \+ curr_lane, free_E, free_NW.

0.8300971::u81.
free_NE :- u81, action(swerve_left), \+ curr_lane, free_E, free_NW.

0.9990010::u82.
free_NE :- u82, action(swerve_right), \+ curr_lane, free_E, free_NW.

0.5020495::u83.
free_NE :- u83, action(change_to_left), curr_lane, free_E, free_NW.

0.5798189::u84.
free_NE :- u84, action(change_to_right), curr_lane, free_E, free_NW.

0.8927696::u85.
free_NE :- u85, action(cruise), curr_lane, free_E, free_NW.

0.0400222::u86.
free_NE :- u86, action(keep), curr_lane, free_E, free_NW.

0.9359784::u87.
free_NE :- u87, action(swerve_left), curr_lane, free_E, free_NW.

0.8916914::u88.
free_NE :- u88, action(swerve_right), curr_lane, free_E, free_NW.

0.5009617::u89.
free_NW :- u89, action(change_to_left), \+ free_SW.

0.5075164::u90.
free_NW :- u90, action(change_to_right), \+ free_SW.

0.4452254::u91.
free_NW :- u91, action(cruise), \+ free_SW.

0.4161429::u92.
free_NW :- u92, action(keep), \+ free_SW.

0.8000000::u93.
free_NW :- u93, action(swerve_left), \+ free_SW.

0.4558824::u94.
free_NW :- u94, action(swerve_right), \+ free_SW.

0.5188676::u95.
free_NW :- u95, action(change_to_left), free_SW.

0.5803730::u96.
free_NW :- u96, action(change_to_right), free_SW.

0.5848830::u97.
free_NW :- u97, action(cruise), free_SW.

0.0220794::u98.
free_NW :- u98, action(keep), free_SW.

0.9641320::u99.
free_NW :- u99, action(swerve_left), free_SW.

0.8441558::u100.
free_NW :- u100, action(swerve_right), free_SW.

