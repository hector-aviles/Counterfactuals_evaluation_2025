%%% Exogenous variables

0.1682316::u_action(change_to_left); 0.1701553::u_action(change_to_right); 0.4049272::u_action(cruise); 0.2543982::u_action(keep); 0.0014062::u_action(swerve_left); 0.0008814::u_action(swerve_right)
action(V) :- u_action(V).

0.5948155::u1.
free_SE :- u1.

0.6788831::u2.
free_SW :- u2.

0.7156883::u3.
free_W :- u3.

0.3858462::u4.
latent_collision :- u4.

0.4301440::u5.
curr_lane :- u5, action(change_to_left), \+ free_SE.

0.4741442::u6.
curr_lane :- u6, action(change_to_right), \+ free_SE.

0.4931838::u7.
curr_lane :- u7, action(cruise), \+ free_SE.

0.1386938::u8.
curr_lane :- u8, action(keep), \+ free_SE.

0.2692308::u9.
curr_lane :- u9, action(swerve_left), \+ free_SE.

0.9990010::u10.
curr_lane :- u10, action(swerve_right), \+ free_SE.

0.5491718::u11.
curr_lane :- u11, action(change_to_left), free_SE.

0.5632886::u12.
curr_lane :- u12, action(change_to_right), free_SE.

0.7160293::u13.
curr_lane :- u13, action(cruise), free_SE.

0.6021624::u14.
curr_lane :- u14, action(keep), free_SE.

0.8485317::u15.
curr_lane :- u15, action(swerve_left), free_SE.

0.9901720::u16.
curr_lane :- u16, action(swerve_right), free_SE.

0.5037110::u17.
free_E :- u17, action(change_to_left), \+ curr_lane, \+ free_SE.

0.5644768::u18.
free_E :- u18, action(change_to_right), \+ curr_lane, \+ free_SE.

0.3946652::u19.
free_E :- u19, action(cruise), \+ curr_lane, \+ free_SE.

0.5652999::u20.
free_E :- u20, action(keep), \+ curr_lane, \+ free_SE.

0.4385965::u21.
free_E :- u21, action(swerve_left), \+ curr_lane, \+ free_SE.

0.5000000::u22.
free_E :- u22, action(swerve_right), \+ curr_lane, \+ free_SE.

0.4998698::u23.
free_E :- u23, action(change_to_left), curr_lane, \+ free_SE.

0.5408671::u24.
free_E :- u24, action(change_to_right), curr_lane, \+ free_SE.

0.8022543::u25.
free_E :- u25, action(cruise), curr_lane, \+ free_SE.

0.9962243::u26.
free_E :- u26, action(keep), curr_lane, \+ free_SE.

0.9990010::u27.
free_E :- u27, action(swerve_left), curr_lane, \+ free_SE.

0.9990010::u28.
free_E :- u28, action(swerve_right), curr_lane, \+ free_SE.

0.5328645::u29.
free_E :- u29, action(change_to_left), \+ curr_lane, free_SE.

0.4114081::u30.
free_E :- u30, action(change_to_right), \+ curr_lane, free_SE.

0.6374813::u31.
free_E :- u31, action(cruise), \+ curr_lane, free_SE.

0.6579094::u32.
free_E :- u32, action(keep), \+ curr_lane, free_SE.

0.9030612::u33.
free_E :- u33, action(swerve_left), \+ curr_lane, free_SE.

0.9990010::u34.
free_E :- u34, action(swerve_right), \+ curr_lane, free_SE.

0.5848256::u35.
free_E :- u35, action(change_to_left), curr_lane, free_SE.

0.5254449::u36.
free_E :- u36, action(change_to_right), curr_lane, free_SE.

0.9240977::u37.
free_E :- u37, action(cruise), curr_lane, free_SE.

0.8787430::u38.
free_E :- u38, action(keep), curr_lane, free_SE.

0.9808743::u39.
free_E :- u39, action(swerve_left), curr_lane, free_SE.

0.9950372::u40.
free_E :- u40, action(swerve_right), curr_lane, free_SE.

0.4632798::u41.
free_NE :- u41, action(change_to_left), \+ curr_lane, \+ free_E, \+ free_NW.

0.4790084::u42.
free_NE :- u42, action(change_to_right), \+ curr_lane, \+ free_E, \+ free_NW.

0.4630330::u43.
free_NE :- u43, action(cruise), \+ curr_lane, \+ free_E, \+ free_NW.

0.2602218::u44.
free_NE :- u44, action(keep), \+ curr_lane, \+ free_E, \+ free_NW.

0.0009990::u45.
free_NE :- u45, action(swerve_left), \+ curr_lane, \+ free_E, \+ free_NW.

0.5000000::u46.
free_NE :- u46, action(swerve_right), \+ curr_lane, \+ free_E, \+ free_NW.

0.4975711::u47.
free_NE :- u47, action(change_to_left), curr_lane, \+ free_E, \+ free_NW.

0.5046507::u48.
free_NE :- u48, action(change_to_right), curr_lane, \+ free_E, \+ free_NW.

0.2483508::u49.
free_NE :- u49, action(cruise), curr_lane, \+ free_E, \+ free_NW.

0.0001133::u50.
free_NE :- u50, action(keep), curr_lane, \+ free_E, \+ free_NW.

0.5000000::u51.
free_NE :- u51, action(swerve_left), curr_lane, \+ free_E, \+ free_NW.

0.6666667::u52.
free_NE :- u52, action(swerve_right), curr_lane, \+ free_E, \+ free_NW.

0.4968210::u53.
free_NE :- u53, action(change_to_left), \+ curr_lane, free_E, \+ free_NW.

0.2419623::u54.
free_NE :- u54, action(change_to_right), \+ curr_lane, free_E, \+ free_NW.

0.4868681::u55.
free_NE :- u55, action(cruise), \+ curr_lane, free_E, \+ free_NW.

0.0106891::u56.
free_NE :- u56, action(keep), \+ curr_lane, free_E, \+ free_NW.

0.0009990::u57.
free_NE :- u57, action(swerve_left), \+ curr_lane, free_E, \+ free_NW.

0.5000000::u58.
free_NE :- u58, action(swerve_right), \+ curr_lane, free_E, \+ free_NW.

0.4712895::u59.
free_NE :- u59, action(change_to_left), curr_lane, free_E, \+ free_NW.

0.5232563::u60.
free_NE :- u60, action(change_to_right), curr_lane, free_E, \+ free_NW.

0.9082651::u61.
free_NE :- u61, action(cruise), curr_lane, free_E, \+ free_NW.

0.0011224::u62.
free_NE :- u62, action(keep), curr_lane, free_E, \+ free_NW.

0.1904762::u63.
free_NE :- u63, action(swerve_left), curr_lane, free_E, \+ free_NW.

0.6547619::u64.
free_NE :- u64, action(swerve_right), curr_lane, free_E, \+ free_NW.

0.4832360::u65.
free_NE :- u65, action(change_to_left), \+ curr_lane, \+ free_E, free_NW.

0.5102853::u66.
free_NE :- u66, action(change_to_right), \+ curr_lane, \+ free_E, free_NW.

0.5525316::u67.
free_NE :- u67, action(cruise), \+ curr_lane, \+ free_E, free_NW.

0.4727273::u68.
free_NE :- u68, action(keep), \+ curr_lane, \+ free_E, free_NW.

0.4285714::u69.
free_NE :- u69, action(swerve_left), \+ curr_lane, \+ free_E, free_NW.

0.5000000::u70.
free_NE :- u70, action(swerve_right), \+ curr_lane, \+ free_E, free_NW.

0.4999694::u71.
free_NE :- u71, action(change_to_left), curr_lane, \+ free_E, free_NW.

0.5056909::u72.
free_NE :- u72, action(change_to_right), curr_lane, \+ free_E, free_NW.

0.2009607::u73.
free_NE :- u73, action(cruise), curr_lane, \+ free_E, free_NW.

0.0061728::u74.
free_NE :- u74, action(keep), curr_lane, \+ free_E, free_NW.

0.0009990::u75.
free_NE :- u75, action(swerve_left), curr_lane, \+ free_E, free_NW.

0.0009990::u76.
free_NE :- u76, action(swerve_right), curr_lane, \+ free_E, free_NW.

0.4506227::u77.
free_NE :- u77, action(change_to_left), \+ curr_lane, free_E, free_NW.

0.6233514::u78.
free_NE :- u78, action(change_to_right), \+ curr_lane, free_E, free_NW.

0.4205837::u79.
free_NE :- u79, action(cruise), \+ curr_lane, free_E, free_NW.

0.4977578::u80.
free_NE :- u80, action(keep), \+ curr_lane, free_E, free_NW.

0.8622449::u81.
free_NE :- u81, action(swerve_left), \+ curr_lane, free_E, free_NW.

0.9990010::u82.
free_NE :- u82, action(swerve_right), \+ curr_lane, free_E, free_NW.

0.5025330::u83.
free_NE :- u83, action(change_to_left), curr_lane, free_E, free_NW.

0.5798471::u84.
free_NE :- u84, action(change_to_right), curr_lane, free_E, free_NW.

0.8931603::u85.
free_NE :- u85, action(cruise), curr_lane, free_E, free_NW.

0.0423705::u86.
free_NE :- u86, action(keep), curr_lane, free_E, free_NW.

0.9346591::u87.
free_NE :- u87, action(swerve_left), curr_lane, free_E, free_NW.

0.8970588::u88.
free_NE :- u88, action(swerve_right), curr_lane, free_E, free_NW.

0.4943290::u89.
free_NW :- u89, action(change_to_left), \+ free_SW.

0.4973936::u90.
free_NW :- u90, action(change_to_right), \+ free_SW.

0.4421551::u91.
free_NW :- u91, action(cruise), \+ free_SW.

0.4214047::u92.
free_NW :- u92, action(keep), \+ free_SW.

0.7608696::u93.
free_NW :- u93, action(swerve_left), \+ free_SW.

0.4615385::u94.
free_NW :- u94, action(swerve_right), \+ free_SW.

0.5256526::u95.
free_NW :- u95, action(change_to_left), free_SW.

0.5875894::u96.
free_NW :- u96, action(change_to_right), free_SW.

0.5882900::u97.
free_NW :- u97, action(cruise), free_SW.

0.0221483::u98.
free_NW :- u98, action(keep), free_SW.

0.9690799::u99.
free_NW :- u99, action(swerve_left), free_SW.

0.8289308::u100.
free_NW :- u100, action(swerve_right), free_SW.

