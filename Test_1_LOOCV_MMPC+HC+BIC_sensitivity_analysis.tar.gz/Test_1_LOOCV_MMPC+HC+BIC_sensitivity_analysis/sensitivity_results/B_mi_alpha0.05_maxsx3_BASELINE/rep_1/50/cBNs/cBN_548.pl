%%% Exogenous variables

0.1674528::u_action(change_to_left); 0.1715309::u_action(change_to_right); 0.4049013::u_action(cruise); 0.2538140::u_action(keep); 0.0014361::u_action(swerve_left); 0.0008650::u_action(swerve_right)
action(V) :- u_action(V).

0.5987489::u1.
free_SE :- u1.

0.6819646::u2.
free_SW :- u2.

0.7118755::u3.
free_W :- u3.

0.3868580::u4.
latent_collision :- u4.

0.4379576::u5.
curr_lane :- u5, action(change_to_left), \+ free_SE.

0.4766591::u6.
curr_lane :- u6, action(change_to_right), \+ free_SE.

0.5006498::u7.
curr_lane :- u7, action(cruise), \+ free_SE.

0.1372860::u8.
curr_lane :- u8, action(keep), \+ free_SE.

0.3052632::u9.
curr_lane :- u9, action(swerve_left), \+ free_SE.

0.9990010::u10.
curr_lane :- u10, action(swerve_right), \+ free_SE.

0.5416106::u11.
curr_lane :- u11, action(change_to_left), free_SE.

0.5559248::u12.
curr_lane :- u12, action(change_to_right), free_SE.

0.7132393::u13.
curr_lane :- u13, action(cruise), free_SE.

0.6016253::u14.
curr_lane :- u14, action(keep), free_SE.

0.8470948::u15.
curr_lane :- u15, action(swerve_left), free_SE.

0.9886792::u16.
curr_lane :- u16, action(swerve_right), free_SE.

0.4867835::u17.
free_E :- u17, action(change_to_left), \+ curr_lane, \+ free_SE.

0.5659780::u18.
free_E :- u18, action(change_to_right), \+ curr_lane, \+ free_SE.

0.3799636::u19.
free_E :- u19, action(cruise), \+ curr_lane, \+ free_SE.

0.5657835::u20.
free_E :- u20, action(keep), \+ curr_lane, \+ free_SE.

0.4242424::u21.
free_E :- u21, action(swerve_left), \+ curr_lane, \+ free_SE.

0.5000000::u22.
free_E :- u22, action(swerve_right), \+ curr_lane, \+ free_SE.

0.5031506::u23.
free_E :- u23, action(change_to_left), curr_lane, \+ free_SE.

0.5393867::u24.
free_E :- u24, action(change_to_right), curr_lane, \+ free_SE.

0.8028860::u25.
free_E :- u25, action(cruise), curr_lane, \+ free_SE.

0.9965761::u26.
free_E :- u26, action(keep), curr_lane, \+ free_SE.

0.9990010::u27.
free_E :- u27, action(swerve_left), curr_lane, \+ free_SE.

0.9990010::u28.
free_E :- u28, action(swerve_right), curr_lane, \+ free_SE.

0.5195434::u29.
free_E :- u29, action(change_to_left), \+ curr_lane, free_SE.

0.3990853::u30.
free_E :- u30, action(change_to_right), \+ curr_lane, free_SE.

0.6286276::u31.
free_E :- u31, action(cruise), \+ curr_lane, free_SE.

0.6591426::u32.
free_E :- u32, action(keep), \+ curr_lane, free_SE.

0.8950000::u33.
free_E :- u33, action(swerve_left), \+ curr_lane, free_SE.

0.9990010::u34.
free_E :- u34, action(swerve_right), \+ curr_lane, free_SE.

0.5834516::u35.
free_E :- u35, action(change_to_left), curr_lane, free_SE.

0.5229284::u36.
free_E :- u36, action(change_to_right), curr_lane, free_SE.

0.9245754::u37.
free_E :- u37, action(cruise), curr_lane, free_SE.

0.8784193::u38.
free_E :- u38, action(keep), curr_lane, free_SE.

0.9801444::u39.
free_E :- u39, action(swerve_left), curr_lane, free_SE.

0.9936387::u40.
free_E :- u40, action(swerve_right), curr_lane, free_SE.

0.4975234::u41.
free_NE :- u41, action(change_to_left), \+ curr_lane, \+ free_E, \+ free_NW.

0.5082908::u42.
free_NE :- u42, action(change_to_right), \+ curr_lane, \+ free_E, \+ free_NW.

0.4964278::u43.
free_NE :- u43, action(cruise), \+ curr_lane, \+ free_E, \+ free_NW.

0.2626315::u44.
free_NE :- u44, action(keep), \+ curr_lane, \+ free_E, \+ free_NW.

0.0009990::u45.
free_NE :- u45, action(swerve_left), \+ curr_lane, \+ free_E, \+ free_NW.

0.5000000::u46.
free_NE :- u46, action(swerve_right), \+ curr_lane, \+ free_E, \+ free_NW.

0.5003998::u47.
free_NE :- u47, action(change_to_left), curr_lane, \+ free_E, \+ free_NW.

0.5026358::u48.
free_NE :- u48, action(change_to_right), curr_lane, \+ free_E, \+ free_NW.

0.2460054::u49.
free_NE :- u49, action(cruise), curr_lane, \+ free_E, \+ free_NW.

0.0002262::u50.
free_NE :- u50, action(keep), curr_lane, \+ free_E, \+ free_NW.

0.0009990::u51.
free_NE :- u51, action(swerve_left), curr_lane, \+ free_E, \+ free_NW.

0.5000000::u52.
free_NE :- u52, action(swerve_right), curr_lane, \+ free_E, \+ free_NW.

0.4656505::u53.
free_NE :- u53, action(change_to_left), \+ curr_lane, free_E, \+ free_NW.

0.2336018::u54.
free_NE :- u54, action(change_to_right), \+ curr_lane, free_E, \+ free_NW.

0.4561093::u55.
free_NE :- u55, action(cruise), \+ curr_lane, free_E, \+ free_NW.

0.0101117::u56.
free_NE :- u56, action(keep), \+ curr_lane, free_E, \+ free_NW.

0.0009990::u57.
free_NE :- u57, action(swerve_left), \+ curr_lane, free_E, \+ free_NW.

0.5000000::u58.
free_NE :- u58, action(swerve_right), \+ curr_lane, free_E, \+ free_NW.

0.4768554::u59.
free_NE :- u59, action(change_to_left), curr_lane, free_E, \+ free_NW.

0.5276756::u60.
free_NE :- u60, action(change_to_right), curr_lane, free_E, \+ free_NW.

0.9082678::u61.
free_NE :- u61, action(cruise), curr_lane, free_E, \+ free_NW.

0.0010834::u62.
free_NE :- u62, action(keep), curr_lane, free_E, \+ free_NW.

0.2790698::u63.
free_NE :- u63, action(swerve_left), curr_lane, free_E, \+ free_NW.

0.7032258::u64.
free_NE :- u64, action(swerve_right), curr_lane, free_E, \+ free_NW.

0.4815491::u65.
free_NE :- u65, action(change_to_left), \+ curr_lane, \+ free_E, free_NW.

0.5108489::u66.
free_NE :- u66, action(change_to_right), \+ curr_lane, \+ free_E, free_NW.

0.5489399::u67.
free_NE :- u67, action(cruise), \+ curr_lane, \+ free_E, free_NW.

0.4363636::u68.
free_NE :- u68, action(keep), \+ curr_lane, \+ free_E, free_NW.

0.4827586::u69.
free_NE :- u69, action(swerve_left), \+ curr_lane, \+ free_E, free_NW.

0.5000000::u70.
free_NE :- u70, action(swerve_right), \+ curr_lane, \+ free_E, free_NW.

0.5018057::u71.
free_NE :- u71, action(change_to_left), curr_lane, \+ free_E, free_NW.

0.5028790::u72.
free_NE :- u72, action(change_to_right), curr_lane, \+ free_E, free_NW.

0.2010386::u73.
free_NE :- u73, action(cruise), curr_lane, \+ free_E, free_NW.

0.0009990::u74.
free_NE :- u74, action(keep), curr_lane, \+ free_E, free_NW.

0.0009990::u75.
free_NE :- u75, action(swerve_left), curr_lane, \+ free_E, free_NW.

0.0009990::u76.
free_NE :- u76, action(swerve_right), curr_lane, \+ free_E, free_NW.

0.4562633::u77.
free_NE :- u77, action(change_to_left), \+ curr_lane, free_E, free_NW.

0.6221265::u78.
free_NE :- u78, action(change_to_right), \+ curr_lane, free_E, free_NW.

0.4197197::u79.
free_NE :- u79, action(cruise), \+ curr_lane, free_E, free_NW.

0.4276316::u80.
free_NE :- u80, action(keep), \+ curr_lane, free_E, free_NW.

0.8325123::u81.
free_NE :- u81, action(swerve_left), \+ curr_lane, free_E, free_NW.

0.9990010::u82.
free_NE :- u82, action(swerve_right), \+ curr_lane, free_E, free_NW.

0.5046905::u83.
free_NE :- u83, action(change_to_left), curr_lane, free_E, free_NW.

0.5798995::u84.
free_NE :- u84, action(change_to_right), curr_lane, free_E, free_NW.

0.8926205::u85.
free_NE :- u85, action(cruise), curr_lane, free_E, free_NW.

0.0406298::u86.
free_NE :- u86, action(keep), curr_lane, free_E, free_NW.

0.9291045::u87.
free_NE :- u87, action(swerve_left), curr_lane, free_E, free_NW.

0.8949704::u88.
free_NE :- u88, action(swerve_right), curr_lane, free_E, free_NW.

0.5025040::u89.
free_NW :- u89, action(change_to_left), \+ free_SW.

0.4973341::u90.
free_NW :- u90, action(change_to_right), \+ free_SW.

0.4460707::u91.
free_NW :- u91, action(cruise), \+ free_SW.

0.4102142::u92.
free_NW :- u92, action(keep), \+ free_SW.

0.7500000::u93.
free_NW :- u93, action(swerve_left), \+ free_SW.

0.6111111::u94.
free_NW :- u94, action(swerve_right), \+ free_SW.

0.5184451::u95.
free_NW :- u95, action(change_to_left), free_SW.

0.5787809::u96.
free_NW :- u96, action(change_to_right), free_SW.

0.5841004::u97.
free_NW :- u97, action(cruise), free_SW.

0.0219481::u98.
free_NW :- u98, action(keep), free_SW.

0.9713866::u99.
free_NW :- u99, action(swerve_left), free_SW.

0.8305304::u100.
free_NW :- u100, action(swerve_right), free_SW.

