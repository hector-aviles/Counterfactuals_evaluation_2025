%%% Exogenous variables

0.1676505::u_action(change_to_left); 0.1699047::u_action(change_to_right); 0.4051120::u_action(cruise); 0.2550478::u_action(keep); 0.0014372::u_action(swerve_left); 0.0008478::u_action(swerve_right)
action(V) :- u_action(V).

0.5958517::u1.
free_SE :- u1.

0.6824432::u2.
free_SW :- u2.

0.7121990::u3.
free_W :- u3.

0.3854857::u4.
latent_collision :- u4.

0.4297917::u5.
curr_lane :- u5, action(change_to_left), \+ free_SE.

0.4772961::u6.
curr_lane :- u6, action(change_to_right), \+ free_SE.

0.4945931::u7.
curr_lane :- u7, action(cruise), \+ free_SE.

0.1365075::u8.
curr_lane :- u8, action(keep), \+ free_SE.

0.3170732::u9.
curr_lane :- u9, action(swerve_left), \+ free_SE.

0.9990010::u10.
curr_lane :- u10, action(swerve_right), \+ free_SE.

0.5516252::u11.
curr_lane :- u11, action(change_to_left), free_SE.

0.5641112::u12.
curr_lane :- u12, action(change_to_right), free_SE.

0.7163355::u13.
curr_lane :- u13, action(cruise), free_SE.

0.6034669::u14.
curr_lane :- u14, action(keep), free_SE.

0.8500000::u15.
curr_lane :- u15, action(swerve_left), free_SE.

0.9935317::u16.
curr_lane :- u16, action(swerve_right), free_SE.

0.5054942::u17.
free_E :- u17, action(change_to_left), \+ curr_lane, \+ free_SE.

0.5646206::u18.
free_E :- u18, action(change_to_right), \+ curr_lane, \+ free_SE.

0.3960730::u19.
free_E :- u19, action(cruise), \+ curr_lane, \+ free_SE.

0.5655790::u20.
free_E :- u20, action(keep), \+ curr_lane, \+ free_SE.

0.5178571::u21.
free_E :- u21, action(swerve_left), \+ curr_lane, \+ free_SE.

0.5000000::u22.
free_E :- u22, action(swerve_right), \+ curr_lane, \+ free_SE.

0.5047233::u23.
free_E :- u23, action(change_to_left), curr_lane, \+ free_SE.

0.5359905::u24.
free_E :- u24, action(change_to_right), curr_lane, \+ free_SE.

0.8033389::u25.
free_E :- u25, action(cruise), curr_lane, \+ free_SE.

0.9965045::u26.
free_E :- u26, action(keep), curr_lane, \+ free_SE.

0.9990010::u27.
free_E :- u27, action(swerve_left), curr_lane, \+ free_SE.

0.9990010::u28.
free_E :- u28, action(swerve_right), curr_lane, \+ free_SE.

0.5333607::u29.
free_E :- u29, action(change_to_left), \+ curr_lane, free_SE.

0.4126017::u30.
free_E :- u30, action(change_to_right), \+ curr_lane, free_SE.

0.6369292::u31.
free_E :- u31, action(cruise), \+ curr_lane, free_SE.

0.6585576::u32.
free_E :- u32, action(keep), \+ curr_lane, free_SE.

0.8787879::u33.
free_E :- u33, action(swerve_left), \+ curr_lane, free_SE.

0.9990010::u34.
free_E :- u34, action(swerve_right), \+ curr_lane, free_SE.

0.5815259::u35.
free_E :- u35, action(change_to_left), curr_lane, free_SE.

0.5189178::u36.
free_E :- u36, action(change_to_right), curr_lane, free_SE.

0.9241720::u37.
free_E :- u37, action(cruise), curr_lane, free_SE.

0.8783667::u38.
free_E :- u38, action(keep), curr_lane, free_SE.

0.9803922::u39.
free_E :- u39, action(swerve_left), curr_lane, free_SE.

0.9960938::u40.
free_E :- u40, action(swerve_right), curr_lane, free_SE.

0.5253867::u41.
free_NE :- u41, action(change_to_left), \+ curr_lane, \+ free_E, \+ free_NW.

0.5403192::u42.
free_NE :- u42, action(change_to_right), \+ curr_lane, \+ free_E, \+ free_NW.

0.5292781::u43.
free_NE :- u43, action(cruise), \+ curr_lane, \+ free_E, \+ free_NW.

0.2607366::u44.
free_NE :- u44, action(keep), \+ curr_lane, \+ free_E, \+ free_NW.

0.3333333::u45.
free_NE :- u45, action(swerve_left), \+ curr_lane, \+ free_E, \+ free_NW.

0.5000000::u46.
free_NE :- u46, action(swerve_right), \+ curr_lane, \+ free_E, \+ free_NW.

0.4961012::u47.
free_NE :- u47, action(change_to_left), curr_lane, \+ free_E, \+ free_NW.

0.4976577::u48.
free_NE :- u48, action(change_to_right), curr_lane, \+ free_E, \+ free_NW.

0.2456745::u49.
free_NE :- u49, action(cruise), curr_lane, \+ free_E, \+ free_NW.

0.0001119::u50.
free_NE :- u50, action(keep), curr_lane, \+ free_E, \+ free_NW.

0.0009990::u51.
free_NE :- u51, action(swerve_left), curr_lane, \+ free_E, \+ free_NW.

0.5000000::u52.
free_NE :- u52, action(swerve_right), curr_lane, \+ free_E, \+ free_NW.

0.4970334::u53.
free_NE :- u53, action(change_to_left), \+ curr_lane, free_E, \+ free_NW.

0.2433606::u54.
free_NE :- u54, action(change_to_right), \+ curr_lane, free_E, \+ free_NW.

0.4857789::u55.
free_NE :- u55, action(cruise), \+ curr_lane, free_E, \+ free_NW.

0.0105279::u56.
free_NE :- u56, action(keep), \+ curr_lane, free_E, \+ free_NW.

0.0009990::u57.
free_NE :- u57, action(swerve_left), \+ curr_lane, free_E, \+ free_NW.

0.5000000::u58.
free_NE :- u58, action(swerve_right), \+ curr_lane, free_E, \+ free_NW.

0.4751174::u59.
free_NE :- u59, action(change_to_left), curr_lane, free_E, \+ free_NW.

0.5219286::u60.
free_NE :- u60, action(change_to_right), curr_lane, free_E, \+ free_NW.

0.9070379::u61.
free_NE :- u61, action(cruise), curr_lane, free_E, \+ free_NW.

0.0011319::u62.
free_NE :- u62, action(keep), curr_lane, free_E, \+ free_NW.

0.2195122::u63.
free_NE :- u63, action(swerve_left), curr_lane, free_E, \+ free_NW.

0.6973684::u64.
free_NE :- u64, action(swerve_right), curr_lane, free_E, \+ free_NW.

0.4876726::u65.
free_NE :- u65, action(change_to_left), \+ curr_lane, \+ free_E, free_NW.

0.5051868::u66.
free_NE :- u66, action(change_to_right), \+ curr_lane, \+ free_E, free_NW.

0.5524528::u67.
free_NE :- u67, action(cruise), \+ curr_lane, \+ free_E, free_NW.

0.3269231::u68.
free_NE :- u68, action(keep), \+ curr_lane, \+ free_E, free_NW.

0.3750000::u69.
free_NE :- u69, action(swerve_left), \+ curr_lane, \+ free_E, free_NW.

0.5000000::u70.
free_NE :- u70, action(swerve_right), \+ curr_lane, \+ free_E, free_NW.

0.5007895::u71.
free_NE :- u71, action(change_to_left), curr_lane, \+ free_E, free_NW.

0.5028566::u72.
free_NE :- u72, action(change_to_right), curr_lane, \+ free_E, free_NW.

0.2023715::u73.
free_NE :- u73, action(cruise), curr_lane, \+ free_E, free_NW.

0.0065789::u74.
free_NE :- u74, action(keep), curr_lane, \+ free_E, free_NW.

0.0500000::u75.
free_NE :- u75, action(swerve_left), curr_lane, \+ free_E, free_NW.

0.0009990::u76.
free_NE :- u76, action(swerve_right), curr_lane, \+ free_E, free_NW.

0.4502113::u77.
free_NE :- u77, action(change_to_left), \+ curr_lane, free_E, free_NW.

0.6201545::u78.
free_NE :- u78, action(change_to_right), \+ curr_lane, free_E, free_NW.

0.4186355::u79.
free_NE :- u79, action(cruise), \+ curr_lane, free_E, free_NW.

0.4442013::u80.
free_NE :- u80, action(keep), \+ curr_lane, free_E, free_NW.

0.8391960::u81.
free_NE :- u81, action(swerve_left), \+ curr_lane, free_E, free_NW.

0.9990010::u82.
free_NE :- u82, action(swerve_right), \+ curr_lane, free_E, free_NW.

0.5018092::u83.
free_NE :- u83, action(change_to_left), curr_lane, free_E, free_NW.

0.5768439::u84.
free_NE :- u84, action(change_to_right), curr_lane, free_E, free_NW.

0.8923473::u85.
free_NE :- u85, action(cruise), curr_lane, free_E, free_NW.

0.0395519::u86.
free_NE :- u86, action(keep), curr_lane, free_E, free_NW.

0.9364055::u87.
free_NE :- u87, action(swerve_left), curr_lane, free_E, free_NW.

0.8890555::u88.
free_NE :- u88, action(swerve_right), curr_lane, free_E, free_NW.

0.5024107::u89.
free_NW :- u89, action(change_to_left), \+ free_SW.

0.5051254::u90.
free_NW :- u90, action(change_to_right), \+ free_SW.

0.4455885::u91.
free_NW :- u91, action(cruise), \+ free_SW.

0.4347096::u92.
free_NW :- u92, action(keep), \+ free_SW.

0.7619048::u93.
free_NW :- u93, action(swerve_left), \+ free_SW.

0.5172414::u94.
free_NW :- u94, action(swerve_right), \+ free_SW.

0.5191402::u95.
free_NW :- u95, action(change_to_left), free_SW.

0.5806987::u96.
free_NW :- u96, action(change_to_right), free_SW.

0.5849682::u97.
free_NW :- u97, action(cruise), free_SW.

0.0218338::u98.
free_NW :- u98, action(keep), free_SW.

0.9705882::u99.
free_NW :- u99, action(swerve_left), free_SW.

0.8361508::u100.
free_NW :- u100, action(swerve_right), free_SW.

