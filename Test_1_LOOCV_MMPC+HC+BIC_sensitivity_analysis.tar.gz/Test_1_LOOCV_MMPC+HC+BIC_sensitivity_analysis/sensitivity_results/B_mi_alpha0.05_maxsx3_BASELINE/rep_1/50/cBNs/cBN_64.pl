%%% Exogenous variables

0.1689256::u_action(change_to_left); 0.1704523::u_action(change_to_right); 0.4070205::u_action(cruise); 0.2512601::u_action(keep); 0.0014999::u_action(swerve_left); 0.0008416::u_action(swerve_right)
action(V) :- u_action(V).

0.5941508::u1.
free_SE :- u1.

0.6765389::u2.
free_SW :- u2.

0.7107140::u3.
free_W :- u3.

0.3867904::u4.
latent_collision :- u4.

0.4312081::u5.
curr_lane :- u5, action(change_to_left), \+ free_SE.

0.4755591::u6.
curr_lane :- u6, action(change_to_right), \+ free_SE.

0.4940513::u7.
curr_lane :- u7, action(cruise), \+ free_SE.

0.1385112::u8.
curr_lane :- u8, action(keep), \+ free_SE.

0.3370787::u9.
curr_lane :- u9, action(swerve_left), \+ free_SE.

0.9990010::u10.
curr_lane :- u10, action(swerve_right), \+ free_SE.

0.5498611::u11.
curr_lane :- u11, action(change_to_left), free_SE.

0.5657440::u12.
curr_lane :- u12, action(change_to_right), free_SE.

0.7174113::u13.
curr_lane :- u13, action(cruise), free_SE.

0.6251121::u14.
curr_lane :- u14, action(keep), free_SE.

0.8514996::u15.
curr_lane :- u15, action(swerve_left), free_SE.

0.9948454::u16.
curr_lane :- u16, action(swerve_right), free_SE.

0.5046992::u17.
free_E :- u17, action(change_to_left), \+ curr_lane, \+ free_SE.

0.5681325::u18.
free_E :- u18, action(change_to_right), \+ curr_lane, \+ free_SE.

0.3952109::u19.
free_E :- u19, action(cruise), \+ curr_lane, \+ free_SE.

0.5647336::u20.
free_E :- u20, action(keep), \+ curr_lane, \+ free_SE.

0.5762712::u21.
free_E :- u21, action(swerve_left), \+ curr_lane, \+ free_SE.

0.5000000::u22.
free_E :- u22, action(swerve_right), \+ curr_lane, \+ free_SE.

0.5027404::u23.
free_E :- u23, action(change_to_left), curr_lane, \+ free_SE.

0.5421229::u24.
free_E :- u24, action(change_to_right), curr_lane, \+ free_SE.

0.8044370::u25.
free_E :- u25, action(cruise), curr_lane, \+ free_SE.

0.9968411::u26.
free_E :- u26, action(keep), curr_lane, \+ free_SE.

0.9990010::u27.
free_E :- u27, action(swerve_left), curr_lane, \+ free_SE.

0.9990010::u28.
free_E :- u28, action(swerve_right), curr_lane, \+ free_SE.

0.5365043::u29.
free_E :- u29, action(change_to_left), \+ curr_lane, free_SE.

0.4157209::u30.
free_E :- u30, action(change_to_right), \+ curr_lane, free_SE.

0.6427375::u31.
free_E :- u31, action(cruise), \+ curr_lane, free_SE.

0.7214876::u32.
free_E :- u32, action(keep), \+ curr_lane, free_SE.

0.9064039::u33.
free_E :- u33, action(swerve_left), \+ curr_lane, free_SE.

0.9990010::u34.
free_E :- u34, action(swerve_right), \+ curr_lane, free_SE.

0.5847184::u35.
free_E :- u35, action(change_to_left), curr_lane, free_SE.

0.5209432::u36.
free_E :- u36, action(change_to_right), curr_lane, free_SE.

0.9243230::u37.
free_E :- u37, action(cruise), curr_lane, free_SE.

0.8784713::u38.
free_E :- u38, action(keep), curr_lane, free_SE.

0.9768041::u39.
free_E :- u39, action(swerve_left), curr_lane, free_SE.

0.9961140::u40.
free_E :- u40, action(swerve_right), curr_lane, free_SE.

0.4661374::u41.
free_NE :- u41, action(change_to_left), \+ curr_lane, \+ free_E, \+ free_NW.

0.4825508::u42.
free_NE :- u42, action(change_to_right), \+ curr_lane, \+ free_E, \+ free_NW.

0.4563303::u43.
free_NE :- u43, action(cruise), \+ curr_lane, \+ free_E, \+ free_NW.

0.2071350::u44.
free_NE :- u44, action(keep), \+ curr_lane, \+ free_E, \+ free_NW.

0.0009990::u45.
free_NE :- u45, action(swerve_left), \+ curr_lane, \+ free_E, \+ free_NW.

0.5000000::u46.
free_NE :- u46, action(swerve_right), \+ curr_lane, \+ free_E, \+ free_NW.

0.4980909::u47.
free_NE :- u47, action(change_to_left), curr_lane, \+ free_E, \+ free_NW.

0.5044310::u48.
free_NE :- u48, action(change_to_right), curr_lane, \+ free_E, \+ free_NW.

0.2474142::u49.
free_NE :- u49, action(cruise), curr_lane, \+ free_E, \+ free_NW.

0.0001126::u50.
free_NE :- u50, action(keep), curr_lane, \+ free_E, \+ free_NW.

0.0009990::u51.
free_NE :- u51, action(swerve_left), curr_lane, \+ free_E, \+ free_NW.

0.5000000::u52.
free_NE :- u52, action(swerve_right), curr_lane, \+ free_E, \+ free_NW.

0.4974272::u53.
free_NE :- u53, action(change_to_left), \+ curr_lane, free_E, \+ free_NW.

0.2405481::u54.
free_NE :- u54, action(change_to_right), \+ curr_lane, free_E, \+ free_NW.

0.4907067::u55.
free_NE :- u55, action(cruise), \+ curr_lane, free_E, \+ free_NW.

0.0097988::u56.
free_NE :- u56, action(keep), \+ curr_lane, free_E, \+ free_NW.

0.0009990::u57.
free_NE :- u57, action(swerve_left), \+ curr_lane, free_E, \+ free_NW.

0.5000000::u58.
free_NE :- u58, action(swerve_right), \+ curr_lane, free_E, \+ free_NW.

0.4748021::u59.
free_NE :- u59, action(change_to_left), curr_lane, free_E, \+ free_NW.

0.5220897::u60.
free_NE :- u60, action(change_to_right), curr_lane, free_E, \+ free_NW.

0.9074549::u61.
free_NE :- u61, action(cruise), curr_lane, free_E, \+ free_NW.

0.0010527::u62.
free_NE :- u62, action(keep), curr_lane, free_E, \+ free_NW.

0.2444444::u63.
free_NE :- u63, action(swerve_left), curr_lane, free_E, \+ free_NW.

0.7250000::u64.
free_NE :- u64, action(swerve_right), curr_lane, free_E, \+ free_NW.

0.4888329::u65.
free_NE :- u65, action(change_to_left), \+ curr_lane, \+ free_E, free_NW.

0.5075702::u66.
free_NE :- u66, action(change_to_right), \+ curr_lane, \+ free_E, free_NW.

0.5518383::u67.
free_NE :- u67, action(cruise), \+ curr_lane, \+ free_E, free_NW.

0.4807692::u68.
free_NE :- u68, action(keep), \+ curr_lane, \+ free_E, free_NW.

0.4523810::u69.
free_NE :- u69, action(swerve_left), \+ curr_lane, \+ free_E, free_NW.

0.5000000::u70.
free_NE :- u70, action(swerve_right), \+ curr_lane, \+ free_E, free_NW.

0.4991405::u71.
free_NE :- u71, action(change_to_left), curr_lane, \+ free_E, free_NW.

0.5068357::u72.
free_NE :- u72, action(change_to_right), curr_lane, \+ free_E, free_NW.

0.2026071::u73.
free_NE :- u73, action(cruise), curr_lane, \+ free_E, free_NW.

0.0064516::u74.
free_NE :- u74, action(keep), curr_lane, \+ free_E, free_NW.

0.0009990::u75.
free_NE :- u75, action(swerve_left), curr_lane, \+ free_E, free_NW.

0.0009990::u76.
free_NE :- u76, action(swerve_right), curr_lane, \+ free_E, free_NW.

0.4503155::u77.
free_NE :- u77, action(change_to_left), \+ curr_lane, free_E, free_NW.

0.6222014::u78.
free_NE :- u78, action(change_to_right), \+ curr_lane, free_E, free_NW.

0.4179209::u79.
free_NE :- u79, action(cruise), \+ curr_lane, free_E, free_NW.

0.4535637::u80.
free_NE :- u80, action(keep), \+ curr_lane, free_E, free_NW.

0.8333333::u81.
free_NE :- u81, action(swerve_left), \+ curr_lane, free_E, free_NW.

0.9990010::u82.
free_NE :- u82, action(swerve_right), \+ curr_lane, free_E, free_NW.

0.5022535::u83.
free_NE :- u83, action(change_to_left), curr_lane, free_E, free_NW.

0.5782987::u84.
free_NE :- u84, action(change_to_right), curr_lane, free_E, free_NW.

0.8930621::u85.
free_NE :- u85, action(cruise), curr_lane, free_E, free_NW.

0.0387543::u86.
free_NE :- u86, action(keep), curr_lane, free_E, free_NW.

0.9313725::u87.
free_NE :- u87, action(swerve_left), curr_lane, free_E, free_NW.

0.8800000::u88.
free_NE :- u88, action(swerve_right), curr_lane, free_E, free_NW.

0.4949751::u89.
free_NW :- u89, action(change_to_left), \+ free_SW.

0.4975211::u90.
free_NW :- u90, action(change_to_right), \+ free_SW.

0.4427167::u91.
free_NW :- u91, action(cruise), \+ free_SW.

0.4170912::u92.
free_NW :- u92, action(keep), \+ free_SW.

0.7272727::u93.
free_NW :- u93, action(swerve_left), \+ free_SW.

0.5166667::u94.
free_NW :- u94, action(swerve_right), \+ free_SW.

0.5278926::u95.
free_NW :- u95, action(change_to_left), free_SW.

0.5900977::u96.
free_NW :- u96, action(change_to_right), free_SW.

0.5884062::u97.
free_NW :- u97, action(cruise), free_SW.

0.0225252::u98.
free_NW :- u98, action(keep), free_SW.

0.9662684::u99.
free_NW :- u99, action(swerve_left), free_SW.

0.8243065::u100.
free_NW :- u100, action(swerve_right), free_SW.

