%%% Exogenous variables

0.1674917::u_action(change_to_left); 0.1701060::u_action(change_to_right); 0.4062074::u_action(cruise); 0.2539358::u_action(keep); 0.0014300::u_action(swerve_left); 0.0008291::u_action(swerve_right)
action(V) :- u_action(V).

0.5988226::u1.
free_SE :- u1.

0.6819687::u2.
free_SW :- u2.

0.7147406::u3.
free_W :- u3.

0.3868969::u4.
latent_collision :- u4.

0.4359352::u5.
curr_lane :- u5, action(change_to_left), \+ free_SE.

0.4848763::u6.
curr_lane :- u6, action(change_to_right), \+ free_SE.

0.4920171::u7.
curr_lane :- u7, action(cruise), \+ free_SE.

0.1375312::u8.
curr_lane :- u8, action(keep), \+ free_SE.

0.3777778::u9.
curr_lane :- u9, action(swerve_left), \+ free_SE.

0.9990010::u10.
curr_lane :- u10, action(swerve_right), \+ free_SE.

0.5429676::u11.
curr_lane :- u11, action(change_to_left), free_SE.

0.5563717::u12.
curr_lane :- u12, action(change_to_right), free_SE.

0.7125938::u13.
curr_lane :- u13, action(cruise), free_SE.

0.6005702::u14.
curr_lane :- u14, action(keep), free_SE.

0.8408569::u15.
curr_lane :- u15, action(swerve_left), free_SE.

0.9882045::u16.
curr_lane :- u16, action(swerve_right), free_SE.

0.5202047::u17.
free_E :- u17, action(change_to_left), \+ curr_lane, \+ free_SE.

0.5806334::u18.
free_E :- u18, action(change_to_right), \+ curr_lane, \+ free_SE.

0.3946296::u19.
free_E :- u19, action(cruise), \+ curr_lane, \+ free_SE.

0.5643505::u20.
free_E :- u20, action(keep), \+ curr_lane, \+ free_SE.

0.5178571::u21.
free_E :- u21, action(swerve_left), \+ curr_lane, \+ free_SE.

0.5000000::u22.
free_E :- u22, action(swerve_right), \+ curr_lane, \+ free_SE.

0.5037535::u23.
free_E :- u23, action(change_to_left), curr_lane, \+ free_SE.

0.5370341::u24.
free_E :- u24, action(change_to_right), curr_lane, \+ free_SE.

0.8039193::u25.
free_E :- u25, action(cruise), curr_lane, \+ free_SE.

0.9965284::u26.
free_E :- u26, action(keep), curr_lane, \+ free_SE.

0.9990010::u27.
free_E :- u27, action(swerve_left), curr_lane, \+ free_SE.

0.9990010::u28.
free_E :- u28, action(swerve_right), curr_lane, \+ free_SE.

0.5181066::u29.
free_E :- u29, action(change_to_left), \+ curr_lane, free_SE.

0.3954933::u30.
free_E :- u30, action(change_to_right), \+ curr_lane, free_SE.

0.6283518::u31.
free_E :- u31, action(cruise), \+ curr_lane, free_SE.

0.6547091::u32.
free_E :- u32, action(keep), \+ curr_lane, free_SE.

0.9086538::u33.
free_E :- u33, action(swerve_left), \+ curr_lane, free_SE.

0.9990010::u34.
free_E :- u34, action(swerve_right), \+ curr_lane, free_SE.

0.5823009::u35.
free_E :- u35, action(change_to_left), curr_lane, free_SE.

0.5203849::u36.
free_E :- u36, action(change_to_right), curr_lane, free_SE.

0.9242571::u37.
free_E :- u37, action(cruise), curr_lane, free_SE.

0.8789804::u38.
free_E :- u38, action(keep), curr_lane, free_SE.

0.9818016::u39.
free_E :- u39, action(swerve_left), curr_lane, free_SE.

0.9960212::u40.
free_E :- u40, action(swerve_right), curr_lane, free_SE.

0.4974339::u41.
free_NE :- u41, action(change_to_left), \+ curr_lane, \+ free_E, \+ free_NW.

0.5122496::u42.
free_NE :- u42, action(change_to_right), \+ curr_lane, \+ free_E, \+ free_NW.

0.4917511::u43.
free_NE :- u43, action(cruise), \+ curr_lane, \+ free_E, \+ free_NW.

0.2616698::u44.
free_NE :- u44, action(keep), \+ curr_lane, \+ free_E, \+ free_NW.

0.0009990::u45.
free_NE :- u45, action(swerve_left), \+ curr_lane, \+ free_E, \+ free_NW.

0.5000000::u46.
free_NE :- u46, action(swerve_right), \+ curr_lane, \+ free_E, \+ free_NW.

0.5009492::u47.
free_NE :- u47, action(change_to_left), curr_lane, \+ free_E, \+ free_NW.

0.5028475::u48.
free_NE :- u48, action(change_to_right), curr_lane, \+ free_E, \+ free_NW.

0.2430948::u49.
free_NE :- u49, action(cruise), curr_lane, \+ free_E, \+ free_NW.

0.0002276::u50.
free_NE :- u50, action(keep), curr_lane, \+ free_E, \+ free_NW.

0.2500000::u51.
free_NE :- u51, action(swerve_left), curr_lane, \+ free_E, \+ free_NW.

0.9990010::u52.
free_NE :- u52, action(swerve_right), curr_lane, \+ free_E, \+ free_NW.

0.5032585::u53.
free_NE :- u53, action(change_to_left), \+ curr_lane, free_E, \+ free_NW.

0.2359869::u54.
free_NE :- u54, action(change_to_right), \+ curr_lane, free_E, \+ free_NW.

0.4829929::u55.
free_NE :- u55, action(cruise), \+ curr_lane, free_E, \+ free_NW.

0.0100175::u56.
free_NE :- u56, action(keep), \+ curr_lane, free_E, \+ free_NW.

0.0009990::u57.
free_NE :- u57, action(swerve_left), \+ curr_lane, free_E, \+ free_NW.

0.5000000::u58.
free_NE :- u58, action(swerve_right), \+ curr_lane, free_E, \+ free_NW.

0.4762942::u59.
free_NE :- u59, action(change_to_left), curr_lane, free_E, \+ free_NW.

0.5235332::u60.
free_NE :- u60, action(change_to_right), curr_lane, free_E, \+ free_NW.

0.9077045::u61.
free_NE :- u61, action(cruise), curr_lane, free_E, \+ free_NW.

0.0011515::u62.
free_NE :- u62, action(keep), curr_lane, free_E, \+ free_NW.

0.2195122::u63.
free_NE :- u63, action(swerve_left), curr_lane, free_E, \+ free_NW.

0.7414966::u64.
free_NE :- u64, action(swerve_right), curr_lane, free_E, \+ free_NW.

0.4572454::u65.
free_NE :- u65, action(change_to_left), \+ curr_lane, \+ free_E, free_NW.

0.4802245::u66.
free_NE :- u66, action(change_to_right), \+ curr_lane, \+ free_E, free_NW.

0.5516325::u67.
free_NE :- u67, action(cruise), \+ curr_lane, \+ free_E, free_NW.

0.4565217::u68.
free_NE :- u68, action(keep), \+ curr_lane, \+ free_E, free_NW.

0.4418605::u69.
free_NE :- u69, action(swerve_left), \+ curr_lane, \+ free_E, free_NW.

0.5000000::u70.
free_NE :- u70, action(swerve_right), \+ curr_lane, \+ free_E, free_NW.

0.4990832::u71.
free_NE :- u71, action(change_to_left), curr_lane, \+ free_E, free_NW.

0.5040838::u72.
free_NE :- u72, action(change_to_right), curr_lane, \+ free_E, free_NW.

0.2036744::u73.
free_NE :- u73, action(cruise), curr_lane, \+ free_E, free_NW.

0.0009990::u74.
free_NE :- u74, action(keep), curr_lane, \+ free_E, free_NW.

0.0009990::u75.
free_NE :- u75, action(swerve_left), curr_lane, \+ free_E, free_NW.

0.0009990::u76.
free_NE :- u76, action(swerve_right), curr_lane, \+ free_E, free_NW.

0.4491894::u77.
free_NE :- u77, action(change_to_left), \+ curr_lane, free_E, free_NW.

0.6195906::u78.
free_NE :- u78, action(change_to_right), \+ curr_lane, free_E, free_NW.

0.4182414::u79.
free_NE :- u79, action(cruise), \+ curr_lane, free_E, free_NW.

0.4590909::u80.
free_NE :- u80, action(keep), \+ curr_lane, free_E, free_NW.

0.8317757::u81.
free_NE :- u81, action(swerve_left), \+ curr_lane, free_E, free_NW.

0.9990010::u82.
free_NE :- u82, action(swerve_right), \+ curr_lane, free_E, free_NW.

0.5020533::u83.
free_NE :- u83, action(change_to_left), curr_lane, free_E, free_NW.

0.5822959::u84.
free_NE :- u84, action(change_to_right), curr_lane, free_E, free_NW.

0.8937909::u85.
free_NE :- u85, action(cruise), curr_lane, free_E, free_NW.

0.0421788::u86.
free_NE :- u86, action(keep), curr_lane, free_E, free_NW.

0.9291045::u87.
free_NE :- u87, action(swerve_left), curr_lane, free_E, free_NW.

0.8955453::u88.
free_NE :- u88, action(swerve_right), curr_lane, free_E, free_NW.

0.4849745::u89.
free_NW :- u89, action(change_to_left), \+ free_SW.

0.4880384::u90.
free_NW :- u90, action(change_to_right), \+ free_SW.

0.4433857::u91.
free_NW :- u91, action(cruise), \+ free_SW.

0.4150000::u92.
free_NW :- u92, action(keep), \+ free_SW.

0.7209302::u93.
free_NW :- u93, action(swerve_left), \+ free_SW.

0.4918033::u94.
free_NW :- u94, action(swerve_right), \+ free_SW.

0.5214601::u95.
free_NW :- u95, action(change_to_left), free_SW.

0.5807095::u96.
free_NW :- u96, action(change_to_right), free_SW.

0.5841680::u97.
free_NW :- u97, action(cruise), free_SW.

0.0220053::u98.
free_NW :- u98, action(keep), free_SW.

0.9704579::u99.
free_NW :- u99, action(swerve_left), free_SW.

0.8424566::u100.
free_NW :- u100, action(swerve_right), free_SW.

