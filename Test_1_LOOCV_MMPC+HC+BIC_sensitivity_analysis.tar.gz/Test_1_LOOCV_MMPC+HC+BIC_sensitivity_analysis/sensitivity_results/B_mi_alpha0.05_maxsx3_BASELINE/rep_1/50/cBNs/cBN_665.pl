%%% Exogenous variables

0.1682989::u_action(change_to_left); 0.1701505::u_action(change_to_right); 0.4058822::u_action(cruise); 0.2532998::u_action(keep); 0.0014700::u_action(swerve_left); 0.0008986::u_action(swerve_right)
action(V) :- u_action(V).

0.5957191::u1.
free_SE :- u1.

0.6782601::u2.
free_SW :- u2.

0.7158058::u3.
free_W :- u3.

0.3859958::u4.
latent_collision :- u4.

0.4288038::u5.
curr_lane :- u5, action(change_to_left), \+ free_SE.

0.4765429::u6.
curr_lane :- u6, action(change_to_right), \+ free_SE.

0.4945627::u7.
curr_lane :- u7, action(cruise), \+ free_SE.

0.1372627::u8.
curr_lane :- u8, action(keep), \+ free_SE.

0.3483146::u9.
curr_lane :- u9, action(swerve_left), \+ free_SE.

0.9990010::u10.
curr_lane :- u10, action(swerve_right), \+ free_SE.

0.5374755::u11.
curr_lane :- u11, action(change_to_left), free_SE.

0.5494194::u12.
curr_lane :- u12, action(change_to_right), free_SE.

0.7136444::u13.
curr_lane :- u13, action(cruise), free_SE.

0.6002076::u14.
curr_lane :- u14, action(keep), free_SE.

0.8571429::u15.
curr_lane :- u15, action(swerve_left), free_SE.

0.9915049::u16.
curr_lane :- u16, action(swerve_right), free_SE.

0.5011784::u17.
free_E :- u17, action(change_to_left), \+ curr_lane, \+ free_SE.

0.5649568::u18.
free_E :- u18, action(change_to_right), \+ curr_lane, \+ free_SE.

0.3964872::u19.
free_E :- u19, action(cruise), \+ curr_lane, \+ free_SE.

0.5654928::u20.
free_E :- u20, action(keep), \+ curr_lane, \+ free_SE.

0.5000000::u21.
free_E :- u21, action(swerve_left), \+ curr_lane, \+ free_SE.

0.5000000::u22.
free_E :- u22, action(swerve_right), \+ curr_lane, \+ free_SE.

0.5019622::u23.
free_E :- u23, action(change_to_left), curr_lane, \+ free_SE.

0.5383945::u24.
free_E :- u24, action(change_to_right), curr_lane, \+ free_SE.

0.8041718::u25.
free_E :- u25, action(cruise), curr_lane, \+ free_SE.

0.9966920::u26.
free_E :- u26, action(keep), curr_lane, \+ free_SE.

0.9990010::u27.
free_E :- u27, action(swerve_left), curr_lane, \+ free_SE.

0.9990010::u28.
free_E :- u28, action(swerve_right), curr_lane, \+ free_SE.

0.5225286::u29.
free_E :- u29, action(change_to_left), \+ curr_lane, free_SE.

0.3963908::u30.
free_E :- u30, action(change_to_right), \+ curr_lane, free_SE.

0.6290730::u31.
free_E :- u31, action(cruise), \+ curr_lane, free_SE.

0.6579988::u32.
free_E :- u32, action(keep), \+ curr_lane, free_SE.

0.8958333::u33.
free_E :- u33, action(swerve_left), \+ curr_lane, free_SE.

0.9990010::u34.
free_E :- u34, action(swerve_right), \+ curr_lane, free_SE.

0.5963533::u35.
free_E :- u35, action(change_to_left), curr_lane, free_SE.

0.5370973::u36.
free_E :- u36, action(change_to_right), curr_lane, free_SE.

0.9303309::u37.
free_E :- u37, action(cruise), curr_lane, free_SE.

0.8892137::u38.
free_E :- u38, action(keep), curr_lane, free_SE.

0.9826389::u39.
free_E :- u39, action(swerve_left), curr_lane, free_SE.

0.9951040::u40.
free_E :- u40, action(swerve_right), curr_lane, free_SE.

0.4957379::u41.
free_NE :- u41, action(change_to_left), \+ curr_lane, \+ free_E, \+ free_NW.

0.5106435::u42.
free_NE :- u42, action(change_to_right), \+ curr_lane, \+ free_E, \+ free_NW.

0.4974594::u43.
free_NE :- u43, action(cruise), \+ curr_lane, \+ free_E, \+ free_NW.

0.2602160::u44.
free_NE :- u44, action(keep), \+ curr_lane, \+ free_E, \+ free_NW.

0.5000000::u45.
free_NE :- u45, action(swerve_left), \+ curr_lane, \+ free_E, \+ free_NW.

0.5000000::u46.
free_NE :- u46, action(swerve_right), \+ curr_lane, \+ free_E, \+ free_NW.

0.5339857::u47.
free_NE :- u47, action(change_to_left), curr_lane, \+ free_E, \+ free_NW.

0.5349072::u48.
free_NE :- u48, action(change_to_right), curr_lane, \+ free_E, \+ free_NW.

0.2666053::u49.
free_NE :- u49, action(cruise), curr_lane, \+ free_E, \+ free_NW.

0.0002506::u50.
free_NE :- u50, action(keep), curr_lane, \+ free_E, \+ free_NW.

0.0009990::u51.
free_NE :- u51, action(swerve_left), curr_lane, \+ free_E, \+ free_NW.

0.9990010::u52.
free_NE :- u52, action(swerve_right), curr_lane, \+ free_E, \+ free_NW.

0.5002493::u53.
free_NE :- u53, action(change_to_left), \+ curr_lane, free_E, \+ free_NW.

0.2406053::u54.
free_NE :- u54, action(change_to_right), \+ curr_lane, free_E, \+ free_NW.

0.4877001::u55.
free_NE :- u55, action(cruise), \+ curr_lane, free_E, \+ free_NW.

0.0101995::u56.
free_NE :- u56, action(keep), \+ curr_lane, free_E, \+ free_NW.

0.0009990::u57.
free_NE :- u57, action(swerve_left), \+ curr_lane, free_E, \+ free_NW.

0.5000000::u58.
free_NE :- u58, action(swerve_right), \+ curr_lane, free_E, \+ free_NW.

0.4751078::u59.
free_NE :- u59, action(change_to_left), curr_lane, free_E, \+ free_NW.

0.5239840::u60.
free_NE :- u60, action(change_to_right), curr_lane, free_E, \+ free_NW.

0.9075557::u61.
free_NE :- u61, action(cruise), curr_lane, free_E, \+ free_NW.

0.0011368::u62.
free_NE :- u62, action(keep), curr_lane, free_E, \+ free_NW.

0.3333333::u63.
free_NE :- u63, action(swerve_left), curr_lane, free_E, \+ free_NW.

0.7177914::u64.
free_NE :- u64, action(swerve_right), curr_lane, free_E, \+ free_NW.

0.4872964::u65.
free_NE :- u65, action(change_to_left), \+ curr_lane, \+ free_E, free_NW.

0.5119851::u66.
free_NE :- u66, action(change_to_right), \+ curr_lane, \+ free_E, free_NW.

0.5502145::u67.
free_NE :- u67, action(cruise), \+ curr_lane, \+ free_E, free_NW.

0.4909091::u68.
free_NE :- u68, action(keep), \+ curr_lane, \+ free_E, free_NW.

0.4680851::u69.
free_NE :- u69, action(swerve_left), \+ curr_lane, \+ free_E, free_NW.

0.5000000::u70.
free_NE :- u70, action(swerve_right), \+ curr_lane, \+ free_E, free_NW.

0.5006730::u71.
free_NE :- u71, action(change_to_left), curr_lane, \+ free_E, free_NW.

0.5010647::u72.
free_NE :- u72, action(change_to_right), curr_lane, \+ free_E, free_NW.

0.1992440::u73.
free_NE :- u73, action(cruise), curr_lane, \+ free_E, free_NW.

0.0009990::u74.
free_NE :- u74, action(keep), curr_lane, \+ free_E, free_NW.

0.0009990::u75.
free_NE :- u75, action(swerve_left), curr_lane, \+ free_E, free_NW.

0.0009990::u76.
free_NE :- u76, action(swerve_right), curr_lane, \+ free_E, free_NW.

0.4524698::u77.
free_NE :- u77, action(change_to_left), \+ curr_lane, free_E, free_NW.

0.6229879::u78.
free_NE :- u78, action(change_to_right), \+ curr_lane, free_E, free_NW.

0.4166309::u79.
free_NE :- u79, action(cruise), \+ curr_lane, free_E, free_NW.

0.4719626::u80.
free_NE :- u80, action(keep), \+ curr_lane, free_E, free_NW.

0.8181818::u81.
free_NE :- u81, action(swerve_left), \+ curr_lane, free_E, free_NW.

0.9990010::u82.
free_NE :- u82, action(swerve_right), \+ curr_lane, free_E, free_NW.

0.4995411::u83.
free_NE :- u83, action(change_to_left), curr_lane, free_E, free_NW.

0.5796707::u84.
free_NE :- u84, action(change_to_right), curr_lane, free_E, free_NW.

0.8928918::u85.
free_NE :- u85, action(cruise), curr_lane, free_E, free_NW.

0.0421301::u86.
free_NE :- u86, action(keep), curr_lane, free_E, free_NW.

0.9295272::u87.
free_NE :- u87, action(swerve_left), curr_lane, free_E, free_NW.

0.8988604::u88.
free_NE :- u88, action(swerve_right), curr_lane, free_E, free_NW.

0.4917998::u89.
free_NW :- u89, action(change_to_left), \+ free_SW.

0.4956562::u90.
free_NW :- u90, action(change_to_right), \+ free_SW.

0.4433986::u91.
free_NW :- u91, action(cruise), \+ free_SW.

0.4218673::u92.
free_NW :- u92, action(keep), \+ free_SW.

0.7234043::u93.
free_NW :- u93, action(swerve_left), \+ free_SW.

0.5211268::u94.
free_NW :- u94, action(swerve_right), \+ free_SW.

0.5275424::u95.
free_NW :- u95, action(change_to_left), free_SW.

0.5881458::u96.
free_NW :- u96, action(change_to_right), free_SW.

0.5878745::u97.
free_NW :- u97, action(cruise), free_SW.

0.0218390::u98.
free_NW :- u98, action(keep), free_SW.

0.9740260::u99.
free_NW :- u99, action(swerve_left), free_SW.

0.8360248::u100.
free_NW :- u100, action(swerve_right), free_SW.

