%%% Exogenous variables

0.1680354::u_action(change_to_left); 0.1699273::u_action(change_to_right); 0.4045931::u_action(cruise); 0.2550553::u_action(keep); 0.0015057::u_action(swerve_left); 0.0008833::u_action(swerve_right)
action(V) :- u_action(V).

0.5961700::u1.
free_SE :- u1.

0.6838565::u2.
free_SW :- u2.

0.7110000::u3.
free_W :- u3.

0.3871780::u4.
latent_collision :- u4.

0.4286420::u5.
curr_lane :- u5, action(change_to_left), \+ free_SE.

0.4763932::u6.
curr_lane :- u6, action(change_to_right), \+ free_SE.

0.4919753::u7.
curr_lane :- u7, action(cruise), \+ free_SE.

0.1368000::u8.
curr_lane :- u8, action(keep), \+ free_SE.

0.3440860::u9.
curr_lane :- u9, action(swerve_left), \+ free_SE.

0.9990010::u10.
curr_lane :- u10, action(swerve_right), \+ free_SE.

0.5505434::u11.
curr_lane :- u11, action(change_to_left), free_SE.

0.5670633::u12.
curr_lane :- u12, action(change_to_right), free_SE.

0.7220852::u13.
curr_lane :- u13, action(cruise), free_SE.

0.6025807::u14.
curr_lane :- u14, action(keep), free_SE.

0.8339403::u15.
curr_lane :- u15, action(swerve_left), free_SE.

0.9864699::u16.
curr_lane :- u16, action(swerve_right), free_SE.

0.5043105::u17.
free_E :- u17, action(change_to_left), \+ curr_lane, \+ free_SE.

0.5635004::u18.
free_E :- u18, action(change_to_right), \+ curr_lane, \+ free_SE.

0.3946163::u19.
free_E :- u19, action(cruise), \+ curr_lane, \+ free_SE.

0.5649906::u20.
free_E :- u20, action(keep), \+ curr_lane, \+ free_SE.

0.5573770::u21.
free_E :- u21, action(swerve_left), \+ curr_lane, \+ free_SE.

0.5000000::u22.
free_E :- u22, action(swerve_right), \+ curr_lane, \+ free_SE.

0.5041981::u23.
free_E :- u23, action(change_to_left), curr_lane, \+ free_SE.

0.5362209::u24.
free_E :- u24, action(change_to_right), curr_lane, \+ free_SE.

0.8032043::u25.
free_E :- u25, action(cruise), curr_lane, \+ free_SE.

0.9968605::u26.
free_E :- u26, action(keep), curr_lane, \+ free_SE.

0.9990010::u27.
free_E :- u27, action(swerve_left), curr_lane, \+ free_SE.

0.9990010::u28.
free_E :- u28, action(swerve_right), curr_lane, \+ free_SE.

0.5340626::u29.
free_E :- u29, action(change_to_left), \+ curr_lane, free_SE.

0.4159567::u30.
free_E :- u30, action(change_to_right), \+ curr_lane, free_SE.

0.6543745::u31.
free_E :- u31, action(cruise), \+ curr_lane, free_SE.

0.6572531::u32.
free_E :- u32, action(keep), \+ curr_lane, free_SE.

0.9035088::u33.
free_E :- u33, action(swerve_left), \+ curr_lane, free_SE.

0.9990010::u34.
free_E :- u34, action(swerve_right), \+ curr_lane, free_SE.

0.5842472::u35.
free_E :- u35, action(change_to_left), curr_lane, free_SE.

0.5227413::u36.
free_E :- u36, action(change_to_right), curr_lane, free_SE.

0.9243285::u37.
free_E :- u37, action(cruise), curr_lane, free_SE.

0.8770659::u38.
free_E :- u38, action(keep), curr_lane, free_SE.

0.9842795::u39.
free_E :- u39, action(swerve_left), curr_lane, free_SE.

0.9950125::u40.
free_E :- u40, action(swerve_right), curr_lane, free_SE.

0.4975525::u41.
free_NE :- u41, action(change_to_left), \+ curr_lane, \+ free_E, \+ free_NW.

0.5089277::u42.
free_NE :- u42, action(change_to_right), \+ curr_lane, \+ free_E, \+ free_NW.

0.4936511::u43.
free_NE :- u43, action(cruise), \+ curr_lane, \+ free_E, \+ free_NW.

0.2606830::u44.
free_NE :- u44, action(keep), \+ curr_lane, \+ free_E, \+ free_NW.

0.0009990::u45.
free_NE :- u45, action(swerve_left), \+ curr_lane, \+ free_E, \+ free_NW.

0.5000000::u46.
free_NE :- u46, action(swerve_right), \+ curr_lane, \+ free_E, \+ free_NW.

0.4984227::u47.
free_NE :- u47, action(change_to_left), curr_lane, \+ free_E, \+ free_NW.

0.5005234::u48.
free_NE :- u48, action(change_to_right), curr_lane, \+ free_E, \+ free_NW.

0.2456023::u49.
free_NE :- u49, action(cruise), curr_lane, \+ free_E, \+ free_NW.

0.0003343::u50.
free_NE :- u50, action(keep), curr_lane, \+ free_E, \+ free_NW.

0.0009990::u51.
free_NE :- u51, action(swerve_left), curr_lane, \+ free_E, \+ free_NW.

0.3333333::u52.
free_NE :- u52, action(swerve_right), curr_lane, \+ free_E, \+ free_NW.

0.4969524::u53.
free_NE :- u53, action(change_to_left), \+ curr_lane, free_E, \+ free_NW.

0.2407622::u54.
free_NE :- u54, action(change_to_right), \+ curr_lane, free_E, \+ free_NW.

0.4836324::u55.
free_NE :- u55, action(cruise), \+ curr_lane, free_E, \+ free_NW.

0.0097433::u56.
free_NE :- u56, action(keep), \+ curr_lane, free_E, \+ free_NW.

0.0009990::u57.
free_NE :- u57, action(swerve_left), \+ curr_lane, free_E, \+ free_NW.

0.5000000::u58.
free_NE :- u58, action(swerve_right), \+ curr_lane, free_E, \+ free_NW.

0.4727757::u59.
free_NE :- u59, action(change_to_left), curr_lane, free_E, \+ free_NW.

0.5232266::u60.
free_NE :- u60, action(change_to_right), curr_lane, free_E, \+ free_NW.

0.9074526::u61.
free_NE :- u61, action(cruise), curr_lane, free_E, \+ free_NW.

0.0012043::u62.
free_NE :- u62, action(keep), curr_lane, free_E, \+ free_NW.

0.1590909::u63.
free_NE :- u63, action(swerve_left), curr_lane, free_E, \+ free_NW.

0.7000000::u64.
free_NE :- u64, action(swerve_right), curr_lane, free_E, \+ free_NW.

0.5193605::u65.
free_NE :- u65, action(change_to_left), \+ curr_lane, \+ free_E, free_NW.

0.5435969::u66.
free_NE :- u66, action(change_to_right), \+ curr_lane, \+ free_E, free_NW.

0.5960840::u67.
free_NE :- u67, action(cruise), \+ curr_lane, \+ free_E, free_NW.

0.4285714::u68.
free_NE :- u68, action(keep), \+ curr_lane, \+ free_E, free_NW.

0.4347826::u69.
free_NE :- u69, action(swerve_left), \+ curr_lane, \+ free_E, free_NW.

0.5000000::u70.
free_NE :- u70, action(swerve_right), \+ curr_lane, \+ free_E, free_NW.

0.4978856::u71.
free_NE :- u71, action(change_to_left), curr_lane, \+ free_E, free_NW.

0.5018578::u72.
free_NE :- u72, action(change_to_right), curr_lane, \+ free_E, free_NW.

0.1986454::u73.
free_NE :- u73, action(cruise), curr_lane, \+ free_E, free_NW.

0.0061728::u74.
free_NE :- u74, action(keep), curr_lane, \+ free_E, free_NW.

0.0009990::u75.
free_NE :- u75, action(swerve_left), curr_lane, \+ free_E, free_NW.

0.0009990::u76.
free_NE :- u76, action(swerve_right), curr_lane, \+ free_E, free_NW.

0.4560537::u77.
free_NE :- u77, action(change_to_left), \+ curr_lane, free_E, free_NW.

0.6220300::u78.
free_NE :- u78, action(change_to_right), \+ curr_lane, free_E, free_NW.

0.4185174::u79.
free_NE :- u79, action(cruise), \+ curr_lane, free_E, free_NW.

0.4444444::u80.
free_NE :- u80, action(keep), \+ curr_lane, free_E, free_NW.

0.8255319::u81.
free_NE :- u81, action(swerve_left), \+ curr_lane, free_E, free_NW.

0.9990010::u82.
free_NE :- u82, action(swerve_right), \+ curr_lane, free_E, free_NW.

0.5020317::u83.
free_NE :- u83, action(change_to_left), curr_lane, free_E, free_NW.

0.5793737::u84.
free_NE :- u84, action(change_to_right), curr_lane, free_E, free_NW.

0.8930462::u85.
free_NE :- u85, action(cruise), curr_lane, free_E, free_NW.

0.0416146::u86.
free_NE :- u86, action(keep), curr_lane, free_E, free_NW.

0.9345291::u87.
free_NE :- u87, action(swerve_left), curr_lane, free_E, free_NW.

0.8817518::u88.
free_NE :- u88, action(swerve_right), curr_lane, free_E, free_NW.

0.4855145::u89.
free_NW :- u89, action(change_to_left), \+ free_SW.

0.4883573::u90.
free_NW :- u90, action(change_to_right), \+ free_SW.

0.4314249::u91.
free_NW :- u91, action(cruise), \+ free_SW.

0.4236076::u92.
free_NW :- u92, action(keep), \+ free_SW.

0.7804878::u93.
free_NW :- u93, action(swerve_left), \+ free_SW.

0.5692308::u94.
free_NW :- u94, action(swerve_right), \+ free_SW.

0.5197395::u95.
free_NW :- u95, action(change_to_left), free_SW.

0.5811990::u96.
free_NW :- u96, action(change_to_right), free_SW.

0.5842499::u97.
free_NW :- u97, action(cruise), free_SW.

0.0220001::u98.
free_NW :- u98, action(keep), free_SW.

0.9684211::u99.
free_NW :- u99, action(swerve_left), free_SW.

0.8301887::u100.
free_NW :- u100, action(swerve_right), free_SW.

