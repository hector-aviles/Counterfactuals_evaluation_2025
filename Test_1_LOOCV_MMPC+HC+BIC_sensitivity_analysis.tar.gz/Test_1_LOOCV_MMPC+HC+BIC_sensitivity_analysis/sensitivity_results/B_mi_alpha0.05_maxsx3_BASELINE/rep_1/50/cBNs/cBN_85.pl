%%% Exogenous variables

0.1679106::u_action(change_to_left); 0.1700363::u_action(change_to_right); 0.4048135::u_action(cruise); 0.2548638::u_action(keep); 0.0015067::u_action(swerve_left); 0.0008691::u_action(swerve_right)
action(V) :- u_action(V).

0.6003214::u1.
free_SE :- u1.

0.6824042::u2.
free_SW :- u2.

0.7115994::u3.
free_W :- u3.

0.3852158::u4.
latent_collision :- u4.

0.4356549::u5.
curr_lane :- u5, action(change_to_left), \+ free_SE.

0.4823041::u6.
curr_lane :- u6, action(change_to_right), \+ free_SE.

0.5005098::u7.
curr_lane :- u7, action(cruise), \+ free_SE.

0.1368347::u8.
curr_lane :- u8, action(keep), \+ free_SE.

0.4000000::u9.
curr_lane :- u9, action(swerve_left), \+ free_SE.

0.9990010::u10.
curr_lane :- u10, action(swerve_right), \+ free_SE.

0.5442131::u11.
curr_lane :- u11, action(change_to_left), free_SE.

0.5566322::u12.
curr_lane :- u12, action(change_to_right), free_SE.

0.7133795::u13.
curr_lane :- u13, action(cruise), free_SE.

0.6009484::u14.
curr_lane :- u14, action(keep), free_SE.

0.8485507::u15.
curr_lane :- u15, action(swerve_left), free_SE.

0.9938042::u16.
curr_lane :- u16, action(swerve_right), free_SE.

0.4905007::u17.
free_E :- u17, action(change_to_left), \+ curr_lane, \+ free_SE.

0.5550354::u18.
free_E :- u18, action(change_to_right), \+ curr_lane, \+ free_SE.

0.3790925::u19.
free_E :- u19, action(cruise), \+ curr_lane, \+ free_SE.

0.5655974::u20.
free_E :- u20, action(keep), \+ curr_lane, \+ free_SE.

0.5370370::u21.
free_E :- u21, action(swerve_left), \+ curr_lane, \+ free_SE.

0.5000000::u22.
free_E :- u22, action(swerve_right), \+ curr_lane, \+ free_SE.

0.5013196::u23.
free_E :- u23, action(change_to_left), curr_lane, \+ free_SE.

0.5379867::u24.
free_E :- u24, action(change_to_right), curr_lane, \+ free_SE.

0.8054392::u25.
free_E :- u25, action(cruise), curr_lane, \+ free_SE.

0.9967502::u26.
free_E :- u26, action(keep), curr_lane, \+ free_SE.

0.9990010::u27.
free_E :- u27, action(swerve_left), curr_lane, \+ free_SE.

0.9990010::u28.
free_E :- u28, action(swerve_right), curr_lane, \+ free_SE.

0.5184952::u29.
free_E :- u29, action(change_to_left), \+ curr_lane, free_SE.

0.3975875::u30.
free_E :- u30, action(change_to_right), \+ curr_lane, free_SE.

0.6301163::u31.
free_E :- u31, action(cruise), \+ curr_lane, free_SE.

0.6602009::u32.
free_E :- u32, action(keep), \+ curr_lane, free_SE.

0.8947368::u33.
free_E :- u33, action(swerve_left), \+ curr_lane, free_SE.

0.9990010::u34.
free_E :- u34, action(swerve_right), \+ curr_lane, free_SE.

0.5842156::u35.
free_E :- u35, action(change_to_left), curr_lane, free_SE.

0.5211663::u36.
free_E :- u36, action(change_to_right), curr_lane, free_SE.

0.9249863::u37.
free_E :- u37, action(cruise), curr_lane, free_SE.

0.8798048::u38.
free_E :- u38, action(keep), curr_lane, free_SE.

0.9846285::u39.
free_E :- u39, action(swerve_left), curr_lane, free_SE.

0.9950125::u40.
free_E :- u40, action(swerve_right), curr_lane, free_SE.

0.4968293::u41.
free_NE :- u41, action(change_to_left), \+ curr_lane, \+ free_E, \+ free_NW.

0.5074953::u42.
free_NE :- u42, action(change_to_right), \+ curr_lane, \+ free_E, \+ free_NW.

0.4997777::u43.
free_NE :- u43, action(cruise), \+ curr_lane, \+ free_E, \+ free_NW.

0.2611346::u44.
free_NE :- u44, action(keep), \+ curr_lane, \+ free_E, \+ free_NW.

0.5000000::u45.
free_NE :- u45, action(swerve_left), \+ curr_lane, \+ free_E, \+ free_NW.

0.5000000::u46.
free_NE :- u46, action(swerve_right), \+ curr_lane, \+ free_E, \+ free_NW.

0.4975304::u47.
free_NE :- u47, action(change_to_left), curr_lane, \+ free_E, \+ free_NW.

0.4994017::u48.
free_NE :- u48, action(change_to_right), curr_lane, \+ free_E, \+ free_NW.

0.2452354::u49.
free_NE :- u49, action(cruise), curr_lane, \+ free_E, \+ free_NW.

0.0009990::u50.
free_NE :- u50, action(keep), curr_lane, \+ free_E, \+ free_NW.

0.0009990::u51.
free_NE :- u51, action(swerve_left), curr_lane, \+ free_E, \+ free_NW.

0.6666667::u52.
free_NE :- u52, action(swerve_right), curr_lane, \+ free_E, \+ free_NW.

0.5303014::u53.
free_NE :- u53, action(change_to_left), \+ curr_lane, free_E, \+ free_NW.

0.2661888::u54.
free_NE :- u54, action(change_to_right), \+ curr_lane, free_E, \+ free_NW.

0.5190311::u55.
free_NE :- u55, action(cruise), \+ curr_lane, free_E, \+ free_NW.

0.0097886::u56.
free_NE :- u56, action(keep), \+ curr_lane, free_E, \+ free_NW.

0.0009990::u57.
free_NE :- u57, action(swerve_left), \+ curr_lane, free_E, \+ free_NW.

0.5000000::u58.
free_NE :- u58, action(swerve_right), \+ curr_lane, free_E, \+ free_NW.

0.4715328::u59.
free_NE :- u59, action(change_to_left), curr_lane, free_E, \+ free_NW.

0.5244424::u60.
free_NE :- u60, action(change_to_right), curr_lane, free_E, \+ free_NW.

0.9089376::u61.
free_NE :- u61, action(cruise), curr_lane, free_E, \+ free_NW.

0.0009883::u62.
free_NE :- u62, action(keep), curr_lane, free_E, \+ free_NW.

0.2500000::u63.
free_NE :- u63, action(swerve_left), curr_lane, free_E, \+ free_NW.

0.7048193::u64.
free_NE :- u64, action(swerve_right), curr_lane, free_E, \+ free_NW.

0.4888932::u65.
free_NE :- u65, action(change_to_left), \+ curr_lane, \+ free_E, free_NW.

0.5097164::u66.
free_NE :- u66, action(change_to_right), \+ curr_lane, \+ free_E, free_NW.

0.5503916::u67.
free_NE :- u67, action(cruise), \+ curr_lane, \+ free_E, free_NW.

0.3846154::u68.
free_NE :- u68, action(keep), \+ curr_lane, \+ free_E, free_NW.

0.4444444::u69.
free_NE :- u69, action(swerve_left), \+ curr_lane, \+ free_E, free_NW.

0.5000000::u70.
free_NE :- u70, action(swerve_right), \+ curr_lane, \+ free_E, free_NW.

0.5003705::u71.
free_NE :- u71, action(change_to_left), curr_lane, \+ free_E, free_NW.

0.5034882::u72.
free_NE :- u72, action(change_to_right), curr_lane, \+ free_E, free_NW.

0.2034677::u73.
free_NE :- u73, action(cruise), curr_lane, \+ free_E, free_NW.

0.0123457::u74.
free_NE :- u74, action(keep), curr_lane, \+ free_E, free_NW.

0.0009990::u75.
free_NE :- u75, action(swerve_left), curr_lane, \+ free_E, free_NW.

0.0009990::u76.
free_NE :- u76, action(swerve_right), curr_lane, \+ free_E, free_NW.

0.4537000::u77.
free_NE :- u77, action(change_to_left), \+ curr_lane, free_E, free_NW.

0.6208419::u78.
free_NE :- u78, action(change_to_right), \+ curr_lane, free_E, free_NW.

0.4195279::u79.
free_NE :- u79, action(cruise), \+ curr_lane, free_E, free_NW.

0.4716553::u80.
free_NE :- u80, action(keep), \+ curr_lane, free_E, free_NW.

0.8672986::u81.
free_NE :- u81, action(swerve_left), \+ curr_lane, free_E, free_NW.

0.9990010::u82.
free_NE :- u82, action(swerve_right), \+ curr_lane, free_E, free_NW.

0.4998129::u83.
free_NE :- u83, action(change_to_left), curr_lane, free_E, free_NW.

0.5782299::u84.
free_NE :- u84, action(change_to_right), curr_lane, free_E, free_NW.

0.8931102::u85.
free_NE :- u85, action(cruise), curr_lane, free_E, free_NW.

0.0410463::u86.
free_NE :- u86, action(keep), curr_lane, free_E, free_NW.

0.9281332::u87.
free_NE :- u87, action(swerve_left), curr_lane, free_E, free_NW.

0.8781575::u88.
free_NE :- u88, action(swerve_right), curr_lane, free_E, free_NW.

0.5003193::u89.
free_NW :- u89, action(change_to_left), \+ free_SW.

0.5069339::u90.
free_NW :- u90, action(change_to_right), \+ free_SW.

0.4473509::u91.
free_NW :- u91, action(cruise), \+ free_SW.

0.4166531::u92.
free_NW :- u92, action(keep), \+ free_SW.

0.7073171::u93.
free_NW :- u93, action(swerve_left), \+ free_SW.

0.5555556::u94.
free_NW :- u94, action(swerve_right), \+ free_SW.

0.5193958::u95.
free_NW :- u95, action(change_to_left), free_SW.

0.5799509::u96.
free_NW :- u96, action(change_to_right), free_SW.

0.5841558::u97.
free_NW :- u97, action(cruise), free_SW.

0.0218109::u98.
free_NW :- u98, action(keep), free_SW.

0.9692092::u99.
free_NW :- u99, action(swerve_left), free_SW.

0.8203822::u100.
free_NW :- u100, action(swerve_right), free_SW.

