%%% Exogenous variables

0.1675717::u_action(change_to_left); 0.1699710::u_action(change_to_right); 0.4053351::u_action(cruise); 0.2547761::u_action(keep); 0.0014656::u_action(swerve_left); 0.0008804::u_action(swerve_right)
action(V) :- u_action(V).

0.5960905::u1.
free_SE :- u1.

0.6827128::u2.
free_SW :- u2.

0.7159582::u3.
free_W :- u3.

0.3854660::u4.
latent_collision :- u4.

0.4278814::u5.
curr_lane :- u5, action(change_to_left), \+ free_SE.

0.4793262::u6.
curr_lane :- u6, action(change_to_right), \+ free_SE.

0.4930889::u7.
curr_lane :- u7, action(cruise), \+ free_SE.

0.1366114::u8.
curr_lane :- u8, action(keep), \+ free_SE.

0.3670886::u9.
curr_lane :- u9, action(swerve_left), \+ free_SE.

0.9990010::u10.
curr_lane :- u10, action(swerve_right), \+ free_SE.

0.5501936::u11.
curr_lane :- u11, action(change_to_left), free_SE.

0.5660393::u12.
curr_lane :- u12, action(change_to_right), free_SE.

0.7156990::u13.
curr_lane :- u13, action(cruise), free_SE.

0.6017537::u14.
curr_lane :- u14, action(keep), free_SE.

0.8378979::u15.
curr_lane :- u15, action(swerve_left), free_SE.

0.9950249::u16.
curr_lane :- u16, action(swerve_right), free_SE.

0.5061902::u17.
free_E :- u17, action(change_to_left), \+ curr_lane, \+ free_SE.

0.5665271::u18.
free_E :- u18, action(change_to_right), \+ curr_lane, \+ free_SE.

0.3936065::u19.
free_E :- u19, action(cruise), \+ curr_lane, \+ free_SE.

0.5640499::u20.
free_E :- u20, action(keep), \+ curr_lane, \+ free_SE.

0.5000000::u21.
free_E :- u21, action(swerve_left), \+ curr_lane, \+ free_SE.

0.5000000::u22.
free_E :- u22, action(swerve_right), \+ curr_lane, \+ free_SE.

0.5049365::u23.
free_E :- u23, action(change_to_left), curr_lane, \+ free_SE.

0.5377268::u24.
free_E :- u24, action(change_to_right), curr_lane, \+ free_SE.

0.8058480::u25.
free_E :- u25, action(cruise), curr_lane, \+ free_SE.

0.9961617::u26.
free_E :- u26, action(keep), curr_lane, \+ free_SE.

0.9990010::u27.
free_E :- u27, action(swerve_left), curr_lane, \+ free_SE.

0.9990010::u28.
free_E :- u28, action(swerve_right), curr_lane, \+ free_SE.

0.5035217::u29.
free_E :- u29, action(change_to_left), \+ curr_lane, free_SE.

0.3743469::u30.
free_E :- u30, action(change_to_right), \+ curr_lane, free_SE.

0.6223229::u31.
free_E :- u31, action(cruise), \+ curr_lane, free_SE.

0.6558830::u32.
free_E :- u32, action(keep), \+ curr_lane, free_SE.

0.8949772::u33.
free_E :- u33, action(swerve_left), \+ curr_lane, free_SE.

0.9990010::u34.
free_E :- u34, action(swerve_right), \+ curr_lane, free_SE.

0.5847336::u35.
free_E :- u35, action(change_to_left), curr_lane, free_SE.

0.5204304::u36.
free_E :- u36, action(change_to_right), curr_lane, free_SE.

0.9240196::u37.
free_E :- u37, action(cruise), curr_lane, free_SE.

0.8779979::u38.
free_E :- u38, action(keep), curr_lane, free_SE.

0.9867491::u39.
free_E :- u39, action(swerve_left), curr_lane, free_SE.

0.9962500::u40.
free_E :- u40, action(swerve_right), curr_lane, free_SE.

0.4958333::u41.
free_NE :- u41, action(change_to_left), \+ curr_lane, \+ free_E, \+ free_NW.

0.5127778::u42.
free_NE :- u42, action(change_to_right), \+ curr_lane, \+ free_E, \+ free_NW.

0.4973687::u43.
free_NE :- u43, action(cruise), \+ curr_lane, \+ free_E, \+ free_NW.

0.2616138::u44.
free_NE :- u44, action(keep), \+ curr_lane, \+ free_E, \+ free_NW.

0.2500000::u45.
free_NE :- u45, action(swerve_left), \+ curr_lane, \+ free_E, \+ free_NW.

0.5000000::u46.
free_NE :- u46, action(swerve_right), \+ curr_lane, \+ free_E, \+ free_NW.

0.5036709::u47.
free_NE :- u47, action(change_to_left), curr_lane, \+ free_E, \+ free_NW.

0.4994796::u48.
free_NE :- u48, action(change_to_right), curr_lane, \+ free_E, \+ free_NW.

0.2449629::u49.
free_NE :- u49, action(cruise), curr_lane, \+ free_E, \+ free_NW.

0.0003366::u50.
free_NE :- u50, action(keep), curr_lane, \+ free_E, \+ free_NW.

0.0009990::u51.
free_NE :- u51, action(swerve_left), curr_lane, \+ free_E, \+ free_NW.

0.6666667::u52.
free_NE :- u52, action(swerve_right), curr_lane, \+ free_E, \+ free_NW.

0.5262346::u53.
free_NE :- u53, action(change_to_left), \+ curr_lane, free_E, \+ free_NW.

0.2643733::u54.
free_NE :- u54, action(change_to_right), \+ curr_lane, free_E, \+ free_NW.

0.5170599::u55.
free_NE :- u55, action(cruise), \+ curr_lane, free_E, \+ free_NW.

0.0097731::u56.
free_NE :- u56, action(keep), \+ curr_lane, free_E, \+ free_NW.

0.0009990::u57.
free_NE :- u57, action(swerve_left), \+ curr_lane, free_E, \+ free_NW.

0.5000000::u58.
free_NE :- u58, action(swerve_right), \+ curr_lane, free_E, \+ free_NW.

0.4728627::u59.
free_NE :- u59, action(change_to_left), curr_lane, free_E, \+ free_NW.

0.5229835::u60.
free_NE :- u60, action(change_to_right), curr_lane, free_E, \+ free_NW.

0.9075364::u61.
free_NE :- u61, action(cruise), curr_lane, free_E, \+ free_NW.

0.0010428::u62.
free_NE :- u62, action(keep), curr_lane, free_E, \+ free_NW.

0.3055556::u63.
free_NE :- u63, action(swerve_left), curr_lane, free_E, \+ free_NW.

0.7307692::u64.
free_NE :- u64, action(swerve_right), curr_lane, free_E, \+ free_NW.

0.4841895::u65.
free_NE :- u65, action(change_to_left), \+ curr_lane, \+ free_E, free_NW.

0.5100891::u66.
free_NE :- u66, action(change_to_right), \+ curr_lane, \+ free_E, free_NW.

0.5504879::u67.
free_NE :- u67, action(cruise), \+ curr_lane, \+ free_E, free_NW.

0.3777778::u68.
free_NE :- u68, action(keep), \+ curr_lane, \+ free_E, free_NW.

0.3863636::u69.
free_NE :- u69, action(swerve_left), \+ curr_lane, \+ free_E, free_NW.

0.5000000::u70.
free_NE :- u70, action(swerve_right), \+ curr_lane, \+ free_E, free_NW.

0.5011973::u71.
free_NE :- u71, action(change_to_left), curr_lane, \+ free_E, free_NW.

0.5044605::u72.
free_NE :- u72, action(change_to_right), curr_lane, \+ free_E, free_NW.

0.1994005::u73.
free_NE :- u73, action(cruise), curr_lane, \+ free_E, free_NW.

0.0122699::u74.
free_NE :- u74, action(keep), curr_lane, \+ free_E, free_NW.

0.0714286::u75.
free_NE :- u75, action(swerve_left), curr_lane, \+ free_E, free_NW.

0.5000000::u76.
free_NE :- u76, action(swerve_right), curr_lane, \+ free_E, free_NW.

0.4553544::u77.
free_NE :- u77, action(change_to_left), \+ curr_lane, free_E, free_NW.

0.6189487::u78.
free_NE :- u78, action(change_to_right), \+ curr_lane, free_E, free_NW.

0.4180204::u79.
free_NE :- u79, action(cruise), \+ curr_lane, free_E, free_NW.

0.4343891::u80.
free_NE :- u80, action(keep), \+ curr_lane, free_E, free_NW.

0.8279070::u81.
free_NE :- u81, action(swerve_left), \+ curr_lane, free_E, free_NW.

0.9990010::u82.
free_NE :- u82, action(swerve_right), \+ curr_lane, free_E, free_NW.

0.5003747::u83.
free_NE :- u83, action(change_to_left), curr_lane, free_E, free_NW.

0.5802079::u84.
free_NE :- u84, action(change_to_right), curr_lane, free_E, free_NW.

0.8931144::u85.
free_NE :- u85, action(cruise), curr_lane, free_E, free_NW.

0.0395031::u86.
free_NE :- u86, action(keep), curr_lane, free_E, free_NW.

0.9351351::u87.
free_NE :- u87, action(swerve_left), curr_lane, free_E, free_NW.

0.8893678::u88.
free_NE :- u88, action(swerve_right), curr_lane, free_E, free_NW.

0.5016170::u89.
free_NW :- u89, action(change_to_left), \+ free_SW.

0.5057380::u90.
free_NW :- u90, action(change_to_right), \+ free_SW.

0.4476333::u91.
free_NW :- u91, action(cruise), \+ free_SW.

0.4071464::u92.
free_NW :- u92, action(keep), \+ free_SW.

0.8125000::u93.
free_NW :- u93, action(swerve_left), \+ free_SW.

0.5185185::u94.
free_NW :- u94, action(swerve_right), \+ free_SW.

0.5197195::u95.
free_NW :- u95, action(change_to_left), free_SW.

0.5790767::u96.
free_NW :- u96, action(change_to_right), free_SW.

0.5849117::u97.
free_NW :- u97, action(cruise), free_SW.

0.0219812::u98.
free_NW :- u98, action(keep), free_SW.

0.9706724::u99.
free_NW :- u99, action(swerve_left), free_SW.

0.8347826::u100.
free_NW :- u100, action(swerve_right), free_SW.

