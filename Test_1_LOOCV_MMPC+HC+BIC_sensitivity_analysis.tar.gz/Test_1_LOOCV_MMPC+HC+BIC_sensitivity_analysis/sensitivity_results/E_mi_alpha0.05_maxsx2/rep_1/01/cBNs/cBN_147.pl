%%% Exogenous variables

0.1702880::u_action(change_to_left); 0.1740289::u_action(change_to_right); 0.4000717::u_action(cruise); 0.2527929::u_action(keep); 0.0021523::u_action(swerve_left); 0.0006662::u_action(swerve_right)
action(V) :- u_action(V).

0.5324895::u1.
curr_lane :- u1.

0.7163062::u2.
free_W :- u2.

0.6138447::u3.
free_E :- u3, \+ curr_lane, \+ latent_collision.

0.9390747::u4.
free_E :- u4, curr_lane, \+ latent_collision.

0.4415034::u5.
free_E :- u5, \+ curr_lane, latent_collision.

0.5281104::u6.
free_E :- u6, curr_lane, latent_collision.

0.4914234::u7.
free_NE :- u7, action(change_to_left).

0.5126620::u8.
free_NE :- u8, action(change_to_right).

0.7153836::u9.
free_NE :- u9, action(cruise).

0.0768295::u10.
free_NE :- u10, action(keep).

0.8333333::u11.
free_NE :- u11, action(swerve_left).

0.8461538::u12.
free_NE :- u12, action(swerve_right).

0.5257298::u13.
free_NW :- u13, action(change_to_left).

0.5368080::u14.
free_NW :- u14, action(change_to_right).

0.5302933::u15.
free_NW :- u15, action(cruise).

0.0300020::u16.
free_NW :- u16, action(keep).

0.9523810::u17.
free_NW :- u17, action(swerve_left).

0.6923077::u18.
free_NW :- u18, action(swerve_right).

0.4557711::u19.
free_SE :- u19, \+ curr_lane.

0.7274565::u20.
free_SE :- u20, curr_lane.

0.5109841::u21.
free_SW :- u21, action(change_to_left).

0.5697880::u22.
free_SW :- u22, action(change_to_right).

0.6077879::u23.
free_SW :- u23, action(cruise).

0.9738496::u24.
free_SW :- u24, action(keep).

0.9761905::u25.
free_SW :- u25, action(swerve_left).

0.8461538::u26.
free_SW :- u26, action(swerve_right).

0.6790101::u27.
latent_collision :- u27, \+ free_W.

0.2762198::u28.
latent_collision :- u28, free_W.

