%%% Exogenous variables

0.1686926::u_action(change_to_left); 0.1705391::u_action(change_to_right); 0.4084731::u_action(cruise); 0.2497820::u_action(keep); 0.0016413::u_action(swerve_left); 0.0008719::u_action(swerve_right)
action(V) :- u_action(V).

0.5252603::u1.
curr_lane :- u1.

0.7093912::u2.
free_W :- u2.

0.5977674::u3.
free_E :- u3, \+ curr_lane, \+ latent_collision.

0.9385277::u4.
free_E :- u4, curr_lane, \+ latent_collision.

0.4529760::u5.
free_E :- u5, \+ curr_lane, latent_collision.

0.5447242::u6.
free_E :- u6, curr_lane, latent_collision.

0.4986318::u7.
free_NE :- u7, action(change_to_left).

0.5058647::u8.
free_NE :- u8, action(change_to_right).

0.7074335::u9.
free_NE :- u9, action(cruise).

0.0759754::u10.
free_NE :- u10, action(keep).

0.8125000::u11.
free_NE :- u11, action(swerve_left).

0.8823529::u12.
free_NE :- u12, action(swerve_right).

0.5241715::u13.
free_NW :- u13, action(change_to_left).

0.5530827::u14.
free_NW :- u14, action(change_to_right).

0.5302612::u15.
free_NW :- u15, action(cruise).

0.0293634::u16.
free_NW :- u16, action(keep).

0.9375000::u17.
free_NW :- u17, action(swerve_left).

0.8823529::u18.
free_NW :- u18, action(swerve_right).

0.4627269::u19.
free_SE :- u19, \+ curr_lane.

0.7218045::u20.
free_SE :- u20, curr_lane.

0.5059289::u21.
free_SW :- u21, action(change_to_left).

0.5807519::u22.
free_SW :- u22, action(change_to_right).

0.6106228::u23.
free_SW :- u23, action(cruise).

0.9770021::u24.
free_SW :- u24, action(keep).

0.9990010::u25.
free_SW :- u25, action(swerve_left).

0.7647059::u26.
free_SW :- u26, action(swerve_right).

0.6909636::u27.
latent_collision :- u27, \+ free_W.

0.2675150::u28.
latent_collision :- u28, free_W.

