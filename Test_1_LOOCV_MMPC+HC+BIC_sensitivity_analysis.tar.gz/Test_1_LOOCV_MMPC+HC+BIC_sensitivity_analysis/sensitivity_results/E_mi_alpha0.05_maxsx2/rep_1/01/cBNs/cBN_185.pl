%%% Exogenous variables

0.1638991::u_action(change_to_left); 0.1722017::u_action(change_to_right); 0.4060066::u_action(cruise); 0.2557401::u_action(keep); 0.0012300::u_action(swerve_left); 0.0009225::u_action(swerve_right)
action(V) :- u_action(V).

0.5280853::u1.
curr_lane :- u1.

0.7120234::u2.
free_W :- u2.

0.6133678::u3.
free_E :- u3, \+ curr_lane, \+ latent_collision.

0.9358974::u4.
free_E :- u4, curr_lane, \+ latent_collision.

0.4409283::u5.
free_E :- u5, \+ curr_lane, latent_collision.

0.5405553::u6.
free_E :- u6, curr_lane, latent_collision.

0.4968730::u7.
free_NE :- u7, action(change_to_left).

0.5238095::u8.
free_NE :- u8, action(change_to_right).

0.7097955::u9.
free_NE :- u9, action(cruise).

0.0727455::u10.
free_NE :- u10, action(keep).

0.9583333::u11.
free_NE :- u11, action(swerve_left).

0.9444444::u12.
free_NE :- u12, action(swerve_right).

0.5115697::u13.
free_NW :- u13, action(change_to_left).

0.5410714::u14.
free_NW :- u14, action(change_to_right).

0.5167887::u15.
free_NW :- u15, action(cruise).

0.0338677::u16.
free_NW :- u16, action(keep).

0.9990010::u17.
free_NW :- u17, action(swerve_left).

0.6111111::u18.
free_NW :- u18, action(swerve_right).

0.4450478::u19.
free_SE :- u19, \+ curr_lane.

0.7209821::u20.
free_SE :- u20, curr_lane.

0.5297061::u21.
free_SW :- u21, action(change_to_left).

0.6032738::u22.
free_SW :- u22, action(change_to_right).

0.5925271::u23.
free_SW :- u23, action(cruise).

0.9761523::u24.
free_SW :- u24, action(keep).

0.9583333::u25.
free_SW :- u25, action(swerve_left).

0.6666667::u26.
free_SW :- u26, action(swerve_right).

0.6832177::u27.
latent_collision :- u27, \+ free_W.

0.2610667::u28.
latent_collision :- u28, free_W.

