%%% Exogenous variables

0.1692512::u_action(change_to_left); 0.1700701::u_action(change_to_right); 0.4044219::u_action(cruise); 0.2539536::u_action(keep); 0.0017913::u_action(swerve_left); 0.0005118::u_action(swerve_right)
action(V) :- u_action(V).

0.5305799::u1.
curr_lane :- u1.

0.7117048::u2.
free_W :- u2.

0.6194527::u3.
free_E :- u3, \+ curr_lane, \+ latent_collision.

0.9338592::u4.
free_E :- u4, curr_lane, \+ latent_collision.

0.4614772::u5.
free_E :- u5, \+ curr_lane, latent_collision.

0.5327152::u6.
free_E :- u6, curr_lane, latent_collision.

0.4853341::u7.
free_NE :- u7, action(change_to_left).

0.5191092::u8.
free_NE :- u8, action(change_to_right).

0.7171602::u9.
free_NE :- u9, action(cruise).

0.0701330::u10.
free_NE :- u10, action(keep).

0.9142857::u11.
free_NE :- u11, action(swerve_left).

0.7000000::u12.
free_NE :- u12, action(swerve_right).

0.5019655::u13.
free_NW :- u13, action(change_to_left).

0.5425820::u14.
free_NW :- u14, action(change_to_right).

0.5256897::u15.
free_NW :- u15, action(cruise).

0.0330512::u16.
free_NW :- u16, action(keep).

0.9990010::u17.
free_NW :- u17, action(swerve_left).

0.9000000::u18.
free_NW :- u18, action(swerve_right).

0.4538814::u19.
free_SE :- u19, \+ curr_lane.

0.7276936::u20.
free_SE :- u20, curr_lane.

0.5349259::u21.
free_SW :- u21, action(change_to_left).

0.5777912::u22.
free_SW :- u22, action(change_to_right).

0.6107315::u23.
free_SW :- u23, action(cruise).

0.9721886::u24.
free_SW :- u24, action(keep).

0.9714286::u25.
free_SW :- u25, action(swerve_left).

0.9000000::u26.
free_SW :- u26, action(swerve_right).

0.6840050::u27.
latent_collision :- u27, \+ free_W.

0.2650654::u28.
latent_collision :- u28, free_W.

