%%% Exogenous variables

0.1728685::u_action(change_to_left); 0.1663770::u_action(change_to_right); 0.4070742::u_action(cruise); 0.2511756::u_action(keep); 0.0013801::u_action(swerve_left); 0.0011245::u_action(swerve_right)
action(V) :- u_action(V).

0.5349622::u1.
curr_lane :- u1.

0.7105398::u2.
free_W :- u2.

0.5969093::u3.
free_E :- u3, \+ curr_lane, \+ latent_collision.

0.9347498::u4.
free_E :- u4, curr_lane, \+ latent_collision.

0.4459351::u5.
free_E :- u5, \+ curr_lane, latent_collision.

0.5381201::u6.
free_E :- u6, curr_lane, latent_collision.

0.4869899::u7.
free_NE :- u7, action(change_to_left).

0.5136713::u8.
free_NE :- u8, action(change_to_right).

0.7143395::u9.
free_NE :- u9, action(cruise).

0.0785511::u10.
free_NE :- u10, action(keep).

0.8888889::u11.
free_NE :- u11, action(swerve_left).

0.9090909::u12.
free_NE :- u12, action(swerve_right).

0.5038439::u13.
free_NW :- u13, action(change_to_left).

0.5351767::u14.
free_NW :- u14, action(change_to_right).

0.5306379::u15.
free_NW :- u15, action(cruise).

0.0370370::u16.
free_NW :- u16, action(keep).

0.9259259::u17.
free_NW :- u17, action(swerve_left).

0.7727273::u18.
free_NW :- u18, action(swerve_right).

0.4549352::u19.
free_SE :- u19, \+ curr_lane.

0.7307472::u20.
free_SE :- u20, curr_lane.

0.5201064::u21.
free_SW :- u21, action(change_to_left).

0.5680492::u22.
free_SW :- u22, action(change_to_right).

0.6037167::u23.
free_SW :- u23, action(cruise).

0.9770045::u24.
free_SW :- u24, action(keep).

0.9629630::u25.
free_SW :- u25, action(swerve_left).

0.8636364::u26.
free_SW :- u26, action(swerve_right).

0.6830302::u27.
latent_collision :- u27, \+ free_W.

0.2653766::u28.
latent_collision :- u28, free_W.

