%%% Exogenous variables

0.1662396::u_action(change_to_left); 0.1744389::u_action(change_to_right); 0.4067336::u_action(cruise); 0.2499231::u_action(keep); 0.0017936::u_action(swerve_left); 0.0008712::u_action(swerve_right)
action(V) :- u_action(V).

0.5296710::u1.
curr_lane :- u1.

0.7120016::u2.
free_W :- u2.

0.6087772::u3.
free_E :- u3, \+ curr_lane, \+ latent_collision.

0.9371886::u4.
free_E :- u4, curr_lane, \+ latent_collision.

0.4490380::u5.
free_E :- u5, \+ curr_lane, latent_collision.

0.5119849::u6.
free_E :- u6, curr_lane, latent_collision.

0.5058570::u7.
free_NE :- u7, action(change_to_left).

0.5002938::u8.
free_NE :- u8, action(change_to_right).

0.7076981::u9.
free_NE :- u9, action(cruise).

0.0740209::u10.
free_NE :- u10, action(keep).

0.8857143::u11.
free_NE :- u11, action(swerve_left).

0.8823529::u12.
free_NE :- u12, action(swerve_right).

0.5095561::u13.
free_NW :- u13, action(change_to_left).

0.5514101::u14.
free_NW :- u14, action(change_to_right).

0.5289152::u15.
free_NW :- u15, action(cruise).

0.0330121::u16.
free_NW :- u16, action(keep).

0.9990010::u17.
free_NW :- u17, action(swerve_left).

0.8235294::u18.
free_NW :- u18, action(swerve_right).

0.4477010::u19.
free_SE :- u19, \+ curr_lane.

0.7328754::u20.
free_SE :- u20, curr_lane.

0.5292848::u21.
free_SW :- u21, action(change_to_left).

0.5819624::u22.
free_SW :- u22, action(change_to_right).

0.5936752::u23.
free_SW :- u23, action(cruise).

0.9735493::u24.
free_SW :- u24, action(keep).

0.9142857::u25.
free_SW :- u25, action(swerve_left).

0.9411765::u26.
free_SW :- u26, action(swerve_right).

0.6745552::u27.
latent_collision :- u27, \+ free_W.

0.2711962::u28.
latent_collision :- u28, free_W.

