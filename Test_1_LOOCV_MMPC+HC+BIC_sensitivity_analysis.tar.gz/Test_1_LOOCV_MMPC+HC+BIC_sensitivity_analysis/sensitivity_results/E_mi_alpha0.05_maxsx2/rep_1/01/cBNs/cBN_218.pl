%%% Exogenous variables

0.1683919::u_action(change_to_left); 0.1709029::u_action(change_to_right); 0.4083735::u_action(cruise); 0.2501281::u_action(keep); 0.0013836::u_action(swerve_left); 0.0008199::u_action(swerve_right)
action(V) :- u_action(V).

0.5300297::u1.
curr_lane :- u1.

0.7149226::u2.
free_W :- u2.

0.6111633::u3.
free_E :- u3, \+ curr_lane, \+ latent_collision.

0.9379154::u4.
free_E :- u4, curr_lane, \+ latent_collision.

0.4400000::u5.
free_E :- u5, \+ curr_lane, latent_collision.

0.5192049::u6.
free_E :- u6, curr_lane, latent_collision.

0.4875228::u7.
free_NE :- u7, action(change_to_left).

0.5265367::u8.
free_NE :- u8, action(change_to_right).

0.7204166::u9.
free_NE :- u9, action(cruise).

0.0725261::u10.
free_NE :- u10, action(keep).

0.8518519::u11.
free_NE :- u11, action(swerve_left).

0.7500000::u12.
free_NE :- u12, action(swerve_right).

0.5109556::u13.
free_NW :- u13, action(change_to_left).

0.5511244::u14.
free_NW :- u14, action(change_to_right).

0.5291756::u15.
free_NW :- u15, action(cruise).

0.0327802::u16.
free_NW :- u16, action(keep).

0.9990010::u17.
free_NW :- u17, action(swerve_left).

0.7500000::u18.
free_NW :- u18, action(swerve_right).

0.4509868::u19.
free_SE :- u19, \+ curr_lane.

0.7351832::u20.
free_SE :- u20, curr_lane.

0.5273889::u21.
free_SW :- u21, action(change_to_left).

0.5952024::u22.
free_SW :- u22, action(change_to_right).

0.6027105::u23.
free_SW :- u23, action(cruise).

0.9801270::u24.
free_SW :- u24, action(keep).

0.9990010::u25.
free_SW :- u25, action(swerve_left).

0.8750000::u26.
free_SW :- u26, action(swerve_right).

0.6722991::u27.
latent_collision :- u27, \+ free_W.

0.2747473::u28.
latent_collision :- u28, free_W.

