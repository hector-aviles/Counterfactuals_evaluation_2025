%%% Exogenous variables

0.1722845::u_action(change_to_left); 0.1662214::u_action(change_to_right); 0.4047374::u_action(cruise); 0.2539307::u_action(keep); 0.0020039::u_action(swerve_left); 0.0008221::u_action(swerve_right)
action(V) :- u_action(V).

0.5230706::u1.
curr_lane :- u1.

0.7183229::u2.
free_W :- u2.

0.6011433::u3.
free_E :- u3, \+ curr_lane, \+ latent_collision.

0.9350330::u4.
free_E :- u4, curr_lane, \+ latent_collision.

0.4475253::u5.
free_E :- u5, \+ curr_lane, latent_collision.

0.5320251::u6.
free_E :- u6, curr_lane, latent_collision.

0.4804653::u7.
free_NE :- u7, action(change_to_left).

0.5153014::u8.
free_NE :- u8, action(change_to_right).

0.7138505::u9.
free_NE :- u9, action(cruise).

0.0766896::u10.
free_NE :- u10, action(keep).

0.8717949::u11.
free_NE :- u11, action(swerve_left).

0.7500000::u12.
free_NE :- u12, action(swerve_right).

0.5073069::u13.
free_NW :- u13, action(change_to_left).

0.5496136::u14.
free_NW :- u14, action(change_to_right).

0.5249460::u15.
free_NW :- u15, action(cruise).

0.0198300::u16.
free_NW :- u16, action(keep).

0.9230769::u17.
free_NW :- u17, action(swerve_left).

0.7500000::u18.
free_NW :- u18, action(swerve_right).

0.4583064::u19.
free_SE :- u19, \+ curr_lane.

0.7270138::u20.
free_SE :- u20, curr_lane.

0.5174471::u21.
free_SW :- u21, action(change_to_left).

0.5678516::u22.
free_SW :- u22, action(change_to_right).

0.6026406::u23.
free_SW :- u23, action(cruise).

0.9740996::u24.
free_SW :- u24, action(keep).

0.9990010::u25.
free_SW :- u25, action(swerve_left).

0.9990010::u26.
free_SW :- u26, action(swerve_right).

0.6877052::u27.
latent_collision :- u27, \+ free_W.

0.2688126::u28.
latent_collision :- u28, free_W.

