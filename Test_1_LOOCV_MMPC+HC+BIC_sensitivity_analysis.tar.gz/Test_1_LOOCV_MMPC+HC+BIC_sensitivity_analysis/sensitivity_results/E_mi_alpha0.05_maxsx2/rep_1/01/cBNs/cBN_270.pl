%%% Exogenous variables

0.1682490::u_action(change_to_left); 0.1696498::u_action(change_to_right); 0.4007782::u_action(cruise); 0.2589883::u_action(keep); 0.0014008::u_action(swerve_left); 0.0009339::u_action(swerve_right)
action(V) :- u_action(V).

0.5260182::u1.
curr_lane :- u1.

0.7283009::u2.
free_W :- u2.

0.6233910::u3.
free_E :- u3, \+ curr_lane, \+ latent_collision.

0.9362101::u4.
free_E :- u4, curr_lane, \+ latent_collision.

0.4510546::u5.
free_E :- u5, \+ curr_lane, latent_collision.

0.5161635::u6.
free_E :- u6, curr_lane, latent_collision.

0.4779525::u7.
free_NE :- u7, action(change_to_left).

0.5180428::u8.
free_NE :- u8, action(change_to_right).

0.7049838::u9.
free_NE :- u9, action(cruise).

0.0787260::u10.
free_NE :- u10, action(keep).

0.8148148::u11.
free_NE :- u11, action(swerve_left).

0.9444444::u12.
free_NE :- u12, action(swerve_right).

0.5013876::u13.
free_NW :- u13, action(change_to_left).

0.5620795::u14.
free_NW :- u14, action(change_to_right).

0.5509385::u15.
free_NW :- u15, action(cruise).

0.0294471::u16.
free_NW :- u16, action(keep).

0.9990010::u17.
free_NW :- u17, action(swerve_left).

0.8888889::u18.
free_NW :- u18, action(swerve_right).

0.4550131::u19.
free_SE :- u19, \+ curr_lane.

0.7049019::u20.
free_SE :- u20, curr_lane.

0.5174221::u21.
free_SW :- u21, action(change_to_left).

0.5935780::u22.
free_SW :- u22, action(change_to_right).

0.6284790::u23.
free_SW :- u23, action(cruise).

0.9771635::u24.
free_SW :- u24, action(keep).

0.8888889::u25.
free_SW :- u25, action(swerve_left).

0.9444444::u26.
free_SW :- u26, action(swerve_right).

0.7109032::u27.
latent_collision :- u27, \+ free_W.

0.2648525::u28.
latent_collision :- u28, free_W.

