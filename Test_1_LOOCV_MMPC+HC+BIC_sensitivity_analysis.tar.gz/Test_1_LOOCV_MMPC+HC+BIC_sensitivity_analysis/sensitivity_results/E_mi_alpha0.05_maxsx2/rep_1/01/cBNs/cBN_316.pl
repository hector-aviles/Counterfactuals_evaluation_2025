%%% Exogenous variables

0.1704593::u_action(change_to_left); 0.1669784::u_action(change_to_right); 0.4124065::u_action(cruise); 0.2471945::u_action(keep); 0.0017664::u_action(swerve_left); 0.0011949::u_action(swerve_right)
action(V) :- u_action(V).

0.5422382::u1.
curr_lane :- u1.

0.7084892::u2.
free_W :- u2.

0.6424385::u3.
free_E :- u3, \+ curr_lane, \+ latent_collision.

0.9332225::u4.
free_E :- u4, curr_lane, \+ latent_collision.

0.4711617::u5.
free_E :- u5, \+ curr_lane, latent_collision.

0.5204295::u6.
free_E :- u6, curr_lane, latent_collision.

0.4946663::u7.
free_NE :- u7, action(change_to_left).

0.5074673::u8.
free_NE :- u8, action(change_to_right).

0.7042076::u9.
free_NE :- u9, action(cruise).

0.0283733::u10.
free_NE :- u10, action(keep).

0.8235294::u11.
free_NE :- u11, action(swerve_left).

0.9990010::u12.
free_NE :- u12, action(swerve_right).

0.5220969::u13.
free_NW :- u13, action(change_to_left).

0.5382701::u14.
free_NW :- u14, action(change_to_right).

0.5233056::u15.
free_NW :- u15, action(cruise).

0.0294241::u16.
free_NW :- u16, action(keep).

0.9117647::u17.
free_NW :- u17, action(swerve_left).

0.8695652::u18.
free_NW :- u18, action(swerve_right).

0.4673703::u19.
free_SE :- u19, \+ curr_lane.

0.7290409::u20.
free_SE :- u20, curr_lane.

0.5108199::u21.
free_SW :- u21, action(change_to_left).

0.5790292::u22.
free_SW :- u22, action(change_to_right).

0.5981356::u23.
free_SW :- u23, action(cruise).

0.9760404::u24.
free_SW :- u24, action(keep).

0.9411765::u25.
free_SW :- u25, action(swerve_left).

0.9565217::u26.
free_SW :- u26, action(swerve_right).

0.6882909::u27.
latent_collision :- u27, \+ free_W.

0.2675808::u28.
latent_collision :- u28, free_W.

