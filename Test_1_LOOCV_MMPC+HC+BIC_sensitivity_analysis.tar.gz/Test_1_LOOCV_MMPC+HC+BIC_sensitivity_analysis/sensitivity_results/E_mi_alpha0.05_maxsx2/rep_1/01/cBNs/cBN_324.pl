%%% Exogenous variables

0.1699032::u_action(change_to_left); 0.1669826::u_action(change_to_right); 0.4031357::u_action(cruise); 0.2573141::u_action(keep); 0.0015371::u_action(swerve_left); 0.0011272::u_action(swerve_right)
action(V) :- u_action(V).

0.5351745::u1.
curr_lane :- u1.

0.7096890::u2.
free_W :- u2.

0.6097786::u3.
free_E :- u3, \+ curr_lane, \+ latent_collision.

0.9319356::u4.
free_E :- u4, curr_lane, \+ latent_collision.

0.4515334::u5.
free_E :- u5, \+ curr_lane, latent_collision.

0.5156614::u6.
free_E :- u6, curr_lane, latent_collision.

0.4885404::u7.
free_NE :- u7, action(change_to_left).

0.5148819::u8.
free_NE :- u8, action(change_to_right).

0.7052618::u9.
free_NE :- u9, action(cruise).

0.0728793::u10.
free_NE :- u10, action(keep).

0.8333333::u11.
free_NE :- u11, action(swerve_left).

0.8181818::u12.
free_NE :- u12, action(swerve_right).

0.4969843::u13.
free_NW :- u13, action(change_to_left).

0.5418840::u14.
free_NW :- u14, action(change_to_right).

0.5339349::u15.
free_NW :- u15, action(cruise).

0.0322581::u16.
free_NW :- u16, action(keep).

0.9990010::u17.
free_NW :- u17, action(swerve_left).

0.6818182::u18.
free_NW :- u18, action(swerve_right).

0.4616402::u19.
free_SE :- u19, \+ curr_lane.

0.7221637::u20.
free_SE :- u20, curr_lane.

0.5162847::u21.
free_SW :- u21, action(change_to_left).

0.5648972::u22.
free_SW :- u22, action(change_to_right).

0.6018048::u23.
free_SW :- u23, action(cruise).

0.9741139::u24.
free_SW :- u24, action(keep).

0.9666667::u25.
free_SW :- u25, action(swerve_left).

0.9090909::u26.
free_SW :- u26, action(swerve_right).

0.6853159::u27.
latent_collision :- u27, \+ free_W.

0.2622193::u28.
latent_collision :- u28, free_W.

