%%% Exogenous variables

0.1678780::u_action(change_to_left); 0.1719726::u_action(change_to_right); 0.4006551::u_action(cruise); 0.2569864::u_action(keep); 0.0015867::u_action(swerve_left); 0.0009213::u_action(swerve_right)
action(V) :- u_action(V).

0.5283550::u1.
curr_lane :- u1.

0.7143515::u2.
free_W :- u2.

0.6091848::u3.
free_E :- u3, \+ curr_lane, \+ latent_collision.

0.9406393::u4.
free_E :- u4, curr_lane, \+ latent_collision.

0.4518851::u5.
free_E :- u5, \+ curr_lane, latent_collision.

0.5259792::u6.
free_E :- u6, curr_lane, latent_collision.

0.4814024::u7.
free_NE :- u7, action(change_to_left).

0.5130952::u8.
free_NE :- u8, action(change_to_right).

0.7130812::u9.
free_NE :- u9, action(cruise).

0.0756821::u10.
free_NE :- u10, action(keep).

0.9032258::u11.
free_NE :- u11, action(swerve_left).

0.8333333::u12.
free_NE :- u12, action(swerve_right).

0.5112805::u13.
free_NW :- u13, action(change_to_left).

0.5568452::u14.
free_NW :- u14, action(change_to_right).

0.5273378::u15.
free_NW :- u15, action(cruise).

0.0322645::u16.
free_NW :- u16, action(keep).

0.9990010::u17.
free_NW :- u17, action(swerve_left).

0.8333333::u18.
free_NW :- u18, action(swerve_right).

0.4472056::u19.
free_SE :- u19, \+ curr_lane.

0.7342827::u20.
free_SE :- u20, curr_lane.

0.5213415::u21.
free_SW :- u21, action(change_to_left).

0.5741071::u22.
free_SW :- u22, action(change_to_right).

0.6088401::u23.
free_SW :- u23, action(cruise).

0.9759012::u24.
free_SW :- u24, action(keep).

0.9990010::u25.
free_SW :- u25, action(swerve_left).

0.9990010::u26.
free_SW :- u26, action(swerve_right).

0.6769396::u27.
latent_collision :- u27, \+ free_W.

0.2699721::u28.
latent_collision :- u28, free_W.

