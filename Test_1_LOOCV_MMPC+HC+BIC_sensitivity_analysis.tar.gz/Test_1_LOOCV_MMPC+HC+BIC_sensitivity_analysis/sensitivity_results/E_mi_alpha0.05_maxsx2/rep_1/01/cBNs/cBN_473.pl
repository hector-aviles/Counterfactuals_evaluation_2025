%%% Exogenous variables

0.1647610::u_action(change_to_left); 0.1700659::u_action(change_to_right); 0.4092501::u_action(cruise); 0.2536053::u_action(keep); 0.0016481::u_action(swerve_left); 0.0006696::u_action(swerve_right)
action(V) :- u_action(V).

0.5298723::u1.
curr_lane :- u1.

0.7146168::u2.
free_W :- u2.

0.6147283::u3.
free_E :- u3, \+ curr_lane, \+ latent_collision.

0.9343635::u4.
free_E :- u4, curr_lane, \+ latent_collision.

0.4551780::u5.
free_E :- u5, \+ curr_lane, latent_collision.

0.5151919::u6.
free_E :- u6, curr_lane, latent_collision.

0.5085964::u7.
free_NE :- u7, action(change_to_left).

0.5142338::u8.
free_NE :- u8, action(change_to_right).

0.7201107::u9.
free_NE :- u9, action(cruise).

0.0725020::u10.
free_NE :- u10, action(keep).

0.8125000::u11.
free_NE :- u11, action(swerve_left).

0.8461538::u12.
free_NE :- u12, action(swerve_right).

0.4945295::u13.
free_NW :- u13, action(change_to_left).

0.5484555::u14.
free_NW :- u14, action(change_to_right).

0.5298263::u15.
free_NW :- u15, action(cruise).

0.0243704::u16.
free_NW :- u16, action(keep).

0.9687500::u17.
free_NW :- u17, action(swerve_left).

0.6923077::u18.
free_NW :- u18, action(swerve_right).

0.4573839::u19.
free_SE :- u19, \+ curr_lane.

0.7154938::u20.
free_SE :- u20, curr_lane.

0.5357924::u21.
free_SW :- u21, action(change_to_left).

0.5929740::u22.
free_SW :- u22, action(change_to_right).

0.6081047::u23.
free_SW :- u23, action(cruise).

0.9798944::u24.
free_SW :- u24, action(keep).

0.9687500::u25.
free_SW :- u25, action(swerve_left).

0.9230769::u26.
free_SW :- u26, action(swerve_right).

0.6785779::u27.
latent_collision :- u27, \+ free_W.

0.2687568::u28.
latent_collision :- u28, free_W.

