%%% Exogenous variables

0.1685849::u_action(change_to_left); 0.1728497::u_action(change_to_right); 0.4096187::u_action(cruise); 0.2467886::u_action(keep); 0.0012332::u_action(swerve_left); 0.0009249::u_action(swerve_right)
action(V) :- u_action(V).

0.5283116::u1.
curr_lane :- u1.

0.7128250::u2.
free_W :- u2.

0.6112782::u3.
free_E :- u3, \+ curr_lane, \+ latent_collision.

0.9362519::u4.
free_E :- u4, curr_lane, \+ latent_collision.

0.4479275::u5.
free_E :- u5, \+ curr_lane, latent_collision.

0.5201485::u6.
free_E :- u6, curr_lane, latent_collision.

0.4855227::u7.
free_NE :- u7, action(change_to_left).

0.5130797::u8.
free_NE :- u8, action(change_to_right).

0.7078525::u9.
free_NE :- u9, action(cruise).

0.0720383::u10.
free_NE :- u10, action(keep).

0.8333333::u11.
free_NE :- u11, action(swerve_left).

0.8333333::u12.
free_NE :- u12, action(swerve_right).

0.5028955::u13.
free_NW :- u13, action(change_to_left).

0.5558859::u14.
free_NW :- u14, action(change_to_right).

0.5164325::u15.
free_NW :- u15, action(cruise).

0.0204039::u16.
free_NW :- u16, action(keep).

0.9166667::u17.
free_NW :- u17, action(swerve_left).

0.5555556::u18.
free_NW :- u18, action(swerve_right).

0.4547930::u19.
free_SE :- u19, \+ curr_lane.

0.7233029::u20.
free_SE :- u20, curr_lane.

0.5099055::u21.
free_SW :- u21, action(change_to_left).

0.5642093::u22.
free_SW :- u22, action(change_to_right).

0.6031109::u23.
free_SW :- u23, action(cruise).

0.9756402::u24.
free_SW :- u24, action(keep).

0.9583333::u25.
free_SW :- u25, action(swerve_left).

0.8333333::u26.
free_SW :- u26, action(swerve_right).

0.6856325::u27.
latent_collision :- u27, \+ free_W.

0.2739134::u28.
latent_collision :- u28, free_W.

