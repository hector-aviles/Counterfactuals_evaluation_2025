%%% Exogenous variables

0.1669398::u_action(change_to_left); 0.1660180::u_action(change_to_right); 0.4066469::u_action(cruise); 0.2577325::u_action(keep); 0.0014850::u_action(swerve_left); 0.0011778::u_action(swerve_right)
action(V) :- u_action(V).

0.5279599::u1.
curr_lane :- u1.

0.7131811::u2.
free_W :- u2.

0.6190564::u3.
free_E :- u3, \+ curr_lane, \+ latent_collision.

0.9305409::u4.
free_E :- u4, curr_lane, \+ latent_collision.

0.4432206::u5.
free_E :- u5, \+ curr_lane, latent_collision.

0.5191941::u6.
free_E :- u6, curr_lane, latent_collision.

0.4754601::u7.
free_NE :- u7, action(change_to_left).

0.5160395::u8.
free_NE :- u8, action(change_to_right).

0.7169122::u9.
free_NE :- u9, action(cruise).

0.0739122::u10.
free_NE :- u10, action(keep).

0.7586207::u11.
free_NE :- u11, action(swerve_left).

0.9130435::u12.
free_NE :- u12, action(swerve_right).

0.5150307::u13.
free_NW :- u13, action(change_to_left).

0.5462677::u14.
free_NW :- u14, action(change_to_right).

0.5238635::u15.
free_NW :- u15, action(cruise).

0.0300020::u16.
free_NW :- u16, action(keep).

0.9990010::u17.
free_NW :- u17, action(swerve_left).

0.6956522::u18.
free_NW :- u18, action(swerve_right).

0.4550879::u19.
free_SE :- u19, \+ curr_lane.

0.7285160::u20.
free_SE :- u20, curr_lane.

0.5343558::u21.
free_SW :- u21, action(change_to_left).

0.5817397::u22.
free_SW :- u22, action(change_to_right).

0.6106284::u23.
free_SW :- u23, action(cruise).

0.9765547::u24.
free_SW :- u24, action(keep).

0.9990010::u25.
free_SW :- u25, action(swerve_left).

0.9565217::u26.
free_SW :- u26, action(swerve_right).

0.6739868::u27.
latent_collision :- u27, \+ free_W.

0.2664608::u28.
latent_collision :- u28, free_W.

