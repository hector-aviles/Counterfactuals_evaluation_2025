%%% Exogenous variables

0.1688258::u_action(change_to_left); 0.1680578::u_action(change_to_right); 0.4080086::u_action(cruise); 0.2530596::u_action(keep); 0.0010241::u_action(swerve_left); 0.0010241::u_action(swerve_right)
action(V) :- u_action(V).

0.5334631::u1.
curr_lane :- u1.

0.7127349::u2.
free_W :- u2.

0.6193804::u3.
free_E :- u3, \+ curr_lane, \+ latent_collision.

0.9353916::u4.
free_E :- u4, curr_lane, \+ latent_collision.

0.4582133::u5.
free_E :- u5, \+ curr_lane, latent_collision.

0.5158814::u6.
free_E :- u6, curr_lane, latent_collision.

0.4913558::u7.
free_NE :- u7, action(change_to_left).

0.5033516::u8.
free_NE :- u8, action(change_to_right).

0.7117219::u9.
free_NE :- u9, action(cruise).

0.0700121::u10.
free_NE :- u10, action(keep).

0.9000000::u11.
free_NE :- u11, action(swerve_left).

0.9000000::u12.
free_NE :- u12, action(swerve_right).

0.5144070::u13.
free_NW :- u13, action(change_to_left).

0.5432663::u14.
free_NW :- u14, action(change_to_right).

0.5168173::u15.
free_NW :- u15, action(cruise).

0.0303521::u16.
free_NW :- u16, action(keep).

0.8500000::u17.
free_NW :- u17, action(swerve_left).

0.8500000::u18.
free_NW :- u18, action(swerve_right).

0.4556031::u19.
free_SE :- u19, \+ curr_lane.

0.7301785::u20.
free_SE :- u20, curr_lane.

0.5204732::u21.
free_SW :- u21, action(change_to_left).

0.5886654::u22.
free_SW :- u22, action(change_to_right).

0.6071787::u23.
free_SW :- u23, action(cruise).

0.9757183::u24.
free_SW :- u24, action(keep).

0.9000000::u25.
free_SW :- u25, action(swerve_left).

0.9990010::u26.
free_SW :- u26, action(swerve_right).

0.6793226::u27.
latent_collision :- u27, \+ free_W.

0.2718586::u28.
latent_collision :- u28, free_W.

