%%% Exogenous variables

0.1689556::u_action(change_to_left); 0.1661884::u_action(change_to_right); 0.4065799::u_action(cruise); 0.2555601::u_action(keep); 0.0016398::u_action(swerve_left); 0.0010762::u_action(swerve_right)
action(V) :- u_action(V).

0.5332582::u1.
curr_lane :- u1.

0.6845854::u2.
free_E :- u2.

0.7150251::u3.
free_W :- u3.

0.4584061::u4.
free_NE :- u4, action(change_to_left), \+ curr_lane.

0.4690096::u5.
free_NE :- u5, action(change_to_right), \+ curr_lane.

0.4759924::u6.
free_NE :- u6, action(cruise), \+ curr_lane.

0.1101668::u7.
free_NE :- u7, action(keep), \+ curr_lane.

0.9990010::u8.
free_NE :- u8, action(swerve_left), \+ curr_lane.

0.5000000::u9.
free_NE :- u9, action(swerve_right), \+ curr_lane.

0.4809886::u10.
free_NE :- u10, action(change_to_left), curr_lane.

0.5464839::u11.
free_NE :- u11, action(change_to_right), curr_lane.

0.8345623::u12.
free_NE :- u12, action(cruise), curr_lane.

0.0033149::u13.
free_NE :- u13, action(keep), curr_lane.

0.9333333::u14.
free_NE :- u14, action(swerve_left), curr_lane.

0.8571429::u15.
free_NE :- u15, action(swerve_right), curr_lane.

0.5250227::u16.
free_NW :- u16, action(change_to_left).

0.5488745::u17.
free_NW :- u17, action(change_to_right).

0.5253340::u18.
free_NW :- u18, action(cruise).

0.0288751::u19.
free_NW :- u19, action(keep).

0.9375000::u20.
free_NW :- u20, action(swerve_left).

0.8571429::u21.
free_NW :- u21, action(swerve_right).

0.4655248::u22.
free_SE :- u22, \+ curr_lane.

0.7319815::u23.
free_SE :- u23, curr_lane.

0.5298756::u24.
free_SW :- u24, action(change_to_left).

0.5784767::u25.
free_SW :- u25, action(change_to_right).

0.6087724::u26.
free_SW :- u26, action(cruise).

0.9735312::u27.
free_SW :- u27, action(keep).

0.9990010::u28.
free_SW :- u28, action(swerve_left).

0.9047619::u29.
free_SW :- u29, action(swerve_right).

0.9626216::u30.
latent_collision :- u30, \+ free_E, \+ free_W.

0.5097007::u31.
latent_collision :- u31, free_E, \+ free_W.

0.4443122::u32.
latent_collision :- u32, \+ free_E, free_W.

0.1952620::u33.
latent_collision :- u33, free_E, free_W.

