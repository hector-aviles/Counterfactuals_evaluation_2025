%%% Exogenous variables

0.1703905::u_action(change_to_left); 0.1677257::u_action(change_to_right); 0.4102696::u_action(cruise); 0.2499231::u_action(keep); 0.0010249::u_action(swerve_left); 0.0006662::u_action(swerve_right)
action(V) :- u_action(V).

0.5323870::u1.
curr_lane :- u1.

0.7170237::u2.
free_W :- u2.

0.5940649::u3.
free_E :- u3, \+ curr_lane, \+ latent_collision.

0.9328930::u4.
free_E :- u4, curr_lane, \+ latent_collision.

0.4637643::u5.
free_E :- u5, \+ curr_lane, latent_collision.

0.5284335::u6.
free_E :- u6, curr_lane, latent_collision.

0.5034586::u7.
free_NE :- u7, action(change_to_left).

0.5053468::u8.
free_NE :- u8, action(change_to_right).

0.7145891::u9.
free_NE :- u9, action(cruise).

0.0818126::u10.
free_NE :- u10, action(keep).

0.9000000::u11.
free_NE :- u11, action(swerve_left).

0.9990010::u12.
free_NE :- u12, action(swerve_right).

0.5218045::u13.
free_NW :- u13, action(change_to_left).

0.5334555::u14.
free_NW :- u14, action(change_to_right).

0.5282288::u15.
free_NW :- u15, action(cruise).

0.0311667::u16.
free_NW :- u16, action(keep).

0.9990010::u17.
free_NW :- u17, action(swerve_left).

0.6153846::u18.
free_NW :- u18, action(swerve_right).

0.4576438::u19.
free_SE :- u19, \+ curr_lane.

0.7298104::u20.
free_SE :- u20, curr_lane.

0.5034586::u21.
free_SW :- u21, action(change_to_left).

0.5783685::u22.
free_SW :- u22, action(change_to_right).

0.5994254::u23.
free_SW :- u23, action(cruise).

0.9700636::u24.
free_SW :- u24, action(keep).

0.9990010::u25.
free_SW :- u25, action(swerve_left).

0.9230769::u26.
free_SW :- u26, action(swerve_right).

0.6794640::u27.
latent_collision :- u27, \+ free_W.

0.2675100::u28.
latent_collision :- u28, free_W.

