%%% Exogenous variables

0.1692001::u_action(change_to_left); 0.1722197::u_action(change_to_right); 0.4058038::u_action(cruise); 0.2503199::u_action(keep); 0.0014842::u_action(swerve_left); 0.0009724::u_action(swerve_right)
action(V) :- u_action(V).

0.5350325::u1.
curr_lane :- u1.

0.7129331::u2.
free_W :- u2.

0.5992086::u3.
free_E :- u3, \+ curr_lane, \+ latent_collision.

0.9388897::u4.
free_E :- u4, curr_lane, \+ latent_collision.

0.4401800::u5.
free_E :- u5, \+ curr_lane, latent_collision.

0.5391621::u6.
free_E :- u6, curr_lane, latent_collision.

0.4945554::u7.
free_NE :- u7, action(change_to_left).

0.5001486::u8.
free_NE :- u8, action(change_to_right).

0.7135830::u9.
free_NE :- u9, action(cruise).

0.0723778::u10.
free_NE :- u10, action(keep).

0.7931034::u11.
free_NE :- u11, action(swerve_left).

0.8947368::u12.
free_NE :- u12, action(swerve_right).

0.4996975::u13.
free_NW :- u13, action(change_to_left).

0.5545319::u14.
free_NW :- u14, action(change_to_right).

0.5257914::u15.
free_NW :- u15, action(cruise).

0.0288285::u16.
free_NW :- u16, action(keep).

0.9990010::u17.
free_NW :- u17, action(swerve_left).

0.8421053::u18.
free_NW :- u18, action(swerve_right).

0.4540451::u19.
free_SE :- u19, \+ curr_lane.

0.7265162::u20.
free_SE :- u20, curr_lane.

0.5069570::u21.
free_SW :- u21, action(change_to_left).

0.5720654::u22.
free_SW :- u22, action(change_to_right).

0.6002018::u23.
free_SW :- u23, action(cruise).

0.9754651::u24.
free_SW :- u24, action(keep).

0.9990010::u25.
free_SW :- u25, action(swerve_left).

0.8421053::u26.
free_SW :- u26, action(swerve_right).

0.6817615::u27.
latent_collision :- u27, \+ free_W.

0.2725772::u28.
latent_collision :- u28, free_W.

