%%% Exogenous variables

0.1710917::u_action(change_to_left); 0.1698104::u_action(change_to_right); 0.4059969::u_action(cruise); 0.2507945::u_action(keep); 0.0015889::u_action(swerve_left); 0.0007176::u_action(swerve_right)
action(V) :- u_action(V).

0.5374167::u1.
curr_lane :- u1.

0.7109687::u2.
free_W :- u2.

0.6055680::u3.
free_E :- u3, \+ curr_lane, \+ latent_collision.

0.9364548::u4.
free_E :- u4, curr_lane, \+ latent_collision.

0.4530357::u5.
free_E :- u5, \+ curr_lane, latent_collision.

0.5305861::u6.
free_E :- u6, curr_lane, latent_collision.

0.4916117::u7.
free_NE :- u7, action(change_to_left).

0.5086025::u8.
free_NE :- u8, action(change_to_right).

0.7102639::u9.
free_NE :- u9, action(cruise).

0.0741876::u10.
free_NE :- u10, action(keep).

0.8387097::u11.
free_NE :- u11, action(swerve_left).

0.9990010::u12.
free_NE :- u12, action(swerve_right).

0.5035950::u13.
free_NW :- u13, action(change_to_left).

0.5384848::u14.
free_NW :- u14, action(change_to_right).

0.5397046::u15.
free_NW :- u15, action(cruise).

0.0306560::u16.
free_NW :- u16, action(keep).

0.9677419::u17.
free_NW :- u17, action(swerve_left).

0.7142857::u18.
free_NW :- u18, action(swerve_right).

0.4558449::u19.
free_SE :- u19, \+ curr_lane.

0.7247496::u20.
free_SE :- u20, curr_lane.

0.5161774::u21.
free_SW :- u21, action(change_to_left).

0.5777241::u22.
free_SW :- u22, action(change_to_right).

0.5972731::u23.
free_SW :- u23, action(cruise).

0.9777233::u24.
free_SW :- u24, action(keep).

0.9677419::u25.
free_SW :- u25, action(swerve_left).

0.9285714::u26.
free_SW :- u26, action(swerve_right).

0.6900160::u27.
latent_collision :- u27, \+ free_W.

0.2659505::u28.
latent_collision :- u28, free_W.

