%%% Exogenous variables

0.1669058::u_action(change_to_left); 0.1696218::u_action(change_to_right); 0.4039151::u_action(cruise); 0.2572512::u_action(keep); 0.0011786::u_action(swerve_left); 0.0011274::u_action(swerve_right)
action(V) :- u_action(V).

0.5360254::u1.
curr_lane :- u1.

0.7121041::u2.
free_W :- u2.

0.6042553::u3.
free_E :- u3, \+ curr_lane, \+ latent_collision.

0.9351949::u4.
free_E :- u4, curr_lane, \+ latent_collision.

0.4362839::u5.
free_E :- u5, \+ curr_lane, latent_collision.

0.5458411::u6.
free_E :- u6, curr_lane, latent_collision.

0.5121277::u7.
free_NE :- u7, action(change_to_left).

0.5163142::u8.
free_NE :- u8, action(change_to_right).

0.7170769::u9.
free_NE :- u9, action(cruise).

0.0671315::u10.
free_NE :- u10, action(keep).

0.9565217::u11.
free_NE :- u11, action(swerve_left).

0.7272727::u12.
free_NE :- u12, action(swerve_right).

0.4906356::u13.
free_NW :- u13, action(change_to_left).

0.5456193::u14.
free_NW :- u14, action(change_to_right).

0.5338747::u15.
free_NW :- u15, action(cruise).

0.0296813::u16.
free_NW :- u16, action(keep).

0.9565217::u17.
free_NW :- u17, action(swerve_left).

0.7727273::u18.
free_NW :- u18, action(swerve_right).

0.4509609::u19.
free_SE :- u19, \+ curr_lane.

0.7263862::u20.
free_SE :- u20, curr_lane.

0.5333129::u21.
free_SW :- u21, action(change_to_left).

0.5833837::u22.
free_SW :- u22, action(change_to_right).

0.6022583::u23.
free_SW :- u23, action(cruise).

0.9733068::u24.
free_SW :- u24, action(keep).

0.9990010::u25.
free_SW :- u25, action(swerve_left).

0.9545455::u26.
free_SW :- u26, action(swerve_right).

0.6607334::u27.
latent_collision :- u27, \+ free_W.

0.2662637::u28.
latent_collision :- u28, free_W.

