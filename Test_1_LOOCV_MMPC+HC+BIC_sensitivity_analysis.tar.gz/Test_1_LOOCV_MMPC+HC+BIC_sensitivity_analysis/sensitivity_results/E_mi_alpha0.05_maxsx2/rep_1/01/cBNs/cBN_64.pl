%%% Exogenous variables

0.1723410::u_action(change_to_left); 0.1706928::u_action(change_to_right); 0.4033994::u_action(cruise); 0.2507340::u_action(keep); 0.0019572::u_action(swerve_left); 0.0008756::u_action(swerve_right)
action(V) :- u_action(V).

0.5365954::u1.
curr_lane :- u1.

0.7088849::u2.
free_W :- u2.

0.6235654::u3.
free_E :- u3, \+ curr_lane, \+ latent_collision.

0.9330384::u4.
free_E :- u4, curr_lane, \+ latent_collision.

0.4521093::u5.
free_E :- u5, \+ curr_lane, latent_collision.

0.5313309::u6.
free_E :- u6, curr_lane, latent_collision.

0.4736999::u7.
free_NE :- u7, action(change_to_left).

0.5048280::u8.
free_NE :- u8, action(change_to_right).

0.7023749::u9.
free_NE :- u9, action(cruise).

0.0542317::u10.
free_NE :- u10, action(keep).

0.8684211::u11.
free_NE :- u11, action(swerve_left).

0.8823529::u12.
free_NE :- u12, action(swerve_right).

0.5179319::u13.
free_NW :- u13, action(change_to_left).

0.5392275::u14.
free_NW :- u14, action(change_to_right).

0.5286006::u15.
free_NW :- u15, action(cruise).

0.0320460::u16.
free_NW :- u16, action(keep).

0.9990010::u17.
free_NW :- u17, action(swerve_left).

0.8235294::u18.
free_NW :- u18, action(swerve_right).

0.4483717::u19.
free_SE :- u19, \+ curr_lane.

0.7249952::u20.
free_SE :- u20, curr_lane.

0.5083682::u21.
free_SW :- u21, action(change_to_left).

0.5630658::u22.
free_SW :- u22, action(change_to_right).

0.6026558::u23.
free_SW :- u23, action(cruise).

0.9749384::u24.
free_SW :- u24, action(keep).

0.9990010::u25.
free_SW :- u25, action(swerve_left).

0.8823529::u26.
free_SW :- u26, action(swerve_right).

0.6896674::u27.
latent_collision :- u27, \+ free_W.

0.2712345::u28.
latent_collision :- u28, free_W.

