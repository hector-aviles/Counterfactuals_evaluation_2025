%%% Exogenous variables

0.1646962::u_action(change_to_left); 0.1678182::u_action(change_to_right); 0.4108706::u_action(cruise); 0.2542607::u_action(keep); 0.0013307::u_action(swerve_left); 0.0010236::u_action(swerve_right)
action(V) :- u_action(V).

0.5377450::u1.
curr_lane :- u1.

0.7155433::u2.
free_W :- u2.

0.6034127::u3.
free_E :- u3, \+ curr_lane, \+ latent_collision.

0.9408002::u4.
free_E :- u4, curr_lane, \+ latent_collision.

0.4571506::u5.
free_E :- u5, \+ curr_lane, latent_collision.

0.5322410::u6.
free_E :- u6, curr_lane, latent_collision.

0.4673710::u7.
free_NE :- u7, action(change_to_left).

0.5065569::u8.
free_NE :- u8, action(change_to_right).

0.7212257::u9.
free_NE :- u9, action(cruise).

0.0684380::u10.
free_NE :- u10, action(keep).

0.8846154::u11.
free_NE :- u11, action(swerve_left).

0.8500000::u12.
free_NE :- u12, action(swerve_right).

0.5024860::u13.
free_NW :- u13, action(change_to_left).

0.5330894::u14.
free_NW :- u14, action(change_to_right).

0.5174390::u15.
free_NW :- u15, action(cruise).

0.0320048::u16.
free_NW :- u16, action(keep).

0.9990010::u17.
free_NW :- u17, action(swerve_left).

0.8000000::u18.
free_NW :- u18, action(swerve_right).

0.4496236::u19.
free_SE :- u19, \+ curr_lane.

0.7261825::u20.
free_SE :- u20, curr_lane.

0.5270354::u21.
free_SW :- u21, action(change_to_left).

0.5806648::u22.
free_SW :- u22, action(change_to_right).

0.5996512::u23.
free_SW :- u23, action(cruise).

0.9766506::u24.
free_SW :- u24, action(keep).

0.9990010::u25.
free_SW :- u25, action(swerve_left).

0.9990010::u26.
free_SW :- u26, action(swerve_right).

0.6756027::u27.
latent_collision :- u27, \+ free_W.

0.2666476::u28.
latent_collision :- u28, free_W.

