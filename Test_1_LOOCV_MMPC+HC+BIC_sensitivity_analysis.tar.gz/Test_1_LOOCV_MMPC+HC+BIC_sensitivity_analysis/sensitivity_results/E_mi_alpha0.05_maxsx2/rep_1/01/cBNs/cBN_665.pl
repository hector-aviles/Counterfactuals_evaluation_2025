%%% Exogenous variables

0.1693594::u_action(change_to_left); 0.1680259::u_action(change_to_right); 0.4085244::u_action(cruise); 0.2515259::u_action(keep); 0.0016926::u_action(swerve_left); 0.0008719::u_action(swerve_right)
action(V) :- u_action(V).

0.5233626::u1.
curr_lane :- u1.

0.7170847::u2.
free_W :- u2.

0.6089850::u3.
free_E :- u3, \+ curr_lane, \+ latent_collision.

0.9363525::u4.
free_E :- u4, curr_lane, \+ latent_collision.

0.4456746::u5.
free_E :- u5, \+ curr_lane, latent_collision.

0.5338059::u6.
free_E :- u6, curr_lane, latent_collision.

0.5124167::u7.
free_NE :- u7, action(change_to_left).

0.5238095::u8.
free_NE :- u8, action(change_to_right).

0.7219083::u9.
free_NE :- u9, action(cruise).

0.0730016::u10.
free_NE :- u10, action(keep).

0.7575758::u11.
free_NE :- u11, action(swerve_left).

0.7647059::u12.
free_NE :- u12, action(swerve_right).

0.5042399::u13.
free_NW :- u13, action(change_to_left).

0.5509768::u14.
free_NW :- u14, action(change_to_right).

0.5345888::u15.
free_NW :- u15, action(cruise).

0.0314029::u16.
free_NW :- u16, action(keep).

0.9393939::u17.
free_NW :- u17, action(swerve_left).

0.8235294::u18.
free_NW :- u18, action(swerve_right).

0.4606693::u19.
free_SE :- u19, \+ curr_lane.

0.7253038::u20.
free_SE :- u20, curr_lane.

0.5039370::u21.
free_SW :- u21, action(change_to_left).

0.5674603::u22.
free_SW :- u22, action(change_to_right).

0.6001255::u23.
free_SW :- u23, action(cruise).

0.9751223::u24.
free_SW :- u24, action(keep).

0.9696970::u25.
free_SW :- u25, action(swerve_left).

0.9411765::u26.
free_SW :- u26, action(swerve_right).

0.6841914::u27.
latent_collision :- u27, \+ free_W.

0.2702239::u28.
latent_collision :- u28, free_W.

