%%% Exogenous variables

0.1680827::u_action(change_to_left); 0.1691575::u_action(change_to_right); 0.4082301::u_action(cruise); 0.2525335::u_action(keep); 0.0013307::u_action(swerve_left); 0.0006654::u_action(swerve_right)
action(V) :- u_action(V).

0.5343945::u1.
curr_lane :- u1.

0.7102569::u2.
free_W :- u2.

0.6134251::u3.
free_E :- u3, \+ curr_lane, \+ latent_collision.

0.9411052::u4.
free_E :- u4, curr_lane, \+ latent_collision.

0.4339876::u5.
free_E :- u5, \+ curr_lane, latent_collision.

0.5315433::u6.
free_E :- u6, curr_lane, latent_collision.

0.4923873::u7.
free_NE :- u7, action(change_to_left).

0.5210287::u8.
free_NE :- u8, action(change_to_right).

0.7117603::u9.
free_NE :- u9, action(cruise).

0.0747872::u10.
free_NE :- u10, action(keep).

0.9230769::u11.
free_NE :- u11, action(swerve_left).

0.7692308::u12.
free_NE :- u12, action(swerve_right).

0.5033496::u13.
free_NW :- u13, action(change_to_left).

0.5440242::u14.
free_NW :- u14, action(change_to_right).

0.5332247::u15.
free_NW :- u15, action(cruise).

0.0304013::u16.
free_NW :- u16, action(keep).

0.9990010::u17.
free_NW :- u17, action(swerve_left).

0.9230769::u18.
free_NW :- u18, action(swerve_right).

0.4598219::u19.
free_SE :- u19, \+ curr_lane.

0.7208122::u20.
free_SE :- u20, curr_lane.

0.5066991::u21.
free_SW :- u21, action(change_to_left).

0.5866868::u22.
free_SW :- u22, action(change_to_right).

0.6030592::u23.
free_SW :- u23, action(cruise).

0.9756790::u24.
free_SW :- u24, action(keep).

0.9990010::u25.
free_SW :- u25, action(swerve_left).

0.9990010::u26.
free_SW :- u26, action(swerve_right).

0.6733793::u27.
latent_collision :- u27, \+ free_W.

0.2697269::u28.
latent_collision :- u28, free_W.

