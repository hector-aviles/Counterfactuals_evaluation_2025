%%% Exogenous variables

0.1655663::u_action(change_to_left); 0.1690977::u_action(change_to_right); 0.4129178::u_action(cruise); 0.2503199::u_action(keep); 0.0012283::u_action(swerve_left); 0.0008701::u_action(swerve_right)
action(V) :- u_action(V).

0.5404064::u1.
curr_lane :- u1.

0.7088387::u2.
free_W :- u2.

0.6104312::u3.
free_E :- u3, \+ curr_lane, \+ latent_collision.

0.9396396::u4.
free_E :- u4, curr_lane, \+ latent_collision.

0.4516217::u5.
free_E :- u5, \+ curr_lane, latent_collision.

0.5147474::u6.
free_E :- u6, curr_lane, latent_collision.

0.4927357::u7.
free_NE :- u7, action(change_to_left).

0.5118039::u8.
free_NE :- u8, action(change_to_right).

0.7090977::u9.
free_NE :- u9, action(cruise).

0.0680842::u10.
free_NE :- u10, action(keep).

0.9166667::u11.
free_NE :- u11, action(swerve_left).

0.8235294::u12.
free_NE :- u12, action(swerve_right).

0.5069552::u13.
free_NW :- u13, action(change_to_left).

0.5375303::u14.
free_NW :- u14, action(change_to_right).

0.5327219::u15.
free_NW :- u15, action(cruise).

0.0280106::u16.
free_NW :- u16, action(keep).

0.9990010::u17.
free_NW :- u17, action(swerve_left).

0.5882353::u18.
free_NW :- u18, action(swerve_right).

0.4451002::u19.
free_SE :- u19, \+ curr_lane.

0.7201440::u20.
free_SE :- u20, curr_lane.

0.5094281::u21.
free_SW :- u21, action(change_to_left).

0.5674939::u22.
free_SW :- u22, action(change_to_right).

0.6002727::u23.
free_SW :- u23, action(cruise).

0.9775097::u24.
free_SW :- u24, action(keep).

0.9990010::u25.
free_SW :- u25, action(swerve_left).

0.8823529::u26.
free_SW :- u26, action(swerve_right).

0.6674284::u27.
latent_collision :- u27, \+ free_W.

0.2722744::u28.
latent_collision :- u28, free_W.

