%%% Exogenous variables

0.1683315::u_action(change_to_left); 0.1667435::u_action(change_to_right); 0.4084832::u_action(cruise); 0.2538804::u_action(keep); 0.0017417::u_action(swerve_left); 0.0008196::u_action(swerve_right)
action(V) :- u_action(V).

0.5371139::u1.
curr_lane :- u1.

0.7102607::u2.
free_W :- u2.

0.6117779::u3.
free_E :- u3, \+ curr_lane, \+ latent_collision.

0.9356325::u4.
free_E :- u4, curr_lane, \+ latent_collision.

0.4565335::u5.
free_E :- u5, \+ curr_lane, latent_collision.

0.5255455::u6.
free_E :- u6, curr_lane, latent_collision.

0.5015216::u7.
free_NE :- u7, action(change_to_left).

0.5256528::u8.
free_NE :- u8, action(change_to_right).

0.7100577::u9.
free_NE :- u9, action(cruise).

0.0694108::u10.
free_NE :- u10, action(keep).

0.9117647::u11.
free_NE :- u11, action(swerve_left).

0.8750000::u12.
free_NE :- u12, action(swerve_right).

0.5170420::u13.
free_NW :- u13, action(change_to_left).

0.5385561::u14.
free_NW :- u14, action(change_to_right).

0.5229496::u15.
free_NW :- u15, action(cruise).

0.0288539::u16.
free_NW :- u16, action(keep).

0.9990010::u17.
free_NW :- u17, action(swerve_left).

0.6875000::u18.
free_NW :- u18, action(swerve_right).

0.4644754::u19.
free_SE :- u19, \+ curr_lane.

0.7234144::u20.
free_SE :- u20, curr_lane.

0.5085210::u21.
free_SW :- u21, action(change_to_left).

0.5932412::u22.
free_SW :- u22, action(change_to_right).

0.6078505::u23.
free_SW :- u23, action(cruise).

0.9747780::u24.
free_SW :- u24, action(keep).

0.9705882::u25.
free_SW :- u25, action(swerve_left).

0.9375000::u26.
free_SW :- u26, action(swerve_right).

0.6787482::u27.
latent_collision :- u27, \+ free_W.

0.2613054::u28.
latent_collision :- u28, free_W.

