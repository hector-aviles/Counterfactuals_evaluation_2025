%%% Exogenous variables

0.1684384::u_action(change_to_left); 0.1700817::u_action(change_to_right); 0.4052791::u_action(cruise); 0.2529143::u_action(keep); 0.0022082::u_action(swerve_left); 0.0010784::u_action(swerve_right)
action(V) :- u_action(V).

0.5353566::u1.
curr_lane :- u1.

0.6790941::u2.
free_E :- u2.

0.7121142::u3.
free_W :- u3.

0.4830508::u4.
free_NE :- u4, action(change_to_left), \+ curr_lane.

0.4846743::u5.
free_NE :- u5, action(change_to_right), \+ curr_lane.

0.4792766::u6.
free_NE :- u6, action(cruise), \+ curr_lane.

0.1206189::u7.
free_NE :- u7, action(keep), \+ curr_lane.

0.6666667::u8.
free_NE :- u8, action(swerve_left), \+ curr_lane.

0.5000000::u9.
free_NE :- u9, action(swerve_right), \+ curr_lane.

0.5049140::u10.
free_NE :- u10, action(change_to_left), curr_lane.

0.5486827::u11.
free_NE :- u11, action(change_to_right), curr_lane.

0.8318060::u12.
free_NE :- u12, action(cruise), curr_lane.

0.0039818::u13.
free_NE :- u13, action(keep), curr_lane.

0.8529412::u14.
free_NE :- u14, action(swerve_left), curr_lane.

0.8095238::u15.
free_NE :- u15, action(swerve_right), curr_lane.

0.5012195::u16.
free_NW :- u16, action(change_to_left).

0.5443841::u17.
free_NW :- u17, action(change_to_right).

0.5295236::u18.
free_NW :- u18, action(cruise).

0.0316751::u19.
free_NW :- u19, action(keep).

0.9534884::u20.
free_NW :- u20, action(swerve_left).

0.7142857::u21.
free_NW :- u21, action(swerve_right).

0.4528073::u22.
free_SE :- u22, \+ curr_lane.

0.7193285::u23.
free_SE :- u23, curr_lane.

0.5277439::u24.
free_SW :- u24, action(change_to_left).

0.5733696::u25.
free_SW :- u25, action(change_to_right).

0.5997212::u26.
free_SW :- u26, action(cruise).

0.9782741::u27.
free_SW :- u27, action(keep).

0.9767442::u28.
free_SW :- u28, action(swerve_left).

0.8095238::u29.
free_SW :- u29, action(swerve_right).

0.9694431::u30.
latent_collision :- u30, \+ free_E, \+ free_W.

0.5239027::u31.
latent_collision :- u31, free_E, \+ free_W.

0.4331754::u32.
latent_collision :- u32, \+ free_E, free_W.

0.1976780::u33.
latent_collision :- u33, free_E, free_W.

