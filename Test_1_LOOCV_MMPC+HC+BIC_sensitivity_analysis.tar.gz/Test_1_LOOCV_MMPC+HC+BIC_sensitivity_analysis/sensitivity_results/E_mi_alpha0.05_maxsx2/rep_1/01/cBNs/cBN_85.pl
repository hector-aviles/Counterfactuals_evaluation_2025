%%% Exogenous variables

0.1684518::u_action(change_to_left); 0.1652744::u_action(change_to_right); 0.4095731::u_action(cruise); 0.2538820::u_action(keep); 0.0017937::u_action(swerve_left); 0.0010250::u_action(swerve_right)
action(V) :- u_action(V).

0.5345155::u1.
curr_lane :- u1.

0.7108082::u2.
free_W :- u2.

0.6079703::u3.
free_E :- u3, \+ curr_lane, \+ latent_collision.

0.9341489::u4.
free_E :- u4, curr_lane, \+ latent_collision.

0.4441432::u5.
free_E :- u5, \+ curr_lane, latent_collision.

0.5379365::u6.
free_E :- u6, curr_lane, latent_collision.

0.4867660::u7.
free_NE :- u7, action(change_to_left).

0.5165891::u8.
free_NE :- u8, action(change_to_right).

0.7059560::u9.
free_NE :- u9, action(cruise).

0.0700444::u10.
free_NE :- u10, action(keep).

0.9428571::u11.
free_NE :- u11, action(swerve_left).

0.9000000::u12.
free_NE :- u12, action(swerve_right).

0.5159720::u13.
free_NW :- u13, action(change_to_left).

0.5469767::u14.
free_NW :- u14, action(change_to_right).

0.5267768::u15.
free_NW :- u15, action(cruise).

0.0316916::u16.
free_NW :- u16, action(keep).

0.9990010::u17.
free_NW :- u17, action(swerve_left).

0.8000000::u18.
free_NW :- u18, action(swerve_right).

0.4551360::u19.
free_SE :- u19, \+ curr_lane.

0.7160115::u20.
free_SE :- u20, curr_lane.

0.5217524::u21.
free_SW :- u21, action(change_to_left).

0.5655814::u22.
free_SW :- u22, action(change_to_right).

0.6021021::u23.
free_SW :- u23, action(cruise).

0.9743642::u24.
free_SW :- u24, action(keep).

0.9714286::u25.
free_SW :- u25, action(swerve_left).

0.8000000::u26.
free_SW :- u26, action(swerve_right).

0.6852738::u27.
latent_collision :- u27, \+ free_W.

0.2617159::u28.
latent_collision :- u28, free_W.

