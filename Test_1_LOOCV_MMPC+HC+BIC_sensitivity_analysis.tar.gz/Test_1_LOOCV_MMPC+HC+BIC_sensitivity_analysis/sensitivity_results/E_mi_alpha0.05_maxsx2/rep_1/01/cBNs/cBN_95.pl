%%% Exogenous variables

0.1675208::u_action(change_to_left); 0.1710054::u_action(change_to_right); 0.4031977::u_action(cruise); 0.2558163::u_action(keep); 0.0017423::u_action(swerve_left); 0.0007174::u_action(swerve_right)
action(V) :- u_action(V).

0.5238290::u1.
curr_lane :- u1.

0.7136927::u2.
free_W :- u2.

0.6083712::u3.
free_E :- u3, \+ curr_lane, \+ latent_collision.

0.9379449::u4.
free_E :- u4, curr_lane, \+ latent_collision.

0.4421912::u5.
free_E :- u5, \+ curr_lane, latent_collision.

0.5276596::u6.
free_E :- u6, curr_lane, latent_collision.

0.4866932::u7.
free_NE :- u7, action(change_to_left).

0.5085406::u8.
free_NE :- u8, action(change_to_right).

0.7114896::u9.
free_NE :- u9, action(cruise).

0.0763221::u10.
free_NE :- u10, action(keep).

0.8823529::u11.
free_NE :- u11, action(swerve_left).

0.8571429::u12.
free_NE :- u12, action(swerve_right).

0.5218721::u13.
free_NW :- u13, action(change_to_left).

0.5501948::u14.
free_NW :- u14, action(change_to_right).

0.5285968::u15.
free_NW :- u15, action(cruise).

0.0294471::u16.
free_NW :- u16, action(keep).

0.9705882::u17.
free_NW :- u17, action(swerve_left).

0.8571429::u18.
free_NW :- u18, action(swerve_right).

0.4474817::u19.
free_SE :- u19, \+ curr_lane.

0.7153199::u20.
free_SE :- u20, curr_lane.

0.5148363::u21.
free_SW :- u21, action(change_to_left).

0.5894516::u22.
free_SW :- u22, action(change_to_right).

0.6042196::u23.
free_SW :- u23, action(cruise).

0.9737580::u24.
free_SW :- u24, action(keep).

0.9990010::u25.
free_SW :- u25, action(swerve_left).

0.9285714::u26.
free_SW :- u26, action(swerve_right).

0.6839091::u27.
latent_collision :- u27, \+ free_W.

0.2682559::u28.
latent_collision :- u28, free_W.

