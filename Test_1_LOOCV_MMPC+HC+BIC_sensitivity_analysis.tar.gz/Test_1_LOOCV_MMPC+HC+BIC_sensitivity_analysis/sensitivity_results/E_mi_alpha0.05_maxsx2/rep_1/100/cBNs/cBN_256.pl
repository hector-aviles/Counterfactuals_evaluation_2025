%%% Exogenous variables

0.1682637::u_action(change_to_left); 0.1704444::u_action(change_to_right); 0.4059096::u_action(cruise); 0.2530366::u_action(keep); 0.0014819::u_action(swerve_left); 0.0008637::u_action(swerve_right)
action(V) :- u_action(V).

0.3987767::u1.
free_NW :- u1.

0.5948354::u2.
free_SE :- u2.

0.6777225::u3.
free_SW :- u3.

0.7176588::u4.
free_W :- u4.

0.3859392::u5.
latent_collision :- u5.

0.4895426::u6.
curr_lane :- u6, action(change_to_left).

0.5082134::u7.
curr_lane :- u7, action(change_to_right).

0.6534333::u8.
curr_lane :- u8, action(cruise).

0.3612256::u9.
curr_lane :- u9, action(keep).

0.8172677::u10.
curr_lane :- u10, action(swerve_left).

0.9928614::u11.
curr_lane :- u11, action(swerve_right).

0.5121620::u12.
free_E :- u12, action(change_to_left), \+ curr_lane.

0.4971955::u13.
free_E :- u13, action(change_to_right), \+ curr_lane.

0.5372419::u14.
free_E :- u14, action(cruise), \+ curr_lane.

0.5936986::u15.
free_E :- u15, action(keep), \+ curr_lane.

0.8140417::u16.
free_E :- u16, action(swerve_left), \+ curr_lane.

0.9990010::u17.
free_E :- u17, action(swerve_right), \+ curr_lane.

0.5464004::u18.
free_E :- u18, action(change_to_left), curr_lane.

0.5232291::u19.
free_E :- u19, action(change_to_right), curr_lane.

0.8998109::u20.
free_E :- u20, action(cruise), curr_lane.

0.8983231::u21.
free_E :- u21, action(keep), curr_lane.

0.9809079::u22.
free_E :- u22, action(swerve_left), curr_lane.

0.9958059::u23.
free_E :- u23, action(swerve_right), curr_lane.

0.4931757::u24.
free_NE :- u24, action(change_to_left), \+ curr_lane, \+ free_E.

0.5109236::u25.
free_NE :- u25, action(change_to_right), \+ curr_lane, \+ free_E.

0.5318763::u26.
free_NE :- u26, action(cruise), \+ curr_lane, \+ free_E.

0.2609284::u27.
free_NE :- u27, action(keep), \+ curr_lane, \+ free_E.

0.4285714::u28.
free_NE :- u28, action(swerve_left), \+ curr_lane, \+ free_E.

0.5000000::u29.
free_NE :- u29, action(swerve_right), \+ curr_lane, \+ free_E.

0.4998969::u30.
free_NE :- u30, action(change_to_left), curr_lane, \+ free_E.

0.5020715::u31.
free_NE :- u31, action(change_to_right), curr_lane, \+ free_E.

0.2250711::u32.
free_NE :- u32, action(cruise), curr_lane, \+ free_E.

0.0002764::u33.
free_NE :- u33, action(keep), curr_lane, \+ free_E.

0.0444444::u34.
free_NE :- u34, action(swerve_left), curr_lane, \+ free_E.

0.4285714::u35.
free_NE :- u35, action(swerve_right), curr_lane, \+ free_E.

0.4740518::u36.
free_NE :- u36, action(change_to_left), \+ curr_lane, free_E.

0.4908580::u37.
free_NE :- u37, action(change_to_right), \+ curr_lane, free_E.

0.4392358::u38.
free_NE :- u38, action(cruise), \+ curr_lane, free_E.

0.0122833::u39.
free_NE :- u39, action(keep), \+ curr_lane, free_E.

0.8135198::u40.
free_NE :- u40, action(swerve_left), \+ curr_lane, free_E.

0.9990010::u41.
free_NE :- u41, action(swerve_right), \+ curr_lane, free_E.

0.5035505::u42.
free_NE :- u42, action(change_to_left), curr_lane, free_E.

0.5684923::u43.
free_NE :- u43, action(change_to_right), curr_lane, free_E.

0.9076854::u44.
free_NE :- u44, action(cruise), curr_lane, free_E.

0.0046683::u45.
free_NE :- u45, action(keep), curr_lane, free_E.

0.9044118::u46.
free_NE :- u46, action(swerve_left), curr_lane, free_E.

0.8567990::u47.
free_NE :- u47, action(swerve_right), curr_lane, free_E.

