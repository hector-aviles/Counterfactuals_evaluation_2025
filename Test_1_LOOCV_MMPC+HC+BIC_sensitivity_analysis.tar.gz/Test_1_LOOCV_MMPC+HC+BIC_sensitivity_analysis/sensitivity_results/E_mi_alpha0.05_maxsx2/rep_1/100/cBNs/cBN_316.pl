%%% Exogenous variables

0.1702068::u_action(change_to_left); 0.1719617::u_action(change_to_right); 0.4102063::u_action(cruise); 0.2452530::u_action(keep); 0.0014983::u_action(swerve_left); 0.0008739::u_action(swerve_right)
action(V) :- u_action(V).

0.4097969::u1.
free_NW :- u1.

0.6080313::u2.
free_SE :- u2.

0.6741448::u3.
free_SW :- u3.

0.7079310::u4.
free_W :- u4.

0.3897170::u5.
latent_collision :- u5.

0.4680429::u6.
curr_lane :- u6, action(change_to_left), \+ free_E, \+ free_NE.

0.4994135::u7.
curr_lane :- u7, action(change_to_right), \+ free_E, \+ free_NE.

0.4032540::u8.
curr_lane :- u8, action(cruise), \+ free_E, \+ free_NE.

0.1606675::u9.
curr_lane :- u9, action(keep), \+ free_E, \+ free_NE.

0.4343434::u10.
curr_lane :- u10, action(swerve_left), \+ free_E, \+ free_NE.

0.9990010::u11.
curr_lane :- u11, action(swerve_right), \+ free_E, \+ free_NE.

0.5060446::u12.
curr_lane :- u12, action(change_to_left), free_E, \+ free_NE.

0.4958738::u13.
curr_lane :- u13, action(change_to_right), free_E, \+ free_NE.

0.3593538::u14.
curr_lane :- u14, action(cruise), free_E, \+ free_NE.

0.4693575::u15.
curr_lane :- u15, action(keep), free_E, \+ free_NE.

0.7342193::u16.
curr_lane :- u16, action(swerve_left), free_E, \+ free_NE.

0.9990010::u17.
curr_lane :- u17, action(swerve_right), free_E, \+ free_NE.

0.4907787::u18.
curr_lane :- u18, action(change_to_left), \+ free_E, free_NE.

0.5109201::u19.
curr_lane :- u19, action(change_to_right), \+ free_E, free_NE.

0.1547029::u20.
curr_lane :- u20, action(cruise), \+ free_E, free_NE.

0.0005643::u21.
curr_lane :- u21, action(keep), \+ free_E, free_NE.

0.0454545::u22.
curr_lane :- u22, action(swerve_left), \+ free_E, free_NE.

0.9990010::u23.
curr_lane :- u23, action(swerve_right), \+ free_E, free_NE.

0.5207925::u24.
curr_lane :- u24, action(change_to_left), free_E, free_NE.

0.5574206::u25.
curr_lane :- u25, action(change_to_right), free_E, free_NE.

0.8671226::u26.
curr_lane :- u26, action(cruise), free_E, free_NE.

0.2453947::u27.
curr_lane :- u27, action(keep), free_E, free_NE.

0.8569672::u28.
curr_lane :- u28, action(swerve_left), free_E, free_NE.

0.9916435::u29.
curr_lane :- u29, action(swerve_right), free_E, free_NE.

0.5367564::u30.
free_E :- u30, action(change_to_left).

0.5192692::u31.
free_E :- u31, action(change_to_right).

0.7788353::u32.
free_E :- u32, action(cruise).

0.7428241::u33.
free_E :- u33, action(keep).

0.9504161::u34.
free_E :- u34, action(swerve_left).

0.9958383::u35.
free_E :- u35, action(swerve_right).

0.4880408::u36.
free_NE :- u36, action(change_to_left), \+ free_E.

0.4963769::u37.
free_NE :- u37, action(change_to_right), \+ free_E.

0.4308719::u38.
free_NE :- u38, action(cruise), \+ free_E.

0.0729877::u39.
free_NE :- u39, action(keep), \+ free_E.

0.3076923::u40.
free_NE :- u40, action(swerve_left), \+ free_E.

0.4285714::u41.
free_NE :- u41, action(swerve_right), \+ free_E.

0.4816264::u42.
free_NE :- u42, action(change_to_left), free_E.

0.5233978::u43.
free_NE :- u43, action(change_to_right), free_E.

0.7906398::u44.
free_NE :- u44, action(cruise), free_E.

0.0086693::u45.
free_NE :- u45, action(keep), free_E.

0.8901861::u46.
free_NE :- u46, action(swerve_left), free_E.

0.8573134::u47.
free_NE :- u47, action(swerve_right), free_E.

