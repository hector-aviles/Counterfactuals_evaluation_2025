%%% Exogenous variables

0.1678974::u_action(change_to_left); 0.1700569::u_action(change_to_right); 0.4053598::u_action(cruise); 0.2543454::u_action(keep); 0.0014783::u_action(swerve_left); 0.0008621::u_action(swerve_right)
action(V) :- u_action(V).

0.4043065::u1.
free_NW :- u1.

0.5958262::u2.
free_SE :- u2.

0.6825680::u3.
free_SW :- u3.

0.7118449::u4.
free_W :- u4.

0.3855142::u5.
latent_collision :- u5.

0.4974753::u6.
curr_lane :- u6, action(change_to_left).

0.5158316::u7.
curr_lane :- u7, action(change_to_right).

0.6569993::u8.
curr_lane :- u8, action(cruise).

0.3667576::u9.
curr_lane :- u9, action(keep).

0.8172677::u10.
curr_lane :- u10, action(swerve_left).

0.9928656::u11.
curr_lane :- u11, action(swerve_right).

0.5201055::u12.
free_E :- u12, action(change_to_left), \+ curr_lane.

0.5049367::u13.
free_E :- u13, action(change_to_right), \+ curr_lane.

0.5422365::u14.
free_E :- u14, action(cruise), \+ curr_lane.

0.5943416::u15.
free_E :- u15, action(keep), \+ curr_lane.

0.8140417::u16.
free_E :- u16, action(swerve_left), \+ curr_lane.

0.9990010::u17.
free_E :- u17, action(swerve_right), \+ curr_lane.

0.5537548::u18.
free_E :- u18, action(change_to_left), curr_lane.

0.5303525::u19.
free_E :- u19, action(change_to_right), curr_lane.

0.9004638::u20.
free_E :- u20, action(cruise), curr_lane.

0.9006160::u21.
free_E :- u21, action(keep), curr_lane.

0.9809079::u22.
free_E :- u22, action(swerve_left), curr_lane.

0.9958084::u23.
free_E :- u23, action(swerve_right), curr_lane.

0.5091146::u24.
free_NE :- u24, action(change_to_left), \+ curr_lane, \+ free_E.

0.5269856::u25.
free_NE :- u25, action(change_to_right), \+ curr_lane, \+ free_E.

0.5426666::u26.
free_NE :- u26, action(cruise), \+ curr_lane, \+ free_E.

0.2616186::u27.
free_NE :- u27, action(keep), \+ curr_lane, \+ free_E.

0.4285714::u28.
free_NE :- u28, action(swerve_left), \+ curr_lane, \+ free_E.

0.5000000::u29.
free_NE :- u29, action(swerve_right), \+ curr_lane, \+ free_E.

0.4998969::u30.
free_NE :- u30, action(change_to_left), curr_lane, \+ free_E.

0.5020715::u31.
free_NE :- u31, action(change_to_right), curr_lane, \+ free_E.

0.2250711::u32.
free_NE :- u32, action(cruise), curr_lane, \+ free_E.

0.0002764::u33.
free_NE :- u33, action(keep), curr_lane, \+ free_E.

0.0444444::u34.
free_NE :- u34, action(swerve_left), curr_lane, \+ free_E.

0.4285714::u35.
free_NE :- u35, action(swerve_right), curr_lane, \+ free_E.

0.4740635::u36.
free_NE :- u36, action(change_to_left), \+ curr_lane, free_E.

0.4908643::u37.
free_NE :- u37, action(change_to_right), \+ curr_lane, free_E.

0.4392328::u38.
free_NE :- u38, action(cruise), \+ curr_lane, free_E.

0.0122780::u39.
free_NE :- u39, action(keep), \+ curr_lane, free_E.

0.8135198::u40.
free_NE :- u40, action(swerve_left), \+ curr_lane, free_E.

0.9990010::u41.
free_NE :- u41, action(swerve_right), \+ curr_lane, free_E.

0.4888071::u42.
free_NE :- u42, action(change_to_left), curr_lane, free_E.

0.5524768::u43.
free_NE :- u43, action(change_to_right), curr_lane, free_E.

0.9011164::u44.
free_NE :- u44, action(cruise), curr_lane, free_E.

0.0045514::u45.
free_NE :- u45, action(keep), curr_lane, free_E.

0.9044118::u46.
free_NE :- u46, action(swerve_left), curr_lane, free_E.

0.8562838::u47.
free_NE :- u47, action(swerve_right), curr_lane, free_E.

