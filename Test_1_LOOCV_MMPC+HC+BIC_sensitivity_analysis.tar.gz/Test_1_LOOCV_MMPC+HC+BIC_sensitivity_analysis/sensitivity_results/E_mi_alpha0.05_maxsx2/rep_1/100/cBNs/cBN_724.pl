%%% Exogenous variables

0.1676784::u_action(change_to_left); 0.1710682::u_action(change_to_right); 0.4047713::u_action(cruise); 0.2541451::u_action(keep); 0.0014761::u_action(swerve_left); 0.0008609::u_action(swerve_right)
action(V) :- u_action(V).

0.4037104::u1.
free_NW :- u1.

0.5990023::u2.
free_SE :- u2.

0.6789832::u3.
free_SW :- u3.

0.7148486::u4.
free_W :- u4.

0.3862626::u5.
latent_collision :- u5.

0.4973887::u6.
curr_lane :- u6, action(change_to_left).

0.5120333::u7.
curr_lane :- u7, action(change_to_right).

0.6569873::u8.
curr_lane :- u8, action(cruise).

0.3665065::u9.
curr_lane :- u9, action(keep).

0.8172677::u10.
curr_lane :- u10, action(swerve_left).

0.9928656::u11.
curr_lane :- u11, action(swerve_right).

0.5047461::u12.
free_E :- u12, action(change_to_left), \+ curr_lane.

0.4970907::u13.
free_E :- u13, action(change_to_right), \+ curr_lane.

0.5329723::u14.
free_E :- u14, action(cruise), \+ curr_lane.

0.5936961::u15.
free_E :- u15, action(keep), \+ curr_lane.

0.8140417::u16.
free_E :- u16, action(swerve_left), \+ curr_lane.

0.9990010::u17.
free_E :- u17, action(swerve_right), \+ curr_lane.

0.5537520::u18.
free_E :- u18, action(change_to_left), curr_lane.

0.5303580::u19.
free_E :- u19, action(change_to_right), curr_lane.

0.9004640::u20.
free_E :- u20, action(cruise), curr_lane.

0.9006160::u21.
free_E :- u21, action(keep), curr_lane.

0.9809079::u22.
free_E :- u22, action(swerve_left), curr_lane.

0.9958084::u23.
free_E :- u23, action(swerve_right), curr_lane.

0.4931698::u24.
free_NE :- u24, action(change_to_left), \+ curr_lane, \+ free_E.

0.5109299::u25.
free_NE :- u25, action(change_to_right), \+ curr_lane, \+ free_E.

0.5318726::u26.
free_NE :- u26, action(cruise), \+ curr_lane, \+ free_E.

0.2609284::u27.
free_NE :- u27, action(keep), \+ curr_lane, \+ free_E.

0.4285714::u28.
free_NE :- u28, action(swerve_left), \+ curr_lane, \+ free_E.

0.5000000::u29.
free_NE :- u29, action(swerve_right), \+ curr_lane, \+ free_E.

0.4998969::u30.
free_NE :- u30, action(change_to_left), curr_lane, \+ free_E.

0.5020715::u31.
free_NE :- u31, action(change_to_right), curr_lane, \+ free_E.

0.2250711::u32.
free_NE :- u32, action(cruise), curr_lane, \+ free_E.

0.0002764::u33.
free_NE :- u33, action(keep), curr_lane, \+ free_E.

0.0444444::u34.
free_NE :- u34, action(swerve_left), curr_lane, \+ free_E.

0.4285714::u35.
free_NE :- u35, action(swerve_right), curr_lane, \+ free_E.

0.4582436::u36.
free_NE :- u36, action(change_to_left), \+ curr_lane, free_E.

0.4906382::u37.
free_NE :- u37, action(change_to_right), \+ curr_lane, free_E.

0.4295170::u38.
free_NE :- u38, action(cruise), \+ curr_lane, free_E.

0.0122834::u39.
free_NE :- u39, action(keep), \+ curr_lane, free_E.

0.8135198::u40.
free_NE :- u40, action(swerve_left), \+ curr_lane, free_E.

0.9990010::u41.
free_NE :- u41, action(swerve_right), \+ curr_lane, free_E.

0.4888015::u42.
free_NE :- u42, action(change_to_left), curr_lane, free_E.

0.5524756::u43.
free_NE :- u43, action(change_to_right), curr_lane, free_E.

0.9011144::u44.
free_NE :- u44, action(cruise), curr_lane, free_E.

0.0045514::u45.
free_NE :- u45, action(keep), curr_lane, free_E.

0.9039792::u46.
free_NE :- u46, action(swerve_left), curr_lane, free_E.

0.8556825::u47.
free_NE :- u47, action(swerve_right), curr_lane, free_E.

