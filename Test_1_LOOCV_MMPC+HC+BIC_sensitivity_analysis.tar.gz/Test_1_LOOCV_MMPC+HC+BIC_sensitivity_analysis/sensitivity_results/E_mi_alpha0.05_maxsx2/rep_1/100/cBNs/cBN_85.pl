%%% Exogenous variables

0.1678917::u_action(change_to_left); 0.1700200::u_action(change_to_right); 0.4052888::u_action(cruise); 0.2544596::u_action(keep); 0.0014780::u_action(swerve_left); 0.0008620::u_action(swerve_right)
action(V) :- u_action(V).

0.4042244::u1.
free_NW :- u1.

0.5997637::u2.
free_SE :- u2.

0.6824301::u3.
free_SW :- u3.

0.7119026::u4.
free_W :- u4.

0.3854722::u5.
latent_collision :- u5.

0.4973918::u6.
curr_lane :- u6, action(change_to_left).

0.5158424::u7.
curr_lane :- u7, action(change_to_right).

0.6569831::u8.
curr_lane :- u8, action(cruise).

0.3665190::u9.
curr_lane :- u9, action(keep).

0.8172677::u10.
curr_lane :- u10, action(swerve_left).

0.9928656::u11.
curr_lane :- u11, action(swerve_right).

0.5047552::u12.
free_E :- u12, action(change_to_left), \+ curr_lane.

0.4893605::u13.
free_E :- u13, action(change_to_right), \+ curr_lane.

0.5329809::u14.
free_E :- u14, action(cruise), \+ curr_lane.

0.5936709::u15.
free_E :- u15, action(keep), \+ curr_lane.

0.8140417::u16.
free_E :- u16, action(swerve_left), \+ curr_lane.

0.9990010::u17.
free_E :- u17, action(swerve_right), \+ curr_lane.

0.5537548::u18.
free_E :- u18, action(change_to_left), curr_lane.

0.5303553::u19.
free_E :- u19, action(change_to_right), curr_lane.

0.9004660::u20.
free_E :- u20, action(cruise), curr_lane.

0.9006160::u21.
free_E :- u21, action(keep), curr_lane.

0.9809079::u22.
free_E :- u22, action(swerve_left), curr_lane.

0.9958084::u23.
free_E :- u23, action(swerve_right), curr_lane.

0.4931574::u24.
free_NE :- u24, action(change_to_left), \+ curr_lane, \+ free_E.

0.5109299::u25.
free_NE :- u25, action(change_to_right), \+ curr_lane, \+ free_E.

0.5318805::u26.
free_NE :- u26, action(cruise), \+ curr_lane, \+ free_E.

0.2609264::u27.
free_NE :- u27, action(keep), \+ curr_lane, \+ free_E.

0.4285714::u28.
free_NE :- u28, action(swerve_left), \+ curr_lane, \+ free_E.

0.5000000::u29.
free_NE :- u29, action(swerve_right), \+ curr_lane, \+ free_E.

0.4998969::u30.
free_NE :- u30, action(change_to_left), curr_lane, \+ free_E.

0.5020715::u31.
free_NE :- u31, action(change_to_right), curr_lane, \+ free_E.

0.2250561::u32.
free_NE :- u32, action(cruise), curr_lane, \+ free_E.

0.0002764::u33.
free_NE :- u33, action(keep), curr_lane, \+ free_E.

0.0444444::u34.
free_NE :- u34, action(swerve_left), curr_lane, \+ free_E.

0.4285714::u35.
free_NE :- u35, action(swerve_right), curr_lane, \+ free_E.

0.4883293::u36.
free_NE :- u36, action(change_to_left), \+ curr_lane, free_E.

0.5065072::u37.
free_NE :- u37, action(change_to_right), \+ curr_lane, free_E.

0.4468275::u38.
free_NE :- u38, action(cruise), \+ curr_lane, free_E.

0.0122846::u39.
free_NE :- u39, action(keep), \+ curr_lane, free_E.

0.8135198::u40.
free_NE :- u40, action(swerve_left), \+ curr_lane, free_E.

0.9990010::u41.
free_NE :- u41, action(swerve_right), \+ curr_lane, free_E.

0.4888071::u42.
free_NE :- u42, action(change_to_left), curr_lane, free_E.

0.5524707::u43.
free_NE :- u43, action(change_to_right), curr_lane, free_E.

0.9011146::u44.
free_NE :- u44, action(cruise), curr_lane, free_E.

0.0045514::u45.
free_NE :- u45, action(keep), curr_lane, free_E.

0.9044118::u46.
free_NE :- u46, action(swerve_left), curr_lane, free_E.

0.8562838::u47.
free_NE :- u47, action(swerve_right), curr_lane, free_E.

