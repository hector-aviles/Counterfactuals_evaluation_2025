%%% Exogenous variables

0.1680513::u_action(change_to_left); 0.1699444::u_action(change_to_right); 0.4051937::u_action(cruise); 0.2544779::u_action(keep); 0.0014503::u_action(swerve_left); 0.0008825::u_action(swerve_right)
action(V) :- u_action(V).

0.4039402::u1.
free_NW :- u1.

0.5994861::u2.
free_SE :- u2.

0.6824269::u3.
free_SW :- u3.

0.7157891::u4.
free_W :- u4.

0.3858237::u5.
latent_collision :- u5.

0.4888421::u6.
curr_lane :- u6, action(change_to_left).

0.5093660::u7.
curr_lane :- u7, action(change_to_right).

0.6530590::u8.
curr_lane :- u8, action(cruise).

0.3664787::u9.
curr_lane :- u9, action(keep).

0.8183746::u10.
curr_lane :- u10, action(swerve_left).

0.9941928::u11.
curr_lane :- u11, action(swerve_right).

0.5138405::u12.
free_E :- u12, action(change_to_left), \+ curr_lane.

0.4970437::u13.
free_E :- u13, action(change_to_right), \+ curr_lane.

0.5370881::u14.
free_E :- u14, action(cruise), \+ curr_lane.

0.5936668::u15.
free_E :- u15, action(keep), \+ curr_lane.

0.7976654::u16.
free_E :- u16, action(swerve_left), \+ curr_lane.

0.9990010::u17.
free_E :- u17, action(swerve_right), \+ curr_lane.

0.5633351::u18.
free_E :- u18, action(change_to_left), curr_lane.

0.5385808::u19.
free_E :- u19, action(change_to_right), curr_lane.

0.9049969::u20.
free_E :- u20, action(cruise), curr_lane.

0.9008385::u21.
free_E :- u21, action(keep), curr_lane.

0.9801382::u22.
free_E :- u22, action(swerve_left), curr_lane.

0.9964953::u23.
free_E :- u23, action(swerve_right), curr_lane.

0.4956069::u24.
free_NE :- u24, action(change_to_left), \+ curr_lane, \+ free_E.

0.5112056::u25.
free_NE :- u25, action(change_to_right), \+ curr_lane, \+ free_E.

0.5330666::u26.
free_NE :- u26, action(cruise), \+ curr_lane, \+ free_E.

0.2600798::u27.
free_NE :- u27, action(keep), \+ curr_lane, \+ free_E.

0.4038462::u28.
free_NE :- u28, action(swerve_left), \+ curr_lane, \+ free_E.

0.5000000::u29.
free_NE :- u29, action(swerve_right), \+ curr_lane, \+ free_E.

0.5182286::u30.
free_NE :- u30, action(change_to_left), curr_lane, \+ free_E.

0.5158708::u31.
free_NE :- u31, action(change_to_right), curr_lane, \+ free_E.

0.2354860::u32.
free_NE :- u32, action(cruise), curr_lane, \+ free_E.

0.0003325::u33.
free_NE :- u33, action(keep), curr_lane, \+ free_E.

0.0869565::u34.
free_NE :- u34, action(swerve_left), curr_lane, \+ free_E.

0.6666667::u35.
free_NE :- u35, action(swerve_right), curr_lane, \+ free_E.

0.4690475::u36.
free_NE :- u36, action(change_to_left), \+ curr_lane, free_E.

0.4913691::u37.
free_NE :- u37, action(change_to_right), \+ curr_lane, free_E.

0.4408894::u38.
free_NE :- u38, action(cruise), \+ curr_lane, free_E.

0.0121865::u39.
free_NE :- u39, action(keep), \+ curr_lane, free_E.

0.7804878::u40.
free_NE :- u40, action(swerve_left), \+ curr_lane, free_E.

0.9990010::u41.
free_NE :- u41, action(swerve_right), \+ curr_lane, free_E.

0.4864793::u42.
free_NE :- u42, action(change_to_left), curr_lane, free_E.

0.5534207::u43.
free_NE :- u43, action(change_to_right), curr_lane, free_E.

0.9015292::u44.
free_NE :- u44, action(cruise), curr_lane, free_E.

0.0041235::u45.
free_NE :- u45, action(keep), curr_lane, free_E.

0.9030837::u46.
free_NE :- u46, action(swerve_left), curr_lane, free_E.

0.8511137::u47.
free_NE :- u47, action(swerve_right), curr_lane, free_E.

