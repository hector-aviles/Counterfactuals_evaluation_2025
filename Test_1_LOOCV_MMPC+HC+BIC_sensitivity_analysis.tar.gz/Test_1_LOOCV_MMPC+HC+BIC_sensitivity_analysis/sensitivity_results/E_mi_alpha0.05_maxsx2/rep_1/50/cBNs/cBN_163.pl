%%% Exogenous variables

0.1683276::u_action(change_to_left); 0.1703998::u_action(change_to_right); 0.4052678::u_action(cruise); 0.2536763::u_action(keep); 0.0014710::u_action(swerve_left); 0.0008576::u_action(swerve_right)
action(V) :- u_action(V).

0.4050862::u1.
free_NW :- u1.

0.5951600::u2.
free_SE :- u2.

0.6777513::u3.
free_SW :- u3.

0.7164357::u4.
free_W :- u4.

0.3858912::u5.
latent_collision :- u5.

0.4896765::u6.
curr_lane :- u6, action(change_to_left).

0.5080127::u7.
curr_lane :- u7, action(change_to_right).

0.6548181::u8.
curr_lane :- u8, action(cruise).

0.3647455::u9.
curr_lane :- u9, action(keep).

0.8138075::u10.
curr_lane :- u10, action(swerve_left).

0.9940191::u11.
curr_lane :- u11, action(swerve_right).

0.5143898::u12.
free_E :- u12, action(change_to_left), \+ curr_lane.

0.4987213::u13.
free_E :- u13, action(change_to_right), \+ curr_lane.

0.5372037::u14.
free_E :- u14, action(cruise), \+ curr_lane.

0.5935236::u15.
free_E :- u15, action(keep), \+ curr_lane.

0.8426966::u16.
free_E :- u16, action(swerve_left), \+ curr_lane.

0.9990010::u17.
free_E :- u17, action(swerve_right), \+ curr_lane.

0.5627365::u18.
free_E :- u18, action(change_to_left), curr_lane.

0.5386967::u19.
free_E :- u19, action(change_to_right), curr_lane.

0.9053224::u20.
free_E :- u20, action(cruise), curr_lane.

0.9086575::u21.
free_E :- u21, action(keep), curr_lane.

0.9751500::u22.
free_E :- u22, action(swerve_left), curr_lane.

0.9963899::u23.
free_E :- u23, action(swerve_right), curr_lane.

0.4918480::u24.
free_NE :- u24, action(change_to_left), \+ curr_lane, \+ free_E.

0.5089950::u25.
free_NE :- u25, action(change_to_right), \+ curr_lane, \+ free_E.

0.5330999::u26.
free_NE :- u26, action(cruise), \+ curr_lane, \+ free_E.

0.2628298::u27.
free_NE :- u27, action(keep), \+ curr_lane, \+ free_E.

0.5000000::u28.
free_NE :- u28, action(swerve_left), \+ curr_lane, \+ free_E.

0.5000000::u29.
free_NE :- u29, action(swerve_right), \+ curr_lane, \+ free_E.

0.5211043::u30.
free_NE :- u30, action(change_to_left), curr_lane, \+ free_E.

0.5163379::u31.
free_NE :- u31, action(change_to_right), curr_lane, \+ free_E.

0.2376597::u32.
free_NE :- u32, action(cruise), curr_lane, \+ free_E.

0.0002427::u33.
free_NE :- u33, action(keep), curr_lane, \+ free_E.

0.0009990::u34.
free_NE :- u34, action(swerve_left), curr_lane, \+ free_E.

0.3333333::u35.
free_NE :- u35, action(swerve_right), curr_lane, \+ free_E.

0.4739408::u36.
free_NE :- u36, action(change_to_left), \+ curr_lane, free_E.

0.4912410::u37.
free_NE :- u37, action(change_to_right), \+ curr_lane, free_E.

0.4380895::u38.
free_NE :- u38, action(cruise), \+ curr_lane, free_E.

0.0128702::u39.
free_NE :- u39, action(keep), \+ curr_lane, free_E.

0.8000000::u40.
free_NE :- u40, action(swerve_left), \+ curr_lane, free_E.

0.9990010::u41.
free_NE :- u41, action(swerve_right), \+ curr_lane, free_E.

0.4894177::u42.
free_NE :- u42, action(change_to_left), curr_lane, free_E.

0.5542577::u43.
free_NE :- u43, action(change_to_right), curr_lane, free_E.

0.9007241::u44.
free_NE :- u44, action(cruise), curr_lane, free_E.

0.0043680::u45.
free_NE :- u45, action(keep), curr_lane, free_E.

0.9156415::u46.
free_NE :- u46, action(swerve_left), curr_lane, free_E.

0.8695652::u47.
free_NE :- u47, action(swerve_right), curr_lane, free_E.

