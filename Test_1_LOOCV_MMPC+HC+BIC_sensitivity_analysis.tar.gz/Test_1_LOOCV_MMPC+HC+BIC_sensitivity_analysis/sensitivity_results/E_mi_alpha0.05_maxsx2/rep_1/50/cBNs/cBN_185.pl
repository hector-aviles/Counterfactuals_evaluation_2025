%%% Exogenous variables

0.1682593::u_action(change_to_left); 0.1700100::u_action(change_to_right); 0.4049409::u_action(cruise); 0.2544805::u_action(keep); 0.0014698::u_action(swerve_left); 0.0008395::u_action(swerve_right)
action(V) :- u_action(V).

0.4005888::u1.
free_NW :- u1.

0.5960011::u2.
free_SE :- u2.

0.6783396::u3.
free_SW :- u3.

0.7155836::u4.
free_W :- u4.

0.3855234::u5.
latent_collision :- u5.

0.4890379::u6.
curr_lane :- u6, action(change_to_left).

0.5074307::u7.
curr_lane :- u7, action(change_to_right).

0.6534521::u8.
curr_lane :- u8, action(cruise).

0.3663987::u9.
curr_lane :- u9, action(keep).

0.8235704::u10.
curr_lane :- u10, action(swerve_left).

0.9938950::u11.
curr_lane :- u11, action(swerve_right).

0.5138415::u12.
free_E :- u12, action(change_to_left), \+ curr_lane.

0.4994982::u13.
free_E :- u13, action(change_to_right), \+ curr_lane.

0.5357315::u14.
free_E :- u14, action(cruise), \+ curr_lane.

0.5934282::u15.
free_E :- u15, action(keep), \+ curr_lane.

0.7984190::u16.
free_E :- u16, action(swerve_left), \+ curr_lane.

0.9990010::u17.
free_E :- u17, action(swerve_right), \+ curr_lane.

0.5627997::u18.
free_E :- u18, action(change_to_left), curr_lane.

0.5387037::u19.
free_E :- u19, action(change_to_right), curr_lane.

0.9050736::u20.
free_E :- u20, action(cruise), curr_lane.

0.9008333::u21.
free_E :- u21, action(keep), curr_lane.

0.9813717::u22.
free_E :- u22, action(swerve_left), curr_lane.

0.9975430::u23.
free_E :- u23, action(swerve_right), curr_lane.

0.4945314::u24.
free_NE :- u24, action(change_to_left), \+ curr_lane, \+ free_E.

0.5100633::u25.
free_NE :- u25, action(change_to_right), \+ curr_lane, \+ free_E.

0.5311109::u26.
free_NE :- u26, action(cruise), \+ curr_lane, \+ free_E.

0.2625045::u27.
free_NE :- u27, action(keep), \+ curr_lane, \+ free_E.

0.5098039::u28.
free_NE :- u28, action(swerve_left), \+ curr_lane, \+ free_E.

0.5000000::u29.
free_NE :- u29, action(swerve_right), \+ curr_lane, \+ free_E.

0.5188900::u30.
free_NE :- u30, action(change_to_left), curr_lane, \+ free_E.

0.5168835::u31.
free_NE :- u31, action(change_to_right), curr_lane, \+ free_E.

0.2385538::u32.
free_NE :- u32, action(cruise), curr_lane, \+ free_E.

0.0004434::u33.
free_NE :- u33, action(keep), curr_lane, \+ free_E.

0.0909091::u34.
free_NE :- u34, action(swerve_left), curr_lane, \+ free_E.

0.9990010::u35.
free_NE :- u35, action(swerve_right), curr_lane, \+ free_E.

0.4738515::u36.
free_NE :- u36, action(change_to_left), \+ curr_lane, free_E.

0.4932245::u37.
free_NE :- u37, action(change_to_right), \+ curr_lane, free_E.

0.4399907::u38.
free_NE :- u38, action(cruise), \+ curr_lane, free_E.

0.0122441::u39.
free_NE :- u39, action(keep), \+ curr_lane, free_E.

0.7970297::u40.
free_NE :- u40, action(swerve_left), \+ curr_lane, free_E.

0.9990010::u41.
free_NE :- u41, action(swerve_right), \+ curr_lane, free_E.

0.4878378::u42.
free_NE :- u42, action(change_to_left), curr_lane, free_E.

0.5521394::u43.
free_NE :- u43, action(change_to_right), curr_lane, free_E.

0.9010623::u44.
free_NE :- u44, action(cruise), curr_lane, free_E.

0.0042344::u45.
free_NE :- u45, action(keep), curr_lane, free_E.

0.9068162::u46.
free_NE :- u46, action(swerve_left), curr_lane, free_E.

0.8596059::u47.
free_NE :- u47, action(swerve_right), curr_lane, free_E.

