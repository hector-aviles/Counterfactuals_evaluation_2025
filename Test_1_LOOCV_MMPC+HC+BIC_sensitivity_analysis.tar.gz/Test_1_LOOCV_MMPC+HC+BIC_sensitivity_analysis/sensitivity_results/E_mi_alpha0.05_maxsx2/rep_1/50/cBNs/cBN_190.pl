%%% Exogenous variables

0.1682857::u_action(change_to_left); 0.1694843::u_action(change_to_right); 0.4056088::u_action(cruise); 0.2542720::u_action(keep); 0.0014801::u_action(swerve_left); 0.0008690::u_action(swerve_right)
action(V) :- u_action(V).

0.4036731::u1.
free_NW :- u1.

0.5989596::u2.
free_SE :- u2.

0.6808177::u3.
free_SW :- u3.

0.7148436::u4.
free_W :- u4.

0.3865276::u5.
latent_collision :- u5.

0.4884553::u6.
curr_lane :- u6, action(change_to_left).

0.5073592::u7.
curr_lane :- u7, action(change_to_right).

0.6549250::u8.
curr_lane :- u8, action(cruise).

0.3672723::u9.
curr_lane :- u9, action(keep).

0.8201936::u10.
curr_lane :- u10, action(swerve_left).

0.9952886::u11.
curr_lane :- u11, action(swerve_right).

0.5130797::u12.
free_E :- u12, action(change_to_left), \+ curr_lane.

0.4959727::u13.
free_E :- u13, action(change_to_right), \+ curr_lane.

0.5373308::u14.
free_E :- u14, action(cruise), \+ curr_lane.

0.5931706::u15.
free_E :- u15, action(keep), \+ curr_lane.

0.8500000::u16.
free_E :- u16, action(swerve_left), \+ curr_lane.

0.9990010::u17.
free_E :- u17, action(swerve_right), \+ curr_lane.

0.5634713::u18.
free_E :- u18, action(change_to_left), curr_lane.

0.5393067::u19.
free_E :- u19, action(change_to_right), curr_lane.

0.9007691::u20.
free_E :- u20, action(cruise), curr_lane.

0.9004527::u21.
free_E :- u21, action(keep), curr_lane.

0.9814503::u22.
free_E :- u22, action(swerve_left), curr_lane.

0.9988166::u23.
free_E :- u23, action(swerve_right), curr_lane.

0.4908181::u24.
free_NE :- u24, action(change_to_left), \+ curr_lane, \+ free_E.

0.5113954::u25.
free_NE :- u25, action(change_to_right), \+ curr_lane, \+ free_E.

0.5336052::u26.
free_NE :- u26, action(cruise), \+ curr_lane, \+ free_E.

0.2607479::u27.
free_NE :- u27, action(keep), \+ curr_lane, \+ free_E.

0.4102564::u28.
free_NE :- u28, action(swerve_left), \+ curr_lane, \+ free_E.

0.5000000::u29.
free_NE :- u29, action(swerve_right), \+ curr_lane, \+ free_E.

0.4840108::u30.
free_NE :- u30, action(change_to_left), curr_lane, \+ free_E.

0.4872226::u31.
free_NE :- u31, action(change_to_right), curr_lane, \+ free_E.

0.2224293::u32.
free_NE :- u32, action(cruise), curr_lane, \+ free_E.

0.0004404::u33.
free_NE :- u33, action(keep), curr_lane, \+ free_E.

0.0454545::u34.
free_NE :- u34, action(swerve_left), curr_lane, \+ free_E.

0.9990010::u35.
free_NE :- u35, action(swerve_right), curr_lane, \+ free_E.

0.4709618::u36.
free_NE :- u36, action(change_to_left), \+ curr_lane, free_E.

0.4951799::u37.
free_NE :- u37, action(change_to_right), \+ curr_lane, free_E.

0.4407333::u38.
free_NE :- u38, action(cruise), \+ curr_lane, free_E.

0.0119703::u39.
free_NE :- u39, action(keep), \+ curr_lane, free_E.

0.8325792::u40.
free_NE :- u40, action(swerve_left), \+ curr_lane, free_E.

0.9990010::u41.
free_NE :- u41, action(swerve_right), \+ curr_lane, free_E.

0.4876793::u42.
free_NE :- u42, action(change_to_left), curr_lane, free_E.

0.5541110::u43.
free_NE :- u43, action(change_to_right), curr_lane, free_E.

0.9012423::u44.
free_NE :- u44, action(cruise), curr_lane, free_E.

0.0046865::u45.
free_NE :- u45, action(keep), curr_lane, free_E.

0.8994845::u46.
free_NE :- u46, action(swerve_left), curr_lane, free_E.

0.8578199::u47.
free_NE :- u47, action(swerve_right), curr_lane, free_E.

