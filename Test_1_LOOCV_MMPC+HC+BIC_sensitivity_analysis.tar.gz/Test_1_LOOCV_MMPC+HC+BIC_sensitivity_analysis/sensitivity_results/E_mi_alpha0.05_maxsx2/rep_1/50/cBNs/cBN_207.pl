%%% Exogenous variables

0.1689301::u_action(change_to_left); 0.1694177::u_action(change_to_right); 0.4058875::u_action(cruise); 0.2533593::u_action(keep); 0.0015335::u_action(swerve_left); 0.0008720::u_action(swerve_right)
action(V) :- u_action(V).

0.4022225::u1.
free_NW :- u1.

0.5985023::u2.
free_SE :- u2.

0.6802685::u3.
free_SW :- u3.

0.7128463::u4.
free_W :- u4.

0.3871087::u5.
latent_collision :- u5.

0.4925141::u6.
curr_lane :- u6, action(change_to_left).

0.5084932::u7.
curr_lane :- u7, action(change_to_right).

0.6546491::u8.
curr_lane :- u8, action(cruise).

0.3655354::u9.
curr_lane :- u9, action(keep).

0.8206667::u10.
curr_lane :- u10, action(swerve_left).

0.9917937::u11.
curr_lane :- u11, action(swerve_right).

0.5107025::u12.
free_E :- u12, action(change_to_left), \+ curr_lane.

0.4976612::u13.
free_E :- u13, action(change_to_right), \+ curr_lane.

0.5370018::u14.
free_E :- u14, action(cruise), \+ curr_lane.

0.5936785::u15.
free_E :- u15, action(keep), \+ curr_lane.

0.8029740::u16.
free_E :- u16, action(swerve_left), \+ curr_lane.

0.9990010::u17.
free_E :- u17, action(swerve_right), \+ curr_lane.

0.5542668::u18.
free_E :- u18, action(change_to_left), curr_lane.

0.5387573::u19.
free_E :- u19, action(change_to_right), curr_lane.

0.9006948::u20.
free_E :- u20, action(cruise), curr_lane.

0.8996148::u21.
free_E :- u21, action(keep), curr_lane.

0.9788790::u22.
free_E :- u22, action(swerve_left), curr_lane.

0.9940898::u23.
free_E :- u23, action(swerve_right), curr_lane.

0.4953938::u24.
free_NE :- u24, action(change_to_left), \+ curr_lane, \+ free_E.

0.5124032::u25.
free_NE :- u25, action(change_to_right), \+ curr_lane, \+ free_E.

0.5303699::u26.
free_NE :- u26, action(cruise), \+ curr_lane, \+ free_E.

0.2616528::u27.
free_NE :- u27, action(keep), \+ curr_lane, \+ free_E.

0.4339623::u28.
free_NE :- u28, action(swerve_left), \+ curr_lane, \+ free_E.

0.5000000::u29.
free_NE :- u29, action(swerve_right), \+ curr_lane, \+ free_E.

0.4998622::u30.
free_NE :- u30, action(change_to_left), curr_lane, \+ free_E.

0.4851549::u31.
free_NE :- u31, action(change_to_right), curr_lane, \+ free_E.

0.2290884::u32.
free_NE :- u32, action(cruise), curr_lane, \+ free_E.

0.0002199::u33.
free_NE :- u33, action(keep), curr_lane, \+ free_E.

0.0769231::u34.
free_NE :- u34, action(swerve_left), curr_lane, \+ free_E.

0.6000000::u35.
free_NE :- u35, action(swerve_right), curr_lane, \+ free_E.

0.4742802::u36.
free_NE :- u36, action(change_to_left), \+ curr_lane, free_E.

0.4920811::u37.
free_NE :- u37, action(change_to_right), \+ curr_lane, free_E.

0.4393666::u38.
free_NE :- u38, action(cruise), \+ curr_lane, free_E.

0.0121264::u39.
free_NE :- u39, action(keep), \+ curr_lane, free_E.

0.8009259::u40.
free_NE :- u40, action(swerve_left), \+ curr_lane, free_E.

0.9990010::u41.
free_NE :- u41, action(swerve_right), \+ curr_lane, free_E.

0.4872198::u42.
free_NE :- u42, action(change_to_left), curr_lane, free_E.

0.5526211::u43.
free_NE :- u43, action(change_to_right), curr_lane, free_E.

0.9008009::u44.
free_NE :- u44, action(cruise), curr_lane, free_E.

0.0044910::u45.
free_NE :- u45, action(keep), curr_lane, free_E.

0.9103734::u46.
free_NE :- u46, action(swerve_left), curr_lane, free_E.

0.8668252::u47.
free_NE :- u47, action(swerve_right), curr_lane, free_E.

