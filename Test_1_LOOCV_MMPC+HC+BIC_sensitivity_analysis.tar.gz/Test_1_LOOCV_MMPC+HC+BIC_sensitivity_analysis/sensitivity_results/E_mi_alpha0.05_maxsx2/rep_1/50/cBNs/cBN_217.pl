%%% Exogenous variables

0.1675466::u_action(change_to_left); 0.1699746::u_action(change_to_right); 0.4050443::u_action(cruise); 0.2551121::u_action(keep); 0.0014851::u_action(swerve_left); 0.0008374::u_action(swerve_right)
action(V) :- u_action(V).

0.4040829::u1.
free_NW :- u1.

0.5995023::u2.
free_SE :- u2.

0.6828062::u3.
free_SW :- u3.

0.7162474::u4.
free_W :- u4.

0.3851351::u5.
latent_collision :- u5.

0.4892153::u6.
curr_lane :- u6, action(change_to_left).

0.5077213::u7.
curr_lane :- u7, action(change_to_right).

0.6536106::u8.
curr_lane :- u8, action(cruise).

0.3661232::u9.
curr_lane :- u9, action(keep).

0.8115942::u10.
curr_lane :- u10, action(swerve_left).

0.9938800::u11.
curr_lane :- u11, action(swerve_right).

0.5121259::u12.
free_E :- u12, action(change_to_left), \+ curr_lane.

0.4979789::u13.
free_E :- u13, action(change_to_right), \+ curr_lane.

0.5392173::u14.
free_E :- u14, action(cruise), \+ curr_lane.

0.5926149::u15.
free_E :- u15, action(keep), \+ curr_lane.

0.8278388::u16.
free_E :- u16, action(swerve_left), \+ curr_lane.

0.9990010::u17.
free_E :- u17, action(swerve_right), \+ curr_lane.

0.5468095::u18.
free_E :- u18, action(change_to_left), curr_lane.

0.5226185::u19.
free_E :- u19, action(change_to_right), curr_lane.

0.8996295::u20.
free_E :- u20, action(cruise), curr_lane.

0.9006485::u21.
free_E :- u21, action(keep), curr_lane.

0.9812925::u22.
free_E :- u22, action(swerve_left), curr_lane.

0.9938424::u23.
free_E :- u23, action(swerve_right), curr_lane.

0.4973857::u24.
free_NE :- u24, action(change_to_left), \+ curr_lane, \+ free_E.

0.5081371::u25.
free_NE :- u25, action(change_to_right), \+ curr_lane, \+ free_E.

0.5319213::u26.
free_NE :- u26, action(cruise), \+ curr_lane, \+ free_E.

0.2629131::u27.
free_NE :- u27, action(keep), \+ curr_lane, \+ free_E.

0.4680851::u28.
free_NE :- u28, action(swerve_left), \+ curr_lane, \+ free_E.

0.5000000::u29.
free_NE :- u29, action(swerve_right), \+ curr_lane, \+ free_E.

0.4974478::u30.
free_NE :- u30, action(change_to_left), curr_lane, \+ free_E.

0.5030849::u31.
free_NE :- u31, action(change_to_right), curr_lane, \+ free_E.

0.2221708::u32.
free_NE :- u32, action(cruise), curr_lane, \+ free_E.

0.0002209::u33.
free_NE :- u33, action(keep), curr_lane, \+ free_E.

0.0454545::u34.
free_NE :- u34, action(swerve_left), curr_lane, \+ free_E.

0.4000000::u35.
free_NE :- u35, action(swerve_right), curr_lane, \+ free_E.

0.4717974::u36.
free_NE :- u36, action(change_to_left), \+ curr_lane, free_E.

0.4884762::u37.
free_NE :- u37, action(change_to_right), \+ curr_lane, free_E.

0.4389953::u38.
free_NE :- u38, action(cruise), \+ curr_lane, free_E.

0.0121603::u39.
free_NE :- u39, action(keep), \+ curr_lane, free_E.

0.7964602::u40.
free_NE :- u40, action(swerve_left), \+ curr_lane, free_E.

0.9990010::u41.
free_NE :- u41, action(swerve_right), \+ curr_lane, free_E.

0.5044592::u42.
free_NE :- u42, action(change_to_left), curr_lane, free_E.

0.5678446::u43.
free_NE :- u43, action(change_to_right), curr_lane, free_E.

0.9061783::u44.
free_NE :- u44, action(cruise), curr_lane, free_E.

0.0044592::u45.
free_NE :- u45, action(keep), curr_lane, free_E.

0.9029463::u46.
free_NE :- u46, action(swerve_left), curr_lane, free_E.

0.8537794::u47.
free_NE :- u47, action(swerve_right), curr_lane, free_E.

