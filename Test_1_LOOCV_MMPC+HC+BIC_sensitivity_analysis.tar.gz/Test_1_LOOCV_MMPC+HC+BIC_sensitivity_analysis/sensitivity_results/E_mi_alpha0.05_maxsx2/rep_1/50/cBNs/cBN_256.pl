%%% Exogenous variables

0.1681523::u_action(change_to_left); 0.1705128::u_action(change_to_right); 0.4063363::u_action(cruise); 0.2526185::u_action(keep); 0.0014973::u_action(swerve_left); 0.0008828::u_action(swerve_right)
action(V) :- u_action(V).

0.3988663::u1.
free_NW :- u1.

0.5951456::u2.
free_SE :- u2.

0.6776622::u3.
free_SW :- u3.

0.7176905::u4.
free_W :- u4.

0.3860977::u5.
latent_collision :- u5.

0.4894241::u6.
curr_lane :- u6, action(change_to_left).

0.5094561::u7.
curr_lane :- u7, action(change_to_right).

0.6532912::u8.
curr_lane :- u8, action(cruise).

0.3619234::u9.
curr_lane :- u9, action(keep).

0.8146877::u10.
curr_lane :- u10, action(swerve_left).

0.9906868::u11.
curr_lane :- u11, action(swerve_right).

0.5122929::u12.
free_E :- u12, action(change_to_left), \+ curr_lane.

0.4976226::u13.
free_E :- u13, action(change_to_right), \+ curr_lane.

0.5369432::u14.
free_E :- u14, action(cruise), \+ curr_lane.

0.5951725::u15.
free_E :- u15, action(keep), \+ curr_lane.

0.8111111::u16.
free_E :- u16, action(swerve_left), \+ curr_lane.

0.9990010::u17.
free_E :- u17, action(swerve_right), \+ curr_lane.

0.5458836::u18.
free_E :- u18, action(change_to_left), curr_lane.

0.5235357::u19.
free_E :- u19, action(change_to_right), curr_lane.

0.8999621::u20.
free_E :- u20, action(cruise), curr_lane.

0.8984579::u21.
free_E :- u21, action(keep), curr_lane.

0.9848357::u22.
free_E :- u22, action(swerve_left), curr_lane.

0.9929495::u23.
free_E :- u23, action(swerve_right), curr_lane.

0.4938765::u24.
free_NE :- u24, action(change_to_left), \+ curr_lane, \+ free_E.

0.5115921::u25.
free_NE :- u25, action(change_to_right), \+ curr_lane, \+ free_E.

0.5309861::u26.
free_NE :- u26, action(cruise), \+ curr_lane, \+ free_E.

0.2618980::u27.
free_NE :- u27, action(keep), \+ curr_lane, \+ free_E.

0.3725490::u28.
free_NE :- u28, action(swerve_left), \+ curr_lane, \+ free_E.

0.5000000::u29.
free_NE :- u29, action(swerve_right), \+ curr_lane, \+ free_E.

0.4969615::u30.
free_NE :- u30, action(change_to_left), curr_lane, \+ free_E.

0.5035753::u31.
free_NE :- u31, action(change_to_right), curr_lane, \+ free_E.

0.2266553::u32.
free_NE :- u32, action(cruise), curr_lane, \+ free_E.

0.0002214::u33.
free_NE :- u33, action(keep), curr_lane, \+ free_E.

0.0009990::u34.
free_NE :- u34, action(swerve_left), curr_lane, \+ free_E.

0.5000000::u35.
free_NE :- u35, action(swerve_right), curr_lane, \+ free_E.

0.4724176::u36.
free_NE :- u36, action(change_to_left), \+ curr_lane, free_E.

0.4881367::u37.
free_NE :- u37, action(change_to_right), \+ curr_lane, free_E.

0.4387507::u38.
free_NE :- u38, action(cruise), \+ curr_lane, free_E.

0.0117617::u39.
free_NE :- u39, action(keep), \+ curr_lane, free_E.

0.8219178::u40.
free_NE :- u40, action(swerve_left), \+ curr_lane, free_E.

0.9990010::u41.
free_NE :- u41, action(swerve_right), \+ curr_lane, free_E.

0.5017385::u42.
free_NE :- u42, action(change_to_left), curr_lane, free_E.

0.5672127::u43.
free_NE :- u43, action(change_to_right), curr_lane, free_E.

0.9079025::u44.
free_NE :- u44, action(cruise), curr_lane, free_E.

0.0043911::u45.
free_NE :- u45, action(keep), curr_lane, free_E.

0.8947819::u46.
free_NE :- u46, action(swerve_left), curr_lane, free_E.

0.8520710::u47.
free_NE :- u47, action(swerve_right), curr_lane, free_E.

