%%% Exogenous variables

0.1700741::u_action(change_to_left); 0.1724336::u_action(change_to_right); 0.3970110::u_action(cruise); 0.2580896::u_action(keep); 0.0015378::u_action(swerve_left); 0.0008540::u_action(swerve_right)
action(V) :- u_action(V).

0.4091160::u1.
free_NW :- u1.

0.5907824::u2.
free_SE :- u2.

0.6917609::u3.
free_SW :- u3.

0.7246443::u4.
free_W :- u4.

0.3918270::u5.
latent_collision :- u5.

0.4900828::u6.
curr_lane :- u6, action(change_to_left).

0.5091316::u7.
curr_lane :- u7, action(change_to_right).

0.6427584::u8.
curr_lane :- u8, action(cruise).

0.3661908::u9.
curr_lane :- u9, action(keep).

0.8164642::u10.
curr_lane :- u10, action(swerve_left).

0.9963548::u11.
curr_lane :- u11, action(swerve_right).

0.5140047::u12.
free_E :- u12, action(change_to_left), \+ curr_lane.

0.4974317::u13.
free_E :- u13, action(change_to_right), \+ curr_lane.

0.5370630::u14.
free_E :- u14, action(cruise), \+ curr_lane.

0.5937341::u15.
free_E :- u15, action(keep), \+ curr_lane.

0.8014706::u16.
free_E :- u16, action(swerve_left), \+ curr_lane.

0.9990010::u17.
free_E :- u17, action(swerve_right), \+ curr_lane.

0.5453640::u18.
free_E :- u18, action(change_to_left), curr_lane.

0.5226456::u19.
free_E :- u19, action(change_to_right), curr_lane.

0.8950795::u20.
free_E :- u20, action(cruise), curr_lane.

0.8995532::u21.
free_E :- u21, action(keep), curr_lane.

0.9809917::u22.
free_E :- u22, action(swerve_left), curr_lane.

0.9914634::u23.
free_E :- u23, action(swerve_right), curr_lane.

0.4913957::u24.
free_NE :- u24, action(change_to_left), \+ curr_lane, \+ free_E.

0.5105132::u25.
free_NE :- u25, action(change_to_right), \+ curr_lane, \+ free_E.

0.5295131::u26.
free_NE :- u26, action(cruise), \+ curr_lane, \+ free_E.

0.2599810::u27.
free_NE :- u27, action(keep), \+ curr_lane, \+ free_E.

0.5000000::u28.
free_NE :- u28, action(swerve_left), \+ curr_lane, \+ free_E.

0.5000000::u29.
free_NE :- u29, action(swerve_right), \+ curr_lane, \+ free_E.

0.4993702::u30.
free_NE :- u30, action(change_to_left), curr_lane, \+ free_E.

0.5042835::u31.
free_NE :- u31, action(change_to_right), curr_lane, \+ free_E.

0.2248188::u32.
free_NE :- u32, action(cruise), curr_lane, \+ free_E.

0.0001093::u33.
free_NE :- u33, action(keep), curr_lane, \+ free_E.

0.0434783::u34.
free_NE :- u34, action(swerve_left), curr_lane, \+ free_E.

0.4285714::u35.
free_NE :- u35, action(swerve_right), curr_lane, \+ free_E.

0.4752793::u36.
free_NE :- u36, action(change_to_left), \+ curr_lane, free_E.

0.4905981::u37.
free_NE :- u37, action(change_to_right), \+ curr_lane, free_E.

0.4403411::u38.
free_NE :- u38, action(cruise), \+ curr_lane, free_E.

0.0125106::u39.
free_NE :- u39, action(keep), \+ curr_lane, free_E.

0.8119266::u40.
free_NE :- u40, action(swerve_left), \+ curr_lane, free_E.

0.9990010::u41.
free_NE :- u41, action(swerve_right), \+ curr_lane, free_E.

0.4739317::u42.
free_NE :- u42, action(change_to_left), curr_lane, free_E.

0.5385798::u43.
free_NE :- u43, action(change_to_right), curr_lane, free_E.

0.8947966::u44.
free_NE :- u44, action(cruise), curr_lane, free_E.

0.0046989::u45.
free_NE :- u45, action(keep), curr_lane, free_E.

0.8887953::u46.
free_NE :- u46, action(swerve_left), curr_lane, free_E.

0.8622386::u47.
free_NE :- u47, action(swerve_right), curr_lane, free_E.

