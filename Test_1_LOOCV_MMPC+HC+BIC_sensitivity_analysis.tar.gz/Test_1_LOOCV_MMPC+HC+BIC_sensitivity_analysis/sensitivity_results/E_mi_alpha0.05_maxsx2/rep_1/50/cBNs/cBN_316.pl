%%% Exogenous variables

0.1699522::u_action(change_to_left); 0.1719046::u_action(change_to_right); 0.4105430::u_action(cruise); 0.2452104::u_action(keep); 0.0015056::u_action(swerve_left); 0.0008842::u_action(swerve_right)
action(V) :- u_action(V).

0.4098260::u1.
free_NW :- u1.

0.6085706::u2.
free_SE :- u2.

0.6740960::u3.
free_SW :- u3.

0.7082635::u4.
free_W :- u4.

0.3892796::u5.
latent_collision :- u5.

0.4658535::u6.
curr_lane :- u6, action(change_to_left), \+ free_E, \+ free_NE.

0.5008230::u7.
curr_lane :- u7, action(change_to_right), \+ free_E, \+ free_NE.

0.4016415::u8.
curr_lane :- u8, action(cruise), \+ free_E, \+ free_NE.

0.1617258::u9.
curr_lane :- u9, action(keep), \+ free_E, \+ free_NE.

0.3653846::u10.
curr_lane :- u10, action(swerve_left), \+ free_E, \+ free_NE.

0.9990010::u11.
curr_lane :- u11, action(swerve_right), \+ free_E, \+ free_NE.

0.5020886::u12.
curr_lane :- u12, action(change_to_left), free_E, \+ free_NE.

0.4957977::u13.
curr_lane :- u13, action(change_to_right), free_E, \+ free_NE.

0.3589221::u14.
curr_lane :- u14, action(cruise), free_E, \+ free_NE.

0.4690719::u15.
curr_lane :- u15, action(keep), free_E, \+ free_NE.

0.7557252::u16.
curr_lane :- u16, action(swerve_left), free_E, \+ free_NE.

0.9990010::u17.
curr_lane :- u17, action(swerve_right), free_E, \+ free_NE.

0.4905544::u18.
curr_lane :- u18, action(change_to_left), \+ free_E, free_NE.

0.5114600::u19.
curr_lane :- u19, action(change_to_right), \+ free_E, free_NE.

0.1528062::u20.
curr_lane :- u20, action(cruise), \+ free_E, free_NE.

0.0004522::u21.
curr_lane :- u21, action(keep), \+ free_E, free_NE.

0.0740741::u22.
curr_lane :- u22, action(swerve_left), \+ free_E, free_NE.

0.5000000::u23.
curr_lane :- u23, action(swerve_right), \+ free_E, free_NE.

0.5229809::u24.
curr_lane :- u24, action(change_to_left), free_E, free_NE.

0.5551415::u25.
curr_lane :- u25, action(change_to_right), free_E, free_NE.

0.8674907::u26.
curr_lane :- u26, action(cruise), free_E, free_NE.

0.2354552::u27.
curr_lane :- u27, action(keep), free_E, free_NE.

0.8563358::u28.
curr_lane :- u28, action(swerve_left), free_E, free_NE.

0.9917012::u29.
curr_lane :- u29, action(swerve_right), free_E, free_NE.

0.5352127::u30.
free_E :- u30, action(change_to_left).

0.5189795::u31.
free_E :- u31, action(change_to_right).

0.7795140::u32.
free_E :- u32, action(cruise).

0.7408344::u33.
free_E :- u33, action(keep).

0.9454796::u34.
free_E :- u34, action(swerve_left).

0.9976498::u35.
free_E :- u35, action(swerve_right).

0.4888059::u36.
free_NE :- u36, action(change_to_left), \+ free_E.

0.4961611::u37.
free_NE :- u37, action(change_to_right), \+ free_E.

0.4321709::u38.
free_NE :- u38, action(cruise), \+ free_E.

0.0723173::u39.
free_NE :- u39, action(keep), \+ free_E.

0.3417722::u40.
free_NE :- u40, action(swerve_left), \+ free_E.

0.0009990::u41.
free_NE :- u41, action(swerve_right), \+ free_E.

0.4831565::u42.
free_NE :- u42, action(change_to_left), free_E.

0.5219133::u43.
free_NE :- u43, action(change_to_right), free_E.

0.7911901::u44.
free_NE :- u44, action(cruise), free_E.

0.0083566::u45.
free_NE :- u45, action(keep), free_E.

0.9043796::u46.
free_NE :- u46, action(swerve_left), free_E.

0.8515901::u47.
free_NE :- u47, action(swerve_right), free_E.

