%%% Exogenous variables

0.1680320::u_action(change_to_left); 0.1701870::u_action(change_to_right); 0.4050279::u_action(cruise); 0.2544228::u_action(keep); 0.0014705::u_action(swerve_left); 0.0008598::u_action(swerve_right)
action(V) :- u_action(V).

0.4013080::u1.
free_NW :- u1.

0.6002640::u2.
free_SE :- u2.

0.6821418::u3.
free_SW :- u3.

0.7118382::u4.
free_W :- u4.

0.3866940::u5.
latent_collision :- u5.

0.4975880::u6.
curr_lane :- u6, action(change_to_left).

0.5161974::u7.
curr_lane :- u7, action(change_to_right).

0.6555141::u8.
curr_lane :- u8, action(cruise).

0.3675451::u9.
curr_lane :- u9, action(keep).

0.8195122::u10.
curr_lane :- u10, action(swerve_left).

0.9952324::u11.
curr_lane :- u11, action(swerve_right).

0.5187905::u12.
free_E :- u12, action(change_to_left), \+ curr_lane.

0.5060238::u13.
free_E :- u13, action(change_to_right), \+ curr_lane.

0.5437954::u14.
free_E :- u14, action(cruise), \+ curr_lane.

0.5933169::u15.
free_E :- u15, action(keep), \+ curr_lane.

0.8146718::u16.
free_E :- u16, action(swerve_left), \+ curr_lane.

0.9990010::u17.
free_E :- u17, action(swerve_right), \+ curr_lane.

0.5548038::u18.
free_E :- u18, action(change_to_left), curr_lane.

0.5291853::u19.
free_E :- u19, action(change_to_right), curr_lane.

0.9008213::u20.
free_E :- u20, action(cruise), curr_lane.

0.9008909::u21.
free_E :- u21, action(keep), curr_lane.

0.9795918::u22.
free_E :- u22, action(swerve_left), curr_lane.

0.9952096::u23.
free_E :- u23, action(swerve_right), curr_lane.

0.4753172::u24.
free_NE :- u24, action(change_to_left), \+ curr_lane, \+ free_E.

0.4976820::u25.
free_NE :- u25, action(change_to_right), \+ curr_lane, \+ free_E.

0.5234001::u26.
free_NE :- u26, action(cruise), \+ curr_lane, \+ free_E.

0.2617016::u27.
free_NE :- u27, action(keep), \+ curr_lane, \+ free_E.

0.4166667::u28.
free_NE :- u28, action(swerve_left), \+ curr_lane, \+ free_E.

0.5000000::u29.
free_NE :- u29, action(swerve_right), \+ curr_lane, \+ free_E.

0.5002202::u30.
free_NE :- u30, action(change_to_left), curr_lane, \+ free_E.

0.5044596::u31.
free_NE :- u31, action(change_to_right), curr_lane, \+ free_E.

0.2238092::u32.
free_NE :- u32, action(cruise), curr_lane, \+ free_E.

0.0002211::u33.
free_NE :- u33, action(keep), curr_lane, \+ free_E.

0.0009990::u34.
free_NE :- u34, action(swerve_left), curr_lane, \+ free_E.

0.7500000::u35.
free_NE :- u35, action(swerve_right), curr_lane, \+ free_E.

0.4731978::u36.
free_NE :- u36, action(change_to_left), \+ curr_lane, free_E.

0.4880958::u37.
free_NE :- u37, action(change_to_right), \+ curr_lane, free_E.

0.4372983::u38.
free_NE :- u38, action(cruise), \+ curr_lane, free_E.

0.0126228::u39.
free_NE :- u39, action(keep), \+ curr_lane, free_E.

0.8151659::u40.
free_NE :- u40, action(swerve_left), \+ curr_lane, free_E.

0.9990010::u41.
free_NE :- u41, action(swerve_right), \+ curr_lane, free_E.

0.4876179::u42.
free_NE :- u42, action(change_to_left), curr_lane, free_E.

0.5522197::u43.
free_NE :- u43, action(change_to_right), curr_lane, free_E.

0.9016333::u44.
free_NE :- u44, action(cruise), curr_lane, free_E.

0.0041601::u45.
free_NE :- u45, action(keep), curr_lane, free_E.

0.9201389::u46.
free_NE :- u46, action(swerve_left), curr_lane, free_E.

0.8760529::u47.
free_NE :- u47, action(swerve_right), curr_lane, free_E.

