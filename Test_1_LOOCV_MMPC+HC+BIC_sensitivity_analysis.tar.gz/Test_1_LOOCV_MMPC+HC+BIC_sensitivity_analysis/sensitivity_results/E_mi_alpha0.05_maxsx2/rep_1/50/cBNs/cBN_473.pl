%%% Exogenous variables

0.1655442::u_action(change_to_left); 0.1709027::u_action(change_to_right); 0.4071223::u_action(cruise); 0.2540636::u_action(keep); 0.0015029::u_action(swerve_left); 0.0008642::u_action(swerve_right)
action(V) :- u_action(V).

0.3976755::u1.
free_NW :- u1.

0.5934009::u2.
free_SE :- u2.

0.6861313::u3.
free_SW :- u3.

0.7101876::u4.
free_W :- u4.

0.3886078::u5.
latent_collision :- u5.

0.4785173::u6.
curr_lane :- u6, action(change_to_left).

0.5074286::u7.
curr_lane :- u7, action(change_to_right).

0.6541408::u8.
curr_lane :- u8, action(cruise).

0.3623047::u9.
curr_lane :- u9, action(keep).

0.8190541::u10.
curr_lane :- u10, action(swerve_left).

0.9928486::u11.
curr_lane :- u11, action(swerve_right).

0.5132923::u12.
free_E :- u12, action(change_to_left), \+ curr_lane.

0.4986662::u13.
free_E :- u13, action(change_to_right), \+ curr_lane.

0.5378797::u14.
free_E :- u14, action(cruise), \+ curr_lane.

0.5938074::u15.
free_E :- u15, action(keep), \+ curr_lane.

0.8068182::u16.
free_E :- u16, action(swerve_left), \+ curr_lane.

0.9990010::u17.
free_E :- u17, action(swerve_right), \+ curr_lane.

0.5270536::u18.
free_E :- u18, action(change_to_left), curr_lane.

0.5244866::u19.
free_E :- u19, action(change_to_right), curr_lane.

0.8998414::u20.
free_E :- u20, action(cruise), curr_lane.

0.8987142::u21.
free_E :- u21, action(keep), curr_lane.

0.9832636::u22.
free_E :- u22, action(swerve_left), curr_lane.

0.9963986::u23.
free_E :- u23, action(swerve_right), curr_lane.

0.4916646::u24.
free_NE :- u24, action(change_to_left), \+ curr_lane, \+ free_E.

0.5107271::u25.
free_NE :- u25, action(change_to_right), \+ curr_lane, \+ free_E.

0.5310432::u26.
free_NE :- u26, action(cruise), \+ curr_lane, \+ free_E.

0.2591566::u27.
free_NE :- u27, action(keep), \+ curr_lane, \+ free_E.

0.3921569::u28.
free_NE :- u28, action(swerve_left), \+ curr_lane, \+ free_E.

0.5000000::u29.
free_NE :- u29, action(swerve_right), \+ curr_lane, \+ free_E.

0.4959171::u30.
free_NE :- u30, action(change_to_left), curr_lane, \+ free_E.

0.5019359::u31.
free_NE :- u31, action(change_to_right), curr_lane, \+ free_E.

0.2266461::u32.
free_NE :- u32, action(cruise), curr_lane, \+ free_E.

0.0002210::u33.
free_NE :- u33, action(keep), curr_lane, \+ free_E.

0.0500000::u34.
free_NE :- u34, action(swerve_left), curr_lane, \+ free_E.

0.6666667::u35.
free_NE :- u35, action(swerve_right), curr_lane, \+ free_E.

0.4757776::u36.
free_NE :- u36, action(change_to_left), \+ curr_lane, free_E.

0.4908105::u37.
free_NE :- u37, action(change_to_right), \+ curr_lane, free_E.

0.4389604::u38.
free_NE :- u38, action(cruise), \+ curr_lane, free_E.

0.0118526::u39.
free_NE :- u39, action(keep), \+ curr_lane, free_E.

0.7699531::u40.
free_NE :- u40, action(swerve_left), \+ curr_lane, free_E.

0.9990010::u41.
free_NE :- u41, action(swerve_right), \+ curr_lane, free_E.

0.5429784::u42.
free_NE :- u42, action(change_to_left), curr_lane, free_E.

0.5677371::u43.
free_NE :- u43, action(change_to_right), curr_lane, free_E.

0.9058566::u44.
free_NE :- u44, action(cruise), curr_lane, free_E.

0.0046321::u45.
free_NE :- u45, action(keep), curr_lane, free_E.

0.9217021::u46.
free_NE :- u46, action(swerve_left), curr_lane, free_E.

0.8457831::u47.
free_NE :- u47, action(swerve_right), curr_lane, free_E.

