%%% Exogenous variables

0.1682191::u_action(change_to_left); 0.1702857::u_action(change_to_right); 0.4058852::u_action(cruise); 0.2533091::u_action(keep); 0.0014562::u_action(swerve_left); 0.0008447::u_action(swerve_right)
action(V) :- u_action(V).

0.3982754::u1.
free_NW :- u1.

0.5949637::u2.
free_SE :- u2.

0.6775708::u3.
free_SW :- u3.

0.7178457::u4.
free_W :- u4.

0.3858181::u5.
latent_collision :- u5.

0.4891687::u6.
curr_lane :- u6, action(change_to_left).

0.5088321::u7.
curr_lane :- u7, action(change_to_right).

0.6534806::u8.
curr_lane :- u8, action(cruise).

0.3609853::u9.
curr_lane :- u9, action(keep).

0.8158080::u10.
curr_lane :- u10, action(swerve_left).

0.9975669::u11.
curr_lane :- u11, action(swerve_right).

0.5117258::u12.
free_E :- u12, action(change_to_left), \+ curr_lane.

0.4974812::u13.
free_E :- u13, action(change_to_right), \+ curr_lane.

0.5368181::u14.
free_E :- u14, action(cruise), \+ curr_lane.

0.5937960::u15.
free_E :- u15, action(keep), \+ curr_lane.

0.8160920::u16.
free_E :- u16, action(swerve_left), \+ curr_lane.

0.9990010::u17.
free_E :- u17, action(swerve_right), \+ curr_lane.

0.5479125::u18.
free_E :- u18, action(change_to_left), curr_lane.

0.5227895::u19.
free_E :- u19, action(change_to_right), curr_lane.

0.8998411::u20.
free_E :- u20, action(cruise), curr_lane.

0.8995505::u21.
free_E :- u21, action(keep), curr_lane.

0.9809689::u22.
free_E :- u22, action(swerve_left), curr_lane.

0.9939024::u23.
free_E :- u23, action(swerve_right), curr_lane.

0.4915134::u24.
free_NE :- u24, action(change_to_left), \+ curr_lane, \+ free_E.

0.5065405::u25.
free_NE :- u25, action(change_to_right), \+ curr_lane, \+ free_E.

0.5321492::u26.
free_NE :- u26, action(cruise), \+ curr_lane, \+ free_E.

0.2616673::u27.
free_NE :- u27, action(keep), \+ curr_lane, \+ free_E.

0.5000000::u28.
free_NE :- u28, action(swerve_left), \+ curr_lane, \+ free_E.

0.5000000::u29.
free_NE :- u29, action(swerve_right), \+ curr_lane, \+ free_E.

0.5008564::u30.
free_NE :- u30, action(change_to_left), curr_lane, \+ free_E.

0.5018391::u31.
free_NE :- u31, action(change_to_right), curr_lane, \+ free_E.

0.2256779::u32.
free_NE :- u32, action(cruise), curr_lane, \+ free_E.

0.0003356::u33.
free_NE :- u33, action(keep), curr_lane, \+ free_E.

0.0454545::u34.
free_NE :- u34, action(swerve_left), curr_lane, \+ free_E.

0.4000000::u35.
free_NE :- u35, action(swerve_right), curr_lane, \+ free_E.

0.4761159::u36.
free_NE :- u36, action(change_to_left), \+ curr_lane, free_E.

0.4887994::u37.
free_NE :- u37, action(change_to_right), \+ curr_lane, free_E.

0.4402205::u38.
free_NE :- u38, action(cruise), \+ curr_lane, free_E.

0.0125200::u39.
free_NE :- u39, action(keep), \+ curr_lane, free_E.

0.7840376::u40.
free_NE :- u40, action(swerve_left), \+ curr_lane, free_E.

0.9990010::u41.
free_NE :- u41, action(swerve_right), \+ curr_lane, free_E.

0.5042965::u42.
free_NE :- u42, action(change_to_left), curr_lane, free_E.

0.5683659::u43.
free_NE :- u43, action(change_to_right), curr_lane, free_E.

0.9081891::u44.
free_NE :- u44, action(cruise), curr_lane, free_E.

0.0048724::u45.
free_NE :- u45, action(keep), curr_lane, free_E.

0.9029982::u46.
free_NE :- u46, action(swerve_left), curr_lane, free_E.

0.8576687::u47.
free_NE :- u47, action(swerve_right), curr_lane, free_E.

