%%% Exogenous variables

0.1688104::u_action(change_to_left); 0.1699492::u_action(change_to_right); 0.4048254::u_action(cruise); 0.2540493::u_action(keep); 0.0014849::u_action(swerve_left); 0.0008807::u_action(swerve_right)
action(V) :- u_action(V).

0.4012625::u1.
free_NW :- u1.

0.5996684::u2.
free_SE :- u2.

0.6819978::u3.
free_SW :- u3.

0.7120213::u4.
free_W :- u4.

0.3875519::u5.
latent_collision :- u5.

0.4932540::u6.
curr_lane :- u6, action(change_to_left).

0.5078277::u7.
curr_lane :- u7, action(change_to_right).

0.6540113::u8.
curr_lane :- u8, action(cruise).

0.3661129::u9.
curr_lane :- u9, action(keep).

0.8193103::u10.
curr_lane :- u10, action(swerve_left).

0.9941860::u11.
curr_lane :- u11, action(swerve_right).

0.5124445::u12.
free_E :- u12, action(change_to_left), \+ curr_lane.

0.4957760::u13.
free_E :- u13, action(change_to_right), \+ curr_lane.

0.5367079::u14.
free_E :- u14, action(cruise), \+ curr_lane.

0.5942423::u15.
free_E :- u15, action(keep), \+ curr_lane.

0.8282443::u16.
free_E :- u16, action(swerve_left), \+ curr_lane.

0.9990010::u17.
free_E :- u17, action(swerve_right), \+ curr_lane.

0.5541712::u18.
free_E :- u18, action(change_to_left), curr_lane.

0.5241237::u19.
free_E :- u19, action(change_to_right), curr_lane.

0.8998608::u20.
free_E :- u20, action(cruise), curr_lane.

0.9003766::u21.
free_E :- u21, action(keep), curr_lane.

0.9848485::u22.
free_E :- u22, action(swerve_left), curr_lane.

0.9953216::u23.
free_E :- u23, action(swerve_right), curr_lane.

0.4939351::u24.
free_NE :- u24, action(change_to_left), \+ curr_lane, \+ free_E.

0.5153097::u25.
free_NE :- u25, action(change_to_right), \+ curr_lane, \+ free_E.

0.5297330::u26.
free_NE :- u26, action(cruise), \+ curr_lane, \+ free_E.

0.2616880::u27.
free_NE :- u27, action(keep), \+ curr_lane, \+ free_E.

0.3111111::u28.
free_NE :- u28, action(swerve_left), \+ curr_lane, \+ free_E.

0.5000000::u29.
free_NE :- u29, action(swerve_right), \+ curr_lane, \+ free_E.

0.4994896::u30.
free_NE :- u30, action(change_to_left), curr_lane, \+ free_E.

0.5015709::u31.
free_NE :- u31, action(change_to_right), curr_lane, \+ free_E.

0.2257716::u32.
free_NE :- u32, action(cruise), curr_lane, \+ free_E.

0.0004421::u33.
free_NE :- u33, action(keep), curr_lane, \+ free_E.

0.0009990::u34.
free_NE :- u34, action(swerve_left), curr_lane, \+ free_E.

0.5000000::u35.
free_NE :- u35, action(swerve_right), curr_lane, \+ free_E.

0.4759491::u36.
free_NE :- u36, action(change_to_left), \+ curr_lane, free_E.

0.4906033::u37.
free_NE :- u37, action(change_to_right), \+ curr_lane, free_E.

0.4424903::u38.
free_NE :- u38, action(cruise), \+ curr_lane, free_E.

0.0121677::u39.
free_NE :- u39, action(keep), \+ curr_lane, free_E.

0.8525346::u40.
free_NE :- u40, action(swerve_left), \+ curr_lane, free_E.

0.9990010::u41.
free_NE :- u41, action(swerve_right), \+ curr_lane, free_E.

0.4908118::u42.
free_NE :- u42, action(change_to_left), curr_lane, free_E.

0.5408875::u43.
free_NE :- u43, action(change_to_right), curr_lane, free_E.

0.9000692::u44.
free_NE :- u44, action(cruise), curr_lane, free_E.

0.0046103::u45.
free_NE :- u45, action(keep), curr_lane, free_E.

0.9128205::u46.
free_NE :- u46, action(swerve_left), curr_lane, free_E.

0.8542891::u47.
free_NE :- u47, action(swerve_right), curr_lane, free_E.

