%%% Exogenous variables

0.1675778::u_action(change_to_left); 0.1703133::u_action(change_to_right); 0.4051496::u_action(cruise); 0.2546357::u_action(keep); 0.0014646::u_action(swerve_left); 0.0008589::u_action(swerve_right)
action(V) :- u_action(V).

0.4039915::u1.
free_NW :- u1.

0.5991079::u2.
free_SE :- u2.

0.6827641::u3.
free_SW :- u3.

0.7155093::u4.
free_W :- u4.

0.3853748::u5.
latent_collision :- u5.

0.4978869::u6.
curr_lane :- u6, action(change_to_left).

0.5152252::u7.
curr_lane :- u7, action(change_to_right).

0.6570360::u8.
curr_lane :- u8, action(cruise).

0.3661630::u9.
curr_lane :- u9, action(keep).

0.8229531::u10.
curr_lane :- u10, action(swerve_left).

0.9928401::u11.
curr_lane :- u11, action(swerve_right).

0.5206889::u12.
free_E :- u12, action(change_to_left), \+ curr_lane.

0.5049531::u13.
free_E :- u13, action(change_to_right), \+ curr_lane.

0.5408083::u14.
free_E :- u14, action(cruise), \+ curr_lane.

0.5950544::u15.
free_E :- u15, action(keep), \+ curr_lane.

0.8498024::u16.
free_E :- u16, action(swerve_left), \+ curr_lane.

0.9990010::u17.
free_E :- u17, action(swerve_right), \+ curr_lane.

0.5546520::u18.
free_E :- u18, action(change_to_left), curr_lane.

0.5304032::u19.
free_E :- u19, action(change_to_right), curr_lane.

0.9003138::u20.
free_E :- u20, action(cruise), curr_lane.

0.9015620::u21.
free_E :- u21, action(keep), curr_lane.

0.9812925::u22.
free_E :- u22, action(swerve_left), curr_lane.

0.9951923::u23.
free_E :- u23, action(swerve_right), curr_lane.

0.4781957::u24.
free_NE :- u24, action(change_to_left), \+ curr_lane, \+ free_E.

0.4970787::u25.
free_NE :- u25, action(change_to_right), \+ curr_lane, \+ free_E.

0.5255084::u26.
free_NE :- u26, action(cruise), \+ curr_lane, \+ free_E.

0.2621221::u27.
free_NE :- u27, action(keep), \+ curr_lane, \+ free_E.

0.4210526::u28.
free_NE :- u28, action(swerve_left), \+ curr_lane, \+ free_E.

0.5000000::u29.
free_NE :- u29, action(swerve_right), \+ curr_lane, \+ free_E.

0.4960004::u30.
free_NE :- u30, action(change_to_left), curr_lane, \+ free_E.

0.5017038::u31.
free_NE :- u31, action(change_to_right), curr_lane, \+ free_E.

0.2264880::u32.
free_NE :- u32, action(cruise), curr_lane, \+ free_E.

0.0004467::u33.
free_NE :- u33, action(keep), curr_lane, \+ free_E.

0.0454545::u34.
free_NE :- u34, action(swerve_left), curr_lane, \+ free_E.

0.7500000::u35.
free_NE :- u35, action(swerve_right), curr_lane, \+ free_E.

0.4741385::u36.
free_NE :- u36, action(change_to_left), \+ curr_lane, free_E.

0.4907933::u37.
free_NE :- u37, action(change_to_right), \+ curr_lane, free_E.

0.4404997::u38.
free_NE :- u38, action(cruise), \+ curr_lane, free_E.

0.0120164::u39.
free_NE :- u39, action(keep), \+ curr_lane, free_E.

0.7953488::u40.
free_NE :- u40, action(swerve_left), \+ curr_lane, free_E.

0.9990010::u41.
free_NE :- u41, action(swerve_right), \+ curr_lane, free_E.

0.4893914::u42.
free_NE :- u42, action(change_to_left), curr_lane, free_E.

0.5538526::u43.
free_NE :- u43, action(change_to_right), curr_lane, free_E.

0.9014686::u44.
free_NE :- u44, action(cruise), curr_lane, free_E.

0.0044991::u45.
free_NE :- u45, action(keep), curr_lane, free_E.

0.9072790::u46.
free_NE :- u46, action(swerve_left), curr_lane, free_E.

0.8586957::u47.
free_NE :- u47, action(swerve_right), curr_lane, free_E.

