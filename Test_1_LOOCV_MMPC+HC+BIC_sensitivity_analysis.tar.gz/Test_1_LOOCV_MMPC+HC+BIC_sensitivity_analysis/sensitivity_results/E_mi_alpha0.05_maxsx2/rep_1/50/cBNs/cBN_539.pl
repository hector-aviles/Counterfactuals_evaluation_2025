%%% Exogenous variables

0.1682316::u_action(change_to_left); 0.1701553::u_action(change_to_right); 0.4049272::u_action(cruise); 0.2543982::u_action(keep); 0.0014062::u_action(swerve_left); 0.0008814::u_action(swerve_right)
action(V) :- u_action(V).

0.4041585::u1.
free_NW :- u1.

0.5948155::u2.
free_SE :- u2.

0.6788831::u3.
free_SW :- u3.

0.7156883::u4.
free_W :- u4.

0.3858462::u5.
latent_collision :- u5.

0.4973925::u6.
curr_lane :- u6, action(change_to_left).

0.5138932::u7.
curr_lane :- u7, action(change_to_right).

0.6563649::u8.
curr_lane :- u8, action(cruise).

0.3668290::u9.
curr_lane :- u9, action(keep).

0.8155977::u10.
curr_lane :- u10, action(swerve_left).

0.9906977::u11.
curr_lane :- u11, action(swerve_right).

0.5184853::u12.
free_E :- u12, action(change_to_left), \+ curr_lane.

0.5031598::u13.
free_E :- u13, action(change_to_right), \+ curr_lane.

0.5415982::u14.
free_E :- u14, action(cruise), \+ curr_lane.

0.5939425::u15.
free_E :- u15, action(keep), \+ curr_lane.

0.7984190::u16.
free_E :- u16, action(swerve_left), \+ curr_lane.

0.9990010::u17.
free_E :- u17, action(swerve_right), \+ curr_lane.

0.5528649::u18.
free_E :- u18, action(change_to_left), curr_lane.

0.5333294::u19.
free_E :- u19, action(change_to_right), curr_lane.

0.8995858::u20.
free_E :- u20, action(cruise), curr_lane.

0.9012971::u21.
free_E :- u21, action(keep), curr_lane.

0.9812332::u22.
free_E :- u22, action(swerve_left), curr_lane.

0.9953052::u23.
free_E :- u23, action(swerve_right), curr_lane.

0.4736935::u24.
free_NE :- u24, action(change_to_left), \+ curr_lane, \+ free_E.

0.4950868::u25.
free_NE :- u25, action(change_to_right), \+ curr_lane, \+ free_E.

0.5221101::u26.
free_NE :- u26, action(cruise), \+ curr_lane, \+ free_E.

0.2604049::u27.
free_NE :- u27, action(keep), \+ curr_lane, \+ free_E.

0.4117647::u28.
free_NE :- u28, action(swerve_left), \+ curr_lane, \+ free_E.

0.5000000::u29.
free_NE :- u29, action(swerve_right), \+ curr_lane, \+ free_E.

0.4986440::u30.
free_NE :- u30, action(change_to_left), curr_lane, \+ free_E.

0.5051741::u31.
free_NE :- u31, action(change_to_right), curr_lane, \+ free_E.

0.2252391::u32.
free_NE :- u32, action(cruise), curr_lane, \+ free_E.

0.0002225::u33.
free_NE :- u33, action(keep), curr_lane, \+ free_E.

0.0476190::u34.
free_NE :- u34, action(swerve_left), curr_lane, \+ free_E.

0.5000000::u35.
free_NE :- u35, action(swerve_right), curr_lane, \+ free_E.

0.4723664::u36.
free_NE :- u36, action(change_to_left), \+ curr_lane, free_E.

0.4933507::u37.
free_NE :- u37, action(change_to_right), \+ curr_lane, free_E.

0.4406289::u38.
free_NE :- u38, action(cruise), \+ curr_lane, free_E.

0.0130164::u39.
free_NE :- u39, action(keep), \+ curr_lane, free_E.

0.8366337::u40.
free_NE :- u40, action(swerve_left), \+ curr_lane, free_E.

0.9990010::u41.
free_NE :- u41, action(swerve_right), \+ curr_lane, free_E.

0.4879589::u42.
free_NE :- u42, action(change_to_left), curr_lane, free_E.

0.5528670::u43.
free_NE :- u43, action(change_to_right), curr_lane, free_E.

0.9015076::u44.
free_NE :- u44, action(cruise), curr_lane, free_E.

0.0047524::u45.
free_NE :- u45, action(keep), curr_lane, free_E.

0.9061931::u46.
free_NE :- u46, action(swerve_left), curr_lane, free_E.

0.8490566::u47.
free_NE :- u47, action(swerve_right), curr_lane, free_E.

