%%% Exogenous variables

0.1674528::u_action(change_to_left); 0.1715309::u_action(change_to_right); 0.4049013::u_action(cruise); 0.2538140::u_action(keep); 0.0014361::u_action(swerve_left); 0.0008650::u_action(swerve_right)
action(V) :- u_action(V).

0.4034600::u1.
free_NW :- u1.

0.5987489::u2.
free_SE :- u2.

0.6819646::u3.
free_SW :- u3.

0.7118755::u4.
free_W :- u4.

0.3868580::u5.
latent_collision :- u5.

0.4972981::u6.
curr_lane :- u6, action(change_to_left).

0.5125258::u7.
curr_lane :- u7, action(change_to_right).

0.6569985::u8.
curr_lane :- u8, action(cruise).

0.3665727::u9.
curr_lane :- u9, action(keep).

0.8104063::u10.
curr_lane :- u10, action(swerve_left).

0.9893491::u11.
curr_lane :- u11, action(swerve_right).

0.5038851::u12.
free_E :- u12, action(change_to_left), \+ curr_lane.

0.4971844::u13.
free_E :- u13, action(change_to_right), \+ curr_lane.

0.5328572::u14.
free_E :- u14, action(cruise), \+ curr_lane.

0.5947767::u15.
free_E :- u15, action(keep), \+ curr_lane.

0.7781955::u16.
free_E :- u16, action(swerve_left), \+ curr_lane.

0.9990010::u17.
free_E :- u17, action(swerve_right), \+ curr_lane.

0.5532187::u18.
free_E :- u18, action(change_to_left), curr_lane.

0.5313089::u19.
free_E :- u19, action(change_to_right), curr_lane.

0.9000435::u20.
free_E :- u20, action(cruise), curr_lane.

0.9008196::u21.
free_E :- u21, action(keep), curr_lane.

0.9806508::u22.
free_E :- u22, action(swerve_left), curr_lane.

0.9940191::u23.
free_E :- u23, action(swerve_right), curr_lane.

0.4893747::u24.
free_NE :- u24, action(change_to_left), \+ curr_lane, \+ free_E.

0.5095681::u25.
free_NE :- u25, action(change_to_right), \+ curr_lane, \+ free_E.

0.5302693::u26.
free_NE :- u26, action(cruise), \+ curr_lane, \+ free_E.

0.2627816::u27.
free_NE :- u27, action(keep), \+ curr_lane, \+ free_E.

0.4745763::u28.
free_NE :- u28, action(swerve_left), \+ curr_lane, \+ free_E.

0.5000000::u29.
free_NE :- u29, action(swerve_right), \+ curr_lane, \+ free_E.

0.5010317::u30.
free_NE :- u30, action(change_to_left), curr_lane, \+ free_E.

0.5027575::u31.
free_NE :- u31, action(change_to_right), curr_lane, \+ free_E.

0.2240059::u32.
free_NE :- u32, action(cruise), curr_lane, \+ free_E.

0.0002219::u33.
free_NE :- u33, action(keep), curr_lane, \+ free_E.

0.0009990::u34.
free_NE :- u34, action(swerve_left), curr_lane, \+ free_E.

0.4000000::u35.
free_NE :- u35, action(swerve_right), curr_lane, \+ free_E.

0.4605435::u36.
free_NE :- u36, action(change_to_left), \+ curr_lane, free_E.

0.4891171::u37.
free_NE :- u37, action(change_to_right), \+ curr_lane, free_E.

0.4302530::u38.
free_NE :- u38, action(cruise), \+ curr_lane, free_E.

0.0121497::u39.
free_NE :- u39, action(keep), \+ curr_lane, free_E.

0.8164251::u40.
free_NE :- u40, action(swerve_left), \+ curr_lane, free_E.

0.9990010::u41.
free_NE :- u41, action(swerve_right), \+ curr_lane, free_E.

0.4916233::u42.
free_NE :- u42, action(change_to_left), curr_lane, free_E.

0.5550053::u43.
free_NE :- u43, action(change_to_right), curr_lane, free_E.

0.9012723::u44.
free_NE :- u44, action(cruise), curr_lane, free_E.

0.0045188::u45.
free_NE :- u45, action(keep), curr_lane, free_E.

0.9040359::u46.
free_NE :- u46, action(swerve_left), curr_lane, free_E.

0.8592058::u47.
free_NE :- u47, action(swerve_right), curr_lane, free_E.

