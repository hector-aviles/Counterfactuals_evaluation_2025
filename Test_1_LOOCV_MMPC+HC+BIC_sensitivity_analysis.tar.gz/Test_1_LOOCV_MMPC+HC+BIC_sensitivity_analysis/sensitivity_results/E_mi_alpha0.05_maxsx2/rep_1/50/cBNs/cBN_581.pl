%%% Exogenous variables

0.1679998::u_action(change_to_left); 0.1705118::u_action(change_to_right); 0.4046788::u_action(cruise); 0.2544513::u_action(keep); 0.0015066::u_action(swerve_left); 0.0008517::u_action(swerve_right)
action(V) :- u_action(V).

0.4004079::u1.
free_NW :- u1.

0.5999713::u2.
free_SE :- u2.

0.6821202::u3.
free_SW :- u3.

0.7154251::u4.
free_W :- u4.

0.3859380::u5.
latent_collision :- u5.

0.4903364::u6.
curr_lane :- u6, action(change_to_left).

0.5080696::u7.
curr_lane :- u7, action(change_to_right).

0.6545283::u8.
curr_lane :- u8, action(cruise).

0.3676222::u9.
curr_lane :- u9, action(keep).

0.8108844::u10.
curr_lane :- u10, action(swerve_left).

0.9963899::u11.
curr_lane :- u11, action(swerve_right).

0.5133767::u12.
free_E :- u12, action(change_to_left), \+ curr_lane.

0.4986315::u13.
free_E :- u13, action(change_to_right), \+ curr_lane.

0.5374803::u14.
free_E :- u14, action(cruise), \+ curr_lane.

0.5946776::u15.
free_E :- u15, action(keep), \+ curr_lane.

0.8273381::u16.
free_E :- u16, action(swerve_left), \+ curr_lane.

0.9990010::u17.
free_E :- u17, action(swerve_right), \+ curr_lane.

0.5625521::u18.
free_E :- u18, action(change_to_left), curr_lane.

0.5394972::u19.
free_E :- u19, action(change_to_right), curr_lane.

0.9046867::u20.
free_E :- u20, action(cruise), curr_lane.

0.9015635::u21.
free_E :- u21, action(keep), curr_lane.

0.9840604::u22.
free_E :- u22, action(swerve_left), curr_lane.

0.9975845::u23.
free_E :- u23, action(swerve_right), curr_lane.

0.4908371::u24.
free_NE :- u24, action(change_to_left), \+ curr_lane, \+ free_E.

0.5107721::u25.
free_NE :- u25, action(change_to_right), \+ curr_lane, \+ free_E.

0.5306705::u26.
free_NE :- u26, action(cruise), \+ curr_lane, \+ free_E.

0.2602382::u27.
free_NE :- u27, action(keep), \+ curr_lane, \+ free_E.

0.3958333::u28.
free_NE :- u28, action(swerve_left), \+ curr_lane, \+ free_E.

0.5000000::u29.
free_NE :- u29, action(swerve_right), \+ curr_lane, \+ free_E.

0.5181888::u30.
free_NE :- u30, action(change_to_left), curr_lane, \+ free_E.

0.5198592::u31.
free_NE :- u31, action(change_to_right), curr_lane, \+ free_E.

0.2370900::u32.
free_NE :- u32, action(cruise), curr_lane, \+ free_E.

0.0003339::u33.
free_NE :- u33, action(keep), curr_lane, \+ free_E.

0.0526316::u34.
free_NE :- u34, action(swerve_left), curr_lane, \+ free_E.

0.5000000::u35.
free_NE :- u35, action(swerve_right), curr_lane, \+ free_E.

0.4750979::u36.
free_NE :- u36, action(change_to_left), \+ curr_lane, free_E.

0.4897569::u37.
free_NE :- u37, action(change_to_right), \+ curr_lane, free_E.

0.4383823::u38.
free_NE :- u38, action(cruise), \+ curr_lane, free_E.

0.0122748::u39.
free_NE :- u39, action(keep), \+ curr_lane, free_E.

0.8043478::u40.
free_NE :- u40, action(swerve_left), \+ curr_lane, free_E.

0.9990010::u41.
free_NE :- u41, action(swerve_right), \+ curr_lane, free_E.

0.4896271::u42.
free_NE :- u42, action(change_to_left), curr_lane, free_E.

0.5552510::u43.
free_NE :- u43, action(change_to_right), curr_lane, free_E.

0.9005518::u44.
free_NE :- u44, action(cruise), curr_lane, free_E.

0.0046911::u45.
free_NE :- u45, action(keep), curr_lane, free_E.

0.9062234::u46.
free_NE :- u46, action(swerve_left), curr_lane, free_E.

0.8498789::u47.
free_NE :- u47, action(swerve_right), curr_lane, free_E.

