%%% Exogenous variables

0.1689256::u_action(change_to_left); 0.1704523::u_action(change_to_right); 0.4070205::u_action(cruise); 0.2512601::u_action(keep); 0.0014999::u_action(swerve_left); 0.0008416::u_action(swerve_right)
action(V) :- u_action(V).

0.4064250::u1.
free_NW :- u1.

0.5941508::u2.
free_SE :- u2.

0.6765389::u3.
free_SW :- u3.

0.7107140::u4.
free_W :- u4.

0.3867904::u5.
latent_collision :- u5.

0.4984267::u6.
curr_lane :- u6, action(change_to_left).

0.5159249::u7.
curr_lane :- u7, action(change_to_right).

0.6576843::u8.
curr_lane :- u8, action(cruise).

0.3743353::u9.
curr_lane :- u9, action(keep).

0.8200549::u10.
curr_lane :- u10, action(swerve_left).

0.9951040::u11.
curr_lane :- u11, action(swerve_right).

0.5208696::u12.
free_E :- u12, action(change_to_left), \+ curr_lane.

0.5069353::u13.
free_E :- u13, action(change_to_right), \+ curr_lane.

0.5449088::u14.
free_E :- u14, action(cruise), \+ curr_lane.

0.6102527::u15.
free_E :- u15, action(keep), \+ curr_lane.

0.8320611::u16.
free_E :- u16, action(swerve_left), \+ curr_lane.

0.9990010::u17.
free_E :- u17, action(swerve_right), \+ curr_lane.

0.5539745::u18.
free_E :- u18, action(change_to_left), curr_lane.

0.5317277::u19.
free_E :- u19, action(change_to_right), curr_lane.

0.9002413::u20.
free_E :- u20, action(cruise), curr_lane.

0.9010438::u21.
free_E :- u21, action(keep), curr_lane.

0.9773869::u22.
free_E :- u22, action(swerve_left), curr_lane.

0.9963100::u23.
free_E :- u23, action(swerve_right), curr_lane.

0.4780248::u24.
free_NE :- u24, action(change_to_left), \+ curr_lane, \+ free_E.

0.4954802::u25.
free_NE :- u25, action(change_to_right), \+ curr_lane, \+ free_E.

0.5195932::u26.
free_NE :- u26, action(cruise), \+ curr_lane, \+ free_E.

0.2073743::u27.
free_NE :- u27, action(keep), \+ curr_lane, \+ free_E.

0.4318182::u28.
free_NE :- u28, action(swerve_left), \+ curr_lane, \+ free_E.

0.5000000::u29.
free_NE :- u29, action(swerve_right), \+ curr_lane, \+ free_E.

0.4985599::u30.
free_NE :- u30, action(change_to_left), curr_lane, \+ free_E.

0.5056410::u31.
free_NE :- u31, action(change_to_right), curr_lane, \+ free_E.

0.2256683::u32.
free_NE :- u32, action(cruise), curr_lane, \+ free_E.

0.0002214::u33.
free_NE :- u33, action(keep), curr_lane, \+ free_E.

0.0009990::u34.
free_NE :- u34, action(swerve_left), curr_lane, \+ free_E.

0.3333333::u35.
free_NE :- u35, action(swerve_right), curr_lane, \+ free_E.

0.4723279::u36.
free_NE :- u36, action(change_to_left), \+ curr_lane, free_E.

0.4911831::u37.
free_NE :- u37, action(change_to_right), \+ curr_lane, free_E.

0.4399186::u38.
free_NE :- u38, action(cruise), \+ curr_lane, free_E.

0.0120051::u39.
free_NE :- u39, action(keep), \+ curr_lane, free_E.

0.8027523::u40.
free_NE :- u40, action(swerve_left), \+ curr_lane, free_E.

0.9990010::u41.
free_NE :- u41, action(swerve_right), \+ curr_lane, free_E.

0.4894651::u42.
free_NE :- u42, action(change_to_left), curr_lane, free_E.

0.5517272::u43.
free_NE :- u43, action(change_to_right), curr_lane, free_E.

0.9010105::u44.
free_NE :- u44, action(cruise), curr_lane, free_E.

0.0043638::u45.
free_NE :- u45, action(keep), curr_lane, free_E.

0.9048843::u46.
free_NE :- u46, action(swerve_left), curr_lane, free_E.

0.8493827::u47.
free_NE :- u47, action(swerve_right), curr_lane, free_E.

