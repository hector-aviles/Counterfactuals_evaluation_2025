%%% Exogenous variables

0.1674917::u_action(change_to_left); 0.1701060::u_action(change_to_right); 0.4062074::u_action(cruise); 0.2539358::u_action(keep); 0.0014300::u_action(swerve_left); 0.0008291::u_action(swerve_right)
action(V) :- u_action(V).

0.4013125::u1.
free_NW :- u1.

0.5988226::u2.
free_SE :- u2.

0.6819687::u3.
free_SW :- u3.

0.7147406::u4.
free_W :- u4.

0.3868969::u5.
latent_collision :- u5.

0.4971949::u6.
curr_lane :- u6, action(change_to_left).

0.5174989::u7.
curr_lane :- u7, action(change_to_right).

0.6537924::u8.
curr_lane :- u8, action(cruise).

0.3660139::u9.
curr_lane :- u9, action(keep).

0.8110236::u10.
curr_lane :- u10, action(swerve_left).

0.9888889::u11.
curr_lane :- u11, action(swerve_right).

0.5191132::u12.
free_E :- u12, action(change_to_left), \+ curr_lane.

0.5029620::u13.
free_E :- u13, action(change_to_right), \+ curr_lane.

0.5369319::u14.
free_E :- u14, action(cruise), \+ curr_lane.

0.5924414::u15.
free_E :- u15, action(keep), \+ curr_lane.

0.8257576::u16.
free_E :- u16, action(swerve_left), \+ curr_lane.

0.9990010::u17.
free_E :- u17, action(swerve_right), \+ curr_lane.

0.5528486::u18.
free_E :- u18, action(change_to_left), curr_lane.

0.5288666::u19.
free_E :- u19, action(change_to_right), curr_lane.

0.9001152::u20.
free_E :- u20, action(cruise), curr_lane.

0.9013546::u21.
free_E :- u21, action(keep), curr_lane.

0.9823477::u22.
free_E :- u22, action(swerve_left), curr_lane.

0.9962547::u23.
free_E :- u23, action(swerve_right), curr_lane.

0.4776312::u24.
free_NE :- u24, action(change_to_left), \+ curr_lane, \+ free_E.

0.4967883::u25.
free_NE :- u25, action(change_to_right), \+ curr_lane, \+ free_E.

0.5303521::u26.
free_NE :- u26, action(cruise), \+ curr_lane, \+ free_E.

0.2618097::u27.
free_NE :- u27, action(keep), \+ curr_lane, \+ free_E.

0.4130435::u28.
free_NE :- u28, action(swerve_left), \+ curr_lane, \+ free_E.

0.5000000::u29.
free_NE :- u29, action(swerve_right), \+ curr_lane, \+ free_E.

0.5001100::u30.
free_NE :- u30, action(change_to_left), curr_lane, \+ free_E.

0.5034677::u31.
free_NE :- u31, action(change_to_right), curr_lane, \+ free_E.

0.2238858::u32.
free_NE :- u32, action(cruise), curr_lane, \+ free_E.

0.0002233::u33.
free_NE :- u33, action(keep), curr_lane, \+ free_E.

0.0500000::u34.
free_NE :- u34, action(swerve_left), curr_lane, \+ free_E.

0.6666667::u35.
free_NE :- u35, action(swerve_right), curr_lane, \+ free_E.

0.4744433::u36.
free_NE :- u36, action(change_to_left), \+ curr_lane, free_E.

0.4887550::u37.
free_NE :- u37, action(change_to_right), \+ curr_lane, free_E.

0.4377508::u38.
free_NE :- u38, action(cruise), \+ curr_lane, free_E.

0.0121381::u39.
free_NE :- u39, action(keep), \+ curr_lane, free_E.

0.8165138::u40.
free_NE :- u40, action(swerve_left), \+ curr_lane, free_E.

0.9990010::u41.
free_NE :- u41, action(swerve_right), \+ curr_lane, free_E.

0.4899615::u42.
free_NE :- u42, action(change_to_left), curr_lane, free_E.

0.5544611::u43.
free_NE :- u43, action(change_to_right), curr_lane, free_E.

0.9014790::u44.
free_NE :- u44, action(cruise), curr_lane, free_E.

0.0047408::u45.
free_NE :- u45, action(keep), curr_lane, free_E.

0.9029650::u46.
free_NE :- u46, action(swerve_left), curr_lane, free_E.

0.8671679::u47.
free_NE :- u47, action(swerve_right), curr_lane, free_E.

