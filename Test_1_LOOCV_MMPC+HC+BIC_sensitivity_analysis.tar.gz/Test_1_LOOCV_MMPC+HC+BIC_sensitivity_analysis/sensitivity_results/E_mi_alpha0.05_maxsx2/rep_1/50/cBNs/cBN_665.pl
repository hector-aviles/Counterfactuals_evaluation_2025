%%% Exogenous variables

0.1682989::u_action(change_to_left); 0.1701505::u_action(change_to_right); 0.4058822::u_action(cruise); 0.2532998::u_action(keep); 0.0014700::u_action(swerve_left); 0.0008986::u_action(swerve_right)
action(V) :- u_action(V).

0.4046964::u1.
free_NW :- u1.

0.5957191::u2.
free_SE :- u2.

0.6782601::u3.
free_SW :- u3.

0.7158058::u4.
free_W :- u4.

0.3859958::u5.
latent_collision :- u5.

0.4902416::u6.
curr_lane :- u6, action(change_to_left).

0.5092332::u7.
curr_lane :- u7, action(change_to_right).

0.6551410::u8.
curr_lane :- u8, action(cruise).

0.3648542::u9.
curr_lane :- u9, action(keep).

0.8255408::u10.
curr_lane :- u10, action(swerve_left).

0.9920091::u11.
curr_lane :- u11, action(swerve_right).

0.5121304::u12.
free_E :- u12, action(change_to_left), \+ curr_lane.

0.4955346::u13.
free_E :- u13, action(change_to_right), \+ curr_lane.

0.5380432::u14.
free_E :- u14, action(cruise), \+ curr_lane.

0.5941186::u15.
free_E :- u15, action(keep), \+ curr_lane.

0.8040000::u16.
free_E :- u16, action(swerve_left), \+ curr_lane.

0.9990010::u17.
free_E :- u17, action(swerve_right), \+ curr_lane.

0.5604680::u18.
free_E :- u18, action(change_to_left), curr_lane.

0.5377667::u19.
free_E :- u19, action(change_to_right), curr_lane.

0.9048989::u20.
free_E :- u20, action(cruise), curr_lane.

0.9097700::u21.
free_E :- u21, action(keep), curr_lane.

0.9830938::u22.
free_E :- u22, action(swerve_left), curr_lane.

0.9953970::u23.
free_E :- u23, action(swerve_right), curr_lane.

0.4914710::u24.
free_NE :- u24, action(change_to_left), \+ curr_lane, \+ free_E.

0.5113113::u25.
free_NE :- u25, action(change_to_right), \+ curr_lane, \+ free_E.

0.5316020::u26.
free_NE :- u26, action(cruise), \+ curr_lane, \+ free_E.

0.2604154::u27.
free_NE :- u27, action(keep), \+ curr_lane, \+ free_E.

0.4693878::u28.
free_NE :- u28, action(swerve_left), \+ curr_lane, \+ free_E.

0.5000000::u29.
free_NE :- u29, action(swerve_right), \+ curr_lane, \+ free_E.

0.5185845::u30.
free_NE :- u30, action(change_to_left), curr_lane, \+ free_E.

0.5174039::u31.
free_NE :- u31, action(change_to_right), curr_lane, \+ free_E.

0.2319082::u32.
free_NE :- u32, action(cruise), curr_lane, \+ free_E.

0.0002460::u33.
free_NE :- u33, action(keep), curr_lane, \+ free_E.

0.0009990::u34.
free_NE :- u34, action(swerve_left), curr_lane, \+ free_E.

0.7500000::u35.
free_NE :- u35, action(swerve_right), curr_lane, \+ free_E.

0.4748430::u36.
free_NE :- u36, action(change_to_left), \+ curr_lane, free_E.

0.4920670::u37.
free_NE :- u37, action(change_to_right), \+ curr_lane, free_E.

0.4380380::u38.
free_NE :- u38, action(cruise), \+ curr_lane, free_E.

0.0123205::u39.
free_NE :- u39, action(keep), \+ curr_lane, free_E.

0.8059701::u40.
free_NE :- u40, action(swerve_left), \+ curr_lane, free_E.

0.9990010::u41.
free_NE :- u41, action(swerve_right), \+ curr_lane, free_E.

0.4880987::u42.
free_NE :- u42, action(change_to_left), curr_lane, free_E.

0.5532440::u43.
free_NE :- u43, action(change_to_right), curr_lane, free_E.

0.9009878::u44.
free_NE :- u44, action(cruise), curr_lane, free_E.

0.0047338::u45.
free_NE :- u45, action(keep), curr_lane, free_E.

0.9079966::u46.
free_NE :- u46, action(swerve_left), curr_lane, free_E.

0.8647399::u47.
free_NE :- u47, action(swerve_right), curr_lane, free_E.

