%%% Exogenous variables

0.1681427::u_action(change_to_left); 0.1712372::u_action(change_to_right); 0.4038800::u_action(cruise); 0.2544072::u_action(keep); 0.0014628::u_action(swerve_left); 0.0008701::u_action(swerve_right)
action(V) :- u_action(V).

0.4034982::u1.
free_NW :- u1.

0.5989964::u2.
free_SE :- u2.

0.6795132::u3.
free_SW :- u3.

0.7150885::u4.
free_W :- u4.

0.3862715::u5.
latent_collision :- u5.

0.4969104::u6.
curr_lane :- u6, action(change_to_left).

0.5115014::u7.
curr_lane :- u7, action(change_to_right).

0.6567965::u8.
curr_lane :- u8, action(cruise).

0.3672777::u9.
curr_lane :- u9, action(keep).

0.8159552::u10.
curr_lane :- u10, action(swerve_left).

0.9894118::u11.
curr_lane :- u11, action(swerve_right).

0.5062441::u12.
free_E :- u12, action(change_to_left), \+ curr_lane.

0.4986539::u13.
free_E :- u13, action(change_to_right), \+ curr_lane.

0.5328144::u14.
free_E :- u14, action(cruise), \+ curr_lane.

0.5946405::u15.
free_E :- u15, action(keep), \+ curr_lane.

0.8441065::u16.
free_E :- u16, action(swerve_left), \+ curr_lane.

0.9990010::u17.
free_E :- u17, action(swerve_right), \+ curr_lane.

0.5546598::u18.
free_E :- u18, action(change_to_left), curr_lane.

0.5298016::u19.
free_E :- u19, action(change_to_right), curr_lane.

0.9002057::u20.
free_E :- u20, action(cruise), curr_lane.

0.8994862::u21.
free_E :- u21, action(keep), curr_lane.

0.9845626::u22.
free_E :- u22, action(swerve_left), curr_lane.

0.9976219::u23.
free_E :- u23, action(swerve_right), curr_lane.

0.4951107::u24.
free_NE :- u24, action(change_to_left), \+ curr_lane, \+ free_E.

0.5085064::u25.
free_NE :- u25, action(change_to_right), \+ curr_lane, \+ free_E.

0.5332817::u26.
free_NE :- u26, action(cruise), \+ curr_lane, \+ free_E.

0.2596323::u27.
free_NE :- u27, action(keep), \+ curr_lane, \+ free_E.

0.4146341::u28.
free_NE :- u28, action(swerve_left), \+ curr_lane, \+ free_E.

0.5000000::u29.
free_NE :- u29, action(swerve_right), \+ curr_lane, \+ free_E.

0.4969739::u30.
free_NE :- u30, action(change_to_left), curr_lane, \+ free_E.

0.5060771::u31.
free_NE :- u31, action(change_to_right), curr_lane, \+ free_E.

0.2282201::u32.
free_NE :- u32, action(cruise), curr_lane, \+ free_E.

0.0003270::u33.
free_NE :- u33, action(keep), curr_lane, \+ free_E.

0.0009990::u34.
free_NE :- u34, action(swerve_left), curr_lane, \+ free_E.

0.5000000::u35.
free_NE :- u35, action(swerve_right), curr_lane, \+ free_E.

0.4550974::u36.
free_NE :- u36, action(change_to_left), \+ curr_lane, free_E.

0.4920121::u37.
free_NE :- u37, action(change_to_right), \+ curr_lane, free_E.

0.4283437::u38.
free_NE :- u38, action(cruise), \+ curr_lane, free_E.

0.0124373::u39.
free_NE :- u39, action(keep), \+ curr_lane, free_E.

0.8153153::u40.
free_NE :- u40, action(swerve_left), \+ curr_lane, free_E.

0.9990010::u41.
free_NE :- u41, action(swerve_right), \+ curr_lane, free_E.

0.4853886::u42.
free_NE :- u42, action(change_to_left), curr_lane, free_E.

0.5526658::u43.
free_NE :- u43, action(change_to_right), curr_lane, free_E.

0.9015269::u44.
free_NE :- u44, action(cruise), curr_lane, free_E.

0.0045064::u45.
free_NE :- u45, action(keep), curr_lane, free_E.

0.9067944::u46.
free_NE :- u46, action(swerve_left), curr_lane, free_E.

0.8533969::u47.
free_NE :- u47, action(swerve_right), curr_lane, free_E.

