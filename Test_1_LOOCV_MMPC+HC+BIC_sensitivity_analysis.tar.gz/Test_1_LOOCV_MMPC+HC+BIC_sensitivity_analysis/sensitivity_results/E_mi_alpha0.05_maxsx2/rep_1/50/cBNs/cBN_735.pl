%%% Exogenous variables

0.1676388::u_action(change_to_left); 0.1699982::u_action(change_to_right); 0.4057306::u_action(cruise); 0.2542894::u_action(keep); 0.0015108::u_action(swerve_left); 0.0008322::u_action(swerve_right)
action(V) :- u_action(V).

0.4010128::u1.
free_NW :- u1.

0.5972021::u2.
free_SE :- u2.

0.6790899::u3.
free_SW :- u3.

0.7143082::u4.
free_W :- u4.

0.3864775::u5.
latent_collision :- u5.

0.4968676::u6.
curr_lane :- u6, action(change_to_left).

0.5166278::u7.
curr_lane :- u7, action(change_to_right).

0.6552683::u8.
curr_lane :- u8, action(cruise).

0.3684668::u9.
curr_lane :- u9, action(keep).

0.8265583::u10.
curr_lane :- u10, action(swerve_left).

0.9901599::u11.
curr_lane :- u11, action(swerve_right).

0.5206495::u12.
free_E :- u12, action(change_to_left), \+ curr_lane.

0.5039301::u13.
free_E :- u13, action(change_to_right), \+ curr_lane.

0.5383703::u14.
free_E :- u14, action(cruise), \+ curr_lane.

0.5928752::u15.
free_E :- u15, action(keep), \+ curr_lane.

0.8046875::u16.
free_E :- u16, action(swerve_left), \+ curr_lane.

0.9990010::u17.
free_E :- u17, action(swerve_right), \+ curr_lane.

0.5533777::u18.
free_E :- u18, action(change_to_left), curr_lane.

0.5320979::u19.
free_E :- u19, action(change_to_right), curr_lane.

0.9002503::u20.
free_E :- u20, action(cruise), curr_lane.

0.9020276::u21.
free_E :- u21, action(keep), curr_lane.

0.9803279::u22.
free_E :- u22, action(swerve_left), curr_lane.

0.9962733::u23.
free_E :- u23, action(swerve_right), curr_lane.

0.4771887::u24.
free_NE :- u24, action(change_to_left), \+ curr_lane, \+ free_E.

0.4971499::u25.
free_NE :- u25, action(change_to_right), \+ curr_lane, \+ free_E.

0.5314214::u26.
free_NE :- u26, action(cruise), \+ curr_lane, \+ free_E.

0.2610806::u27.
free_NE :- u27, action(keep), \+ curr_lane, \+ free_E.

0.4600000::u28.
free_NE :- u28, action(swerve_left), \+ curr_lane, \+ free_E.

0.5000000::u29.
free_NE :- u29, action(swerve_right), \+ curr_lane, \+ free_E.

0.5011419::u30.
free_NE :- u30, action(change_to_left), curr_lane, \+ free_E.

0.5010213::u31.
free_NE :- u31, action(change_to_right), curr_lane, \+ free_E.

0.2263394::u32.
free_NE :- u32, action(cruise), curr_lane, \+ free_E.

0.0005575::u33.
free_NE :- u33, action(keep), curr_lane, \+ free_E.

0.0416667::u34.
free_NE :- u34, action(swerve_left), curr_lane, \+ free_E.

0.6666667::u35.
free_NE :- u35, action(swerve_right), curr_lane, \+ free_E.

0.4714109::u36.
free_NE :- u36, action(change_to_left), \+ curr_lane, free_E.

0.4876650::u37.
free_NE :- u37, action(change_to_right), \+ curr_lane, free_E.

0.4400250::u38.
free_NE :- u38, action(cruise), \+ curr_lane, free_E.

0.0126539::u39.
free_NE :- u39, action(keep), \+ curr_lane, free_E.

0.8155340::u40.
free_NE :- u40, action(swerve_left), \+ curr_lane, free_E.

0.9990010::u41.
free_NE :- u41, action(swerve_right), \+ curr_lane, free_E.

0.4893626::u42.
free_NE :- u42, action(change_to_left), curr_lane, free_E.

0.5552854::u43.
free_NE :- u43, action(change_to_right), curr_lane, free_E.

0.9007664::u44.
free_NE :- u44, action(cruise), curr_lane, free_E.

0.0048687::u45.
free_NE :- u45, action(keep), curr_lane, free_E.

0.9063545::u46.
free_NE :- u46, action(swerve_left), curr_lane, free_E.

0.8391521::u47.
free_NE :- u47, action(swerve_right), curr_lane, free_E.

