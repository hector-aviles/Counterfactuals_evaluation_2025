%%% Exogenous variables

0.1679668::u_action(change_to_left); 0.1697064::u_action(change_to_right); 0.4059271::u_action(cruise); 0.2540720::u_action(keep); 0.0014784::u_action(swerve_left); 0.0008493::u_action(swerve_right)
action(V) :- u_action(V).

0.4002963::u1.
free_NW :- u1.

0.5996678::u2.
free_SE :- u2.

0.6816319::u3.
free_SW :- u3.

0.7119353::u4.
free_W :- u4.

0.3863576::u5.
latent_collision :- u5.

0.4991766::u6.
curr_lane :- u6, action(change_to_left).

0.5170848::u7.
curr_lane :- u7, action(change_to_right).

0.6572298::u8.
curr_lane :- u8, action(cruise).

0.3664503::u9.
curr_lane :- u9, action(keep).

0.8225918::u10.
curr_lane :- u10, action(swerve_left).

0.9915561::u11.
curr_lane :- u11, action(swerve_right).

0.5207288::u12.
free_E :- u12, action(change_to_left), \+ curr_lane.

0.5042004::u13.
free_E :- u13, action(change_to_right), \+ curr_lane.

0.5412749::u14.
free_E :- u14, action(cruise), \+ curr_lane.

0.5934799::u15.
free_E :- u15, action(keep), \+ curr_lane.

0.8046875::u16.
free_E :- u16, action(swerve_left), \+ curr_lane.

0.9990010::u17.
free_E :- u17, action(swerve_right), \+ curr_lane.

0.5517364::u18.
free_E :- u18, action(change_to_left), curr_lane.

0.5296432::u19.
free_E :- u19, action(change_to_right), curr_lane.

0.9012177::u20.
free_E :- u20, action(cruise), curr_lane.

0.9010960::u21.
free_E :- u21, action(keep), curr_lane.

0.9797810::u22.
free_E :- u22, action(swerve_left), curr_lane.

0.9951338::u23.
free_E :- u23, action(swerve_right), curr_lane.

0.5067849::u24.
free_NE :- u24, action(change_to_left), \+ curr_lane, \+ free_E.

0.5239536::u25.
free_NE :- u25, action(change_to_right), \+ curr_lane, \+ free_E.

0.5402655::u26.
free_NE :- u26, action(cruise), \+ curr_lane, \+ free_E.

0.2614999::u27.
free_NE :- u27, action(keep), \+ curr_lane, \+ free_E.

0.4000000::u28.
free_NE :- u28, action(swerve_left), \+ curr_lane, \+ free_E.

0.5000000::u29.
free_NE :- u29, action(swerve_right), \+ curr_lane, \+ free_E.

0.4988687::u30.
free_NE :- u30, action(change_to_left), curr_lane, \+ free_E.

0.5012783::u31.
free_NE :- u31, action(change_to_right), curr_lane, \+ free_E.

0.2249738::u32.
free_NE :- u32, action(cruise), curr_lane, \+ free_E.

0.0001113::u33.
free_NE :- u33, action(keep), curr_lane, \+ free_E.

0.0009990::u34.
free_NE :- u34, action(swerve_left), curr_lane, \+ free_E.

0.5000000::u35.
free_NE :- u35, action(swerve_right), curr_lane, \+ free_E.

0.4756759::u36.
free_NE :- u36, action(change_to_left), \+ curr_lane, free_E.

0.4922394::u37.
free_NE :- u37, action(change_to_right), \+ curr_lane, free_E.

0.4404979::u38.
free_NE :- u38, action(cruise), \+ curr_lane, free_E.

0.0122582::u39.
free_NE :- u39, action(keep), \+ curr_lane, free_E.

0.8592233::u40.
free_NE :- u40, action(swerve_left), \+ curr_lane, free_E.

0.9990010::u41.
free_NE :- u41, action(swerve_right), \+ curr_lane, free_E.

0.4895356::u42.
free_NE :- u42, action(change_to_left), curr_lane, free_E.

0.5530475::u43.
free_NE :- u43, action(change_to_right), curr_lane, free_E.

0.9014650::u44.
free_NE :- u44, action(cruise), curr_lane, free_E.

0.0045062::u45.
free_NE :- u45, action(keep), curr_lane, free_E.

0.9019776::u46.
free_NE :- u46, action(swerve_left), curr_lane, free_E.

0.8618582::u47.
free_NE :- u47, action(swerve_right), curr_lane, free_E.

