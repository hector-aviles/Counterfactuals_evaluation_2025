%%% Exogenous variables

0.1679106::u_action(change_to_left); 0.1700363::u_action(change_to_right); 0.4048135::u_action(cruise); 0.2548638::u_action(keep); 0.0015067::u_action(swerve_left); 0.0008691::u_action(swerve_right)
action(V) :- u_action(V).

0.4038839::u1.
free_NW :- u1.

0.6003214::u2.
free_SE :- u2.

0.6824042::u3.
free_SW :- u3.

0.7115994::u4.
free_W :- u4.

0.3852158::u5.
latent_collision :- u5.

0.4981077::u6.
curr_lane :- u6, action(change_to_left).

0.5161483::u7.
curr_lane :- u7, action(change_to_right).

0.6573528::u8.
curr_lane :- u8, action(cruise).

0.3659034::u9.
curr_lane :- u9, action(keep).

0.8210884::u10.
curr_lane :- u10, action(swerve_left).

0.9941038::u11.
curr_lane :- u11, action(swerve_right).

0.5051263::u12.
free_E :- u12, action(change_to_left), \+ curr_lane.

0.4893424::u13.
free_E :- u13, action(change_to_right), \+ curr_lane.

0.5338053::u14.
free_E :- u14, action(cruise), \+ curr_lane.

0.5949821::u15.
free_E :- u15, action(keep), \+ curr_lane.

0.8212928::u16.
free_E :- u16, action(swerve_left), \+ curr_lane.

0.9990010::u17.
free_E :- u17, action(swerve_right), \+ curr_lane.

0.5534233::u18.
free_E :- u18, action(change_to_left), curr_lane.

0.5297271::u19.
free_E :- u19, action(change_to_right), curr_lane.

0.9010291::u20.
free_E :- u20, action(cruise), curr_lane.

0.9019530::u21.
free_E :- u21, action(keep), curr_lane.

0.9850870::u22.
free_E :- u22, action(swerve_left), curr_lane.

0.9952550::u23.
free_E :- u23, action(swerve_right), curr_lane.

0.4927992::u24.
free_NE :- u24, action(change_to_left), \+ curr_lane, \+ free_E.

0.5085994::u25.
free_NE :- u25, action(change_to_right), \+ curr_lane, \+ free_E.

0.5323496::u26.
free_NE :- u26, action(cruise), \+ curr_lane, \+ free_E.

0.2612352::u27.
free_NE :- u27, action(keep), \+ curr_lane, \+ free_E.

0.4468085::u28.
free_NE :- u28, action(swerve_left), \+ curr_lane, \+ free_E.

0.5000000::u29.
free_NE :- u29, action(swerve_right), \+ curr_lane, \+ free_E.

0.4987926::u30.
free_NE :- u30, action(change_to_left), curr_lane, \+ free_E.

0.5014527::u31.
free_NE :- u31, action(change_to_right), curr_lane, \+ free_E.

0.2247042::u32.
free_NE :- u32, action(cruise), curr_lane, \+ free_E.

0.0002242::u33.
free_NE :- u33, action(keep), curr_lane, \+ free_E.

0.0009990::u34.
free_NE :- u34, action(swerve_left), curr_lane, \+ free_E.

0.5000000::u35.
free_NE :- u35, action(swerve_right), curr_lane, \+ free_E.

0.4884550::u36.
free_NE :- u36, action(change_to_left), \+ curr_lane, free_E.

0.5074847::u37.
free_NE :- u37, action(change_to_right), \+ curr_lane, free_E.

0.4481880::u38.
free_NE :- u38, action(cruise), \+ curr_lane, free_E.

0.0119597::u39.
free_NE :- u39, action(keep), \+ curr_lane, free_E.

0.8472222::u40.
free_NE :- u40, action(swerve_left), \+ curr_lane, free_E.

0.9990010::u41.
free_NE :- u41, action(swerve_right), \+ curr_lane, free_E.

0.4865924::u42.
free_NE :- u42, action(change_to_left), curr_lane, free_E.

0.5527116::u43.
free_NE :- u43, action(change_to_right), curr_lane, free_E.

0.9018535::u44.
free_NE :- u44, action(cruise), curr_lane, free_E.

0.0044964::u45.
free_NE :- u45, action(keep), curr_lane, free_E.

0.9007569::u46.
free_NE :- u46, action(swerve_left), curr_lane, free_E.

0.8438617::u47.
free_NE :- u47, action(swerve_right), curr_lane, free_E.

