%%% Exogenous variables

0.1675717::u_action(change_to_left); 0.1699710::u_action(change_to_right); 0.4053351::u_action(cruise); 0.2547761::u_action(keep); 0.0014656::u_action(swerve_left); 0.0008804::u_action(swerve_right)
action(V) :- u_action(V).

0.4041226::u1.
free_NW :- u1.

0.5960905::u2.
free_SE :- u2.

0.6827128::u3.
free_SW :- u3.

0.7159582::u4.
free_W :- u4.

0.3854660::u5.
latent_collision :- u5.

0.4970672::u6.
curr_lane :- u6, action(change_to_left).

0.5183010::u7.
curr_lane :- u7, action(change_to_right).

0.6561613::u8.
curr_lane :- u8, action(cruise).

0.3662307::u9.
curr_lane :- u9, action(keep).

0.8118881::u10.
curr_lane :- u10, action(swerve_left).

0.9953434::u11.
curr_lane :- u11, action(swerve_right).

0.5048402::u12.
free_E :- u12, action(change_to_left), \+ curr_lane.

0.4887086::u13.
free_E :- u13, action(change_to_right), \+ curr_lane.

0.5321405::u14.
free_E :- u14, action(cruise), \+ curr_lane.

0.5925366::u15.
free_E :- u15, action(keep), \+ curr_lane.

0.8215613::u16.
free_E :- u16, action(swerve_left), \+ curr_lane.

0.9990010::u17.
free_E :- u17, action(swerve_right), \+ curr_lane.

0.5548979::u18.
free_E :- u18, action(change_to_left), curr_lane.

0.5292366::u19.
free_E :- u19, action(change_to_right), curr_lane.

0.9002690::u20.
free_E :- u20, action(cruise), curr_lane.

0.9003164::u21.
free_E :- u21, action(keep), curr_lane.

0.9870801::u22.
free_E :- u22, action(swerve_left), curr_lane.

0.9964912::u23.
free_E :- u23, action(swerve_right), curr_lane.

0.4899548::u24.
free_NE :- u24, action(change_to_left), \+ curr_lane, \+ free_E.

0.5114337::u25.
free_NE :- u25, action(change_to_right), \+ curr_lane, \+ free_E.

0.5317667::u26.
free_NE :- u26, action(cruise), \+ curr_lane, \+ free_E.

0.2616952::u27.
free_NE :- u27, action(keep), \+ curr_lane, \+ free_E.

0.3750000::u28.
free_NE :- u28, action(swerve_left), \+ curr_lane, \+ free_E.

0.5000000::u29.
free_NE :- u29, action(swerve_right), \+ curr_lane, \+ free_E.

0.5025572::u30.
free_NE :- u30, action(change_to_left), curr_lane, \+ free_E.

0.5019771::u31.
free_NE :- u31, action(change_to_right), curr_lane, \+ free_E.

0.2226430::u32.
free_NE :- u32, action(cruise), curr_lane, \+ free_E.

0.0005510::u33.
free_NE :- u33, action(keep), curr_lane, \+ free_E.

0.0666667::u34.
free_NE :- u34, action(swerve_left), curr_lane, \+ free_E.

0.6666667::u35.
free_NE :- u35, action(swerve_right), curr_lane, \+ free_E.

0.4874735::u36.
free_NE :- u36, action(change_to_left), \+ curr_lane, free_E.

0.5048924::u37.
free_NE :- u37, action(change_to_right), \+ curr_lane, free_E.

0.4466218::u38.
free_NE :- u38, action(cruise), \+ curr_lane, free_E.

0.0117836::u39.
free_NE :- u39, action(keep), \+ curr_lane, free_E.

0.8054299::u40.
free_NE :- u40, action(swerve_left), \+ curr_lane, free_E.

0.9990010::u41.
free_NE :- u41, action(swerve_right), \+ curr_lane, free_E.

0.4875155::u42.
free_NE :- u42, action(change_to_left), curr_lane, free_E.

0.5528688::u43.
free_NE :- u43, action(change_to_right), curr_lane, free_E.

0.9010821::u44.
free_NE :- u44, action(cruise), curr_lane, free_E.

0.0044044::u45.
free_NE :- u45, action(keep), curr_lane, free_E.

0.9153578::u46.
free_NE :- u46, action(swerve_left), curr_lane, free_E.

0.8603286::u47.
free_NE :- u47, action(swerve_right), curr_lane, free_E.

