%%% Exogenous variables

0.1686926::u_action(change_to_left); 0.1705391::u_action(change_to_right); 0.4084731::u_action(cruise); 0.2497820::u_action(keep); 0.0016413::u_action(swerve_left); 0.0008719::u_action(swerve_right)
action(V) :- u_action(V).

0.5252603::u1.
curr_lane :- u1.

0.5977674::u2.
free_E :- u2, \+ curr_lane, \+ latent_collision.

0.9385277::u3.
free_E :- u3, curr_lane, \+ latent_collision.

0.4529760::u4.
free_E :- u4, \+ curr_lane, latent_collision.

0.5447242::u5.
free_E :- u5, curr_lane, latent_collision.

0.5000000::u6.
free_NE :- u6, action(change_to_left), \+ curr_lane, \+ free_E.

0.5042735::u7.
free_NE :- u7, action(change_to_right), \+ curr_lane, \+ free_E.

0.5275708::u8.
free_NE :- u8, action(cruise), \+ curr_lane, \+ free_E.

0.2629179::u9.
free_NE :- u9, action(keep), \+ curr_lane, \+ free_E.

0.0009990::u10.
free_NE :- u10, action(swerve_left), \+ curr_lane, \+ free_E.

0.5000000::u11.
free_NE :- u11, action(swerve_right), \+ curr_lane, \+ free_E.

0.5211679::u12.
free_NE :- u12, action(change_to_left), curr_lane, \+ free_E.

0.4941785::u13.
free_NE :- u13, action(change_to_right), curr_lane, \+ free_E.

0.2292576::u14.
free_NE :- u14, action(cruise), curr_lane, \+ free_E.

0.0009990::u15.
free_NE :- u15, action(keep), curr_lane, \+ free_E.

0.5000000::u16.
free_NE :- u16, action(swerve_left), curr_lane, \+ free_E.

0.5000000::u17.
free_NE :- u17, action(swerve_right), curr_lane, \+ free_E.

0.4831461::u18.
free_NE :- u18, action(change_to_left), \+ curr_lane, free_E.

0.4884569::u19.
free_NE :- u19, action(change_to_right), \+ curr_lane, free_E.

0.4448898::u20.
free_NE :- u20, action(cruise), \+ curr_lane, free_E.

0.0102506::u21.
free_NE :- u21, action(keep), \+ curr_lane, free_E.

0.6000000::u22.
free_NE :- u22, action(swerve_left), \+ curr_lane, free_E.

0.5000000::u23.
free_NE :- u23, action(swerve_right), \+ curr_lane, free_E.

0.4955947::u24.
free_NE :- u24, action(change_to_left), curr_lane, free_E.

0.5329670::u25.
free_NE :- u25, action(change_to_right), curr_lane, free_E.

0.8902936::u26.
free_NE :- u26, action(cruise), curr_lane, free_E.

0.0037175::u27.
free_NE :- u27, action(keep), curr_lane, free_E.

0.9200000::u28.
free_NE :- u28, action(swerve_left), curr_lane, free_E.

0.8823529::u29.
free_NE :- u29, action(swerve_right), curr_lane, free_E.

0.5241715::u30.
free_NW :- u30, action(change_to_left).

0.5530827::u31.
free_NW :- u31, action(change_to_right).

0.5302612::u32.
free_NW :- u32, action(cruise).

0.0293634::u33.
free_NW :- u33, action(keep).

0.9375000::u34.
free_NW :- u34, action(swerve_left).

0.8823529::u35.
free_NW :- u35, action(swerve_right).

0.6666667::u36.
free_SE :- u36, \+ curr_lane, \+ free_E, \+ free_SW, \+ latent_collision.

0.9990010::u37.
free_SE :- u37, curr_lane, \+ free_E, \+ free_SW, \+ latent_collision.

0.8670886::u38.
free_SE :- u38, \+ curr_lane, free_E, \+ free_SW, \+ latent_collision.

0.9694149::u39.
free_SE :- u39, curr_lane, free_E, \+ free_SW, \+ latent_collision.

0.3531727::u40.
free_SE :- u40, \+ curr_lane, \+ free_E, free_SW, \+ latent_collision.

0.9815789::u41.
free_SE :- u41, curr_lane, \+ free_E, free_SW, \+ latent_collision.

0.4464812::u42.
free_SE :- u42, \+ curr_lane, free_E, free_SW, \+ latent_collision.

0.7738250::u43.
free_SE :- u43, curr_lane, free_E, free_SW, \+ latent_collision.

0.5204957::u44.
free_SE :- u44, \+ curr_lane, \+ free_E, \+ free_SW, latent_collision.

0.4942263::u45.
free_SE :- u45, curr_lane, \+ free_E, \+ free_SW, latent_collision.

0.5301775::u46.
free_SE :- u46, \+ curr_lane, free_E, \+ free_SW, latent_collision.

0.4895947::u47.
free_SE :- u47, curr_lane, free_E, \+ free_SW, latent_collision.

0.4953445::u48.
free_SE :- u48, \+ curr_lane, \+ free_E, free_SW, latent_collision.

0.4496403::u49.
free_SE :- u49, curr_lane, \+ free_E, free_SW, latent_collision.

0.4950712::u50.
free_SE :- u50, \+ curr_lane, free_E, free_SW, latent_collision.

0.5191793::u51.
free_SE :- u51, curr_lane, free_E, free_SW, latent_collision.

0.4990415::u52.
free_SW :- u52, action(change_to_left), \+ free_NW.

0.5444145::u53.
free_SW :- u53, action(change_to_right), \+ free_NW.

0.5364876::u54.
free_SW :- u54, action(cruise), \+ free_NW.

0.9858261::u55.
free_SW :- u55, action(keep), \+ free_NW.

0.9990010::u56.
free_SW :- u56, action(swerve_left), \+ free_NW.

0.9990010::u57.
free_SW :- u57, action(swerve_right), \+ free_NW.

0.5121810::u58.
free_SW :- u58, action(change_to_left), free_NW.

0.6101142::u59.
free_SW :- u59, action(change_to_right), free_NW.

0.6762965::u60.
free_SW :- u60, action(cruise), free_NW.

0.6853147::u61.
free_SW :- u61, action(keep), free_NW.

0.9990010::u62.
free_SW :- u62, action(swerve_left), free_NW.

0.7333333::u63.
free_SW :- u63, action(swerve_right), free_NW.

0.5000000::u64.
free_W :- u64, action(change_to_left), \+ curr_lane, \+ free_NW, \+ latent_collision.

0.9718310::u65.
free_W :- u65, action(change_to_right), \+ curr_lane, \+ free_NW, \+ latent_collision.

0.5000000::u66.
free_W :- u66, action(cruise), \+ curr_lane, \+ free_NW, \+ latent_collision.

0.9990010::u67.
free_W :- u67, action(keep), \+ curr_lane, \+ free_NW, \+ latent_collision.

0.5000000::u68.
free_W :- u68, action(swerve_left), \+ curr_lane, \+ free_NW, \+ latent_collision.

0.5000000::u69.
free_W :- u69, action(swerve_right), \+ curr_lane, \+ free_NW, \+ latent_collision.

0.5000000::u70.
free_W :- u70, action(change_to_left), curr_lane, \+ free_NW, \+ latent_collision.

0.5000000::u71.
free_W :- u71, action(change_to_right), curr_lane, \+ free_NW, \+ latent_collision.

0.7250319::u72.
free_W :- u72, action(cruise), curr_lane, \+ free_NW, \+ latent_collision.

0.8471223::u73.
free_W :- u73, action(keep), curr_lane, \+ free_NW, \+ latent_collision.

0.5000000::u74.
free_W :- u74, action(swerve_left), curr_lane, \+ free_NW, \+ latent_collision.

0.9990010::u75.
free_W :- u75, action(swerve_right), curr_lane, \+ free_NW, \+ latent_collision.

0.5000000::u76.
free_W :- u76, action(change_to_left), \+ curr_lane, free_NW, \+ latent_collision.

0.9969789::u77.
free_W :- u77, action(change_to_right), \+ curr_lane, free_NW, \+ latent_collision.

0.9990010::u78.
free_W :- u78, action(cruise), \+ curr_lane, free_NW, \+ latent_collision.

0.9990010::u79.
free_W :- u79, action(keep), \+ curr_lane, free_NW, \+ latent_collision.

0.9990010::u80.
free_W :- u80, action(swerve_left), \+ curr_lane, free_NW, \+ latent_collision.

0.5000000::u81.
free_W :- u81, action(swerve_right), \+ curr_lane, free_NW, \+ latent_collision.

0.9990010::u82.
free_W :- u82, action(change_to_left), curr_lane, free_NW, \+ latent_collision.

0.5000000::u83.
free_W :- u83, action(change_to_right), curr_lane, free_NW, \+ latent_collision.

0.5957001::u84.
free_W :- u84, action(cruise), curr_lane, free_NW, \+ latent_collision.

0.4307692::u85.
free_W :- u85, action(keep), curr_lane, free_NW, \+ latent_collision.

0.9990010::u86.
free_W :- u86, action(swerve_left), curr_lane, free_NW, \+ latent_collision.

0.9990010::u87.
free_W :- u87, action(swerve_right), curr_lane, free_NW, \+ latent_collision.

0.4956843::u88.
free_W :- u88, action(change_to_left), \+ curr_lane, \+ free_NW, latent_collision.

0.5007874::u89.
free_W :- u89, action(change_to_right), \+ curr_lane, \+ free_NW, latent_collision.

0.5481481::u90.
free_W :- u90, action(cruise), \+ curr_lane, \+ free_NW, latent_collision.

0.5000000::u91.
free_W :- u91, action(keep), \+ curr_lane, \+ free_NW, latent_collision.

0.5000000::u92.
free_W :- u92, action(swerve_left), \+ curr_lane, \+ free_NW, latent_collision.

0.5000000::u93.
free_W :- u93, action(swerve_right), \+ curr_lane, \+ free_NW, latent_collision.

0.4973475::u94.
free_W :- u94, action(change_to_left), curr_lane, \+ free_NW, latent_collision.

0.5064103::u95.
free_W :- u95, action(change_to_right), curr_lane, \+ free_NW, latent_collision.

0.5304740::u96.
free_W :- u96, action(cruise), curr_lane, \+ free_NW, latent_collision.

0.5000000::u97.
free_W :- u97, action(keep), curr_lane, \+ free_NW, latent_collision.

0.5000000::u98.
free_W :- u98, action(swerve_left), curr_lane, \+ free_NW, latent_collision.

0.5000000::u99.
free_W :- u99, action(swerve_right), curr_lane, \+ free_NW, latent_collision.

0.5446328::u100.
free_W :- u100, action(change_to_left), \+ curr_lane, free_NW, latent_collision.

0.4975207::u101.
free_W :- u101, action(change_to_right), \+ curr_lane, free_NW, latent_collision.

0.5000000::u102.
free_W :- u102, action(cruise), \+ curr_lane, free_NW, latent_collision.

0.5000000::u103.
free_W :- u103, action(keep), \+ curr_lane, free_NW, latent_collision.

0.5000000::u104.
free_W :- u104, action(swerve_left), \+ curr_lane, free_NW, latent_collision.

0.5000000::u105.
free_W :- u105, action(swerve_right), \+ curr_lane, free_NW, latent_collision.

0.0009990::u106.
free_W :- u106, action(change_to_left), curr_lane, free_NW, latent_collision.

0.5238095::u107.
free_W :- u107, action(change_to_right), curr_lane, free_NW, latent_collision.

0.4763033::u108.
free_W :- u108, action(cruise), curr_lane, free_NW, latent_collision.

0.5000000::u109.
free_W :- u109, action(keep), curr_lane, free_NW, latent_collision.

0.5000000::u110.
free_W :- u110, action(swerve_left), curr_lane, free_NW, latent_collision.

0.5000000::u111.
free_W :- u111, action(swerve_right), curr_lane, free_NW, latent_collision.

0.8892308::u112.
latent_collision :- u112, action(change_to_left), \+ free_SW.

0.9928264::u113.
latent_collision :- u113, action(change_to_right), \+ free_SW.

0.2721703::u114.
latent_collision :- u114, action(cruise), \+ free_SW.

0.0009990::u115.
latent_collision :- u115, action(keep), \+ free_SW.

0.5000000::u116.
latent_collision :- u116, action(swerve_left), \+ free_SW.

0.0009990::u117.
latent_collision :- u117, action(swerve_right), \+ free_SW.

0.8635817::u118.
latent_collision :- u118, action(change_to_left), free_SW.

0.7969964::u119.
latent_collision :- u119, action(change_to_right), free_SW.

0.1986428::u120.
latent_collision :- u120, action(cruise), free_SW.

0.0009990::u121.
latent_collision :- u121, action(keep), free_SW.

0.0009990::u122.
latent_collision :- u122, action(swerve_left), free_SW.

0.0009990::u123.
latent_collision :- u123, action(swerve_right), free_SW.

