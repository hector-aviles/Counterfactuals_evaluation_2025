%%% Exogenous variables

0.1638991::u_action(change_to_left); 0.1722017::u_action(change_to_right); 0.4060066::u_action(cruise); 0.2557401::u_action(keep); 0.0012300::u_action(swerve_left); 0.0009225::u_action(swerve_right)
action(V) :- u_action(V).

0.5280853::u1.
curr_lane :- u1.

0.6133678::u2.
free_E :- u2, \+ curr_lane, \+ latent_collision.

0.9358974::u3.
free_E :- u3, curr_lane, \+ latent_collision.

0.4409283::u4.
free_E :- u4, \+ curr_lane, latent_collision.

0.5405553::u5.
free_E :- u5, curr_lane, latent_collision.

0.4962963::u6.
free_NE :- u6, action(change_to_left), \+ curr_lane, \+ free_E.

0.5186480::u7.
free_NE :- u7, action(change_to_right), \+ curr_lane, \+ free_E.

0.5203837::u8.
free_NE :- u8, action(cruise), \+ curr_lane, \+ free_E.

0.2550232::u9.
free_NE :- u9, action(keep), \+ curr_lane, \+ free_E.

0.9990010::u10.
free_NE :- u10, action(swerve_left), \+ curr_lane, \+ free_E.

0.5000000::u11.
free_NE :- u11, action(swerve_right), \+ curr_lane, \+ free_E.

0.4860908::u12.
free_NE :- u12, action(change_to_left), curr_lane, \+ free_E.

0.5146871::u13.
free_NE :- u13, action(change_to_right), curr_lane, \+ free_E.

0.2473573::u14.
free_NE :- u14, action(cruise), curr_lane, \+ free_E.

0.0009990::u15.
free_NE :- u15, action(keep), curr_lane, \+ free_E.

0.5000000::u16.
free_NE :- u16, action(swerve_left), curr_lane, \+ free_E.

0.5000000::u17.
free_NE :- u17, action(swerve_right), curr_lane, \+ free_E.

0.4801536::u18.
free_NE :- u18, action(change_to_left), \+ curr_lane, free_E.

0.4970828::u19.
free_NE :- u19, action(change_to_right), \+ curr_lane, free_E.

0.4241611::u20.
free_NE :- u20, action(cruise), \+ curr_lane, free_E.

0.0139860::u21.
free_NE :- u21, action(keep), \+ curr_lane, free_E.

0.8571429::u22.
free_NE :- u22, action(swerve_left), \+ curr_lane, free_E.

0.5000000::u23.
free_NE :- u23, action(swerve_right), \+ curr_lane, free_E.

0.5194805::u24.
free_NE :- u24, action(change_to_left), curr_lane, free_E.

0.5638051::u25.
free_NE :- u25, action(change_to_right), curr_lane, free_E.

0.8969839::u26.
free_NE :- u26, action(cruise), curr_lane, free_E.

0.0042093::u27.
free_NE :- u27, action(keep), curr_lane, free_E.

0.9990010::u28.
free_NE :- u28, action(swerve_left), curr_lane, free_E.

0.9444444::u29.
free_NE :- u29, action(swerve_right), curr_lane, free_E.

0.5135834::u30.
free_NW :- u30, action(change_to_left), \+ free_SW, \+ free_W.

0.5112360::u31.
free_NW :- u31, action(change_to_right), \+ free_SW, \+ free_W.

0.4443414::u32.
free_NW :- u32, action(cruise), \+ free_SW, \+ free_W.

0.4814815::u33.
free_NW :- u33, action(keep), \+ free_SW, \+ free_W.

0.9990010::u34.
free_NW :- u34, action(swerve_left), \+ free_SW, \+ free_W.

0.1666667::u35.
free_NW :- u35, action(swerve_right), \+ free_SW, \+ free_W.

0.4851117::u36.
free_NW :- u36, action(change_to_left), free_SW, \+ free_W.

0.4621849::u37.
free_NW :- u37, action(change_to_right), free_SW, \+ free_W.

0.3857645::u38.
free_NW :- u38, action(cruise), free_SW, \+ free_W.

0.2208955::u39.
free_NW :- u39, action(keep), free_SW, \+ free_W.

0.5000000::u40.
free_NW :- u40, action(swerve_left), free_SW, \+ free_W.

0.0009990::u41.
free_NW :- u41, action(swerve_right), free_SW, \+ free_W.

0.4911081::u42.
free_NW :- u42, action(change_to_left), \+ free_SW, free_W.

0.5056361::u43.
free_NW :- u43, action(change_to_right), \+ free_SW, free_W.

0.4306977::u44.
free_NW :- u44, action(cruise), \+ free_SW, free_W.

0.4461538::u45.
free_NW :- u45, action(keep), \+ free_SW, free_W.

0.5000000::u46.
free_NW :- u46, action(swerve_left), \+ free_SW, free_W.

0.5000000::u47.
free_NW :- u47, action(swerve_right), \+ free_SW, free_W.

0.5506757::u48.
free_NW :- u48, action(change_to_left), free_SW, free_W.

0.6169078::u49.
free_NW :- u49, action(change_to_right), free_SW, free_W.

0.6327334::u50.
free_NW :- u50, action(cruise), free_SW, free_W.

0.0088183::u51.
free_NW :- u51, action(keep), free_SW, free_W.

0.9990010::u52.
free_NW :- u52, action(swerve_left), free_SW, free_W.

0.9990010::u53.
free_NW :- u53, action(swerve_right), free_SW, free_W.

0.6240000::u54.
free_SE :- u54, \+ curr_lane, \+ free_E, \+ free_SW, \+ latent_collision.

0.9990010::u55.
free_SE :- u55, curr_lane, \+ free_E, \+ free_SW, \+ latent_collision.

0.8826816::u56.
free_SE :- u56, \+ curr_lane, free_E, \+ free_SW, \+ latent_collision.

0.9720457::u57.
free_SE :- u57, curr_lane, free_E, \+ free_SW, \+ latent_collision.

0.3214830::u58.
free_SE :- u58, \+ curr_lane, \+ free_E, free_SW, \+ latent_collision.

0.9773869::u59.
free_SE :- u59, curr_lane, \+ free_E, free_SW, \+ latent_collision.

0.4234808::u60.
free_SE :- u60, \+ curr_lane, free_E, free_SW, \+ latent_collision.

0.7614464::u61.
free_SE :- u61, curr_lane, free_E, free_SW, \+ latent_collision.

0.5157042::u62.
free_SE :- u62, \+ curr_lane, \+ free_E, \+ free_SW, latent_collision.

0.5057339::u63.
free_SE :- u63, curr_lane, \+ free_E, \+ free_SW, latent_collision.

0.5032938::u64.
free_SE :- u64, \+ curr_lane, free_E, \+ free_SW, latent_collision.

0.5096481::u65.
free_SE :- u65, curr_lane, free_E, \+ free_SW, latent_collision.

0.4757282::u66.
free_SE :- u66, \+ curr_lane, \+ free_E, free_SW, latent_collision.

0.4497549::u67.
free_SE :- u67, curr_lane, \+ free_E, free_SW, latent_collision.

0.5125958::u68.
free_SE :- u68, \+ curr_lane, free_E, free_SW, latent_collision.

0.4832579::u69.
free_SE :- u69, curr_lane, free_E, free_SW, latent_collision.

0.5297061::u70.
free_SW :- u70, action(change_to_left).

0.6032738::u71.
free_SW :- u71, action(change_to_right).

0.5925271::u72.
free_SW :- u72, action(cruise).

0.9761523::u73.
free_SW :- u73, action(keep).

0.9583333::u74.
free_SW :- u74, action(swerve_left).

0.6666667::u75.
free_SW :- u75, action(swerve_right).

0.5000000::u76.
free_W :- u76, action(change_to_left), \+ curr_lane, \+ latent_collision.

0.9906103::u77.
free_W :- u77, action(change_to_right), \+ curr_lane, \+ latent_collision.

0.9990010::u78.
free_W :- u78, action(cruise), \+ curr_lane, \+ latent_collision.

0.9990010::u79.
free_W :- u79, action(keep), \+ curr_lane, \+ latent_collision.

0.9990010::u80.
free_W :- u80, action(swerve_left), \+ curr_lane, \+ latent_collision.

0.5000000::u81.
free_W :- u81, action(swerve_right), \+ curr_lane, \+ latent_collision.

0.9990010::u82.
free_W :- u82, action(change_to_left), curr_lane, \+ latent_collision.

0.5000000::u83.
free_W :- u83, action(change_to_right), curr_lane, \+ latent_collision.

0.6824885::u84.
free_W :- u84, action(cruise), curr_lane, \+ latent_collision.

0.7882417::u85.
free_W :- u85, action(keep), curr_lane, \+ latent_collision.

0.9375000::u86.
free_W :- u86, action(swerve_left), curr_lane, \+ latent_collision.

0.5555556::u87.
free_W :- u87, action(swerve_right), curr_lane, \+ latent_collision.

0.5078567::u88.
free_W :- u88, action(change_to_left), \+ curr_lane, latent_collision.

0.4887510::u89.
free_W :- u89, action(change_to_right), \+ curr_lane, latent_collision.

0.5317982::u90.
free_W :- u90, action(cruise), \+ curr_lane, latent_collision.

0.5000000::u91.
free_W :- u91, action(keep), \+ curr_lane, latent_collision.

0.5000000::u92.
free_W :- u92, action(swerve_left), \+ curr_lane, latent_collision.

0.5000000::u93.
free_W :- u93, action(swerve_right), \+ curr_lane, latent_collision.

0.3299663::u94.
free_W :- u94, action(change_to_left), curr_lane, latent_collision.

0.5361702::u95.
free_W :- u95, action(change_to_right), curr_lane, latent_collision.

0.5112961::u96.
free_W :- u96, action(cruise), curr_lane, latent_collision.

0.5000000::u97.
free_W :- u97, action(keep), curr_lane, latent_collision.

0.5000000::u98.
free_W :- u98, action(swerve_left), curr_lane, latent_collision.

0.5000000::u99.
free_W :- u99, action(swerve_right), curr_lane, latent_collision.

0.8856383::u100.
latent_collision :- u100, action(change_to_left), \+ free_SW.

0.9947487::u101.
latent_collision :- u101, action(change_to_right), \+ free_SW.

0.2605328::u102.
latent_collision :- u102, action(cruise), \+ free_SW.

0.0009990::u103.
latent_collision :- u103, action(keep), \+ free_SW.

0.0009990::u104.
latent_collision :- u104, action(swerve_left), \+ free_SW.

0.0009990::u105.
latent_collision :- u105, action(swerve_right), \+ free_SW.

0.8541913::u106.
latent_collision :- u106, action(change_to_left), free_SW.

0.7932906::u107.
latent_collision :- u107, action(change_to_right), free_SW.

0.1942906::u108.
latent_collision :- u108, action(cruise), free_SW.

0.0009990::u109.
latent_collision :- u109, action(keep), free_SW.

0.0009990::u110.
latent_collision :- u110, action(swerve_left), free_SW.

0.0009990::u111.
latent_collision :- u111, action(swerve_right), free_SW.

