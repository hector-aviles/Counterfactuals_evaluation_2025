%%% Exogenous variables

0.1728685::u_action(change_to_left); 0.1663770::u_action(change_to_right); 0.4070742::u_action(cruise); 0.2511756::u_action(keep); 0.0013801::u_action(swerve_left); 0.0011245::u_action(swerve_right)
action(V) :- u_action(V).

0.5349622::u1.
curr_lane :- u1.

0.5969093::u2.
free_E :- u2, \+ curr_lane, \+ latent_collision.

0.9347498::u3.
free_E :- u3, curr_lane, \+ latent_collision.

0.4459351::u4.
free_E :- u4, \+ curr_lane, latent_collision.

0.5381201::u5.
free_E :- u5, curr_lane, latent_collision.

0.4926290::u6.
free_NE :- u6, action(change_to_left), \+ curr_lane, \+ free_E.

0.5190652::u7.
free_NE :- u7, action(change_to_right), \+ curr_lane, \+ free_E.

0.5321101::u8.
free_NE :- u8, action(cruise), \+ curr_lane, \+ free_E.

0.2727975::u9.
free_NE :- u9, action(keep), \+ curr_lane, \+ free_E.

0.0009990::u10.
free_NE :- u10, action(swerve_left), \+ curr_lane, \+ free_E.

0.5000000::u11.
free_NE :- u11, action(swerve_right), \+ curr_lane, \+ free_E.

0.5100942::u12.
free_NE :- u12, action(change_to_left), curr_lane, \+ free_E.

0.5133333::u13.
free_NE :- u13, action(change_to_right), curr_lane, \+ free_E.

0.2371917::u14.
free_NE :- u14, action(cruise), curr_lane, \+ free_E.

0.0009990::u15.
free_NE :- u15, action(keep), curr_lane, \+ free_E.

0.0009990::u16.
free_NE :- u16, action(swerve_left), curr_lane, \+ free_E.

0.5000000::u17.
free_NE :- u17, action(swerve_right), curr_lane, \+ free_E.

0.4577057::u18.
free_NE :- u18, action(change_to_left), \+ curr_lane, free_E.

0.4823529::u19.
free_NE :- u19, action(change_to_right), \+ curr_lane, free_E.

0.4401408::u20.
free_NE :- u20, action(cruise), \+ curr_lane, free_E.

0.0132086::u21.
free_NE :- u21, action(keep), \+ curr_lane, free_E.

0.9990010::u22.
free_NE :- u22, action(swerve_left), \+ curr_lane, free_E.

0.5000000::u23.
free_NE :- u23, action(swerve_right), \+ curr_lane, free_E.

0.4906445::u24.
free_NE :- u24, action(change_to_left), curr_lane, free_E.

0.5350593::u25.
free_NE :- u25, action(change_to_right), curr_lane, free_E.

0.9010406::u26.
free_NE :- u26, action(cruise), curr_lane, free_E.

0.0055487::u27.
free_NE :- u27, action(keep), curr_lane, free_E.

0.9545455::u28.
free_NE :- u28, action(swerve_left), curr_lane, free_E.

0.9090909::u29.
free_NE :- u29, action(swerve_right), curr_lane, free_E.

0.5003081::u30.
free_NW :- u30, action(change_to_left), \+ free_SW.

0.4786629::u31.
free_NW :- u31, action(change_to_right), \+ free_SW.

0.4489861::u32.
free_NW :- u32, action(cruise), \+ free_SW.

0.4778761::u33.
free_NW :- u33, action(keep), \+ free_SW.

0.0009990::u34.
free_NW :- u34, action(swerve_left), \+ free_SW.

0.9990010::u35.
free_NW :- u35, action(swerve_right), \+ free_SW.

0.5071063::u36.
free_NW :- u36, action(change_to_left), free_SW.

0.5781504::u37.
free_NW :- u37, action(change_to_right), free_SW.

0.5842346::u38.
free_NW :- u38, action(cruise), free_SW.

0.0266611::u39.
free_NW :- u39, action(keep), free_SW.

0.9615385::u40.
free_NW :- u40, action(swerve_left), free_SW.

0.7368421::u41.
free_NW :- u41, action(swerve_right), free_SW.

0.6643357::u42.
free_SE :- u42, \+ curr_lane, \+ free_E, \+ free_SW, \+ latent_collision.

0.9990010::u43.
free_SE :- u43, curr_lane, \+ free_E, \+ free_SW, \+ latent_collision.

0.8611111::u44.
free_SE :- u44, \+ curr_lane, free_E, \+ free_SW, \+ latent_collision.

0.9693039::u45.
free_SE :- u45, curr_lane, free_E, \+ free_SW, \+ latent_collision.

0.3377844::u46.
free_SE :- u46, \+ curr_lane, \+ free_E, free_SW, \+ latent_collision.

0.9924812::u47.
free_SE :- u47, curr_lane, \+ free_E, free_SW, \+ latent_collision.

0.4481163::u48.
free_SE :- u48, \+ curr_lane, free_E, free_SW, \+ latent_collision.

0.7760925::u49.
free_SE :- u49, curr_lane, free_E, free_SW, \+ latent_collision.

0.4783920::u50.
free_SE :- u50, \+ curr_lane, \+ free_E, \+ free_SW, latent_collision.

0.5166094::u51.
free_SE :- u51, curr_lane, \+ free_E, \+ free_SW, latent_collision.

0.5036058::u52.
free_SE :- u52, \+ curr_lane, free_E, \+ free_SW, latent_collision.

0.5236052::u53.
free_SE :- u53, curr_lane, free_E, \+ free_SW, latent_collision.

0.4953271::u54.
free_SE :- u54, \+ curr_lane, \+ free_E, free_SW, latent_collision.

0.4988839::u55.
free_SE :- u55, curr_lane, \+ free_E, free_SW, latent_collision.

0.5120482::u56.
free_SE :- u56, \+ curr_lane, free_E, free_SW, latent_collision.

0.5057573::u57.
free_SE :- u57, curr_lane, free_E, free_SW, latent_collision.

0.5201064::u58.
free_SW :- u58, action(change_to_left).

0.5680492::u59.
free_SW :- u59, action(change_to_right).

0.6037167::u60.
free_SW :- u60, action(cruise).

0.9770045::u61.
free_SW :- u61, action(keep).

0.9629630::u62.
free_SW :- u62, action(swerve_left).

0.8636364::u63.
free_SW :- u63, action(swerve_right).

0.5000000::u64.
free_W :- u64, action(change_to_left), \+ curr_lane, \+ free_NW, \+ latent_collision.

0.9841270::u65.
free_W :- u65, action(change_to_right), \+ curr_lane, \+ free_NW, \+ latent_collision.

0.5000000::u66.
free_W :- u66, action(cruise), \+ curr_lane, \+ free_NW, \+ latent_collision.

0.9990010::u67.
free_W :- u67, action(keep), \+ curr_lane, \+ free_NW, \+ latent_collision.

0.5000000::u68.
free_W :- u68, action(swerve_left), \+ curr_lane, \+ free_NW, \+ latent_collision.

0.5000000::u69.
free_W :- u69, action(swerve_right), \+ curr_lane, \+ free_NW, \+ latent_collision.

0.5000000::u70.
free_W :- u70, action(change_to_left), curr_lane, \+ free_NW, \+ latent_collision.

0.5000000::u71.
free_W :- u71, action(change_to_right), curr_lane, \+ free_NW, \+ latent_collision.

0.7258592::u72.
free_W :- u72, action(cruise), curr_lane, \+ free_NW, \+ latent_collision.

0.8459658::u73.
free_W :- u73, action(keep), curr_lane, \+ free_NW, \+ latent_collision.

0.9990010::u74.
free_W :- u74, action(swerve_left), curr_lane, \+ free_NW, \+ latent_collision.

0.9990010::u75.
free_W :- u75, action(swerve_right), curr_lane, \+ free_NW, \+ latent_collision.

0.5000000::u76.
free_W :- u76, action(change_to_left), \+ curr_lane, free_NW, \+ latent_collision.

0.9967320::u77.
free_W :- u77, action(change_to_right), \+ curr_lane, free_NW, \+ latent_collision.

0.9990010::u78.
free_W :- u78, action(cruise), \+ curr_lane, free_NW, \+ latent_collision.

0.9990010::u79.
free_W :- u79, action(keep), \+ curr_lane, free_NW, \+ latent_collision.

0.9990010::u80.
free_W :- u80, action(swerve_left), \+ curr_lane, free_NW, \+ latent_collision.

0.5000000::u81.
free_W :- u81, action(swerve_right), \+ curr_lane, free_NW, \+ latent_collision.

0.9990010::u82.
free_W :- u82, action(change_to_left), curr_lane, free_NW, \+ latent_collision.

0.5000000::u83.
free_W :- u83, action(change_to_right), curr_lane, free_NW, \+ latent_collision.

0.6018711::u84.
free_W :- u84, action(cruise), curr_lane, free_NW, \+ latent_collision.

0.3772455::u85.
free_W :- u85, action(keep), curr_lane, free_NW, \+ latent_collision.

0.9990010::u86.
free_W :- u86, action(swerve_left), curr_lane, free_NW, \+ latent_collision.

0.9411765::u87.
free_W :- u87, action(swerve_right), curr_lane, free_NW, \+ latent_collision.

0.4969098::u88.
free_W :- u88, action(change_to_left), \+ curr_lane, \+ free_NW, latent_collision.

0.5079365::u89.
free_W :- u89, action(change_to_right), \+ curr_lane, \+ free_NW, latent_collision.

0.5315101::u90.
free_W :- u90, action(cruise), \+ curr_lane, \+ free_NW, latent_collision.

0.5000000::u91.
free_W :- u91, action(keep), \+ curr_lane, \+ free_NW, latent_collision.

0.5000000::u92.
free_W :- u92, action(swerve_left), \+ curr_lane, \+ free_NW, latent_collision.

0.5000000::u93.
free_W :- u93, action(swerve_right), \+ curr_lane, \+ free_NW, latent_collision.

0.5097814::u94.
free_W :- u94, action(change_to_left), curr_lane, \+ free_NW, latent_collision.

0.5146341::u95.
free_W :- u95, action(change_to_right), curr_lane, \+ free_NW, latent_collision.

0.5408389::u96.
free_W :- u96, action(cruise), curr_lane, \+ free_NW, latent_collision.

0.5000000::u97.
free_W :- u97, action(keep), curr_lane, \+ free_NW, latent_collision.

0.5000000::u98.
free_W :- u98, action(swerve_left), curr_lane, \+ free_NW, latent_collision.

0.5000000::u99.
free_W :- u99, action(swerve_right), curr_lane, \+ free_NW, latent_collision.

0.5126728::u100.
free_W :- u100, action(change_to_left), \+ curr_lane, free_NW, latent_collision.

0.4991364::u101.
free_W :- u101, action(change_to_right), \+ curr_lane, free_NW, latent_collision.

0.5000000::u102.
free_W :- u102, action(cruise), \+ curr_lane, free_NW, latent_collision.

0.5000000::u103.
free_W :- u103, action(keep), \+ curr_lane, free_NW, latent_collision.

0.5000000::u104.
free_W :- u104, action(swerve_left), \+ curr_lane, free_NW, latent_collision.

0.5000000::u105.
free_W :- u105, action(swerve_right), \+ curr_lane, free_NW, latent_collision.

0.0009990::u106.
free_W :- u106, action(change_to_left), curr_lane, free_NW, latent_collision.

0.5379230::u107.
free_W :- u107, action(change_to_right), curr_lane, free_NW, latent_collision.

0.5180723::u108.
free_W :- u108, action(cruise), curr_lane, free_NW, latent_collision.

0.5000000::u109.
free_W :- u109, action(keep), curr_lane, free_NW, latent_collision.

0.5000000::u110.
free_W :- u110, action(swerve_left), curr_lane, free_NW, latent_collision.

0.5000000::u111.
free_W :- u111, action(swerve_right), curr_lane, free_NW, latent_collision.

0.8915588::u112.
latent_collision :- u112, action(change_to_left), \+ free_SW.

0.9935989::u113.
latent_collision :- u113, action(change_to_right), \+ free_SW.

0.2496831::u114.
latent_collision :- u114, action(cruise), \+ free_SW.

0.0009990::u115.
latent_collision :- u115, action(keep), \+ free_SW.

0.0009990::u116.
latent_collision :- u116, action(swerve_left), \+ free_SW.

0.0009990::u117.
latent_collision :- u117, action(swerve_right), \+ free_SW.

0.8612848::u118.
latent_collision :- u118, action(change_to_left), free_SW.

0.8053002::u119.
latent_collision :- u119, action(change_to_right), free_SW.

0.1915557::u120.
latent_collision :- u120, action(cruise), free_SW.

0.0009990::u121.
latent_collision :- u121, action(keep), free_SW.

0.0009990::u122.
latent_collision :- u122, action(swerve_left), free_SW.

0.0009990::u123.
latent_collision :- u123, action(swerve_right), free_SW.

