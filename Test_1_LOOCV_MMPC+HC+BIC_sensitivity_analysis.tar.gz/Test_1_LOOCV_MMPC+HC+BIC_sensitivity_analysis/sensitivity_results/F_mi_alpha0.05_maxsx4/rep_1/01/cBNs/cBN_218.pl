%%% Exogenous variables

0.1683919::u_action(change_to_left); 0.1709029::u_action(change_to_right); 0.4083735::u_action(cruise); 0.2501281::u_action(keep); 0.0013836::u_action(swerve_left); 0.0008199::u_action(swerve_right)
action(V) :- u_action(V).

0.3523283::u1.
curr_lane :- u1, \+ free_SE.

0.6477002::u2.
curr_lane :- u2, free_SE.

0.5585262::u3.
free_E :- u3, \+ curr_lane, \+ free_SE, \+ latent_collision.

0.9907881::u4.
free_E :- u4, curr_lane, \+ free_SE, \+ latent_collision.

0.6827862::u5.
free_E :- u5, \+ curr_lane, free_SE, \+ latent_collision.

0.9287613::u6.
free_E :- u6, curr_lane, free_SE, \+ latent_collision.

0.4420732::u7.
free_E :- u7, \+ curr_lane, \+ free_SE, latent_collision.

0.4914869::u8.
free_E :- u8, curr_lane, \+ free_SE, latent_collision.

0.4378321::u9.
free_E :- u9, \+ curr_lane, free_SE, latent_collision.

0.5441101::u10.
free_E :- u10, curr_lane, free_SE, latent_collision.

0.4660422::u11.
free_NE :- u11, action(change_to_left), \+ curr_lane, \+ free_E.

0.5305882::u12.
free_NE :- u12, action(change_to_right), \+ curr_lane, \+ free_E.

0.5323224::u13.
free_NE :- u13, action(cruise), \+ curr_lane, \+ free_E.

0.2598736::u14.
free_NE :- u14, action(keep), \+ curr_lane, \+ free_E.

0.0009990::u15.
free_NE :- u15, action(swerve_left), \+ curr_lane, \+ free_E.

0.5000000::u16.
free_NE :- u16, action(swerve_right), \+ curr_lane, \+ free_E.

0.5076709::u17.
free_NE :- u17, action(change_to_left), curr_lane, \+ free_E.

0.5130435::u18.
free_NE :- u18, action(change_to_right), curr_lane, \+ free_E.

0.2461538::u19.
free_NE :- u19, action(cruise), curr_lane, \+ free_E.

0.0009990::u20.
free_NE :- u20, action(keep), curr_lane, \+ free_E.

0.0009990::u21.
free_NE :- u21, action(swerve_left), curr_lane, \+ free_E.

0.5000000::u22.
free_NE :- u22, action(swerve_right), curr_lane, \+ free_E.

0.4741176::u23.
free_NE :- u23, action(change_to_left), \+ curr_lane, free_E.

0.4776119::u24.
free_NE :- u24, action(change_to_right), \+ curr_lane, free_E.

0.4522161::u25.
free_NE :- u25, action(cruise), \+ curr_lane, free_E.

0.0102981::u26.
free_NE :- u26, action(keep), \+ curr_lane, free_E.

0.5000000::u27.
free_NE :- u27, action(swerve_left), \+ curr_lane, free_E.

0.9990010::u28.
free_NE :- u28, action(swerve_right), \+ curr_lane, free_E.

0.5052023::u29.
free_NE :- u29, action(change_to_left), curr_lane, free_E.

0.5799087::u30.
free_NE :- u30, action(change_to_right), curr_lane, free_E.

0.9034091::u31.
free_NE :- u31, action(cruise), curr_lane, free_E.

0.0037221::u32.
free_NE :- u32, action(keep), curr_lane, free_E.

0.9990010::u33.
free_NE :- u33, action(swerve_left), curr_lane, free_E.

0.7333333::u34.
free_NE :- u34, action(swerve_right), curr_lane, free_E.

0.5109556::u35.
free_NW :- u35, action(change_to_left).

0.5511244::u36.
free_NW :- u36, action(change_to_right).

0.5291756::u37.
free_NW :- u37, action(cruise).

0.0327802::u38.
free_NW :- u38, action(keep).

0.9990010::u39.
free_NW :- u39, action(swerve_left).

0.7500000::u40.
free_NW :- u40, action(swerve_right).

0.9574228::u41.
free_SE :- u41, \+ free_SW, \+ latent_collision.

0.5767201::u42.
free_SE :- u42, free_SW, \+ latent_collision.

0.5034149::u43.
free_SE :- u43, \+ free_SW, latent_collision.

0.5109633::u44.
free_SE :- u44, free_SW, latent_collision.

0.5245800::u45.
free_SW :- u45, action(change_to_left), \+ free_NW.

0.5718103::u46.
free_SW :- u46, action(change_to_right), \+ free_NW.

0.5282516::u47.
free_SW :- u47, action(cruise), \+ free_NW.

0.9900445::u48.
free_SW :- u48, action(keep), \+ free_NW.

0.5000000::u49.
free_SW :- u49, action(swerve_left), \+ free_NW.

0.5000000::u50.
free_SW :- u50, action(swerve_right), \+ free_NW.

0.5300774::u51.
free_SW :- u51, action(change_to_left), free_NW.

0.6142546::u52.
free_SW :- u52, action(change_to_right), free_NW.

0.6689590::u53.
free_SW :- u53, action(cruise), free_NW.

0.6875000::u54.
free_SW :- u54, action(keep), free_NW.

0.9990010::u55.
free_SW :- u55, action(swerve_left), free_NW.

0.9990010::u56.
free_SW :- u56, action(swerve_right), free_NW.

0.5000000::u57.
free_W :- u57, action(change_to_left), \+ curr_lane, \+ free_NW, \+ latent_collision.

0.9990010::u58.
free_W :- u58, action(change_to_right), \+ curr_lane, \+ free_NW, \+ latent_collision.

0.5000000::u59.
free_W :- u59, action(cruise), \+ curr_lane, \+ free_NW, \+ latent_collision.

0.9990010::u60.
free_W :- u60, action(keep), \+ curr_lane, \+ free_NW, \+ latent_collision.

0.5000000::u61.
free_W :- u61, action(swerve_left), \+ curr_lane, \+ free_NW, \+ latent_collision.

0.5000000::u62.
free_W :- u62, action(swerve_right), \+ curr_lane, \+ free_NW, \+ latent_collision.

0.5000000::u63.
free_W :- u63, action(change_to_left), curr_lane, \+ free_NW, \+ latent_collision.

0.5000000::u64.
free_W :- u64, action(change_to_right), curr_lane, \+ free_NW, \+ latent_collision.

0.7335781::u65.
free_W :- u65, action(cruise), curr_lane, \+ free_NW, \+ latent_collision.

0.8301421::u66.
free_W :- u66, action(keep), curr_lane, \+ free_NW, \+ latent_collision.

0.5000000::u67.
free_W :- u67, action(swerve_left), curr_lane, \+ free_NW, \+ latent_collision.

0.7500000::u68.
free_W :- u68, action(swerve_right), curr_lane, \+ free_NW, \+ latent_collision.

0.5000000::u69.
free_W :- u69, action(change_to_left), \+ curr_lane, free_NW, \+ latent_collision.

0.9938838::u70.
free_W :- u70, action(change_to_right), \+ curr_lane, free_NW, \+ latent_collision.

0.9990010::u71.
free_W :- u71, action(cruise), \+ curr_lane, free_NW, \+ latent_collision.

0.9990010::u72.
free_W :- u72, action(keep), \+ curr_lane, free_NW, \+ latent_collision.

0.9990010::u73.
free_W :- u73, action(swerve_left), \+ curr_lane, free_NW, \+ latent_collision.

0.9990010::u74.
free_W :- u74, action(swerve_right), \+ curr_lane, free_NW, \+ latent_collision.

0.9990010::u75.
free_W :- u75, action(change_to_left), curr_lane, free_NW, \+ latent_collision.

0.5000000::u76.
free_W :- u76, action(change_to_right), curr_lane, free_NW, \+ latent_collision.

0.5939086::u77.
free_W :- u77, action(cruise), curr_lane, free_NW, \+ latent_collision.

0.3907285::u78.
free_W :- u78, action(keep), curr_lane, free_NW, \+ latent_collision.

0.9990010::u79.
free_W :- u79, action(swerve_left), curr_lane, free_NW, \+ latent_collision.

0.9990010::u80.
free_W :- u80, action(swerve_right), curr_lane, free_NW, \+ latent_collision.

0.4878049::u81.
free_W :- u81, action(change_to_left), \+ curr_lane, \+ free_NW, latent_collision.

0.5376176::u82.
free_W :- u82, action(change_to_right), \+ curr_lane, \+ free_NW, latent_collision.

0.5570776::u83.
free_W :- u83, action(cruise), \+ curr_lane, \+ free_NW, latent_collision.

0.5000000::u84.
free_W :- u84, action(keep), \+ curr_lane, \+ free_NW, latent_collision.

0.5000000::u85.
free_W :- u85, action(swerve_left), \+ curr_lane, \+ free_NW, latent_collision.

0.5000000::u86.
free_W :- u86, action(swerve_right), \+ curr_lane, \+ free_NW, latent_collision.

0.5336722::u87.
free_W :- u87, action(change_to_left), curr_lane, \+ free_NW, latent_collision.

0.5311721::u88.
free_W :- u88, action(change_to_right), curr_lane, \+ free_NW, latent_collision.

0.5552941::u89.
free_W :- u89, action(cruise), curr_lane, \+ free_NW, latent_collision.

0.5000000::u90.
free_W :- u90, action(keep), curr_lane, \+ free_NW, latent_collision.

0.5000000::u91.
free_W :- u91, action(swerve_left), curr_lane, \+ free_NW, latent_collision.

0.5000000::u92.
free_W :- u92, action(swerve_right), curr_lane, \+ free_NW, latent_collision.

0.5407240::u93.
free_W :- u93, action(change_to_left), \+ curr_lane, free_NW, latent_collision.

0.5110759::u94.
free_W :- u94, action(change_to_right), \+ curr_lane, free_NW, latent_collision.

0.5000000::u95.
free_W :- u95, action(cruise), \+ curr_lane, free_NW, latent_collision.

0.5000000::u96.
free_W :- u96, action(keep), \+ curr_lane, free_NW, latent_collision.

0.5000000::u97.
free_W :- u97, action(swerve_left), \+ curr_lane, free_NW, latent_collision.

0.5000000::u98.
free_W :- u98, action(swerve_right), \+ curr_lane, free_NW, latent_collision.

0.0009990::u99.
free_W :- u99, action(change_to_left), curr_lane, free_NW, latent_collision.

0.5620023::u100.
free_W :- u100, action(change_to_right), curr_lane, free_NW, latent_collision.

0.5281690::u101.
free_W :- u101, action(cruise), curr_lane, free_NW, latent_collision.

0.5000000::u102.
free_W :- u102, action(keep), curr_lane, free_NW, latent_collision.

0.5000000::u103.
free_W :- u103, action(swerve_left), curr_lane, free_NW, latent_collision.

0.5000000::u104.
free_W :- u104, action(swerve_right), curr_lane, free_NW, latent_collision.

0.8892466::u105.
latent_collision :- u105, action(change_to_left), \+ free_SW.

0.9948148::u106.
latent_collision :- u106, action(change_to_right), \+ free_SW.

0.2495262::u107.
latent_collision :- u107, action(cruise), \+ free_SW.

0.0009990::u108.
latent_collision :- u108, action(keep), \+ free_SW.

0.5000000::u109.
latent_collision :- u109, action(swerve_left), \+ free_SW.

0.0009990::u110.
latent_collision :- u110, action(swerve_right), \+ free_SW.

0.8736295::u111.
latent_collision :- u111, action(change_to_left), free_SW.

0.8100756::u112.
latent_collision :- u112, action(change_to_right), free_SW.

0.1950864::u113.
latent_collision :- u113, action(cruise), free_SW.

0.0009990::u114.
latent_collision :- u114, action(keep), free_SW.

0.0009990::u115.
latent_collision :- u115, action(swerve_left), free_SW.

0.0009990::u116.
latent_collision :- u116, action(swerve_right), free_SW.

