%%% Exogenous variables

0.1704593::u_action(change_to_left); 0.1669784::u_action(change_to_right); 0.4124065::u_action(cruise); 0.2471945::u_action(keep); 0.0017664::u_action(swerve_left); 0.0011949::u_action(swerve_right)
action(V) :- u_action(V).

0.4312977::u1.
curr_lane :- u1, \+ free_NE.

0.6677741::u2.
curr_lane :- u2, free_NE.

0.6537234::u3.
free_E :- u3, \+ curr_lane, \+ free_NE, \+ latent_collision.

0.8690535::u4.
free_E :- u4, curr_lane, \+ free_NE, \+ latent_collision.

0.6111929::u5.
free_E :- u5, \+ curr_lane, free_NE, \+ latent_collision.

0.9617904::u6.
free_E :- u6, curr_lane, free_NE, \+ latent_collision.

0.5275475::u7.
free_E :- u7, \+ curr_lane, \+ free_NE, latent_collision.

0.5168919::u8.
free_E :- u8, curr_lane, \+ free_NE, latent_collision.

0.4007308::u9.
free_E :- u9, \+ curr_lane, free_NE, latent_collision.

0.5262069::u10.
free_E :- u10, curr_lane, free_NE, latent_collision.

0.4946663::u11.
free_NE :- u11, action(change_to_left).

0.5074673::u12.
free_NE :- u12, action(change_to_right).

0.7042076::u13.
free_NE :- u13, action(cruise).

0.0283733::u14.
free_NE :- u14, action(keep).

0.8235294::u15.
free_NE :- u15, action(swerve_left).

0.9990010::u16.
free_NE :- u16, action(swerve_right).

0.5220969::u17.
free_NW :- u17, action(change_to_left).

0.5382701::u18.
free_NW :- u18, action(change_to_right).

0.5233056::u19.
free_NW :- u19, action(cruise).

0.0294241::u20.
free_NW :- u20, action(keep).

0.9117647::u21.
free_NW :- u21, action(swerve_left).

0.8695652::u22.
free_NW :- u22, action(swerve_right).

0.6250000::u23.
free_SE :- u23, \+ curr_lane, \+ free_E, \+ free_SW, \+ latent_collision.

0.9990010::u24.
free_SE :- u24, curr_lane, \+ free_E, \+ free_SW, \+ latent_collision.

0.8411765::u25.
free_SE :- u25, \+ curr_lane, free_E, \+ free_SW, \+ latent_collision.

0.9729965::u26.
free_SE :- u26, curr_lane, free_E, \+ free_SW, \+ latent_collision.

0.3748538::u27.
free_SE :- u27, \+ curr_lane, \+ free_E, free_SW, \+ latent_collision.

0.9784173::u28.
free_SE :- u28, curr_lane, \+ free_E, free_SW, \+ latent_collision.

0.4384221::u29.
free_SE :- u29, \+ curr_lane, free_E, free_SW, \+ latent_collision.

0.7696470::u30.
free_SE :- u30, curr_lane, free_E, free_SW, \+ latent_collision.

0.5153374::u31.
free_SE :- u31, \+ curr_lane, \+ free_E, \+ free_SW, latent_collision.

0.5115766::u32.
free_SE :- u32, curr_lane, \+ free_E, \+ free_SW, latent_collision.

0.5011962::u33.
free_SE :- u33, \+ curr_lane, free_E, \+ free_SW, latent_collision.

0.5037513::u34.
free_SE :- u34, curr_lane, free_E, \+ free_SW, latent_collision.

0.5312821::u35.
free_SE :- u35, \+ curr_lane, \+ free_E, free_SW, latent_collision.

0.4924242::u36.
free_SE :- u36, curr_lane, \+ free_E, free_SW, latent_collision.

0.4988938::u37.
free_SE :- u37, \+ curr_lane, free_E, free_SW, latent_collision.

0.5370019::u38.
free_SE :- u38, curr_lane, free_E, free_SW, latent_collision.

0.4885204::u39.
free_SW :- u39, action(change_to_left), \+ free_NW.

0.5242588::u40.
free_SW :- u40, action(change_to_right), \+ free_NW.

0.5322410::u41.
free_SW :- u41, action(cruise), \+ free_NW.

0.9848419::u42.
free_SW :- u42, action(keep), \+ free_NW.

0.6666667::u43.
free_SW :- u43, action(swerve_left), \+ free_NW.

0.6666667::u44.
free_SW :- u44, action(swerve_right), \+ free_NW.

0.5312318::u45.
free_SW :- u45, action(change_to_left), free_NW.

0.6260116::u46.
free_SW :- u46, action(change_to_right), free_NW.

0.6581608::u47.
free_SW :- u47, action(cruise), free_NW.

0.6857143::u48.
free_SW :- u48, action(keep), free_NW.

0.9677419::u49.
free_SW :- u49, action(swerve_left), free_NW.

0.9990010::u50.
free_SW :- u50, action(swerve_right), free_NW.

0.5000000::u51.
free_W :- u51, action(change_to_left), \+ curr_lane, \+ free_NW, \+ latent_collision.

0.9838710::u52.
free_W :- u52, action(change_to_right), \+ curr_lane, \+ free_NW, \+ latent_collision.

0.5000000::u53.
free_W :- u53, action(cruise), \+ curr_lane, \+ free_NW, \+ latent_collision.

0.9996578::u54.
free_W :- u54, action(keep), \+ curr_lane, \+ free_NW, \+ latent_collision.

0.5000000::u55.
free_W :- u55, action(swerve_left), \+ curr_lane, \+ free_NW, \+ latent_collision.

0.5000000::u56.
free_W :- u56, action(swerve_right), \+ curr_lane, \+ free_NW, \+ latent_collision.

0.5000000::u57.
free_W :- u57, action(change_to_left), curr_lane, \+ free_NW, \+ latent_collision.

0.5000000::u58.
free_W :- u58, action(change_to_right), curr_lane, \+ free_NW, \+ latent_collision.

0.7348296::u59.
free_W :- u59, action(cruise), curr_lane, \+ free_NW, \+ latent_collision.

0.8301887::u60.
free_W :- u60, action(keep), curr_lane, \+ free_NW, \+ latent_collision.

0.9990010::u61.
free_W :- u61, action(swerve_left), curr_lane, \+ free_NW, \+ latent_collision.

0.0009990::u62.
free_W :- u62, action(swerve_right), curr_lane, \+ free_NW, \+ latent_collision.

0.5000000::u63.
free_W :- u63, action(change_to_left), \+ curr_lane, free_NW, \+ latent_collision.

0.9990010::u64.
free_W :- u64, action(change_to_right), \+ curr_lane, free_NW, \+ latent_collision.

0.9990010::u65.
free_W :- u65, action(cruise), \+ curr_lane, free_NW, \+ latent_collision.

0.9990010::u66.
free_W :- u66, action(keep), \+ curr_lane, free_NW, \+ latent_collision.

0.9990010::u67.
free_W :- u67, action(swerve_left), \+ curr_lane, free_NW, \+ latent_collision.

0.5000000::u68.
free_W :- u68, action(swerve_right), \+ curr_lane, free_NW, \+ latent_collision.

0.9990010::u69.
free_W :- u69, action(change_to_left), curr_lane, free_NW, \+ latent_collision.

0.5000000::u70.
free_W :- u70, action(change_to_right), curr_lane, free_NW, \+ latent_collision.

0.6049448::u71.
free_W :- u71, action(cruise), curr_lane, free_NW, \+ latent_collision.

0.4885496::u72.
free_W :- u72, action(keep), curr_lane, free_NW, \+ latent_collision.

0.9990010::u73.
free_W :- u73, action(swerve_left), curr_lane, free_NW, \+ latent_collision.

0.9990010::u74.
free_W :- u74, action(swerve_right), curr_lane, free_NW, \+ latent_collision.

0.4635762::u75.
free_W :- u75, action(change_to_left), \+ curr_lane, \+ free_NW, latent_collision.

0.5045704::u76.
free_W :- u76, action(change_to_right), \+ curr_lane, \+ free_NW, latent_collision.

0.5072788::u77.
free_W :- u77, action(cruise), \+ curr_lane, \+ free_NW, latent_collision.

0.5000000::u78.
free_W :- u78, action(keep), \+ curr_lane, \+ free_NW, latent_collision.

0.5000000::u79.
free_W :- u79, action(swerve_left), \+ curr_lane, \+ free_NW, latent_collision.

0.5000000::u80.
free_W :- u80, action(swerve_right), \+ curr_lane, \+ free_NW, latent_collision.

0.5338253::u81.
free_W :- u81, action(change_to_left), curr_lane, \+ free_NW, latent_collision.

0.4880000::u82.
free_W :- u82, action(change_to_right), curr_lane, \+ free_NW, latent_collision.

0.5113402::u83.
free_W :- u83, action(cruise), curr_lane, \+ free_NW, latent_collision.

0.5000000::u84.
free_W :- u84, action(keep), curr_lane, \+ free_NW, latent_collision.

0.5000000::u85.
free_W :- u85, action(swerve_left), curr_lane, \+ free_NW, latent_collision.

0.5000000::u86.
free_W :- u86, action(swerve_right), curr_lane, \+ free_NW, latent_collision.

0.5762712::u87.
free_W :- u87, action(change_to_left), \+ curr_lane, free_NW, latent_collision.

0.4861338::u88.
free_W :- u88, action(change_to_right), \+ curr_lane, free_NW, latent_collision.

0.5000000::u89.
free_W :- u89, action(cruise), \+ curr_lane, free_NW, latent_collision.

0.5000000::u90.
free_W :- u90, action(keep), \+ curr_lane, free_NW, latent_collision.

0.5000000::u91.
free_W :- u91, action(swerve_left), \+ curr_lane, free_NW, latent_collision.

0.5000000::u92.
free_W :- u92, action(swerve_right), \+ curr_lane, free_NW, latent_collision.

0.0009990::u93.
free_W :- u93, action(change_to_left), curr_lane, free_NW, latent_collision.

0.5380711::u94.
free_W :- u94, action(change_to_right), curr_lane, free_NW, latent_collision.

0.4989107::u95.
free_W :- u95, action(cruise), curr_lane, free_NW, latent_collision.

0.5000000::u96.
free_W :- u96, action(keep), curr_lane, free_NW, latent_collision.

0.5000000::u97.
free_W :- u97, action(swerve_left), curr_lane, free_NW, latent_collision.

0.5000000::u98.
free_W :- u98, action(swerve_right), curr_lane, free_NW, latent_collision.

0.8934579::u99.
latent_collision :- u99, action(change_to_left), \+ free_SW.

0.9948263::u100.
latent_collision :- u100, action(change_to_right), \+ free_SW.

0.2739812::u101.
latent_collision :- u101, action(cruise), \+ free_SW.

0.0009990::u102.
latent_collision :- u102, action(keep), \+ free_SW.

0.0009990::u103.
latent_collision :- u103, action(swerve_left), \+ free_SW.

0.0009990::u104.
latent_collision :- u104, action(swerve_right), \+ free_SW.

0.8454654::u105.
latent_collision :- u105, action(change_to_left), free_SW.

0.7936593::u106.
latent_collision :- u106, action(change_to_right), free_SW.

0.2028222::u107.
latent_collision :- u107, action(cruise), free_SW.

0.0009990::u108.
latent_collision :- u108, action(keep), free_SW.

0.0009990::u109.
latent_collision :- u109, action(swerve_left), free_SW.

0.0009990::u110.
latent_collision :- u110, action(swerve_right), free_SW.

