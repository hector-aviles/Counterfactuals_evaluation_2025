%%% Exogenous variables

0.1647610::u_action(change_to_left); 0.1700659::u_action(change_to_right); 0.4092501::u_action(cruise); 0.2536053::u_action(keep); 0.0016481::u_action(swerve_left); 0.0006696::u_action(swerve_right)
action(V) :- u_action(V).

0.5298723::u1.
curr_lane :- u1.

0.6147283::u2.
free_E :- u2, \+ curr_lane, \+ latent_collision.

0.9343635::u3.
free_E :- u3, curr_lane, \+ latent_collision.

0.4551780::u4.
free_E :- u4, \+ curr_lane, latent_collision.

0.5151919::u5.
free_E :- u5, curr_lane, latent_collision.

0.4713896::u6.
free_NE :- u6, action(change_to_left), \+ curr_lane, \+ free_E, \+ free_SW.

0.5090909::u7.
free_NE :- u7, action(change_to_right), \+ curr_lane, \+ free_E, \+ free_SW.

0.4827586::u8.
free_NE :- u8, action(cruise), \+ curr_lane, \+ free_E, \+ free_SW.

0.0009990::u9.
free_NE :- u9, action(keep), \+ curr_lane, \+ free_E, \+ free_SW.

0.5000000::u10.
free_NE :- u10, action(swerve_left), \+ curr_lane, \+ free_E, \+ free_SW.

0.5000000::u11.
free_NE :- u11, action(swerve_right), \+ curr_lane, \+ free_E, \+ free_SW.

0.5015198::u12.
free_NE :- u12, action(change_to_left), curr_lane, \+ free_E, \+ free_SW.

0.4893048::u13.
free_NE :- u13, action(change_to_right), curr_lane, \+ free_E, \+ free_SW.

0.0607477::u14.
free_NE :- u14, action(cruise), curr_lane, \+ free_E, \+ free_SW.

0.0009990::u15.
free_NE :- u15, action(keep), curr_lane, \+ free_E, \+ free_SW.

0.5000000::u16.
free_NE :- u16, action(swerve_left), curr_lane, \+ free_E, \+ free_SW.

0.5000000::u17.
free_NE :- u17, action(swerve_right), curr_lane, \+ free_E, \+ free_SW.

0.4753695::u18.
free_NE :- u18, action(change_to_left), \+ curr_lane, free_E, \+ free_SW.

0.0294118::u19.
free_NE :- u19, action(change_to_right), \+ curr_lane, free_E, \+ free_SW.

0.3211268::u20.
free_NE :- u20, action(cruise), \+ curr_lane, free_E, \+ free_SW.

0.5000000::u21.
free_NE :- u21, action(keep), \+ curr_lane, free_E, \+ free_SW.

0.5000000::u22.
free_NE :- u22, action(swerve_left), \+ curr_lane, free_E, \+ free_SW.

0.5000000::u23.
free_NE :- u23, action(swerve_right), \+ curr_lane, free_E, \+ free_SW.

0.6449086::u24.
free_NE :- u24, action(change_to_left), curr_lane, free_E, \+ free_SW.

0.5459318::u25.
free_NE :- u25, action(change_to_right), curr_lane, free_E, \+ free_SW.

0.9228381::u26.
free_NE :- u26, action(cruise), curr_lane, free_E, \+ free_SW.

0.0009990::u27.
free_NE :- u27, action(keep), curr_lane, free_E, \+ free_SW.

0.0009990::u28.
free_NE :- u28, action(swerve_left), curr_lane, free_E, \+ free_SW.

0.9990010::u29.
free_NE :- u29, action(swerve_right), curr_lane, free_E, \+ free_SW.

0.4987212::u30.
free_NE :- u30, action(change_to_left), \+ curr_lane, \+ free_E, free_SW.

0.5247748::u31.
free_NE :- u31, action(change_to_right), \+ curr_lane, \+ free_E, free_SW.

0.5768834::u32.
free_NE :- u32, action(cruise), \+ curr_lane, \+ free_E, free_SW.

0.2561459::u33.
free_NE :- u33, action(keep), \+ curr_lane, \+ free_E, free_SW.

0.5000000::u34.
free_NE :- u34, action(swerve_left), \+ curr_lane, \+ free_E, free_SW.

0.5000000::u35.
free_NE :- u35, action(swerve_right), \+ curr_lane, \+ free_E, free_SW.

0.4725275::u36.
free_NE :- u36, action(change_to_left), curr_lane, \+ free_E, free_SW.

0.4611650::u37.
free_NE :- u37, action(change_to_right), curr_lane, \+ free_E, free_SW.

0.3356890::u38.
free_NE :- u38, action(cruise), curr_lane, \+ free_E, free_SW.

0.0009990::u39.
free_NE :- u39, action(keep), curr_lane, \+ free_E, free_SW.

0.0009990::u40.
free_NE :- u40, action(swerve_left), curr_lane, \+ free_E, free_SW.

0.5000000::u41.
free_NE :- u41, action(swerve_right), curr_lane, \+ free_E, free_SW.

0.4886878::u42.
free_NE :- u42, action(change_to_left), \+ curr_lane, free_E, free_SW.

0.6501650::u43.
free_NE :- u43, action(change_to_right), \+ curr_lane, free_E, free_SW.

0.4754098::u44.
free_NE :- u44, action(cruise), \+ curr_lane, free_E, free_SW.

0.0147139::u45.
free_NE :- u45, action(keep), \+ curr_lane, free_E, free_SW.

0.8571429::u46.
free_NE :- u46, action(swerve_left), \+ curr_lane, free_E, free_SW.

0.9990010::u47.
free_NE :- u47, action(swerve_right), \+ curr_lane, free_E, free_SW.

0.5234742::u48.
free_NE :- u48, action(change_to_left), curr_lane, free_E, free_SW.

0.5806452::u49.
free_NE :- u49, action(change_to_right), curr_lane, free_E, free_SW.

0.8959108::u50.
free_NE :- u50, action(cruise), curr_lane, free_E, free_SW.

0.0045161::u51.
free_NE :- u51, action(keep), curr_lane, free_E, free_SW.

0.8695652::u52.
free_NE :- u52, action(swerve_left), curr_lane, free_E, free_SW.

0.8181818::u53.
free_NE :- u53, action(swerve_right), curr_lane, free_E, free_SW.

0.4945295::u54.
free_NW :- u54, action(change_to_left).

0.5484555::u55.
free_NW :- u55, action(change_to_right).

0.5298263::u56.
free_NW :- u56, action(cruise).

0.0243704::u57.
free_NW :- u57, action(keep).

0.9687500::u58.
free_NW :- u58, action(swerve_left).

0.6923077::u59.
free_NW :- u59, action(swerve_right).

0.6460177::u60.
free_SE :- u60, \+ curr_lane, \+ free_E, \+ free_SW, \+ latent_collision.

0.9990010::u61.
free_SE :- u61, curr_lane, \+ free_E, \+ free_SW, \+ latent_collision.

0.8812500::u62.
free_SE :- u62, \+ curr_lane, free_E, \+ free_SW, \+ latent_collision.

0.9679430::u63.
free_SE :- u63, curr_lane, free_E, \+ free_SW, \+ latent_collision.

0.3248473::u64.
free_SE :- u64, \+ curr_lane, \+ free_E, free_SW, \+ latent_collision.

0.9801489::u65.
free_SE :- u65, curr_lane, \+ free_E, free_SW, \+ latent_collision.

0.4454661::u66.
free_SE :- u66, \+ curr_lane, free_E, free_SW, \+ latent_collision.

0.7544678::u67.
free_SE :- u67, curr_lane, free_E, free_SW, \+ latent_collision.

0.5005348::u68.
free_SE :- u68, \+ curr_lane, \+ free_E, \+ free_SW, latent_collision.

0.4775785::u69.
free_SE :- u69, curr_lane, \+ free_E, \+ free_SW, latent_collision.

0.4968944::u70.
free_SE :- u70, \+ curr_lane, free_E, \+ free_SW, latent_collision.

0.4671280::u71.
free_SE :- u71, curr_lane, free_E, \+ free_SW, latent_collision.

0.5158946::u72.
free_SE :- u72, \+ curr_lane, \+ free_E, free_SW, latent_collision.

0.4962244::u73.
free_SE :- u73, curr_lane, \+ free_E, free_SW, latent_collision.

0.5379464::u74.
free_SE :- u74, \+ curr_lane, free_E, free_SW, latent_collision.

0.5272045::u75.
free_SE :- u75, curr_lane, free_E, free_SW, latent_collision.

0.5357924::u76.
free_SW :- u76, action(change_to_left).

0.5929740::u77.
free_SW :- u77, action(change_to_right).

0.6081047::u78.
free_SW :- u78, action(cruise).

0.9798944::u79.
free_SW :- u79, action(keep).

0.9687500::u80.
free_SW :- u80, action(swerve_left).

0.9230769::u81.
free_SW :- u81, action(swerve_right).

0.5000000::u82.
free_W :- u82, action(change_to_left), \+ curr_lane, \+ free_NW, \+ latent_collision.

0.9420290::u83.
free_W :- u83, action(change_to_right), \+ curr_lane, \+ free_NW, \+ latent_collision.

0.5000000::u84.
free_W :- u84, action(cruise), \+ curr_lane, \+ free_NW, \+ latent_collision.

0.9990010::u85.
free_W :- u85, action(keep), \+ curr_lane, \+ free_NW, \+ latent_collision.

0.5000000::u86.
free_W :- u86, action(swerve_left), \+ curr_lane, \+ free_NW, \+ latent_collision.

0.5000000::u87.
free_W :- u87, action(swerve_right), \+ curr_lane, \+ free_NW, \+ latent_collision.

0.5000000::u88.
free_W :- u88, action(change_to_left), curr_lane, \+ free_NW, \+ latent_collision.

0.5000000::u89.
free_W :- u89, action(change_to_right), curr_lane, \+ free_NW, \+ latent_collision.

0.7558570::u90.
free_W :- u90, action(cruise), curr_lane, \+ free_NW, \+ latent_collision.

0.8194039::u91.
free_W :- u91, action(keep), curr_lane, \+ free_NW, \+ latent_collision.

0.9990010::u92.
free_W :- u92, action(swerve_left), curr_lane, \+ free_NW, \+ latent_collision.

0.2500000::u93.
free_W :- u93, action(swerve_right), curr_lane, \+ free_NW, \+ latent_collision.

0.5000000::u94.
free_W :- u94, action(change_to_left), \+ curr_lane, free_NW, \+ latent_collision.

0.9990010::u95.
free_W :- u95, action(change_to_right), \+ curr_lane, free_NW, \+ latent_collision.

0.9994684::u96.
free_W :- u96, action(cruise), \+ curr_lane, free_NW, \+ latent_collision.

0.9990010::u97.
free_W :- u97, action(keep), \+ curr_lane, free_NW, \+ latent_collision.

0.9990010::u98.
free_W :- u98, action(swerve_left), \+ curr_lane, free_NW, \+ latent_collision.

0.9990010::u99.
free_W :- u99, action(swerve_right), \+ curr_lane, free_NW, \+ latent_collision.

0.9990010::u100.
free_W :- u100, action(change_to_left), curr_lane, free_NW, \+ latent_collision.

0.5000000::u101.
free_W :- u101, action(change_to_right), curr_lane, free_NW, \+ latent_collision.

0.5922078::u102.
free_W :- u102, action(cruise), curr_lane, free_NW, \+ latent_collision.

0.2342342::u103.
free_W :- u103, action(keep), curr_lane, free_NW, \+ latent_collision.

0.9990010::u104.
free_W :- u104, action(swerve_left), curr_lane, free_NW, \+ latent_collision.

0.9990010::u105.
free_W :- u105, action(swerve_right), curr_lane, free_NW, \+ latent_collision.

0.4878361::u106.
free_W :- u106, action(change_to_left), \+ curr_lane, \+ free_NW, latent_collision.

0.5065359::u107.
free_W :- u107, action(change_to_right), \+ curr_lane, \+ free_NW, latent_collision.

0.5683857::u108.
free_W :- u108, action(cruise), \+ curr_lane, \+ free_NW, latent_collision.

0.5000000::u109.
free_W :- u109, action(keep), \+ curr_lane, \+ free_NW, latent_collision.

0.5000000::u110.
free_W :- u110, action(swerve_left), \+ curr_lane, \+ free_NW, latent_collision.

0.5000000::u111.
free_W :- u111, action(swerve_right), \+ curr_lane, \+ free_NW, latent_collision.

0.5131579::u112.
free_W :- u112, action(change_to_left), curr_lane, \+ free_NW, latent_collision.

0.5419753::u113.
free_W :- u113, action(change_to_right), curr_lane, \+ free_NW, latent_collision.

0.5231144::u114.
free_W :- u114, action(cruise), curr_lane, \+ free_NW, latent_collision.

0.5000000::u115.
free_W :- u115, action(keep), curr_lane, \+ free_NW, latent_collision.

0.5000000::u116.
free_W :- u116, action(swerve_left), curr_lane, \+ free_NW, latent_collision.

0.5000000::u117.
free_W :- u117, action(swerve_right), curr_lane, \+ free_NW, latent_collision.

0.5684848::u118.
free_W :- u118, action(change_to_left), \+ curr_lane, free_NW, latent_collision.

0.5039872::u119.
free_W :- u119, action(change_to_right), \+ curr_lane, free_NW, latent_collision.

0.5000000::u120.
free_W :- u120, action(cruise), \+ curr_lane, free_NW, latent_collision.

0.5000000::u121.
free_W :- u121, action(keep), \+ curr_lane, free_NW, latent_collision.

0.5000000::u122.
free_W :- u122, action(swerve_left), \+ curr_lane, free_NW, latent_collision.

0.5000000::u123.
free_W :- u123, action(swerve_right), \+ curr_lane, free_NW, latent_collision.

0.0009990::u124.
free_W :- u124, action(change_to_left), curr_lane, free_NW, latent_collision.

0.5404455::u125.
free_W :- u125, action(change_to_right), curr_lane, free_NW, latent_collision.

0.5000000::u126.
free_W :- u126, action(cruise), curr_lane, free_NW, latent_collision.

0.5000000::u127.
free_W :- u127, action(keep), curr_lane, free_NW, latent_collision.

0.5000000::u128.
free_W :- u128, action(swerve_left), curr_lane, free_NW, latent_collision.

0.5000000::u129.
free_W :- u129, action(swerve_right), curr_lane, free_NW, latent_collision.

0.9441077::u130.
latent_collision :- u130, action(change_to_left), \+ free_SW.

0.9955357::u131.
latent_collision :- u131, action(change_to_right), \+ free_SW.

0.2437380::u132.
latent_collision :- u132, action(cruise), \+ free_SW.

0.0009990::u133.
latent_collision :- u133, action(keep), \+ free_SW.

0.0009990::u134.
latent_collision :- u134, action(swerve_left), \+ free_SW.

0.0009990::u135.
latent_collision :- u135, action(swerve_right), \+ free_SW.

0.8623104::u136.
latent_collision :- u136, action(change_to_left), free_SW.

0.7987743::u137.
latent_collision :- u137, action(change_to_right), free_SW.

0.1961921::u138.
latent_collision :- u138, action(cruise), free_SW.

0.0009990::u139.
latent_collision :- u139, action(keep), free_SW.

0.0009990::u140.
latent_collision :- u140, action(swerve_left), free_SW.

0.0009990::u141.
latent_collision :- u141, action(swerve_right), free_SW.

