%%% Exogenous variables

0.1685849::u_action(change_to_left); 0.1728497::u_action(change_to_right); 0.4096187::u_action(cruise); 0.2467886::u_action(keep); 0.0012332::u_action(swerve_left); 0.0009249::u_action(swerve_right)
action(V) :- u_action(V).

0.5283116::u1.
curr_lane :- u1.

0.6112782::u2.
free_E :- u2, \+ curr_lane, \+ latent_collision.

0.9362519::u3.
free_E :- u3, curr_lane, \+ latent_collision.

0.4479275::u4.
free_E :- u4, \+ curr_lane, latent_collision.

0.5201485::u5.
free_E :- u5, curr_lane, latent_collision.

0.4790875::u6.
free_NE :- u6, action(change_to_left), \+ curr_lane, \+ free_E.

0.5091533::u7.
free_NE :- u7, action(change_to_right), \+ curr_lane, \+ free_E.

0.5183164::u8.
free_NE :- u8, action(cruise), \+ curr_lane, \+ free_E.

0.2577813::u9.
free_NE :- u9, action(keep), \+ curr_lane, \+ free_E.

0.5000000::u10.
free_NE :- u10, action(swerve_left), \+ curr_lane, \+ free_E.

0.5000000::u11.
free_NE :- u11, action(swerve_right), \+ curr_lane, \+ free_E.

0.4848901::u12.
free_NE :- u12, action(change_to_left), curr_lane, \+ free_E.

0.5083227::u13.
free_NE :- u13, action(change_to_right), curr_lane, \+ free_E.

0.1955307::u14.
free_NE :- u14, action(cruise), curr_lane, \+ free_E.

0.0009990::u15.
free_NE :- u15, action(keep), curr_lane, \+ free_E.

0.5000000::u16.
free_NE :- u16, action(swerve_left), curr_lane, \+ free_E.

0.5000000::u17.
free_NE :- u17, action(swerve_right), curr_lane, \+ free_E.

0.4762443::u18.
free_NE :- u18, action(change_to_left), \+ curr_lane, free_E.

0.4961735::u19.
free_NE :- u19, action(change_to_right), \+ curr_lane, free_E.

0.4403485::u20.
free_NE :- u20, action(cruise), \+ curr_lane, free_E.

0.0087912::u21.
free_NE :- u21, action(keep), \+ curr_lane, free_E.

0.9990010::u22.
free_NE :- u22, action(swerve_left), \+ curr_lane, free_E.

0.5000000::u23.
free_NE :- u23, action(swerve_right), \+ curr_lane, free_E.

0.5011364::u24.
free_NE :- u24, action(change_to_left), curr_lane, free_E.

0.5351351::u25.
free_NE :- u25, action(change_to_right), curr_lane, free_E.

0.9047210::u26.
free_NE :- u26, action(cruise), curr_lane, free_E.

0.0045132::u27.
free_NE :- u27, action(keep), curr_lane, free_E.

0.8260870::u28.
free_NE :- u28, action(swerve_left), curr_lane, free_E.

0.8333333::u29.
free_NE :- u29, action(swerve_right), curr_lane, free_E.

0.5028955::u30.
free_NW :- u30, action(change_to_left).

0.5558859::u31.
free_NW :- u31, action(change_to_right).

0.5164325::u32.
free_NW :- u32, action(cruise).

0.0204039::u33.
free_NW :- u33, action(keep).

0.9166667::u34.
free_NW :- u34, action(swerve_left).

0.5555556::u35.
free_NW :- u35, action(swerve_right).

0.6496350::u36.
free_SE :- u36, \+ curr_lane, \+ free_E, \+ free_SW, \+ latent_collision.

0.9990010::u37.
free_SE :- u37, curr_lane, \+ free_E, \+ free_SW, \+ latent_collision.

0.9017341::u38.
free_SE :- u38, \+ curr_lane, free_E, \+ free_SW, \+ latent_collision.

0.9724409::u39.
free_SE :- u39, curr_lane, free_E, \+ free_SW, \+ latent_collision.

0.3345417::u40.
free_SE :- u40, \+ curr_lane, \+ free_E, free_SW, \+ latent_collision.

0.9872449::u41.
free_SE :- u41, curr_lane, \+ free_E, free_SW, \+ latent_collision.

0.4313089::u42.
free_SE :- u42, \+ curr_lane, free_E, free_SW, \+ latent_collision.

0.7684432::u43.
free_SE :- u43, curr_lane, free_E, free_SW, \+ latent_collision.

0.5004926::u44.
free_SE :- u44, \+ curr_lane, \+ free_E, \+ free_SW, latent_collision.

0.5137131::u45.
free_SE :- u45, curr_lane, \+ free_E, \+ free_SW, latent_collision.

0.5162500::u46.
free_SE :- u46, \+ curr_lane, free_E, \+ free_SW, latent_collision.

0.4994882::u47.
free_SE :- u47, curr_lane, free_E, \+ free_SW, latent_collision.

0.5089606::u48.
free_SE :- u48, \+ curr_lane, \+ free_E, free_SW, latent_collision.

0.4953596::u49.
free_SE :- u49, curr_lane, \+ free_E, free_SW, latent_collision.

0.5026911::u50.
free_SE :- u50, \+ curr_lane, free_E, free_SW, latent_collision.

0.4822335::u51.
free_SE :- u51, curr_lane, free_E, free_SW, latent_collision.

0.4923360::u52.
free_SW :- u52, action(change_to_left), \+ free_NW.

0.5281124::u53.
free_SW :- u53, action(change_to_right), \+ free_NW.

0.5299611::u54.
free_SW :- u54, action(cruise), \+ free_NW.

0.9844846::u55.
free_SW :- u55, action(keep), \+ free_NW.

0.5000000::u56.
free_SW :- u56, action(swerve_left), \+ free_NW.

0.7500000::u57.
free_SW :- u57, action(swerve_right), \+ free_NW.

0.5272727::u58.
free_SW :- u58, action(change_to_left), free_NW.

0.5930481::u59.
free_SW :- u59, action(change_to_right), free_NW.

0.6716055::u60.
free_SW :- u60, action(cruise), free_NW.

0.5510204::u61.
free_SW :- u61, action(keep), free_NW.

0.9990010::u62.
free_SW :- u62, action(swerve_left), free_NW.

0.9000000::u63.
free_SW :- u63, action(swerve_right), free_NW.

0.5000000::u64.
free_W :- u64, action(change_to_left), \+ curr_lane, \+ latent_collision.

0.9990010::u65.
free_W :- u65, action(change_to_right), \+ curr_lane, \+ latent_collision.

0.9989230::u66.
free_W :- u66, action(cruise), \+ curr_lane, \+ latent_collision.

0.9990010::u67.
free_W :- u67, action(keep), \+ curr_lane, \+ latent_collision.

0.9990010::u68.
free_W :- u68, action(swerve_left), \+ curr_lane, \+ latent_collision.

0.5000000::u69.
free_W :- u69, action(swerve_right), \+ curr_lane, \+ latent_collision.

0.9990010::u70.
free_W :- u70, action(change_to_left), curr_lane, \+ latent_collision.

0.5000000::u71.
free_W :- u71, action(change_to_right), curr_lane, \+ latent_collision.

0.6718352::u72.
free_W :- u72, action(cruise), curr_lane, \+ latent_collision.

0.8075145::u73.
free_W :- u73, action(keep), curr_lane, \+ latent_collision.

0.9565217::u74.
free_W :- u74, action(swerve_left), curr_lane, \+ latent_collision.

0.8333333::u75.
free_W :- u75, action(swerve_right), curr_lane, \+ latent_collision.

0.5038852::u76.
free_W :- u76, action(change_to_left), \+ curr_lane, latent_collision.

0.5303388::u77.
free_W :- u77, action(change_to_right), \+ curr_lane, latent_collision.

0.5653595::u78.
free_W :- u78, action(cruise), \+ curr_lane, latent_collision.

0.5000000::u79.
free_W :- u79, action(keep), \+ curr_lane, latent_collision.

0.5000000::u80.
free_W :- u80, action(swerve_left), \+ curr_lane, latent_collision.

0.5000000::u81.
free_W :- u81, action(swerve_right), \+ curr_lane, latent_collision.

0.3571429::u82.
free_W :- u82, action(change_to_left), curr_lane, latent_collision.

0.5310668::u83.
free_W :- u83, action(change_to_right), curr_lane, latent_collision.

0.4954338::u84.
free_W :- u84, action(cruise), curr_lane, latent_collision.

0.5000000::u85.
free_W :- u85, action(keep), curr_lane, latent_collision.

0.5000000::u86.
free_W :- u86, action(swerve_left), curr_lane, latent_collision.

0.5000000::u87.
free_W :- u87, action(swerve_right), curr_lane, latent_collision.

0.8961443::u88.
latent_collision :- u88, action(change_to_left), \+ free_SW.

0.9979536::u89.
latent_collision :- u89, action(change_to_right), \+ free_SW.

0.2642225::u90.
latent_collision :- u90, action(cruise), \+ free_SW.

0.0009990::u91.
latent_collision :- u91, action(keep), \+ free_SW.

0.0009990::u92.
latent_collision :- u92, action(swerve_left), \+ free_SW.

0.0009990::u93.
latent_collision :- u93, action(swerve_right), \+ free_SW.

0.8499701::u94.
latent_collision :- u94, action(change_to_left), free_SW.

0.7966280::u95.
latent_collision :- u95, action(change_to_right), free_SW.

0.1992512::u96.
latent_collision :- u96, action(cruise), free_SW.

0.0009990::u97.
latent_collision :- u97, action(keep), free_SW.

0.0009990::u98.
latent_collision :- u98, action(swerve_left), free_SW.

0.0009990::u99.
latent_collision :- u99, action(swerve_right), free_SW.

