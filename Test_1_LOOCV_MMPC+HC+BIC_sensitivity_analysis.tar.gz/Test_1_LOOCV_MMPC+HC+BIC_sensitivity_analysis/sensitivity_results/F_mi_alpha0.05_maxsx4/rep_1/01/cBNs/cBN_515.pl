%%% Exogenous variables

0.1689556::u_action(change_to_left); 0.1661884::u_action(change_to_right); 0.4065799::u_action(cruise); 0.2555601::u_action(keep); 0.0016398::u_action(swerve_left); 0.0010762::u_action(swerve_right)
action(V) :- u_action(V).

0.5332582::u1.
curr_lane :- u1.

0.6266392::u2.
free_E :- u2, \+ curr_lane, \+ latent_collision.

0.9379300::u3.
free_E :- u3, curr_lane, \+ latent_collision.

0.4801061::u4.
free_E :- u4, \+ curr_lane, latent_collision.

0.5196237::u5.
free_E :- u5, curr_lane, latent_collision.

0.4583333::u6.
free_NE :- u6, action(change_to_left), \+ curr_lane, \+ free_E, \+ free_SW.

0.4699140::u7.
free_NE :- u7, action(change_to_right), \+ curr_lane, \+ free_E, \+ free_SW.

0.4007353::u8.
free_NE :- u8, action(cruise), \+ curr_lane, \+ free_E, \+ free_SW.

0.0555556::u9.
free_NE :- u9, action(keep), \+ curr_lane, \+ free_E, \+ free_SW.

0.5000000::u10.
free_NE :- u10, action(swerve_left), \+ curr_lane, \+ free_E, \+ free_SW.

0.5000000::u11.
free_NE :- u11, action(swerve_right), \+ curr_lane, \+ free_E, \+ free_SW.

0.5033333::u12.
free_NE :- u12, action(change_to_left), curr_lane, \+ free_E, \+ free_SW.

0.4810127::u13.
free_NE :- u13, action(change_to_right), curr_lane, \+ free_E, \+ free_SW.

0.0897959::u14.
free_NE :- u14, action(cruise), curr_lane, \+ free_E, \+ free_SW.

0.0009990::u15.
free_NE :- u15, action(keep), curr_lane, \+ free_E, \+ free_SW.

0.5000000::u16.
free_NE :- u16, action(swerve_left), curr_lane, \+ free_E, \+ free_SW.

0.5000000::u17.
free_NE :- u17, action(swerve_right), curr_lane, \+ free_E, \+ free_SW.

0.4551724::u18.
free_NE :- u18, action(change_to_left), \+ curr_lane, free_E, \+ free_SW.

0.0091743::u19.
free_NE :- u19, action(change_to_right), \+ curr_lane, free_E, \+ free_SW.

0.3081395::u20.
free_NE :- u20, action(cruise), \+ curr_lane, free_E, \+ free_SW.

0.0009990::u21.
free_NE :- u21, action(keep), \+ curr_lane, free_E, \+ free_SW.

0.5000000::u22.
free_NE :- u22, action(swerve_left), \+ curr_lane, free_E, \+ free_SW.

0.5000000::u23.
free_NE :- u23, action(swerve_right), \+ curr_lane, free_E, \+ free_SW.

0.4640371::u24.
free_NE :- u24, action(change_to_left), curr_lane, free_E, \+ free_SW.

0.4987654::u25.
free_NE :- u25, action(change_to_right), curr_lane, free_E, \+ free_SW.

0.9068212::u26.
free_NE :- u26, action(cruise), curr_lane, free_E, \+ free_SW.

0.0009990::u27.
free_NE :- u27, action(keep), curr_lane, free_E, \+ free_SW.

0.5000000::u28.
free_NE :- u28, action(swerve_left), curr_lane, free_E, \+ free_SW.

0.9990010::u29.
free_NE :- u29, action(swerve_right), curr_lane, free_E, \+ free_SW.

0.4567901::u30.
free_NE :- u30, action(change_to_left), \+ curr_lane, \+ free_E, free_SW.

0.5000000::u31.
free_NE :- u31, action(change_to_right), \+ curr_lane, \+ free_E, free_SW.

0.5604520::u32.
free_NE :- u32, action(cruise), \+ curr_lane, \+ free_E, free_SW.

0.2630719::u33.
free_NE :- u33, action(keep), \+ curr_lane, \+ free_E, free_SW.

0.5000000::u34.
free_NE :- u34, action(swerve_left), \+ curr_lane, \+ free_E, free_SW.

0.5000000::u35.
free_NE :- u35, action(swerve_right), \+ curr_lane, \+ free_E, free_SW.

0.4773869::u36.
free_NE :- u36, action(change_to_left), curr_lane, \+ free_E, free_SW.

0.5648855::u37.
free_NE :- u37, action(change_to_right), curr_lane, \+ free_E, free_SW.

0.3137255::u38.
free_NE :- u38, action(cruise), curr_lane, \+ free_E, free_SW.

0.0009990::u39.
free_NE :- u39, action(keep), curr_lane, \+ free_E, free_SW.

0.5000000::u40.
free_NE :- u40, action(swerve_left), curr_lane, \+ free_E, free_SW.

0.5000000::u41.
free_NE :- u41, action(swerve_right), curr_lane, \+ free_E, free_SW.

0.4626263::u42.
free_NE :- u42, action(change_to_left), \+ curr_lane, free_E, free_SW.

0.6185567::u43.
free_NE :- u43, action(change_to_right), \+ curr_lane, free_E, free_SW.

0.4790210::u44.
free_NE :- u44, action(cruise), \+ curr_lane, free_E, free_SW.

0.0139679::u45.
free_NE :- u45, action(keep), \+ curr_lane, free_E, free_SW.

0.9990010::u46.
free_NE :- u46, action(swerve_left), \+ curr_lane, free_E, free_SW.

0.5000000::u47.
free_NE :- u47, action(swerve_right), \+ curr_lane, free_E, free_SW.

0.4855234::u48.
free_NE :- u48, action(change_to_left), curr_lane, free_E, free_SW.

0.6247423::u49.
free_NE :- u49, action(change_to_right), curr_lane, free_E, free_SW.

0.9066132::u50.
free_NE :- u50, action(cruise), curr_lane, free_E, free_SW.

0.0039113::u51.
free_NE :- u51, action(keep), curr_lane, free_E, free_SW.

0.9333333::u52.
free_NE :- u52, action(swerve_left), curr_lane, free_E, free_SW.

0.8421053::u53.
free_NE :- u53, action(swerve_right), curr_lane, free_E, free_SW.

0.5250227::u54.
free_NW :- u54, action(change_to_left).

0.5488745::u55.
free_NW :- u55, action(change_to_right).

0.5253340::u56.
free_NW :- u56, action(cruise).

0.0288751::u57.
free_NW :- u57, action(keep).

0.9375000::u58.
free_NW :- u58, action(swerve_left).

0.8571429::u59.
free_NW :- u59, action(swerve_right).

0.6766917::u60.
free_SE :- u60, \+ curr_lane, \+ free_E, \+ free_SW, \+ latent_collision.

0.9714286::u61.
free_SE :- u61, curr_lane, \+ free_E, \+ free_SW, \+ latent_collision.

0.8767123::u62.
free_SE :- u62, \+ curr_lane, free_E, \+ free_SW, \+ latent_collision.

0.9725729::u63.
free_SE :- u63, curr_lane, free_E, \+ free_SW, \+ latent_collision.

0.3360215::u64.
free_SE :- u64, \+ curr_lane, \+ free_E, free_SW, \+ latent_collision.

0.9710526::u65.
free_SE :- u65, curr_lane, \+ free_E, free_SW, \+ latent_collision.

0.4479525::u66.
free_SE :- u66, \+ curr_lane, free_E, free_SW, \+ latent_collision.

0.7795672::u67.
free_SE :- u67, curr_lane, free_E, free_SW, \+ latent_collision.

0.5640449::u68.
free_SE :- u68, \+ curr_lane, \+ free_E, \+ free_SW, latent_collision.

0.5176600::u69.
free_SE :- u69, curr_lane, \+ free_E, \+ free_SW, latent_collision.

0.5076202::u70.
free_SE :- u70, \+ curr_lane, free_E, \+ free_SW, latent_collision.

0.4837989::u71.
free_SE :- u71, curr_lane, free_E, \+ free_SW, latent_collision.

0.4990654::u72.
free_SE :- u72, \+ curr_lane, \+ free_E, free_SW, latent_collision.

0.4846765::u73.
free_SE :- u73, curr_lane, \+ free_E, free_SW, latent_collision.

0.5172414::u74.
free_SE :- u74, \+ curr_lane, free_E, free_SW, latent_collision.

0.5327553::u75.
free_SE :- u75, curr_lane, free_E, free_SW, latent_collision.

0.5298756::u76.
free_SW :- u76, action(change_to_left).

0.5784767::u77.
free_SW :- u77, action(change_to_right).

0.6087724::u78.
free_SW :- u78, action(cruise).

0.9735312::u79.
free_SW :- u79, action(keep).

0.9990010::u80.
free_SW :- u80, action(swerve_left).

0.9047619::u81.
free_SW :- u81, action(swerve_right).

0.5000000::u82.
free_W :- u82, action(change_to_left), \+ curr_lane, \+ free_NW, \+ latent_collision.

0.9814815::u83.
free_W :- u83, action(change_to_right), \+ curr_lane, \+ free_NW, \+ latent_collision.

0.5000000::u84.
free_W :- u84, action(cruise), \+ curr_lane, \+ free_NW, \+ latent_collision.

0.9990010::u85.
free_W :- u85, action(keep), \+ curr_lane, \+ free_NW, \+ latent_collision.

0.5000000::u86.
free_W :- u86, action(swerve_left), \+ curr_lane, \+ free_NW, \+ latent_collision.

0.5000000::u87.
free_W :- u87, action(swerve_right), \+ curr_lane, \+ free_NW, \+ latent_collision.

0.5000000::u88.
free_W :- u88, action(change_to_left), curr_lane, \+ free_NW, \+ latent_collision.

0.5000000::u89.
free_W :- u89, action(change_to_right), curr_lane, \+ free_NW, \+ latent_collision.

0.7229839::u90.
free_W :- u90, action(cruise), curr_lane, \+ free_NW, \+ latent_collision.

0.8198091::u91.
free_W :- u91, action(keep), curr_lane, \+ free_NW, \+ latent_collision.

0.5000000::u92.
free_W :- u92, action(swerve_left), curr_lane, \+ free_NW, \+ latent_collision.

0.3333333::u93.
free_W :- u93, action(swerve_right), curr_lane, \+ free_NW, \+ latent_collision.

0.5000000::u94.
free_W :- u94, action(change_to_left), \+ curr_lane, free_NW, \+ latent_collision.

0.9990010::u95.
free_W :- u95, action(change_to_right), \+ curr_lane, free_NW, \+ latent_collision.

0.9990010::u96.
free_W :- u96, action(cruise), \+ curr_lane, free_NW, \+ latent_collision.

0.9990010::u97.
free_W :- u97, action(keep), \+ curr_lane, free_NW, \+ latent_collision.

0.9990010::u98.
free_W :- u98, action(swerve_left), \+ curr_lane, free_NW, \+ latent_collision.

0.5000000::u99.
free_W :- u99, action(swerve_right), \+ curr_lane, free_NW, \+ latent_collision.

0.9990010::u100.
free_W :- u100, action(change_to_left), curr_lane, free_NW, \+ latent_collision.

0.5000000::u101.
free_W :- u101, action(change_to_right), curr_lane, free_NW, \+ latent_collision.

0.6028956::u102.
free_W :- u102, action(cruise), curr_lane, free_NW, \+ latent_collision.

0.4029851::u103.
free_W :- u103, action(keep), curr_lane, free_NW, \+ latent_collision.

0.9990010::u104.
free_W :- u104, action(swerve_left), curr_lane, free_NW, \+ latent_collision.

0.9444444::u105.
free_W :- u105, action(swerve_right), curr_lane, free_NW, \+ latent_collision.

0.5371795::u106.
free_W :- u106, action(change_to_left), \+ curr_lane, \+ free_NW, latent_collision.

0.5244519::u107.
free_W :- u107, action(change_to_right), \+ curr_lane, \+ free_NW, latent_collision.

0.5636792::u108.
free_W :- u108, action(cruise), \+ curr_lane, \+ free_NW, latent_collision.

0.5000000::u109.
free_W :- u109, action(keep), \+ curr_lane, \+ free_NW, latent_collision.

0.5000000::u110.
free_W :- u110, action(swerve_left), \+ curr_lane, \+ free_NW, latent_collision.

0.5000000::u111.
free_W :- u111, action(swerve_right), \+ curr_lane, \+ free_NW, latent_collision.

0.5089059::u112.
free_W :- u112, action(change_to_left), curr_lane, \+ free_NW, latent_collision.

0.5000000::u113.
free_W :- u113, action(change_to_right), curr_lane, \+ free_NW, latent_collision.

0.5251142::u114.
free_W :- u114, action(cruise), curr_lane, \+ free_NW, latent_collision.

0.5000000::u115.
free_W :- u115, action(keep), curr_lane, \+ free_NW, latent_collision.

0.5000000::u116.
free_W :- u116, action(swerve_left), curr_lane, \+ free_NW, latent_collision.

0.5000000::u117.
free_W :- u117, action(swerve_right), curr_lane, \+ free_NW, latent_collision.

0.5569755::u118.
free_W :- u118, action(change_to_left), \+ curr_lane, free_NW, latent_collision.

0.5360656::u119.
free_W :- u119, action(change_to_right), \+ curr_lane, free_NW, latent_collision.

0.5000000::u120.
free_W :- u120, action(cruise), \+ curr_lane, free_NW, latent_collision.

0.5000000::u121.
free_W :- u121, action(keep), \+ curr_lane, free_NW, latent_collision.

0.5000000::u122.
free_W :- u122, action(swerve_left), \+ curr_lane, free_NW, latent_collision.

0.5000000::u123.
free_W :- u123, action(swerve_right), \+ curr_lane, free_NW, latent_collision.

0.0009990::u124.
free_W :- u124, action(change_to_left), curr_lane, free_NW, latent_collision.

0.5371230::u125.
free_W :- u125, action(change_to_right), curr_lane, free_NW, latent_collision.

0.4851259::u126.
free_W :- u126, action(cruise), curr_lane, free_NW, latent_collision.

0.5000000::u127.
free_W :- u127, action(keep), curr_lane, free_NW, latent_collision.

0.5000000::u128.
free_W :- u128, action(swerve_left), curr_lane, free_NW, latent_collision.

0.5000000::u129.
free_W :- u129, action(swerve_right), curr_lane, free_NW, latent_collision.

0.8954839::u130.
latent_collision :- u130, action(change_to_left), \+ free_SW.

0.9985369::u131.
latent_collision :- u131, action(change_to_right), \+ free_SW.

0.2548325::u132.
latent_collision :- u132, action(cruise), \+ free_SW.

0.0009990::u133.
latent_collision :- u133, action(keep), \+ free_SW.

0.5000000::u134.
latent_collision :- u134, action(swerve_left), \+ free_SW.

0.0009990::u135.
latent_collision :- u135, action(swerve_right), \+ free_SW.

0.8574699::u136.
latent_collision :- u136, action(change_to_left), free_SW.

0.8081023::u137.
latent_collision :- u137, action(change_to_right), free_SW.

0.1929607::u138.
latent_collision :- u138, action(cruise), free_SW.

0.0009990::u139.
latent_collision :- u139, action(keep), free_SW.

0.0009990::u140.
latent_collision :- u140, action(swerve_left), free_SW.

0.0009990::u141.
latent_collision :- u141, action(swerve_right), free_SW.

