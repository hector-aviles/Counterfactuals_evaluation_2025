%%% Exogenous variables

0.1710917::u_action(change_to_left); 0.1698104::u_action(change_to_right); 0.4059969::u_action(cruise); 0.2507945::u_action(keep); 0.0015889::u_action(swerve_left); 0.0007176::u_action(swerve_right)
action(V) :- u_action(V).

0.5374167::u1.
curr_lane :- u1.

0.6055680::u2.
free_E :- u2, \+ curr_lane, \+ latent_collision.

0.9364548::u3.
free_E :- u3, curr_lane, \+ latent_collision.

0.4530357::u4.
free_E :- u4, \+ curr_lane, latent_collision.

0.5305861::u5.
free_E :- u5, curr_lane, latent_collision.

0.5109489::u6.
free_NE :- u6, action(change_to_left), \+ curr_lane, \+ free_E.

0.4911839::u7.
free_NE :- u7, action(change_to_right), \+ curr_lane, \+ free_E.

0.5410359::u8.
free_NE :- u8, action(cruise), \+ curr_lane, \+ free_E.

0.2694467::u9.
free_NE :- u9, action(keep), \+ curr_lane, \+ free_E.

0.5000000::u10.
free_NE :- u10, action(swerve_left), \+ curr_lane, \+ free_E.

0.5000000::u11.
free_NE :- u11, action(swerve_right), \+ curr_lane, \+ free_E.

0.4953146::u12.
free_NE :- u12, action(change_to_left), curr_lane, \+ free_E.

0.4899749::u13.
free_NE :- u13, action(change_to_right), curr_lane, \+ free_E.

0.2320755::u14.
free_NE :- u14, action(cruise), curr_lane, \+ free_E.

0.0009990::u15.
free_NE :- u15, action(keep), curr_lane, \+ free_E.

0.0009990::u16.
free_NE :- u16, action(swerve_left), curr_lane, \+ free_E.

0.5000000::u17.
free_NE :- u17, action(swerve_right), curr_lane, \+ free_E.

0.4713764::u18.
free_NE :- u18, action(change_to_left), \+ curr_lane, free_E.

0.4961735::u19.
free_NE :- u19, action(change_to_right), \+ curr_lane, free_E.

0.4375821::u20.
free_NE :- u20, action(cruise), \+ curr_lane, free_E.

0.0112676::u21.
free_NE :- u21, action(keep), \+ curr_lane, free_E.

0.9990010::u22.
free_NE :- u22, action(swerve_left), \+ curr_lane, free_E.

0.5000000::u23.
free_NE :- u23, action(swerve_right), \+ curr_lane, free_E.

0.4894515::u24.
free_NE :- u24, action(change_to_left), curr_lane, free_E.

0.5496265::u25.
free_NE :- u25, action(change_to_right), curr_lane, free_E.

0.9011704::u26.
free_NE :- u26, action(cruise), curr_lane, free_E.

0.0041249::u27.
free_NE :- u27, action(keep), curr_lane, free_E.

0.9565217::u28.
free_NE :- u28, action(swerve_left), curr_lane, free_E.

0.9990010::u29.
free_NE :- u29, action(swerve_right), curr_lane, free_E.

0.5176471::u30.
free_NW :- u30, action(change_to_left), \+ free_SW.

0.5082202::u31.
free_NW :- u31, action(change_to_right), \+ free_SW.

0.4557994::u32.
free_NW :- u32, action(cruise), \+ free_SW.

0.4128440::u33.
free_NW :- u33, action(keep), \+ free_SW.

0.9990010::u34.
free_NW :- u34, action(swerve_left), \+ free_SW.

0.0009990::u35.
free_NW :- u35, action(swerve_right), \+ free_SW.

0.4904237::u36.
free_NW :- u36, action(change_to_left), free_SW.

0.5606061::u37.
free_NW :- u37, action(change_to_right), free_SW.

0.5962799::u38.
free_NW :- u38, action(cruise), free_SW.

0.0219482::u39.
free_NW :- u39, action(keep), free_SW.

0.9666667::u40.
free_NW :- u40, action(swerve_left), free_SW.

0.7692308::u41.
free_NW :- u41, action(swerve_right), free_SW.

0.6293706::u42.
free_SE :- u42, \+ curr_lane, \+ free_E, \+ free_SW, \+ latent_collision.

0.9990010::u43.
free_SE :- u43, curr_lane, \+ free_E, \+ free_SW, \+ latent_collision.

0.8304094::u44.
free_SE :- u44, \+ curr_lane, free_E, \+ free_SW, \+ latent_collision.

0.9706644::u45.
free_SE :- u45, curr_lane, free_E, \+ free_SW, \+ latent_collision.

0.3323171::u46.
free_SE :- u46, \+ curr_lane, \+ free_E, free_SW, \+ latent_collision.

0.9845361::u47.
free_SE :- u47, curr_lane, \+ free_E, free_SW, \+ latent_collision.

0.4514658::u48.
free_SE :- u48, \+ curr_lane, free_E, free_SW, \+ latent_collision.

0.7563769::u49.
free_SE :- u49, curr_lane, free_E, free_SW, \+ latent_collision.

0.4713701::u50.
free_SE :- u50, \+ curr_lane, \+ free_E, \+ free_SW, latent_collision.

0.5193370::u51.
free_SE :- u51, curr_lane, \+ free_E, \+ free_SW, latent_collision.

0.5333333::u52.
free_SE :- u52, \+ curr_lane, free_E, \+ free_SW, latent_collision.

0.5227513::u53.
free_SE :- u53, curr_lane, free_E, \+ free_SW, latent_collision.

0.5072745::u54.
free_SE :- u54, \+ curr_lane, \+ free_E, free_SW, latent_collision.

0.5134553::u55.
free_SE :- u55, curr_lane, \+ free_E, free_SW, latent_collision.

0.4982122::u56.
free_SE :- u56, \+ curr_lane, free_E, free_SW, latent_collision.

0.5230496::u57.
free_SE :- u57, curr_lane, free_E, free_SW, latent_collision.

0.5161774::u58.
free_SW :- u58, action(change_to_left).

0.5777241::u59.
free_SW :- u59, action(change_to_right).

0.5972731::u60.
free_SW :- u60, action(cruise).

0.9777233::u61.
free_SW :- u61, action(keep).

0.9677419::u62.
free_SW :- u62, action(swerve_left).

0.9285714::u63.
free_SW :- u63, action(swerve_right).

0.5000000::u64.
free_W :- u64, action(change_to_left), \+ curr_lane, \+ free_NW, \+ latent_collision.

0.9838710::u65.
free_W :- u65, action(change_to_right), \+ curr_lane, \+ free_NW, \+ latent_collision.

0.5000000::u66.
free_W :- u66, action(cruise), \+ curr_lane, \+ free_NW, \+ latent_collision.

0.9990010::u67.
free_W :- u67, action(keep), \+ curr_lane, \+ free_NW, \+ latent_collision.

0.9990010::u68.
free_W :- u68, action(swerve_left), \+ curr_lane, \+ free_NW, \+ latent_collision.

0.5000000::u69.
free_W :- u69, action(swerve_right), \+ curr_lane, \+ free_NW, \+ latent_collision.

0.5000000::u70.
free_W :- u70, action(change_to_left), curr_lane, \+ free_NW, \+ latent_collision.

0.5000000::u71.
free_W :- u71, action(change_to_right), curr_lane, \+ free_NW, \+ latent_collision.

0.7417582::u72.
free_W :- u72, action(cruise), curr_lane, \+ free_NW, \+ latent_collision.

0.8161383::u73.
free_W :- u73, action(keep), curr_lane, \+ free_NW, \+ latent_collision.

0.5000000::u74.
free_W :- u74, action(swerve_left), curr_lane, \+ free_NW, \+ latent_collision.

0.5000000::u75.
free_W :- u75, action(swerve_right), curr_lane, \+ free_NW, \+ latent_collision.

0.5000000::u76.
free_W :- u76, action(change_to_left), \+ curr_lane, free_NW, \+ latent_collision.

0.9969419::u77.
free_W :- u77, action(change_to_right), \+ curr_lane, free_NW, \+ latent_collision.

0.9990010::u78.
free_W :- u78, action(cruise), \+ curr_lane, free_NW, \+ latent_collision.

0.9990010::u79.
free_W :- u79, action(keep), \+ curr_lane, free_NW, \+ latent_collision.

0.9990010::u80.
free_W :- u80, action(swerve_left), \+ curr_lane, free_NW, \+ latent_collision.

0.5000000::u81.
free_W :- u81, action(swerve_right), \+ curr_lane, free_NW, \+ latent_collision.

0.9990010::u82.
free_W :- u82, action(change_to_left), curr_lane, free_NW, \+ latent_collision.

0.5000000::u83.
free_W :- u83, action(change_to_right), curr_lane, free_NW, \+ latent_collision.

0.6177546::u84.
free_W :- u84, action(cruise), curr_lane, free_NW, \+ latent_collision.

0.4044118::u85.
free_W :- u85, action(keep), curr_lane, free_NW, \+ latent_collision.

0.9615385::u86.
free_W :- u86, action(swerve_left), curr_lane, free_NW, \+ latent_collision.

0.9990010::u87.
free_W :- u87, action(swerve_right), curr_lane, free_NW, \+ latent_collision.

0.4928105::u88.
free_W :- u88, action(change_to_left), \+ curr_lane, \+ free_NW, latent_collision.

0.5075630::u89.
free_W :- u89, action(change_to_right), \+ curr_lane, \+ free_NW, latent_collision.

0.5505351::u90.
free_W :- u90, action(cruise), \+ curr_lane, \+ free_NW, latent_collision.

0.5000000::u91.
free_W :- u91, action(keep), \+ curr_lane, \+ free_NW, latent_collision.

0.5000000::u92.
free_W :- u92, action(swerve_left), \+ curr_lane, \+ free_NW, latent_collision.

0.5000000::u93.
free_W :- u93, action(swerve_right), \+ curr_lane, \+ free_NW, latent_collision.

0.5156951::u94.
free_W :- u94, action(change_to_left), curr_lane, \+ free_NW, latent_collision.

0.4942661::u95.
free_W :- u95, action(change_to_right), curr_lane, \+ free_NW, latent_collision.

0.4783599::u96.
free_W :- u96, action(cruise), curr_lane, \+ free_NW, latent_collision.

0.5000000::u97.
free_W :- u97, action(keep), curr_lane, \+ free_NW, latent_collision.

0.5000000::u98.
free_W :- u98, action(swerve_left), curr_lane, \+ free_NW, latent_collision.

0.5000000::u99.
free_W :- u99, action(swerve_right), curr_lane, \+ free_NW, latent_collision.

0.5523918::u100.
free_W :- u100, action(change_to_left), \+ curr_lane, free_NW, latent_collision.

0.4915825::u101.
free_W :- u101, action(change_to_right), \+ curr_lane, free_NW, latent_collision.

0.5000000::u102.
free_W :- u102, action(cruise), \+ curr_lane, free_NW, latent_collision.

0.5000000::u103.
free_W :- u103, action(keep), \+ curr_lane, free_NW, latent_collision.

0.5000000::u104.
free_W :- u104, action(swerve_left), \+ curr_lane, free_NW, latent_collision.

0.5000000::u105.
free_W :- u105, action(swerve_right), \+ curr_lane, free_NW, latent_collision.

0.0009990::u106.
free_W :- u106, action(change_to_left), curr_lane, free_NW, latent_collision.

0.5457706::u107.
free_W :- u107, action(change_to_right), curr_lane, free_NW, latent_collision.

0.4669811::u108.
free_W :- u108, action(cruise), curr_lane, free_NW, latent_collision.

0.5000000::u109.
free_W :- u109, action(keep), curr_lane, free_NW, latent_collision.

0.5000000::u110.
free_W :- u110, action(swerve_left), curr_lane, free_NW, latent_collision.

0.5000000::u111.
free_W :- u111, action(swerve_right), curr_lane, free_NW, latent_collision.

0.9009288::u112.
latent_collision :- u112, action(change_to_left), \+ free_SW.

0.9964260::u113.
latent_collision :- u113, action(change_to_right), \+ free_SW.

0.2520376::u114.
latent_collision :- u114, action(cruise), \+ free_SW.

0.0009990::u115.
latent_collision :- u115, action(keep), \+ free_SW.

0.0009990::u116.
latent_collision :- u116, action(swerve_left), \+ free_SW.

0.0009990::u117.
latent_collision :- u117, action(swerve_right), \+ free_SW.

0.8688334::u118.
latent_collision :- u118, action(change_to_left), free_SW.

0.7993730::u119.
latent_collision :- u119, action(change_to_right), free_SW.

0.1902346::u120.
latent_collision :- u120, action(cruise), free_SW.

0.0009990::u121.
latent_collision :- u121, action(keep), free_SW.

0.0009990::u122.
latent_collision :- u122, action(swerve_left), free_SW.

0.0009990::u123.
latent_collision :- u123, action(swerve_right), free_SW.

