%%% Exogenous variables

0.1693594::u_action(change_to_left); 0.1680259::u_action(change_to_right); 0.4085244::u_action(cruise); 0.2515259::u_action(keep); 0.0016926::u_action(swerve_left); 0.0008719::u_action(swerve_right)
action(V) :- u_action(V).

0.5233626::u1.
curr_lane :- u1.

0.6089850::u2.
free_E :- u2, \+ curr_lane, \+ latent_collision.

0.9363525::u3.
free_E :- u3, curr_lane, \+ latent_collision.

0.4456746::u4.
free_E :- u4, \+ curr_lane, latent_collision.

0.5338059::u5.
free_E :- u5, curr_lane, latent_collision.

0.5160906::u6.
free_NE :- u6, action(change_to_left), \+ curr_lane, \+ free_E.

0.5283688::u7.
free_NE :- u7, action(change_to_right), \+ curr_lane, \+ free_E.

0.5353535::u8.
free_NE :- u8, action(cruise), \+ curr_lane, \+ free_E.

0.2438272::u9.
free_NE :- u9, action(keep), \+ curr_lane, \+ free_E.

0.5000000::u10.
free_NE :- u10, action(swerve_left), \+ curr_lane, \+ free_E.

0.5000000::u11.
free_NE :- u11, action(swerve_right), \+ curr_lane, \+ free_E.

0.5276074::u12.
free_NE :- u12, action(change_to_left), curr_lane, \+ free_E.

0.5226391::u13.
free_NE :- u13, action(change_to_right), curr_lane, \+ free_E.

0.2694497::u14.
free_NE :- u14, action(cruise), curr_lane, \+ free_E.

0.0009990::u15.
free_NE :- u15, action(keep), curr_lane, \+ free_E.

0.5000000::u16.
free_NE :- u16, action(swerve_left), curr_lane, \+ free_E.

0.5000000::u17.
free_NE :- u17, action(swerve_right), curr_lane, \+ free_E.

0.5011086::u18.
free_NE :- u18, action(change_to_left), \+ curr_lane, free_E.

0.4907652::u19.
free_NE :- u19, action(change_to_right), \+ curr_lane, free_E.

0.4681422::u20.
free_NE :- u20, action(cruise), \+ curr_lane, free_E.

0.0192823::u21.
free_NE :- u21, action(keep), \+ curr_lane, free_E.

0.5000000::u22.
free_NE :- u22, action(swerve_left), \+ curr_lane, free_E.

0.9990010::u23.
free_NE :- u23, action(swerve_right), \+ curr_lane, free_E.

0.5093509::u24.
free_NE :- u24, action(change_to_left), curr_lane, free_E.

0.5483871::u25.
free_NE :- u25, action(change_to_right), curr_lane, free_E.

0.9057940::u26.
free_NE :- u26, action(cruise), curr_lane, free_E.

0.0038290::u27.
free_NE :- u27, action(keep), curr_lane, free_E.

0.8148148::u28.
free_NE :- u28, action(swerve_left), curr_lane, free_E.

0.7500000::u29.
free_NE :- u29, action(swerve_right), curr_lane, free_E.

0.4932845::u30.
free_NW :- u30, action(change_to_left), \+ free_SW.

0.4897671::u31.
free_NW :- u31, action(change_to_right), \+ free_SW.

0.4386185::u32.
free_NW :- u32, action(cruise), \+ free_SW.

0.4180328::u33.
free_NW :- u33, action(keep), \+ free_SW.

0.0009990::u34.
free_NW :- u34, action(swerve_left), \+ free_SW.

0.0009990::u35.
free_NW :- u35, action(swerve_right), \+ free_SW.

0.5150240::u36.
free_NW :- u36, action(change_to_left), free_SW.

0.5976331::u37.
free_NW :- u37, action(change_to_right), free_SW.

0.5985356::u38.
free_NW :- u38, action(cruise), free_SW.

0.0215391::u39.
free_NW :- u39, action(keep), free_SW.

0.9687500::u40.
free_NW :- u40, action(swerve_left), free_SW.

0.8750000::u41.
free_NW :- u41, action(swerve_right), free_SW.

0.6212121::u42.
free_SE :- u42, \+ curr_lane, \+ free_E, \+ free_SW, \+ latent_collision.

0.9990010::u43.
free_SE :- u43, curr_lane, \+ free_E, \+ free_SW, \+ latent_collision.

0.9102564::u44.
free_SE :- u44, \+ curr_lane, free_E, \+ free_SW, \+ latent_collision.

0.9769295::u45.
free_SE :- u45, curr_lane, free_E, \+ free_SW, \+ latent_collision.

0.3182047::u46.
free_SE :- u46, \+ curr_lane, \+ free_E, free_SW, \+ latent_collision.

0.9791123::u47.
free_SE :- u47, curr_lane, \+ free_E, free_SW, \+ latent_collision.

0.4541109::u48.
free_SE :- u48, \+ curr_lane, free_E, free_SW, \+ latent_collision.

0.7566916::u49.
free_SE :- u49, curr_lane, free_E, free_SW, \+ latent_collision.

0.4967074::u50.
free_SE :- u50, \+ curr_lane, \+ free_E, \+ free_SW, latent_collision.

0.4948097::u51.
free_SE :- u51, curr_lane, \+ free_E, \+ free_SW, latent_collision.

0.5129108::u52.
free_SE :- u52, \+ curr_lane, free_E, \+ free_SW, latent_collision.

0.5039909::u53.
free_SE :- u53, curr_lane, free_E, \+ free_SW, latent_collision.

0.5045872::u54.
free_SE :- u54, \+ curr_lane, \+ free_E, free_SW, latent_collision.

0.4685647::u55.
free_SE :- u55, curr_lane, \+ free_E, free_SW, latent_collision.

0.5529010::u56.
free_SE :- u56, \+ curr_lane, free_E, free_SW, latent_collision.

0.5282146::u57.
free_SE :- u57, curr_lane, free_E, free_SW, latent_collision.

0.5064267::u58.
free_SW :- u58, action(change_to_left), \+ latent_collision.

0.9811828::u59.
free_SW :- u59, action(change_to_right), \+ latent_collision.

0.6176565::u60.
free_SW :- u60, action(cruise), \+ latent_collision.

0.9751223::u61.
free_SW :- u61, action(keep), \+ latent_collision.

0.9696970::u62.
free_SW :- u62, action(swerve_left), \+ latent_collision.

0.9411765::u63.
free_SW :- u63, action(swerve_right), \+ latent_collision.

0.5036045::u64.
free_SW :- u64, action(change_to_left), latent_collision.

0.5144628::u65.
free_SW :- u65, action(change_to_right), latent_collision.

0.5371758::u66.
free_SW :- u66, action(cruise), latent_collision.

0.5000000::u67.
free_SW :- u67, action(keep), latent_collision.

0.5000000::u68.
free_SW :- u68, action(swerve_left), latent_collision.

0.5000000::u69.
free_SW :- u69, action(swerve_right), latent_collision.

0.5000000::u70.
free_W :- u70, action(change_to_left), \+ curr_lane, \+ free_NW, \+ latent_collision.

0.9811321::u71.
free_W :- u71, action(change_to_right), \+ curr_lane, \+ free_NW, \+ latent_collision.

0.5000000::u72.
free_W :- u72, action(cruise), \+ curr_lane, \+ free_NW, \+ latent_collision.

0.9990010::u73.
free_W :- u73, action(keep), \+ curr_lane, \+ free_NW, \+ latent_collision.

0.5000000::u74.
free_W :- u74, action(swerve_left), \+ curr_lane, \+ free_NW, \+ latent_collision.

0.5000000::u75.
free_W :- u75, action(swerve_right), \+ curr_lane, \+ free_NW, \+ latent_collision.

0.5000000::u76.
free_W :- u76, action(change_to_left), curr_lane, \+ free_NW, \+ latent_collision.

0.5000000::u77.
free_W :- u77, action(change_to_right), curr_lane, \+ free_NW, \+ latent_collision.

0.7436326::u78.
free_W :- u78, action(cruise), curr_lane, \+ free_NW, \+ latent_collision.

0.8355222::u79.
free_W :- u79, action(keep), curr_lane, \+ free_NW, \+ latent_collision.

0.5000000::u80.
free_W :- u80, action(swerve_left), curr_lane, \+ free_NW, \+ latent_collision.

0.6666667::u81.
free_W :- u81, action(swerve_right), curr_lane, \+ free_NW, \+ latent_collision.

0.5000000::u82.
free_W :- u82, action(change_to_left), \+ curr_lane, free_NW, \+ latent_collision.

0.9990010::u83.
free_W :- u83, action(change_to_right), \+ curr_lane, free_NW, \+ latent_collision.

0.9990010::u84.
free_W :- u84, action(cruise), \+ curr_lane, free_NW, \+ latent_collision.

0.9990010::u85.
free_W :- u85, action(keep), \+ curr_lane, free_NW, \+ latent_collision.

0.9990010::u86.
free_W :- u86, action(swerve_left), \+ curr_lane, free_NW, \+ latent_collision.

0.9990010::u87.
free_W :- u87, action(swerve_right), \+ curr_lane, free_NW, \+ latent_collision.

0.9990010::u88.
free_W :- u88, action(change_to_left), curr_lane, free_NW, \+ latent_collision.

0.5000000::u89.
free_W :- u89, action(change_to_right), curr_lane, free_NW, \+ latent_collision.

0.6082317::u90.
free_W :- u90, action(cruise), curr_lane, free_NW, \+ latent_collision.

0.3591549::u91.
free_W :- u91, action(keep), curr_lane, free_NW, \+ latent_collision.

0.9990010::u92.
free_W :- u92, action(swerve_left), curr_lane, free_NW, \+ latent_collision.

0.9990010::u93.
free_W :- u93, action(swerve_right), curr_lane, free_NW, \+ latent_collision.

0.5087515::u94.
free_W :- u94, action(change_to_left), \+ curr_lane, \+ free_NW, latent_collision.

0.5178295::u95.
free_W :- u95, action(change_to_right), \+ curr_lane, \+ free_NW, latent_collision.

0.5236004::u96.
free_W :- u96, action(cruise), \+ curr_lane, \+ free_NW, latent_collision.

0.5000000::u97.
free_W :- u97, action(keep), \+ curr_lane, \+ free_NW, latent_collision.

0.5000000::u98.
free_W :- u98, action(swerve_left), \+ curr_lane, \+ free_NW, latent_collision.

0.5000000::u99.
free_W :- u99, action(swerve_right), \+ curr_lane, \+ free_NW, latent_collision.

0.5230769::u100.
free_W :- u100, action(change_to_left), curr_lane, \+ free_NW, latent_collision.

0.5523933::u101.
free_W :- u101, action(change_to_right), curr_lane, \+ free_NW, latent_collision.

0.5037406::u102.
free_W :- u102, action(cruise), curr_lane, \+ free_NW, latent_collision.

0.5000000::u103.
free_W :- u103, action(keep), curr_lane, \+ free_NW, latent_collision.

0.5000000::u104.
free_W :- u104, action(swerve_left), curr_lane, \+ free_NW, latent_collision.

0.5000000::u105.
free_W :- u105, action(swerve_right), curr_lane, \+ free_NW, latent_collision.

0.5452489::u106.
free_W :- u106, action(change_to_left), \+ curr_lane, free_NW, latent_collision.

0.4923339::u107.
free_W :- u107, action(change_to_right), \+ curr_lane, free_NW, latent_collision.

0.5000000::u108.
free_W :- u108, action(cruise), \+ curr_lane, free_NW, latent_collision.

0.5000000::u109.
free_W :- u109, action(keep), \+ curr_lane, free_NW, latent_collision.

0.5000000::u110.
free_W :- u110, action(swerve_left), \+ curr_lane, free_NW, latent_collision.

0.5000000::u111.
free_W :- u111, action(swerve_right), \+ curr_lane, free_NW, latent_collision.

0.0009990::u112.
free_W :- u112, action(change_to_left), curr_lane, free_NW, latent_collision.

0.5661846::u113.
free_W :- u113, action(change_to_right), curr_lane, free_NW, latent_collision.

0.5059102::u114.
free_W :- u114, action(cruise), curr_lane, free_NW, latent_collision.

0.5000000::u115.
free_W :- u115, action(keep), curr_lane, free_NW, latent_collision.

0.5000000::u116.
free_W :- u116, action(swerve_left), curr_lane, free_NW, latent_collision.

0.5000000::u117.
free_W :- u117, action(swerve_right), curr_lane, free_NW, latent_collision.

0.8821926::u118.
latent_collision :- u118, action(change_to_left).

0.8864469::u119.
latent_collision :- u119, action(change_to_right).

0.2178280::u120.
latent_collision :- u120, action(cruise).

0.0009990::u121.
latent_collision :- u121, action(keep).

0.0009990::u122.
latent_collision :- u122, action(swerve_left).

0.0009990::u123.
latent_collision :- u123, action(swerve_right).

