%%% Exogenous variables

0.1684384::u_action(change_to_left); 0.1700817::u_action(change_to_right); 0.4052791::u_action(cruise); 0.2529143::u_action(keep); 0.0022082::u_action(swerve_left); 0.0010784::u_action(swerve_right)
action(V) :- u_action(V).

0.5353566::u1.
curr_lane :- u1.

0.6148496::u2.
free_E :- u2, \+ curr_lane, \+ latent_collision.

0.9384218::u3.
free_E :- u3, curr_lane, \+ latent_collision.

0.4699571::u4.
free_E :- u4, \+ curr_lane, latent_collision.

0.5272869::u5.
free_E :- u5, curr_lane, latent_collision.

0.5069886::u6.
free_NE :- u6, action(change_to_left), \+ curr_lane, \+ free_E.

0.5340314::u7.
free_NE :- u7, action(change_to_right), \+ curr_lane, \+ free_E.

0.5343053::u8.
free_NE :- u8, action(cruise), \+ curr_lane, \+ free_E.

0.2712644::u9.
free_NE :- u9, action(keep), \+ curr_lane, \+ free_E.

0.3333333::u10.
free_NE :- u10, action(swerve_left), \+ curr_lane, \+ free_E.

0.5000000::u11.
free_NE :- u11, action(swerve_right), \+ curr_lane, \+ free_E.

0.5092725::u12.
free_NE :- u12, action(change_to_left), curr_lane, \+ free_E.

0.5201465::u13.
free_NE :- u13, action(change_to_right), curr_lane, \+ free_E.

0.2213884::u14.
free_NE :- u14, action(cruise), curr_lane, \+ free_E.

0.0058824::u15.
free_NE :- u15, action(keep), curr_lane, \+ free_E.

0.0009990::u16.
free_NE :- u16, action(swerve_left), curr_lane, \+ free_E.

0.5000000::u17.
free_NE :- u17, action(swerve_right), curr_lane, \+ free_E.

0.4612717::u18.
free_NE :- u18, action(change_to_left), \+ curr_lane, free_E.

0.4376559::u19.
free_NE :- u19, action(change_to_right), \+ curr_lane, free_E.

0.4361559::u20.
free_NE :- u20, action(cruise), \+ curr_lane, free_E.

0.0150376::u21.
free_NE :- u21, action(keep), \+ curr_lane, free_E.

0.8333333::u22.
free_NE :- u22, action(swerve_left), \+ curr_lane, free_E.

0.5000000::u23.
free_NE :- u23, action(swerve_right), \+ curr_lane, free_E.

0.5016181::u24.
free_NE :- u24, action(change_to_left), curr_lane, free_E.

0.5738943::u25.
free_NE :- u25, action(change_to_right), curr_lane, free_E.

0.9009564::u26.
free_NE :- u26, action(cruise), curr_lane, free_E.

0.0037783::u27.
free_NE :- u27, action(keep), curr_lane, free_E.

0.8787879::u28.
free_NE :- u28, action(swerve_left), curr_lane, free_E.

0.8095238::u29.
free_NE :- u29, action(swerve_right), curr_lane, free_E.

0.4848289::u30.
free_NW :- u30, action(change_to_left), \+ free_SW.

0.4939844::u31.
free_NW :- u31, action(change_to_right), \+ free_SW.

0.4453941::u32.
free_NW :- u32, action(cruise), \+ free_SW.

0.4018692::u33.
free_NW :- u33, action(keep), \+ free_SW.

0.0009990::u34.
free_NW :- u34, action(swerve_left), \+ free_SW.

0.2500000::u35.
free_NW :- u35, action(swerve_right), \+ free_SW.

0.5158868::u36.
free_NW :- u36, action(change_to_left), free_SW.

0.5818852::u37.
free_NW :- u37, action(change_to_right), free_SW.

0.5856750::u38.
free_NW :- u38, action(cruise), free_SW.

0.0234537::u39.
free_NW :- u39, action(keep), free_SW.

0.9761905::u40.
free_NW :- u40, action(swerve_left), free_SW.

0.8235294::u41.
free_NW :- u41, action(swerve_right), free_SW.

0.3194444::u42.
free_SE :- u42, \+ curr_lane, \+ free_E, \+ free_SW, \+ latent_collision.

0.9990010::u43.
free_SE :- u43, curr_lane, \+ free_E, \+ free_SW, \+ latent_collision.

0.8830409::u44.
free_SE :- u44, \+ curr_lane, free_E, \+ free_SW, \+ latent_collision.

0.9672269::u45.
free_SE :- u45, curr_lane, free_E, \+ free_SW, \+ latent_collision.

0.3267577::u46.
free_SE :- u46, \+ curr_lane, \+ free_E, free_SW, \+ latent_collision.

0.9816754::u47.
free_SE :- u47, curr_lane, \+ free_E, free_SW, \+ latent_collision.

0.4467742::u48.
free_SE :- u48, \+ curr_lane, free_E, free_SW, \+ latent_collision.

0.7563291::u49.
free_SE :- u49, curr_lane, free_E, free_SW, \+ latent_collision.

0.4924569::u50.
free_SE :- u50, \+ curr_lane, \+ free_E, \+ free_SW, latent_collision.

0.4870690::u51.
free_SE :- u51, curr_lane, \+ free_E, \+ free_SW, latent_collision.

0.5235149::u52.
free_SE :- u52, \+ curr_lane, free_E, \+ free_SW, latent_collision.

0.5157096::u53.
free_SE :- u53, curr_lane, free_E, \+ free_SW, latent_collision.

0.4809160::u54.
free_SE :- u54, \+ curr_lane, \+ free_E, free_SW, latent_collision.

0.5185185::u55.
free_SE :- u55, curr_lane, \+ free_E, free_SW, latent_collision.

0.5381356::u56.
free_SE :- u56, \+ curr_lane, free_E, free_SW, latent_collision.

0.4891501::u57.
free_SE :- u57, curr_lane, free_E, free_SW, latent_collision.

0.5277439::u58.
free_SW :- u58, action(change_to_left).

0.5733696::u59.
free_SW :- u59, action(change_to_right).

0.5997212::u60.
free_SW :- u60, action(cruise).

0.9782741::u61.
free_SW :- u61, action(keep).

0.9767442::u62.
free_SW :- u62, action(swerve_left).

0.8095238::u63.
free_SW :- u63, action(swerve_right).

0.5000000::u64.
free_W :- u64, action(change_to_left), \+ curr_lane, \+ free_NW, \+ latent_collision.

0.9818182::u65.
free_W :- u65, action(change_to_right), \+ curr_lane, \+ free_NW, \+ latent_collision.

0.5000000::u66.
free_W :- u66, action(cruise), \+ curr_lane, \+ free_NW, \+ latent_collision.

0.9990010::u67.
free_W :- u67, action(keep), \+ curr_lane, \+ free_NW, \+ latent_collision.

0.5000000::u68.
free_W :- u68, action(swerve_left), \+ curr_lane, \+ free_NW, \+ latent_collision.

0.5000000::u69.
free_W :- u69, action(swerve_right), \+ curr_lane, \+ free_NW, \+ latent_collision.

0.5000000::u70.
free_W :- u70, action(change_to_left), curr_lane, \+ free_NW, \+ latent_collision.

0.5000000::u71.
free_W :- u71, action(change_to_right), curr_lane, \+ free_NW, \+ latent_collision.

0.7520868::u72.
free_W :- u72, action(cruise), curr_lane, \+ free_NW, \+ latent_collision.

0.8217391::u73.
free_W :- u73, action(keep), curr_lane, \+ free_NW, \+ latent_collision.

0.0009990::u74.
free_W :- u74, action(swerve_left), curr_lane, \+ free_NW, \+ latent_collision.

0.3333333::u75.
free_W :- u75, action(swerve_right), curr_lane, \+ free_NW, \+ latent_collision.

0.5000000::u76.
free_W :- u76, action(change_to_left), \+ curr_lane, free_NW, \+ latent_collision.

0.9990010::u77.
free_W :- u77, action(change_to_right), \+ curr_lane, free_NW, \+ latent_collision.

0.9990010::u78.
free_W :- u78, action(cruise), \+ curr_lane, free_NW, \+ latent_collision.

0.9990010::u79.
free_W :- u79, action(keep), \+ curr_lane, free_NW, \+ latent_collision.

0.9990010::u80.
free_W :- u80, action(swerve_left), \+ curr_lane, free_NW, \+ latent_collision.

0.5000000::u81.
free_W :- u81, action(swerve_right), \+ curr_lane, free_NW, \+ latent_collision.

0.9990010::u82.
free_W :- u82, action(change_to_left), curr_lane, free_NW, \+ latent_collision.

0.5000000::u83.
free_W :- u83, action(change_to_right), curr_lane, free_NW, \+ latent_collision.

0.5996940::u84.
free_W :- u84, action(cruise), curr_lane, free_NW, \+ latent_collision.

0.3783784::u85.
free_W :- u85, action(keep), curr_lane, free_NW, \+ latent_collision.

0.9990010::u86.
free_W :- u86, action(swerve_left), curr_lane, free_NW, \+ latent_collision.

0.9990010::u87.
free_W :- u87, action(swerve_right), curr_lane, free_NW, \+ latent_collision.

0.4664179::u88.
free_W :- u88, action(change_to_left), \+ curr_lane, \+ free_NW, latent_collision.

0.4991817::u89.
free_W :- u89, action(change_to_right), \+ curr_lane, \+ free_NW, latent_collision.

0.5702671::u90.
free_W :- u90, action(cruise), \+ curr_lane, \+ free_NW, latent_collision.

0.5000000::u91.
free_W :- u91, action(keep), \+ curr_lane, \+ free_NW, latent_collision.

0.5000000::u92.
free_W :- u92, action(swerve_left), \+ curr_lane, \+ free_NW, latent_collision.

0.5000000::u93.
free_W :- u93, action(swerve_right), \+ curr_lane, \+ free_NW, latent_collision.

0.5036058::u94.
free_W :- u94, action(change_to_left), curr_lane, \+ free_NW, latent_collision.

0.5172005::u95.
free_W :- u95, action(change_to_right), curr_lane, \+ free_NW, latent_collision.

0.5241228::u96.
free_W :- u96, action(cruise), curr_lane, \+ free_NW, latent_collision.

0.5000000::u97.
free_W :- u97, action(keep), curr_lane, \+ free_NW, latent_collision.

0.5000000::u98.
free_W :- u98, action(swerve_left), curr_lane, \+ free_NW, latent_collision.

0.5000000::u99.
free_W :- u99, action(swerve_right), curr_lane, \+ free_NW, latent_collision.

0.5448113::u100.
free_W :- u100, action(change_to_left), \+ curr_lane, free_NW, latent_collision.

0.4751656::u101.
free_W :- u101, action(change_to_right), \+ curr_lane, free_NW, latent_collision.

0.5000000::u102.
free_W :- u102, action(cruise), \+ curr_lane, free_NW, latent_collision.

0.5000000::u103.
free_W :- u103, action(keep), \+ curr_lane, free_NW, latent_collision.

0.5000000::u104.
free_W :- u104, action(swerve_left), \+ curr_lane, free_NW, latent_collision.

0.5000000::u105.
free_W :- u105, action(swerve_right), \+ curr_lane, free_NW, latent_collision.

0.0009990::u106.
free_W :- u106, action(change_to_left), curr_lane, free_NW, latent_collision.

0.5581395::u107.
free_W :- u107, action(change_to_right), curr_lane, free_NW, latent_collision.

0.5105882::u108.
free_W :- u108, action(cruise), curr_lane, free_NW, latent_collision.

0.5000000::u109.
free_W :- u109, action(keep), curr_lane, free_NW, latent_collision.

0.5000000::u110.
free_W :- u110, action(swerve_left), curr_lane, free_NW, latent_collision.

0.5000000::u111.
free_W :- u111, action(swerve_right), curr_lane, free_NW, latent_collision.

0.8992899::u112.
latent_collision :- u112, action(change_to_left), \+ free_SW.

0.9936306::u113.
latent_collision :- u113, action(change_to_right), \+ free_SW.

0.2500791::u114.
latent_collision :- u114, action(cruise), \+ free_SW.

0.0009990::u115.
latent_collision :- u115, action(keep), \+ free_SW.

0.0009990::u116.
latent_collision :- u116, action(swerve_left), \+ free_SW.

0.0009990::u117.
latent_collision :- u117, action(swerve_right), \+ free_SW.

0.8549971::u118.
latent_collision :- u118, action(change_to_left), free_SW.

0.8199052::u119.
latent_collision :- u119, action(change_to_right), free_SW.

0.2011409::u120.
latent_collision :- u120, action(cruise), free_SW.

0.0009990::u121.
latent_collision :- u121, action(keep), free_SW.

0.0009990::u122.
latent_collision :- u122, action(swerve_left), free_SW.

0.0009990::u123.
latent_collision :- u123, action(swerve_right), free_SW.

