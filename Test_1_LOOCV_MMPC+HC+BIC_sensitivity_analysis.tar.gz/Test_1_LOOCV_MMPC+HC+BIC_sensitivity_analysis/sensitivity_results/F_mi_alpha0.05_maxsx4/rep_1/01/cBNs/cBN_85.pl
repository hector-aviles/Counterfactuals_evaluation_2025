%%% Exogenous variables

0.1684518::u_action(change_to_left); 0.1652744::u_action(change_to_right); 0.4095731::u_action(cruise); 0.2538820::u_action(keep); 0.0017937::u_action(swerve_left); 0.0010250::u_action(swerve_right)
action(V) :- u_action(V).

0.5345155::u1.
curr_lane :- u1.

0.6079703::u2.
free_E :- u2, \+ curr_lane, \+ latent_collision.

0.9341489::u3.
free_E :- u3, curr_lane, \+ latent_collision.

0.4441432::u4.
free_E :- u4, \+ curr_lane, latent_collision.

0.5379365::u5.
free_E :- u5, curr_lane, latent_collision.

0.5085784::u6.
free_NE :- u6, action(change_to_left), \+ curr_lane, \+ free_E.

0.5019108::u7.
free_NE :- u7, action(change_to_right), \+ curr_lane, \+ free_E.

0.5372093::u8.
free_NE :- u8, action(cruise), \+ curr_lane, \+ free_E.

0.2505892::u9.
free_NE :- u9, action(keep), \+ curr_lane, \+ free_E.

0.0009990::u10.
free_NE :- u10, action(swerve_left), \+ curr_lane, \+ free_E.

0.5000000::u11.
free_NE :- u11, action(swerve_right), \+ curr_lane, \+ free_E.

0.4648276::u12.
free_NE :- u12, action(change_to_left), curr_lane, \+ free_E.

0.4921466::u13.
free_NE :- u13, action(change_to_right), curr_lane, \+ free_E.

0.2241379::u14.
free_NE :- u14, action(cruise), curr_lane, \+ free_E.

0.0009990::u15.
free_NE :- u15, action(keep), curr_lane, \+ free_E.

0.5000000::u16.
free_NE :- u16, action(swerve_left), curr_lane, \+ free_E.

0.5000000::u17.
free_NE :- u17, action(swerve_right), curr_lane, \+ free_E.

0.4801444::u18.
free_NE :- u18, action(change_to_left), \+ curr_lane, free_E.

0.4960000::u19.
free_NE :- u19, action(change_to_right), \+ curr_lane, free_E.

0.4212651::u20.
free_NE :- u20, action(cruise), \+ curr_lane, free_E.

0.0124661::u21.
free_NE :- u21, action(keep), \+ curr_lane, free_E.

0.8333333::u22.
free_NE :- u22, action(swerve_left), \+ curr_lane, free_E.

0.5000000::u23.
free_NE :- u23, action(swerve_right), \+ curr_lane, free_E.

0.4907104::u24.
free_NE :- u24, action(change_to_left), curr_lane, free_E.

0.5658747::u25.
free_NE :- u25, action(change_to_right), curr_lane, free_E.

0.8960375::u26.
free_NE :- u26, action(cruise), curr_lane, free_E.

0.0030285::u27.
free_NE :- u27, action(keep), curr_lane, free_E.

0.9990010::u28.
free_NE :- u28, action(swerve_left), curr_lane, free_E.

0.9000000::u29.
free_NE :- u29, action(swerve_right), curr_lane, free_E.

0.5069975::u30.
free_NW :- u30, action(change_to_left), \+ free_SW.

0.5153462::u31.
free_NW :- u31, action(change_to_right), \+ free_SW.

0.4383648::u32.
free_NW :- u32, action(cruise), \+ free_SW.

0.3937008::u33.
free_NW :- u33, action(keep), \+ free_SW.

0.9990010::u34.
free_NW :- u34, action(swerve_left), \+ free_SW.

0.7500000::u35.
free_NW :- u35, action(swerve_right), \+ free_SW.

0.5241983::u36.
free_NW :- u36, action(change_to_left), free_SW.

0.5712719::u37.
free_NW :- u37, action(change_to_right), free_SW.

0.5852037::u38.
free_NW :- u38, action(cruise), free_SW.

0.0221670::u39.
free_NW :- u39, action(keep), free_SW.

0.9990010::u40.
free_NW :- u40, action(swerve_left), free_SW.

0.8125000::u41.
free_NW :- u41, action(swerve_right), free_SW.

0.6564417::u42.
free_SE :- u42, \+ curr_lane, \+ free_E, \+ free_SW, \+ latent_collision.

0.9990010::u43.
free_SE :- u43, curr_lane, \+ free_E, \+ free_SW, \+ latent_collision.

0.9065934::u44.
free_SE :- u44, \+ curr_lane, free_E, \+ free_SW, \+ latent_collision.

0.9712919::u45.
free_SE :- u45, curr_lane, free_E, \+ free_SW, \+ latent_collision.

0.3237705::u46.
free_SE :- u46, \+ curr_lane, \+ free_E, free_SW, \+ latent_collision.

0.9753086::u47.
free_SE :- u47, curr_lane, \+ free_E, free_SW, \+ latent_collision.

0.4438347::u48.
free_SE :- u48, \+ curr_lane, free_E, free_SW, \+ latent_collision.

0.7511580::u49.
free_SE :- u49, curr_lane, free_E, free_SW, \+ latent_collision.

0.5019920::u50.
free_SE :- u50, \+ curr_lane, \+ free_E, \+ free_SW, latent_collision.

0.4686469::u51.
free_SE :- u51, curr_lane, \+ free_E, \+ free_SW, latent_collision.

0.5437416::u52.
free_SE :- u52, \+ curr_lane, free_E, \+ free_SW, latent_collision.

0.5115304::u53.
free_SE :- u53, curr_lane, free_E, \+ free_SW, latent_collision.

0.4904398::u54.
free_SE :- u54, \+ curr_lane, \+ free_E, free_SW, latent_collision.

0.4806110::u55.
free_SE :- u55, curr_lane, \+ free_E, free_SW, latent_collision.

0.4849162::u56.
free_SE :- u56, \+ curr_lane, free_E, free_SW, latent_collision.

0.5178082::u57.
free_SE :- u57, curr_lane, free_E, free_SW, latent_collision.

0.5217524::u58.
free_SW :- u58, action(change_to_left).

0.5655814::u59.
free_SW :- u59, action(change_to_right).

0.6021021::u60.
free_SW :- u60, action(cruise).

0.9743642::u61.
free_SW :- u61, action(keep).

0.9714286::u62.
free_SW :- u62, action(swerve_left).

0.8000000::u63.
free_SW :- u63, action(swerve_right).

0.5000000::u64.
free_W :- u64, action(change_to_left), \+ curr_lane, \+ free_NW, \+ latent_collision.

0.9714286::u65.
free_W :- u65, action(change_to_right), \+ curr_lane, \+ free_NW, \+ latent_collision.

0.5000000::u66.
free_W :- u66, action(cruise), \+ curr_lane, \+ free_NW, \+ latent_collision.

0.9990010::u67.
free_W :- u67, action(keep), \+ curr_lane, \+ free_NW, \+ latent_collision.

0.5000000::u68.
free_W :- u68, action(swerve_left), \+ curr_lane, \+ free_NW, \+ latent_collision.

0.5000000::u69.
free_W :- u69, action(swerve_right), \+ curr_lane, \+ free_NW, \+ latent_collision.

0.5000000::u70.
free_W :- u70, action(change_to_left), curr_lane, \+ free_NW, \+ latent_collision.

0.5000000::u71.
free_W :- u71, action(change_to_right), curr_lane, \+ free_NW, \+ latent_collision.

0.7323770::u72.
free_W :- u72, action(cruise), curr_lane, \+ free_NW, \+ latent_collision.

0.8391484::u73.
free_W :- u73, action(keep), curr_lane, \+ free_NW, \+ latent_collision.

0.5000000::u74.
free_W :- u74, action(swerve_left), curr_lane, \+ free_NW, \+ latent_collision.

0.9990010::u75.
free_W :- u75, action(swerve_right), curr_lane, \+ free_NW, \+ latent_collision.

0.5000000::u76.
free_W :- u76, action(change_to_left), \+ curr_lane, free_NW, \+ latent_collision.

0.9990010::u77.
free_W :- u77, action(change_to_right), \+ curr_lane, free_NW, \+ latent_collision.

0.9994731::u78.
free_W :- u78, action(cruise), \+ curr_lane, free_NW, \+ latent_collision.

0.9990010::u79.
free_W :- u79, action(keep), \+ curr_lane, free_NW, \+ latent_collision.

0.9990010::u80.
free_W :- u80, action(swerve_left), \+ curr_lane, free_NW, \+ latent_collision.

0.5000000::u81.
free_W :- u81, action(swerve_right), \+ curr_lane, free_NW, \+ latent_collision.

0.9990010::u82.
free_W :- u82, action(change_to_left), curr_lane, free_NW, \+ latent_collision.

0.5000000::u83.
free_W :- u83, action(change_to_right), curr_lane, free_NW, \+ latent_collision.

0.6001062::u84.
free_W :- u84, action(cruise), curr_lane, free_NW, \+ latent_collision.

0.3586207::u85.
free_W :- u85, action(keep), curr_lane, free_NW, \+ latent_collision.

0.9642857::u86.
free_W :- u86, action(swerve_left), curr_lane, free_NW, \+ latent_collision.

0.9375000::u87.
free_W :- u87, action(swerve_right), curr_lane, free_NW, \+ latent_collision.

0.4955752::u88.
free_W :- u88, action(change_to_left), \+ curr_lane, \+ free_NW, latent_collision.

0.5111492::u89.
free_W :- u89, action(change_to_right), \+ curr_lane, \+ free_NW, latent_collision.

0.5159453::u90.
free_W :- u90, action(cruise), \+ curr_lane, \+ free_NW, latent_collision.

0.5000000::u91.
free_W :- u91, action(keep), \+ curr_lane, \+ free_NW, latent_collision.

0.5000000::u92.
free_W :- u92, action(swerve_left), \+ curr_lane, \+ free_NW, latent_collision.

0.5000000::u93.
free_W :- u93, action(swerve_right), \+ curr_lane, \+ free_NW, latent_collision.

0.4900000::u94.
free_W :- u94, action(change_to_left), curr_lane, \+ free_NW, latent_collision.

0.5024752::u95.
free_W :- u95, action(change_to_right), curr_lane, \+ free_NW, latent_collision.

0.4849138::u96.
free_W :- u96, action(cruise), curr_lane, \+ free_NW, latent_collision.

0.5000000::u97.
free_W :- u97, action(keep), curr_lane, \+ free_NW, latent_collision.

0.5000000::u98.
free_W :- u98, action(swerve_left), curr_lane, \+ free_NW, latent_collision.

0.5000000::u99.
free_W :- u99, action(swerve_right), curr_lane, \+ free_NW, latent_collision.

0.5268692::u100.
free_W :- u100, action(change_to_left), \+ curr_lane, free_NW, latent_collision.

0.5327586::u101.
free_W :- u101, action(change_to_right), \+ curr_lane, free_NW, latent_collision.

0.5000000::u102.
free_W :- u102, action(cruise), \+ curr_lane, free_NW, latent_collision.

0.5000000::u103.
free_W :- u103, action(keep), \+ curr_lane, free_NW, latent_collision.

0.5000000::u104.
free_W :- u104, action(swerve_left), \+ curr_lane, free_NW, latent_collision.

0.5000000::u105.
free_W :- u105, action(swerve_right), \+ curr_lane, free_NW, latent_collision.

0.0009990::u106.
free_W :- u106, action(change_to_left), curr_lane, free_NW, latent_collision.

0.5453515::u107.
free_W :- u107, action(change_to_right), curr_lane, free_NW, latent_collision.

0.5198135::u108.
free_W :- u108, action(cruise), curr_lane, free_NW, latent_collision.

0.5000000::u109.
free_W :- u109, action(keep), curr_lane, free_NW, latent_collision.

0.5000000::u110.
free_W :- u110, action(swerve_left), curr_lane, free_NW, latent_collision.

0.5000000::u111.
free_W :- u111, action(swerve_right), curr_lane, free_NW, latent_collision.

0.8867684::u112.
latent_collision :- u112, action(change_to_left), \+ free_SW.

0.9935760::u113.
latent_collision :- u113, action(change_to_right), \+ free_SW.

0.2591195::u114.
latent_collision :- u114, action(cruise), \+ free_SW.

0.0009990::u115.
latent_collision :- u115, action(keep), \+ free_SW.

0.0009990::u116.
latent_collision :- u116, action(swerve_left), \+ free_SW.

0.0009990::u117.
latent_collision :- u117, action(swerve_right), \+ free_SW.

0.8623907::u118.
latent_collision :- u118, action(change_to_left), free_SW.

0.8009868::u119.
latent_collision :- u119, action(change_to_right), free_SW.

0.1967997::u120.
latent_collision :- u120, action(cruise), free_SW.

0.0009990::u121.
latent_collision :- u121, action(keep), free_SW.

0.0009990::u122.
latent_collision :- u122, action(swerve_left), free_SW.

0.0009990::u123.
latent_collision :- u123, action(swerve_right), free_SW.

