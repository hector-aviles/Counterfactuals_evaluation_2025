%%% Exogenous variables

0.1675208::u_action(change_to_left); 0.1710054::u_action(change_to_right); 0.4031977::u_action(cruise); 0.2558163::u_action(keep); 0.0017423::u_action(swerve_left); 0.0007174::u_action(swerve_right)
action(V) :- u_action(V).

0.5238290::u1.
curr_lane :- u1.

0.6083712::u2.
free_E :- u2, \+ curr_lane, \+ latent_collision.

0.9379449::u3.
free_E :- u3, curr_lane, \+ latent_collision.

0.4421912::u4.
free_E :- u4, \+ curr_lane, latent_collision.

0.5276596::u5.
free_E :- u5, curr_lane, latent_collision.

0.4888060::u6.
free_NE :- u6, action(change_to_left), \+ curr_lane, \+ free_E.

0.5088339::u7.
free_NE :- u7, action(change_to_right), \+ curr_lane, \+ free_E.

0.5227103::u8.
free_NE :- u8, action(cruise), \+ curr_lane, \+ free_E.

0.2715856::u9.
free_NE :- u9, action(keep), \+ curr_lane, \+ free_E.

0.5000000::u10.
free_NE :- u10, action(swerve_left), \+ curr_lane, \+ free_E.

0.5000000::u11.
free_NE :- u11, action(swerve_right), \+ curr_lane, \+ free_E.

0.5100287::u12.
free_NE :- u12, action(change_to_left), curr_lane, \+ free_E.

0.4948718::u13.
free_NE :- u13, action(change_to_right), curr_lane, \+ free_E.

0.2115385::u14.
free_NE :- u14, action(cruise), curr_lane, \+ free_E.

0.0009990::u15.
free_NE :- u15, action(keep), curr_lane, \+ free_E.

0.0009990::u16.
free_NE :- u16, action(swerve_left), curr_lane, \+ free_E.

0.9990010::u17.
free_NE :- u17, action(swerve_right), curr_lane, \+ free_E.

0.4744958::u18.
free_NE :- u18, action(change_to_left), \+ curr_lane, free_E.

0.4944513::u19.
free_NE :- u19, action(change_to_right), \+ curr_lane, free_E.

0.4588897::u20.
free_NE :- u20, action(cruise), \+ curr_lane, free_E.

0.0159876::u21.
free_NE :- u21, action(keep), \+ curr_lane, free_E.

0.6666667::u22.
free_NE :- u22, action(swerve_left), \+ curr_lane, free_E.

0.5000000::u23.
free_NE :- u23, action(swerve_right), \+ curr_lane, free_E.

0.4783550::u24.
free_NE :- u24, action(change_to_left), curr_lane, free_E.

0.5328874::u25.
free_NE :- u25, action(change_to_right), curr_lane, free_E.

0.9020079::u26.
free_NE :- u26, action(cruise), curr_lane, free_E.

0.0024969::u27.
free_NE :- u27, action(keep), curr_lane, free_E.

0.9629630::u28.
free_NE :- u28, action(swerve_left), curr_lane, free_E.

0.8461538::u29.
free_NE :- u29, action(swerve_right), curr_lane, free_E.

0.5226986::u30.
free_NW :- u30, action(change_to_left), \+ free_SW.

0.5138686::u31.
free_NW :- u31, action(change_to_right), \+ free_SW.

0.4412331::u32.
free_NW :- u32, action(cruise), \+ free_SW.

0.3664122::u33.
free_NW :- u33, action(keep), \+ free_SW.

0.5000000::u34.
free_NW :- u34, action(swerve_left), \+ free_SW.

0.9990010::u35.
free_NW :- u35, action(swerve_right), \+ free_SW.

0.5210933::u36.
free_NW :- u36, action(change_to_left), free_SW.

0.5754957::u37.
free_NW :- u37, action(change_to_right), free_SW.

0.5858225::u38.
free_NW :- u38, action(cruise), free_SW.

0.0203662::u39.
free_NW :- u39, action(keep), free_SW.

0.9705882::u40.
free_NW :- u40, action(swerve_left), free_SW.

0.8461538::u41.
free_NW :- u41, action(swerve_right), free_SW.

0.6644295::u42.
free_SE :- u42, \+ curr_lane, \+ free_E, \+ free_SW, \+ latent_collision.

0.9990010::u43.
free_SE :- u43, curr_lane, \+ free_E, \+ free_SW, \+ latent_collision.

0.8684211::u44.
free_SE :- u44, \+ curr_lane, free_E, \+ free_SW, \+ latent_collision.

0.9698690::u45.
free_SE :- u45, curr_lane, free_E, \+ free_SW, \+ latent_collision.

0.3265102::u46.
free_SE :- u46, \+ curr_lane, \+ free_E, free_SW, \+ latent_collision.

0.9758065::u47.
free_SE :- u47, curr_lane, \+ free_E, free_SW, \+ latent_collision.

0.4471952::u48.
free_SE :- u48, \+ curr_lane, free_E, free_SW, \+ latent_collision.

0.7531159::u49.
free_SE :- u49, curr_lane, free_E, free_SW, \+ latent_collision.

0.5161290::u50.
free_SE :- u50, \+ curr_lane, \+ free_E, \+ free_SW, latent_collision.

0.4821634::u51.
free_SE :- u51, curr_lane, \+ free_E, \+ free_SW, latent_collision.

0.4519104::u52.
free_SE :- u52, \+ curr_lane, free_E, \+ free_SW, latent_collision.

0.5069817::u53.
free_SE :- u53, curr_lane, free_E, \+ free_SW, latent_collision.

0.4940639::u54.
free_SE :- u54, \+ curr_lane, \+ free_E, free_SW, latent_collision.

0.4663727::u55.
free_SE :- u55, curr_lane, \+ free_E, free_SW, latent_collision.

0.4717391::u56.
free_SE :- u56, \+ curr_lane, free_E, free_SW, latent_collision.

0.5175689::u57.
free_SE :- u57, curr_lane, free_E, free_SW, latent_collision.

0.5148363::u58.
free_SW :- u58, action(change_to_left).

0.5894516::u59.
free_SW :- u59, action(change_to_right).

0.6042196::u60.
free_SW :- u60, action(cruise).

0.9737580::u61.
free_SW :- u61, action(keep).

0.9990010::u62.
free_SW :- u62, action(swerve_left).

0.9285714::u63.
free_SW :- u63, action(swerve_right).

0.5000000::u64.
free_W :- u64, action(change_to_left), \+ curr_lane, \+ free_NW, \+ latent_collision.

0.9285714::u65.
free_W :- u65, action(change_to_right), \+ curr_lane, \+ free_NW, \+ latent_collision.

0.5000000::u66.
free_W :- u66, action(cruise), \+ curr_lane, \+ free_NW, \+ latent_collision.

0.9990010::u67.
free_W :- u67, action(keep), \+ curr_lane, \+ free_NW, \+ latent_collision.

0.5000000::u68.
free_W :- u68, action(swerve_left), \+ curr_lane, \+ free_NW, \+ latent_collision.

0.5000000::u69.
free_W :- u69, action(swerve_right), \+ curr_lane, \+ free_NW, \+ latent_collision.

0.5000000::u70.
free_W :- u70, action(change_to_left), curr_lane, \+ free_NW, \+ latent_collision.

0.5000000::u71.
free_W :- u71, action(change_to_right), curr_lane, \+ free_NW, \+ latent_collision.

0.7369309::u72.
free_W :- u72, action(cruise), curr_lane, \+ free_NW, \+ latent_collision.

0.8246041::u73.
free_W :- u73, action(keep), curr_lane, \+ free_NW, \+ latent_collision.

0.0009990::u74.
free_W :- u74, action(swerve_left), curr_lane, \+ free_NW, \+ latent_collision.

0.5000000::u75.
free_W :- u75, action(swerve_right), curr_lane, \+ free_NW, \+ latent_collision.

0.5000000::u76.
free_W :- u76, action(change_to_left), \+ curr_lane, free_NW, \+ latent_collision.

0.9990010::u77.
free_W :- u77, action(change_to_right), \+ curr_lane, free_NW, \+ latent_collision.

0.9990010::u78.
free_W :- u78, action(cruise), \+ curr_lane, free_NW, \+ latent_collision.

0.9990010::u79.
free_W :- u79, action(keep), \+ curr_lane, free_NW, \+ latent_collision.

0.9990010::u80.
free_W :- u80, action(swerve_left), \+ curr_lane, free_NW, \+ latent_collision.

0.5000000::u81.
free_W :- u81, action(swerve_right), \+ curr_lane, free_NW, \+ latent_collision.

0.9990010::u82.
free_W :- u82, action(change_to_left), curr_lane, free_NW, \+ latent_collision.

0.5000000::u83.
free_W :- u83, action(change_to_right), curr_lane, free_NW, \+ latent_collision.

0.5911277::u84.
free_W :- u84, action(cruise), curr_lane, free_NW, \+ latent_collision.

0.3941606::u85.
free_W :- u85, action(keep), curr_lane, free_NW, \+ latent_collision.

0.9990010::u86.
free_W :- u86, action(swerve_left), curr_lane, free_NW, \+ latent_collision.

0.9990010::u87.
free_W :- u87, action(swerve_right), curr_lane, free_NW, \+ latent_collision.

0.5505319::u88.
free_W :- u88, action(change_to_left), \+ curr_lane, \+ free_NW, latent_collision.

0.5119617::u89.
free_W :- u89, action(change_to_right), \+ curr_lane, \+ free_NW, latent_collision.

0.5286195::u90.
free_W :- u90, action(cruise), \+ curr_lane, \+ free_NW, latent_collision.

0.5000000::u91.
free_W :- u91, action(keep), \+ curr_lane, \+ free_NW, latent_collision.

0.5000000::u92.
free_W :- u92, action(swerve_left), \+ curr_lane, \+ free_NW, latent_collision.

0.5000000::u93.
free_W :- u93, action(swerve_right), \+ curr_lane, \+ free_NW, latent_collision.

0.5154131::u94.
free_W :- u94, action(change_to_left), curr_lane, \+ free_NW, latent_collision.

0.5085575::u95.
free_W :- u95, action(change_to_right), curr_lane, \+ free_NW, latent_collision.

0.4730942::u96.
free_W :- u96, action(cruise), curr_lane, \+ free_NW, latent_collision.

0.5000000::u97.
free_W :- u97, action(keep), curr_lane, \+ free_NW, latent_collision.

0.5000000::u98.
free_W :- u98, action(swerve_left), curr_lane, \+ free_NW, latent_collision.

0.5000000::u99.
free_W :- u99, action(swerve_right), curr_lane, \+ free_NW, latent_collision.

0.5296089::u100.
free_W :- u100, action(change_to_left), \+ curr_lane, free_NW, latent_collision.

0.5253165::u101.
free_W :- u101, action(change_to_right), \+ curr_lane, free_NW, latent_collision.

0.5000000::u102.
free_W :- u102, action(cruise), \+ curr_lane, free_NW, latent_collision.

0.5000000::u103.
free_W :- u103, action(keep), \+ curr_lane, free_NW, latent_collision.

0.5000000::u104.
free_W :- u104, action(swerve_left), \+ curr_lane, free_NW, latent_collision.

0.5000000::u105.
free_W :- u105, action(swerve_right), \+ curr_lane, free_NW, latent_collision.

0.0009990::u106.
free_W :- u106, action(change_to_left), curr_lane, free_NW, latent_collision.

0.5448196::u107.
free_W :- u107, action(change_to_right), curr_lane, free_NW, latent_collision.

0.5108959::u108.
free_W :- u108, action(cruise), curr_lane, free_NW, latent_collision.

0.5000000::u109.
free_W :- u109, action(keep), curr_lane, free_NW, latent_collision.

0.5000000::u110.
free_W :- u110, action(swerve_left), curr_lane, free_NW, latent_collision.

0.5000000::u111.
free_W :- u111, action(swerve_right), curr_lane, free_NW, latent_collision.

0.8965952::u112.
latent_collision :- u112, action(change_to_left), \+ free_SW.

0.9963504::u113.
latent_collision :- u113, action(change_to_right), \+ free_SW.

0.2552987::u114.
latent_collision :- u114, action(cruise), \+ free_SW.

0.0009990::u115.
latent_collision :- u115, action(keep), \+ free_SW.

0.5000000::u116.
latent_collision :- u116, action(swerve_left), \+ free_SW.

0.0009990::u117.
latent_collision :- u117, action(swerve_right), \+ free_SW.

0.8609626::u118.
latent_collision :- u118, action(change_to_left), free_SW.

0.7986782::u119.
latent_collision :- u119, action(change_to_right), free_SW.

0.2008835::u120.
latent_collision :- u120, action(cruise), free_SW.

0.0009990::u121.
latent_collision :- u121, action(keep), free_SW.

0.0009990::u122.
latent_collision :- u122, action(swerve_left), free_SW.

0.0009990::u123.
latent_collision :- u123, action(swerve_right), free_SW.

