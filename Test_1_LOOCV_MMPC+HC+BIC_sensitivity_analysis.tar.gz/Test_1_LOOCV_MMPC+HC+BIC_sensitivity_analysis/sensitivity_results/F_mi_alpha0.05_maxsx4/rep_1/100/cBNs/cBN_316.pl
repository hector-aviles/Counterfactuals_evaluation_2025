%%% Exogenous variables

0.1702068::u_action(change_to_left); 0.1719617::u_action(change_to_right); 0.4102063::u_action(cruise); 0.2452530::u_action(keep); 0.0014983::u_action(swerve_left); 0.0008739::u_action(swerve_right)
action(V) :- u_action(V).

0.6741448::u1.
free_SW :- u1.

0.7079310::u2.
free_W :- u2.

0.3897170::u3.
latent_collision :- u3.

0.4268151::u4.
curr_lane :- u4, action(change_to_left), \+ free_E, \+ free_NE, \+ free_SW.

0.5000750::u5.
curr_lane :- u5, action(change_to_right), \+ free_E, \+ free_NE, \+ free_SW.

0.5246611::u6.
curr_lane :- u6, action(cruise), \+ free_E, \+ free_NE, \+ free_SW.

0.0785398::u7.
curr_lane :- u7, action(keep), \+ free_E, \+ free_NE, \+ free_SW.

0.8000000::u8.
curr_lane :- u8, action(swerve_left), \+ free_E, \+ free_NE, \+ free_SW.

0.5000000::u9.
curr_lane :- u9, action(swerve_right), \+ free_E, \+ free_NE, \+ free_SW.

0.5330120::u10.
curr_lane :- u10, action(change_to_left), free_E, \+ free_NE, \+ free_SW.

0.4989399::u11.
curr_lane :- u11, action(change_to_right), free_E, \+ free_NE, \+ free_SW.

0.4571447::u12.
curr_lane :- u12, action(cruise), free_E, \+ free_NE, \+ free_SW.

0.9848172::u13.
curr_lane :- u13, action(keep), free_E, \+ free_NE, \+ free_SW.

0.9990010::u14.
curr_lane :- u14, action(swerve_left), free_E, \+ free_NE, \+ free_SW.

0.9990010::u15.
curr_lane :- u15, action(swerve_right), free_E, \+ free_NE, \+ free_SW.

0.4416497::u16.
curr_lane :- u16, action(change_to_left), \+ free_E, free_NE, \+ free_SW.

0.5002622::u17.
curr_lane :- u17, action(change_to_right), \+ free_E, free_NE, \+ free_SW.

0.1183582::u18.
curr_lane :- u18, action(cruise), \+ free_E, free_NE, \+ free_SW.

0.0009990::u19.
curr_lane :- u19, action(keep), \+ free_E, free_NE, \+ free_SW.

0.5000000::u20.
curr_lane :- u20, action(swerve_left), \+ free_E, free_NE, \+ free_SW.

0.5000000::u21.
curr_lane :- u21, action(swerve_right), \+ free_E, free_NE, \+ free_SW.

0.5212179::u22.
curr_lane :- u22, action(change_to_left), free_E, free_NE, \+ free_SW.

0.9587906::u23.
curr_lane :- u23, action(change_to_right), free_E, free_NE, \+ free_SW.

0.9526929::u24.
curr_lane :- u24, action(cruise), free_E, free_NE, \+ free_SW.

0.3600000::u25.
curr_lane :- u25, action(keep), free_E, free_NE, \+ free_SW.

0.6818182::u26.
curr_lane :- u26, action(swerve_left), free_E, free_NE, \+ free_SW.

0.9990010::u27.
curr_lane :- u27, action(swerve_right), free_E, free_NE, \+ free_SW.

0.5025168::u28.
curr_lane :- u28, action(change_to_left), \+ free_E, \+ free_NE, free_SW.

0.4987540::u29.
curr_lane :- u29, action(change_to_right), \+ free_E, \+ free_NE, free_SW.

0.3276569::u30.
curr_lane :- u30, action(cruise), \+ free_E, \+ free_NE, free_SW.

0.1613325::u31.
curr_lane :- u31, action(keep), \+ free_E, \+ free_NE, free_SW.

0.4148936::u32.
curr_lane :- u32, action(swerve_left), \+ free_E, \+ free_NE, free_SW.

0.9990010::u33.
curr_lane :- u33, action(swerve_right), \+ free_E, \+ free_NE, free_SW.

0.4787570::u34.
curr_lane :- u34, action(change_to_left), free_E, \+ free_NE, free_SW.

0.4929348::u35.
curr_lane :- u35, action(change_to_right), free_E, \+ free_NE, free_SW.

0.3050040::u36.
curr_lane :- u36, action(cruise), free_E, \+ free_NE, free_SW.

0.4523063::u37.
curr_lane :- u37, action(keep), free_E, \+ free_NE, free_SW.

0.6721311::u38.
curr_lane :- u38, action(swerve_left), free_E, \+ free_NE, free_SW.

0.9990010::u39.
curr_lane :- u39, action(swerve_right), free_E, \+ free_NE, free_SW.

0.5368911::u40.
curr_lane :- u40, action(change_to_left), \+ free_E, free_NE, free_SW.

0.5218787::u41.
curr_lane :- u41, action(change_to_right), \+ free_E, free_NE, free_SW.

0.1646197::u42.
curr_lane :- u42, action(cruise), \+ free_E, free_NE, free_SW.

0.0005701::u43.
curr_lane :- u43, action(keep), \+ free_E, free_NE, free_SW.

0.0454545::u44.
curr_lane :- u44, action(swerve_left), \+ free_E, free_NE, free_SW.

0.9990010::u45.
curr_lane :- u45, action(swerve_right), \+ free_E, free_NE, free_SW.

0.5203765::u46.
curr_lane :- u46, action(change_to_left), free_E, free_NE, free_SW.

0.4361847::u47.
curr_lane :- u47, action(change_to_right), free_E, free_NE, free_SW.

0.7995000::u48.
curr_lane :- u48, action(cruise), free_E, free_NE, free_SW.

0.2444444::u49.
curr_lane :- u49, action(keep), free_E, free_NE, free_SW.

0.8585608::u50.
curr_lane :- u50, action(swerve_left), free_E, free_NE, free_SW.

0.9909774::u51.
curr_lane :- u51, action(swerve_right), free_E, free_NE, free_SW.

0.5367564::u52.
free_E :- u52, action(change_to_left).

0.5192692::u53.
free_E :- u53, action(change_to_right).

0.7788353::u54.
free_E :- u54, action(cruise).

0.7428241::u55.
free_E :- u55, action(keep).

0.9504161::u56.
free_E :- u56, action(swerve_left).

0.9958383::u57.
free_E :- u57, action(swerve_right).

0.4880408::u58.
free_NE :- u58, action(change_to_left), \+ free_E.

0.4963769::u59.
free_NE :- u59, action(change_to_right), \+ free_E.

0.4308719::u60.
free_NE :- u60, action(cruise), \+ free_E.

0.0729877::u61.
free_NE :- u61, action(keep), \+ free_E.

0.3076923::u62.
free_NE :- u62, action(swerve_left), \+ free_E.

0.4285714::u63.
free_NE :- u63, action(swerve_right), \+ free_E.

0.4816264::u64.
free_NE :- u64, action(change_to_left), free_E.

0.5233978::u65.
free_NE :- u65, action(change_to_right), free_E.

0.7906398::u66.
free_NE :- u66, action(cruise), free_E.

0.0086693::u67.
free_NE :- u67, action(keep), free_E.

0.8901861::u68.
free_NE :- u68, action(swerve_left), free_E.

0.8573134::u69.
free_NE :- u69, action(swerve_right), free_E.

0.4331459::u70.
free_NW :- u70, action(change_to_left), \+ free_E, \+ free_NE, \+ free_SW.

0.5000750::u71.
free_NW :- u71, action(change_to_right), \+ free_E, \+ free_NE, \+ free_SW.

0.4749718::u72.
free_NW :- u72, action(cruise), \+ free_E, \+ free_NE, \+ free_SW.

0.0398230::u73.
free_NW :- u73, action(keep), \+ free_E, \+ free_NE, \+ free_SW.

0.4000000::u74.
free_NW :- u74, action(swerve_left), \+ free_E, \+ free_NE, \+ free_SW.

0.5000000::u75.
free_NW :- u75, action(swerve_right), \+ free_E, \+ free_NE, \+ free_SW.

0.5551290::u76.
free_NW :- u76, action(change_to_left), free_E, \+ free_NE, \+ free_SW.

0.4989399::u77.
free_NW :- u77, action(change_to_right), free_E, \+ free_NE, \+ free_SW.

0.5485954::u78.
free_NW :- u78, action(cruise), free_E, \+ free_NE, \+ free_SW.

0.4511724::u79.
free_NW :- u79, action(keep), free_E, \+ free_NE, \+ free_SW.

0.7894737::u80.
free_NW :- u80, action(swerve_left), free_E, \+ free_NE, \+ free_SW.

0.4210526::u81.
free_NW :- u81, action(swerve_right), free_E, \+ free_NE, \+ free_SW.

0.4422911::u82.
free_NW :- u82, action(change_to_left), \+ free_E, free_NE, \+ free_SW.

0.4999625::u83.
free_NW :- u83, action(change_to_right), \+ free_E, free_NE, \+ free_SW.

0.3703887::u84.
free_NW :- u84, action(cruise), \+ free_E, free_NE, \+ free_SW.

0.0329670::u85.
free_NW :- u85, action(keep), \+ free_E, free_NE, \+ free_SW.

0.5000000::u86.
free_NW :- u86, action(swerve_left), \+ free_E, free_NE, \+ free_SW.

0.5000000::u87.
free_NW :- u87, action(swerve_right), \+ free_E, free_NE, \+ free_SW.

0.5221731::u88.
free_NW :- u88, action(change_to_left), free_E, free_NE, \+ free_SW.

0.4813360::u89.
free_NW :- u89, action(change_to_right), free_E, free_NE, \+ free_SW.

0.4201306::u90.
free_NW :- u90, action(cruise), free_E, free_NE, \+ free_SW.

0.6800000::u91.
free_NW :- u91, action(keep), free_E, free_NE, \+ free_SW.

0.8181818::u92.
free_NW :- u92, action(swerve_left), free_E, free_NE, \+ free_SW.

0.5566038::u93.
free_NW :- u93, action(swerve_right), free_E, free_NE, \+ free_SW.

0.5245185::u94.
free_NW :- u94, action(change_to_left), \+ free_E, \+ free_NE, free_SW.

0.4988039::u95.
free_NW :- u95, action(change_to_right), \+ free_E, \+ free_NE, free_SW.

0.6311003::u96.
free_NW :- u96, action(cruise), \+ free_E, \+ free_NE, free_SW.

0.0031530::u97.
free_NW :- u97, action(keep), \+ free_E, \+ free_NE, free_SW.

0.9574468::u98.
free_NW :- u98, action(swerve_left), \+ free_E, \+ free_NE, free_SW.

0.2500000::u99.
free_NW :- u99, action(swerve_right), \+ free_E, \+ free_NE, free_SW.

0.5143570::u100.
free_NW :- u100, action(change_to_left), free_E, \+ free_NE, free_SW.

0.4852122::u101.
free_NW :- u101, action(change_to_right), free_E, \+ free_NE, free_SW.

0.6881442::u102.
free_NW :- u102, action(cruise), free_E, \+ free_NE, free_SW.

0.0275045::u103.
free_NW :- u103, action(keep), free_E, \+ free_NE, free_SW.

0.7500000::u104.
free_NW :- u104, action(swerve_left), free_E, \+ free_NE, free_SW.

0.6181818::u105.
free_NW :- u105, action(swerve_right), free_E, \+ free_NE, free_SW.

0.5419164::u106.
free_NW :- u106, action(change_to_left), \+ free_E, free_NE, free_SW.

0.5440399::u107.
free_NW :- u107, action(change_to_right), \+ free_E, free_NE, free_SW.

0.7494417::u108.
free_NW :- u108, action(cruise), \+ free_E, free_NE, free_SW.

0.0045610::u109.
free_NW :- u109, action(keep), \+ free_E, free_NE, free_SW.

0.9545455::u110.
free_NW :- u110, action(swerve_left), \+ free_E, free_NE, free_SW.

0.0009990::u111.
free_NW :- u111, action(swerve_right), \+ free_E, free_NE, free_SW.

0.5328242::u112.
free_NW :- u112, action(change_to_left), free_E, free_NE, free_SW.

0.7335504::u113.
free_NW :- u113, action(change_to_right), free_E, free_NE, free_SW.

0.5146973::u114.
free_NW :- u114, action(cruise), free_E, free_NE, free_SW.

0.3233831::u115.
free_NW :- u115, action(keep), free_E, free_NE, free_SW.

0.9937965::u116.
free_NW :- u116, action(swerve_left), free_E, free_NE, free_SW.

0.8654135::u117.
free_NW :- u117, action(swerve_right), free_E, free_NE, free_SW.

0.5031550::u118.
free_SE :- u118, action(change_to_left), \+ curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.4988813::u119.
free_SE :- u119, action(change_to_right), \+ curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.4938048::u120.
free_SE :- u120, action(cruise), \+ curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.2600557::u121.
free_SE :- u121, action(keep), \+ curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.9990010::u122.
free_SE :- u122, action(swerve_left), \+ curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.5000000::u123.
free_SE :- u123, action(swerve_right), \+ curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.5011970::u124.
free_SE :- u124, action(change_to_left), curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.5000000::u125.
free_SE :- u125, action(change_to_right), curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.5004246::u126.
free_SE :- u126, action(cruise), curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.9932980::u127.
free_SE :- u127, action(keep), curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.9990010::u128.
free_SE :- u128, action(swerve_left), curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.9990010::u129.
free_SE :- u129, action(swerve_right), curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.5028824::u130.
free_SE :- u130, action(change_to_left), \+ curr_lane, free_E, \+ free_NE, \+ free_NW.

0.4964223::u131.
free_SE :- u131, action(change_to_right), \+ curr_lane, free_E, \+ free_NE, \+ free_NW.

0.5150128::u132.
free_SE :- u132, action(cruise), \+ curr_lane, free_E, \+ free_NE, \+ free_NW.

0.3435450::u133.
free_SE :- u133, action(keep), \+ curr_lane, free_E, \+ free_NE, \+ free_NW.

0.9990010::u134.
free_SE :- u134, action(swerve_left), \+ curr_lane, free_E, \+ free_NE, \+ free_NW.

0.5000000::u135.
free_SE :- u135, action(swerve_right), \+ curr_lane, free_E, \+ free_NE, \+ free_NW.

0.5370769::u136.
free_SE :- u136, action(change_to_left), curr_lane, free_E, \+ free_NE, \+ free_NW.

0.5093585::u137.
free_SE :- u137, action(change_to_right), curr_lane, free_E, \+ free_NE, \+ free_NW.

0.5741175::u138.
free_SE :- u138, action(cruise), curr_lane, free_E, \+ free_NE, \+ free_NW.

0.7918084::u139.
free_SE :- u139, action(keep), curr_lane, free_E, \+ free_NE, \+ free_NW.

0.9677419::u140.
free_SE :- u140, action(swerve_left), curr_lane, free_E, \+ free_NE, \+ free_NW.

0.8947368::u141.
free_SE :- u141, action(swerve_right), curr_lane, free_E, \+ free_NE, \+ free_NW.

0.5714775::u142.
free_SE :- u142, action(change_to_left), \+ curr_lane, \+ free_E, free_NE, \+ free_NW.

0.5768493::u143.
free_SE :- u143, action(change_to_right), \+ curr_lane, \+ free_E, free_NE, \+ free_NW.

0.5934739::u144.
free_SE :- u144, action(cruise), \+ curr_lane, \+ free_E, free_NE, \+ free_NW.

0.9902439::u145.
free_SE :- u145, action(keep), \+ curr_lane, \+ free_E, free_NE, \+ free_NW.

0.9990010::u146.
free_SE :- u146, action(swerve_left), \+ curr_lane, \+ free_E, free_NE, \+ free_NW.

0.5000000::u147.
free_SE :- u147, action(swerve_right), \+ curr_lane, \+ free_E, free_NE, \+ free_NW.

0.5000000::u148.
free_SE :- u148, action(change_to_left), curr_lane, \+ free_E, free_NE, \+ free_NW.

0.5003992::u149.
free_SE :- u149, action(change_to_right), curr_lane, \+ free_E, free_NE, \+ free_NW.

0.9820470::u150.
free_SE :- u150, action(cruise), curr_lane, \+ free_E, free_NE, \+ free_NW.

0.9990010::u151.
free_SE :- u151, action(keep), curr_lane, \+ free_E, free_NE, \+ free_NW.

0.9990010::u152.
free_SE :- u152, action(swerve_left), curr_lane, \+ free_E, free_NE, \+ free_NW.

0.9990010::u153.
free_SE :- u153, action(swerve_right), curr_lane, \+ free_E, free_NE, \+ free_NW.

0.5001499::u154.
free_SE :- u154, action(change_to_left), \+ curr_lane, free_E, free_NE, \+ free_NW.

0.3295386::u155.
free_SE :- u155, action(change_to_right), \+ curr_lane, free_E, free_NE, \+ free_NW.

0.4969129::u156.
free_SE :- u156, action(cruise), \+ curr_lane, free_E, free_NE, \+ free_NW.

0.0095592::u157.
free_SE :- u157, action(keep), \+ curr_lane, free_E, free_NE, \+ free_NW.

0.5000000::u158.
free_SE :- u158, action(swerve_left), \+ curr_lane, free_E, free_NE, \+ free_NW.

0.5000000::u159.
free_SE :- u159, action(swerve_right), \+ curr_lane, free_E, free_NE, \+ free_NW.

0.5000250::u160.
free_SE :- u160, action(change_to_left), curr_lane, free_E, free_NE, \+ free_NW.

0.4641575::u161.
free_SE :- u161, action(change_to_right), curr_lane, free_E, free_NE, \+ free_NW.

0.8430099::u162.
free_SE :- u162, action(cruise), curr_lane, free_E, free_NE, \+ free_NW.

0.7151515::u163.
free_SE :- u163, action(keep), curr_lane, free_E, free_NE, \+ free_NW.

0.9990010::u164.
free_SE :- u164, action(swerve_left), curr_lane, free_E, free_NE, \+ free_NW.

0.8761062::u165.
free_SE :- u165, action(swerve_right), curr_lane, free_E, free_NE, \+ free_NW.

0.5158689::u166.
free_SE :- u166, action(change_to_left), \+ curr_lane, \+ free_E, \+ free_NE, free_NW.

0.4999500::u167.
free_SE :- u167, action(change_to_right), \+ curr_lane, \+ free_E, \+ free_NE, free_NW.

0.5876216::u168.
free_SE :- u168, action(cruise), \+ curr_lane, \+ free_E, \+ free_NE, free_NW.

0.7580645::u169.
free_SE :- u169, action(keep), \+ curr_lane, \+ free_E, \+ free_NE, free_NW.

0.6346154::u170.
free_SE :- u170, action(swerve_left), \+ curr_lane, \+ free_E, \+ free_NE, free_NW.

0.5000000::u171.
free_SE :- u171, action(swerve_right), \+ curr_lane, \+ free_E, \+ free_NE, free_NW.

0.6934911::u172.
free_SE :- u172, action(change_to_left), curr_lane, \+ free_E, \+ free_NE, free_NW.

0.4999750::u173.
free_SE :- u173, action(change_to_right), curr_lane, \+ free_E, \+ free_NE, free_NW.

0.5000499::u174.
free_SE :- u174, action(cruise), curr_lane, \+ free_E, \+ free_NE, free_NW.

0.9877301::u175.
free_SE :- u175, action(keep), curr_lane, \+ free_E, \+ free_NE, free_NW.

0.9990010::u176.
free_SE :- u176, action(swerve_left), curr_lane, \+ free_E, \+ free_NE, free_NW.

0.9990010::u177.
free_SE :- u177, action(swerve_right), curr_lane, \+ free_E, \+ free_NE, free_NW.

0.5587231::u178.
free_SE :- u178, action(change_to_left), \+ curr_lane, free_E, \+ free_NE, free_NW.

0.5015104::u179.
free_SE :- u179, action(change_to_right), \+ curr_lane, free_E, \+ free_NE, free_NW.

0.7851956::u180.
free_SE :- u180, action(cruise), \+ curr_lane, free_E, \+ free_NE, free_NW.

0.9510204::u181.
free_SE :- u181, action(keep), \+ curr_lane, free_E, \+ free_NE, free_NW.

0.6231884::u182.
free_SE :- u182, action(swerve_left), \+ curr_lane, free_E, \+ free_NE, free_NW.

0.5000000::u183.
free_SE :- u183, action(swerve_right), \+ curr_lane, free_E, \+ free_NE, free_NW.

0.7771582::u184.
free_SE :- u184, action(change_to_left), curr_lane, free_E, \+ free_NE, free_NW.

0.5008953::u185.
free_SE :- u185, action(change_to_right), curr_lane, free_E, \+ free_NE, free_NW.

0.5433046::u186.
free_SE :- u186, action(cruise), curr_lane, free_E, \+ free_NE, free_NW.

0.7653587::u187.
free_SE :- u187, action(keep), curr_lane, free_E, \+ free_NE, free_NW.

0.7672956::u188.
free_SE :- u188, action(swerve_left), curr_lane, free_E, \+ free_NE, free_NW.

0.9791667::u189.
free_SE :- u189, action(swerve_right), curr_lane, free_E, \+ free_NE, free_NW.

0.5035370::u190.
free_SE :- u190, action(change_to_left), \+ curr_lane, \+ free_E, free_NE, free_NW.

0.4838463::u191.
free_SE :- u191, action(change_to_right), \+ curr_lane, \+ free_E, free_NE, free_NW.

0.4056963::u192.
free_SE :- u192, action(cruise), \+ curr_lane, \+ free_E, free_NE, free_NW.

0.9024390::u193.
free_SE :- u193, action(keep), \+ curr_lane, \+ free_E, free_NE, free_NW.

0.0487805::u194.
free_SE :- u194, action(swerve_left), \+ curr_lane, \+ free_E, free_NE, free_NW.

0.5000000::u195.
free_SE :- u195, action(swerve_right), \+ curr_lane, \+ free_E, free_NE, free_NW.

0.6743930::u196.
free_SE :- u196, action(change_to_left), curr_lane, \+ free_E, free_NE, free_NW.

0.4989661::u197.
free_SE :- u197, action(change_to_right), curr_lane, \+ free_E, free_NE, free_NW.

0.9650595::u198.
free_SE :- u198, action(cruise), curr_lane, \+ free_E, free_NE, free_NW.

0.9990010::u199.
free_SE :- u199, action(keep), curr_lane, \+ free_E, free_NE, free_NW.

0.9990010::u200.
free_SE :- u200, action(swerve_left), curr_lane, \+ free_E, free_NE, free_NW.

0.5000000::u201.
free_SE :- u201, action(swerve_right), curr_lane, \+ free_E, free_NE, free_NW.

0.5133178::u202.
free_SE :- u202, action(change_to_left), \+ curr_lane, free_E, free_NE, free_NW.

0.1198926::u203.
free_SE :- u203, action(change_to_right), \+ curr_lane, free_E, free_NE, free_NW.

0.8265605::u204.
free_SE :- u204, action(cruise), \+ curr_lane, free_E, free_NE, free_NW.

0.9489051::u205.
free_SE :- u205, action(keep), \+ curr_lane, free_E, free_NE, free_NW.

0.8968481::u206.
free_SE :- u206, action(swerve_left), \+ curr_lane, free_E, free_NE, free_NW.

0.9990010::u207.
free_SE :- u207, action(swerve_right), \+ curr_lane, free_E, free_NE, free_NW.

0.7862032::u208.
free_SE :- u208, action(change_to_left), curr_lane, free_E, free_NE, free_NW.

0.4646223::u209.
free_SE :- u209, action(change_to_right), curr_lane, free_E, free_NE, free_NW.

0.8575335::u210.
free_SE :- u210, action(cruise), curr_lane, free_E, free_NE, free_NW.

0.9879518::u211.
free_SE :- u211, action(keep), curr_lane, free_E, free_NE, free_NW.

0.9879344::u212.
free_SE :- u212, action(swerve_left), curr_lane, free_E, free_NE, free_NW.

0.9557596::u213.
free_SE :- u213, action(swerve_right), curr_lane, free_E, free_NE, free_NW.

