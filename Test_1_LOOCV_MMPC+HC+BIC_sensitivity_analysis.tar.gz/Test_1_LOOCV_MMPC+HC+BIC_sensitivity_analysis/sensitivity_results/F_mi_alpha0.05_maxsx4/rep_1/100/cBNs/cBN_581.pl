%%% Exogenous variables

0.1678911::u_action(change_to_left); 0.1700189::u_action(change_to_right); 0.4052830::u_action(cruise); 0.2544671::u_action(keep); 0.0014779::u_action(swerve_left); 0.0008620::u_action(swerve_right)
action(V) :- u_action(V).

0.7157531::u1.
free_W :- u1.

0.3854686::u2.
latent_collision :- u2.

0.4626632::u3.
curr_lane :- u3, action(change_to_left), \+ free_E.

0.4870101::u4.
curr_lane :- u4, action(change_to_right), \+ free_E.

0.2797703::u5.
curr_lane :- u5, action(cruise), \+ free_E.

0.1239650::u6.
curr_lane :- u6, action(keep), \+ free_E.

0.3146853::u7.
curr_lane :- u7, action(swerve_left), \+ free_E.

0.9990010::u8.
curr_lane :- u8, action(swerve_right), \+ free_E.

0.5131448::u9.
curr_lane :- u9, action(change_to_left), free_E.

0.5280903::u10.
curr_lane :- u10, action(change_to_right), free_E.

0.7608172::u11.
curr_lane :- u11, action(cruise), free_E.

0.4674172::u12.
curr_lane :- u12, action(keep), free_E.

0.8434878::u13.
curr_lane :- u13, action(swerve_left), free_E.

0.9928358::u14.
curr_lane :- u14, action(swerve_right), free_E.

0.5090243::u15.
free_E :- u15, action(change_to_left), \+ free_W.

0.4393390::u16.
free_E :- u16, action(change_to_right), \+ free_W.

0.8066300::u17.
free_E :- u17, action(cruise), \+ free_W.

0.9512951::u18.
free_E :- u18, action(keep), \+ free_W.

0.9990010::u19.
free_E :- u19, action(swerve_left), \+ free_W.

0.9689441::u20.
free_E :- u20, action(swerve_right), \+ free_W.

0.5625364::u21.
free_E :- u21, action(change_to_left), free_W.

0.5743888::u22.
free_E :- u22, action(change_to_right), free_W.

0.7663891::u23.
free_E :- u23, action(cruise), free_W.

0.6856562::u24.
free_E :- u24, action(keep), free_W.

0.9496833::u25.
free_E :- u25, action(swerve_left), free_W.

0.9986851::u26.
free_E :- u26, action(swerve_right), free_W.

0.4971465::u27.
free_NE :- u27, action(change_to_left), \+ curr_lane, \+ free_E, \+ free_SE.

0.5178391::u28.
free_NE :- u28, action(change_to_right), \+ curr_lane, \+ free_E, \+ free_SE.

0.5892018::u29.
free_NE :- u29, action(cruise), \+ curr_lane, \+ free_E, \+ free_SE.

0.2602808::u30.
free_NE :- u30, action(keep), \+ curr_lane, \+ free_E, \+ free_SE.

0.6724138::u31.
free_NE :- u31, action(swerve_left), \+ curr_lane, \+ free_E, \+ free_SE.

0.5000000::u32.
free_NE :- u32, action(swerve_right), \+ curr_lane, \+ free_E, \+ free_SE.

0.5507080::u33.
free_NE :- u33, action(change_to_left), curr_lane, \+ free_E, \+ free_SE.

0.5355864::u34.
free_NE :- u34, action(change_to_right), curr_lane, \+ free_E, \+ free_SE.

0.0166096::u35.
free_NE :- u35, action(cruise), curr_lane, \+ free_E, \+ free_SE.

0.0009990::u36.
free_NE :- u36, action(keep), curr_lane, \+ free_E, \+ free_SE.

0.5000000::u37.
free_NE :- u37, action(swerve_left), curr_lane, \+ free_E, \+ free_SE.

0.5000000::u38.
free_NE :- u38, action(swerve_right), curr_lane, \+ free_E, \+ free_SE.

0.4880880::u39.
free_NE :- u39, action(change_to_left), \+ curr_lane, free_E, \+ free_SE.

0.6191449::u40.
free_NE :- u40, action(change_to_right), \+ curr_lane, free_E, \+ free_SE.

0.4342030::u41.
free_NE :- u41, action(cruise), \+ curr_lane, free_E, \+ free_SE.

0.0153735::u42.
free_NE :- u42, action(keep), \+ curr_lane, free_E, \+ free_SE.

0.5806452::u43.
free_NE :- u43, action(swerve_left), \+ curr_lane, free_E, \+ free_SE.

0.5000000::u44.
free_NE :- u44, action(swerve_right), \+ curr_lane, free_E, \+ free_SE.

0.4923007::u45.
free_NE :- u45, action(change_to_left), curr_lane, free_E, \+ free_SE.

0.5719488::u46.
free_NE :- u46, action(change_to_right), curr_lane, free_E, \+ free_SE.

0.7568264::u47.
free_NE :- u47, action(cruise), curr_lane, free_E, \+ free_SE.

0.0015703::u48.
free_NE :- u48, action(keep), curr_lane, free_E, \+ free_SE.

0.3906250::u49.
free_NE :- u49, action(swerve_left), curr_lane, free_E, \+ free_SE.

0.8631579::u50.
free_NE :- u50, action(swerve_right), curr_lane, free_E, \+ free_SE.

0.4892843::u51.
free_NE :- u51, action(change_to_left), \+ curr_lane, \+ free_E, free_SE.

0.5037896::u52.
free_NE :- u52, action(change_to_right), \+ curr_lane, \+ free_E, free_SE.

0.4720627::u53.
free_NE :- u53, action(cruise), \+ curr_lane, \+ free_E, free_SE.

0.2627540::u54.
free_NE :- u54, action(keep), \+ curr_lane, \+ free_E, free_SE.

0.0750000::u55.
free_NE :- u55, action(swerve_left), \+ curr_lane, \+ free_E, free_SE.

0.5000000::u56.
free_NE :- u56, action(swerve_right), \+ curr_lane, \+ free_E, free_SE.

0.4960251::u57.
free_NE :- u57, action(change_to_left), curr_lane, \+ free_E, free_SE.

0.5019043::u58.
free_NE :- u58, action(change_to_right), curr_lane, \+ free_E, free_SE.

0.3613660::u59.
free_NE :- u59, action(cruise), curr_lane, \+ free_E, free_SE.

0.0002783::u60.
free_NE :- u60, action(keep), curr_lane, \+ free_E, free_SE.

0.0444444::u61.
free_NE :- u61, action(swerve_left), curr_lane, \+ free_E, free_SE.

0.4285714::u62.
free_NE :- u62, action(swerve_right), curr_lane, \+ free_E, free_SE.

0.4611694::u63.
free_NE :- u63, action(change_to_left), \+ curr_lane, free_E, free_SE.

0.2305423::u64.
free_NE :- u64, action(change_to_right), \+ curr_lane, free_E, free_SE.

0.4412580::u65.
free_NE :- u65, action(cruise), \+ curr_lane, free_E, free_SE.

0.0063673::u66.
free_NE :- u66, action(keep), \+ curr_lane, free_E, free_SE.

0.8528610::u67.
free_NE :- u67, action(swerve_left), \+ curr_lane, free_E, free_SE.

0.9990010::u68.
free_NE :- u68, action(swerve_right), \+ curr_lane, free_E, free_SE.

0.4869984::u69.
free_NE :- u69, action(change_to_left), curr_lane, free_E, free_SE.

0.5315924::u70.
free_NE :- u70, action(change_to_right), curr_lane, free_E, free_SE.

0.9326271::u71.
free_NE :- u71, action(cruise), curr_lane, free_E, free_SE.

0.0053429::u72.
free_NE :- u72, action(keep), curr_lane, free_E, free_SE.

0.9190391::u73.
free_NE :- u73, action(swerve_left), curr_lane, free_E, free_SE.

0.8558673::u74.
free_NE :- u74, action(swerve_right), curr_lane, free_E, free_SE.

0.4285714::u75.
free_NW :- u75, action(change_to_left), \+ free_NE, \+ free_SE, \+ free_SW, \+ free_W.

0.4286367::u76.
free_NW :- u76, action(change_to_right), \+ free_NE, \+ free_SE, \+ free_SW, \+ free_W.

0.2002559::u77.
free_NW :- u77, action(cruise), \+ free_NE, \+ free_SE, \+ free_SW, \+ free_W.

0.3636364::u78.
free_NW :- u78, action(keep), \+ free_NE, \+ free_SE, \+ free_SW, \+ free_W.

0.5000000::u79.
free_NW :- u79, action(swerve_left), \+ free_NE, \+ free_SE, \+ free_SW, \+ free_W.

0.5000000::u80.
free_NW :- u80, action(swerve_right), \+ free_NE, \+ free_SE, \+ free_SW, \+ free_W.

0.5001500::u81.
free_NW :- u81, action(change_to_left), free_NE, \+ free_SE, \+ free_SW, \+ free_W.

0.5001666::u82.
free_NW :- u82, action(change_to_right), free_NE, \+ free_SE, \+ free_SW, \+ free_W.

0.2967299::u83.
free_NW :- u83, action(cruise), free_NE, \+ free_SE, \+ free_SW, \+ free_W.

0.0009990::u84.
free_NW :- u84, action(keep), free_NE, \+ free_SE, \+ free_SW, \+ free_W.

0.5000000::u85.
free_NW :- u85, action(swerve_left), free_NE, \+ free_SE, \+ free_SW, \+ free_W.

0.9990010::u86.
free_NW :- u86, action(swerve_right), free_NE, \+ free_SE, \+ free_SW, \+ free_W.

0.5022854::u87.
free_NW :- u87, action(change_to_left), \+ free_NE, free_SE, \+ free_SW, \+ free_W.

0.5000250::u88.
free_NW :- u88, action(change_to_right), \+ free_NE, free_SE, \+ free_SW, \+ free_W.

0.3306102::u89.
free_NW :- u89, action(cruise), \+ free_NE, free_SE, \+ free_SW, \+ free_W.

0.4067298::u90.
free_NW :- u90, action(keep), \+ free_NE, free_SE, \+ free_SW, \+ free_W.

0.6111111::u91.
free_NW :- u91, action(swerve_left), \+ free_NE, free_SE, \+ free_SW, \+ free_W.

0.3000000::u92.
free_NW :- u92, action(swerve_right), \+ free_NE, free_SE, \+ free_SW, \+ free_W.

0.5008735::u93.
free_NW :- u93, action(change_to_left), free_NE, free_SE, \+ free_SW, \+ free_W.

0.4978467::u94.
free_NW :- u94, action(change_to_right), free_NE, free_SE, \+ free_SW, \+ free_W.

0.5385608::u95.
free_NW :- u95, action(cruise), free_NE, free_SE, \+ free_SW, \+ free_W.

0.0009990::u96.
free_NW :- u96, action(keep), free_NE, free_SE, \+ free_SW, \+ free_W.

0.6666667::u97.
free_NW :- u97, action(swerve_left), free_NE, free_SE, \+ free_SW, \+ free_W.

0.3000000::u98.
free_NW :- u98, action(swerve_right), free_NE, free_SE, \+ free_SW, \+ free_W.

0.5000000::u99.
free_NW :- u99, action(change_to_left), \+ free_NE, \+ free_SE, free_SW, \+ free_W.

0.4996019::u100.
free_NW :- u100, action(change_to_right), \+ free_NE, \+ free_SE, free_SW, \+ free_W.

0.3359596::u101.
free_NW :- u101, action(cruise), \+ free_NE, \+ free_SE, free_SW, \+ free_W.

0.2543923::u102.
free_NW :- u102, action(keep), \+ free_NE, \+ free_SE, free_SW, \+ free_W.

0.5000000::u103.
free_NW :- u103, action(swerve_left), \+ free_NE, \+ free_SE, free_SW, \+ free_W.

0.0009990::u104.
free_NW :- u104, action(swerve_right), \+ free_NE, \+ free_SE, free_SW, \+ free_W.

0.5000500::u105.
free_NW :- u105, action(change_to_left), free_NE, \+ free_SE, free_SW, \+ free_W.

0.4994707::u106.
free_NW :- u106, action(change_to_right), free_NE, \+ free_SE, free_SW, \+ free_W.

0.1396810::u107.
free_NW :- u107, action(cruise), free_NE, \+ free_SE, free_SW, \+ free_W.

0.5000000::u108.
free_NW :- u108, action(keep), free_NE, \+ free_SE, free_SW, \+ free_W.

0.5000000::u109.
free_NW :- u109, action(swerve_left), free_NE, \+ free_SE, free_SW, \+ free_W.

0.0009990::u110.
free_NW :- u110, action(swerve_right), free_NE, \+ free_SE, free_SW, \+ free_W.

0.5033001::u111.
free_NW :- u111, action(change_to_left), \+ free_NE, free_SE, free_SW, \+ free_W.

0.4933379::u112.
free_NW :- u112, action(change_to_right), \+ free_NE, free_SE, free_SW, \+ free_W.

0.3445319::u113.
free_NW :- u113, action(cruise), \+ free_NE, free_SE, free_SW, \+ free_W.

0.1880865::u114.
free_NW :- u114, action(keep), \+ free_NE, free_SE, free_SW, \+ free_W.

0.0009990::u115.
free_NW :- u115, action(swerve_left), \+ free_NE, free_SE, free_SW, \+ free_W.

0.0416667::u116.
free_NW :- u116, action(swerve_right), \+ free_NE, free_SE, free_SW, \+ free_W.

0.5007240::u117.
free_NW :- u117, action(change_to_left), free_NE, free_SE, free_SW, \+ free_W.

0.4975269::u118.
free_NW :- u118, action(change_to_right), free_NE, free_SE, free_SW, \+ free_W.

0.4763162::u119.
free_NW :- u119, action(cruise), free_NE, free_SE, free_SW, \+ free_W.

0.0140845::u120.
free_NW :- u120, action(keep), free_NE, free_SE, free_SW, \+ free_W.

0.0009990::u121.
free_NW :- u121, action(swerve_left), free_NE, free_SE, free_SW, \+ free_W.

0.0416667::u122.
free_NW :- u122, action(swerve_right), free_NE, free_SE, free_SW, \+ free_W.

0.3337994::u123.
free_NW :- u123, action(change_to_left), \+ free_NE, \+ free_SE, \+ free_SW, free_W.

0.4999000::u124.
free_NW :- u124, action(change_to_right), \+ free_NE, \+ free_SE, \+ free_SW, free_W.

0.4608958::u125.
free_NW :- u125, action(cruise), \+ free_NE, \+ free_SE, \+ free_SW, free_W.

0.0019569::u126.
free_NW :- u126, action(keep), \+ free_NE, \+ free_SE, \+ free_SW, free_W.

0.9990010::u127.
free_NW :- u127, action(swerve_left), \+ free_NE, \+ free_SE, \+ free_SW, free_W.

0.9990010::u128.
free_NW :- u128, action(swerve_right), \+ free_NE, \+ free_SE, \+ free_SW, free_W.

0.3347083::u129.
free_NW :- u129, action(change_to_left), free_NE, \+ free_SE, \+ free_SW, free_W.

0.5011633::u130.
free_NW :- u130, action(change_to_right), free_NE, \+ free_SE, \+ free_SW, free_W.

0.4796839::u131.
free_NW :- u131, action(cruise), free_NE, \+ free_SE, \+ free_SW, free_W.

0.0444444::u132.
free_NW :- u132, action(keep), free_NE, \+ free_SE, \+ free_SW, free_W.

0.9990010::u133.
free_NW :- u133, action(swerve_left), free_NE, \+ free_SE, \+ free_SW, free_W.

0.9990010::u134.
free_NW :- u134, action(swerve_right), free_NE, \+ free_SE, \+ free_SW, free_W.

0.6001380::u135.
free_NW :- u135, action(change_to_left), \+ free_NE, free_SE, \+ free_SW, free_W.

0.4979834::u136.
free_NW :- u136, action(change_to_right), \+ free_NE, free_SE, \+ free_SW, free_W.

0.7050430::u137.
free_NW :- u137, action(cruise), \+ free_NE, free_SE, \+ free_SW, free_W.

0.4614474::u138.
free_NW :- u138, action(keep), \+ free_NE, free_SE, \+ free_SW, free_W.

0.8139535::u139.
free_NW :- u139, action(swerve_left), \+ free_NE, free_SE, \+ free_SW, free_W.

0.3333333::u140.
free_NW :- u140, action(swerve_right), \+ free_NE, free_SE, \+ free_SW, free_W.

0.5583745::u141.
free_NW :- u141, action(change_to_left), free_NE, free_SE, \+ free_SW, free_W.

0.4759640::u142.
free_NW :- u142, action(change_to_right), free_NE, free_SE, \+ free_SW, free_W.

0.3598029::u143.
free_NW :- u143, action(cruise), free_NE, free_SE, \+ free_SW, free_W.

0.6956522::u144.
free_NW :- u144, action(keep), free_NE, free_SE, \+ free_SW, free_W.

0.8181818::u145.
free_NW :- u145, action(swerve_left), free_NE, free_SE, \+ free_SW, free_W.

0.8529412::u146.
free_NW :- u146, action(swerve_right), free_NE, free_SE, \+ free_SW, free_W.

0.3887736::u147.
free_NW :- u147, action(change_to_left), \+ free_NE, \+ free_SE, free_SW, free_W.

0.4845043::u148.
free_NW :- u148, action(change_to_right), \+ free_NE, \+ free_SE, free_SW, free_W.

0.7028434::u149.
free_NW :- u149, action(cruise), \+ free_NE, \+ free_SE, free_SW, free_W.

0.0020334::u150.
free_NW :- u150, action(keep), \+ free_NE, \+ free_SE, free_SW, free_W.

0.9759036::u151.
free_NW :- u151, action(swerve_left), \+ free_NE, \+ free_SE, free_SW, free_W.

0.0009990::u152.
free_NW :- u152, action(swerve_right), \+ free_NE, \+ free_SE, free_SW, free_W.

0.3542702::u153.
free_NW :- u153, action(change_to_left), free_NE, \+ free_SE, free_SW, free_W.

0.7409315::u154.
free_NW :- u154, action(change_to_right), free_NE, \+ free_SE, free_SW, free_W.

0.5618181::u155.
free_NW :- u155, action(cruise), free_NE, \+ free_SE, free_SW, free_W.

0.0010594::u156.
free_NW :- u156, action(keep), free_NE, \+ free_SE, free_SW, free_W.

0.9990010::u157.
free_NW :- u157, action(swerve_left), free_NE, \+ free_SE, free_SW, free_W.

0.7500000::u158.
free_NW :- u158, action(swerve_right), free_NE, \+ free_SE, free_SW, free_W.

0.6143263::u159.
free_NW :- u159, action(change_to_left), \+ free_NE, free_SE, free_SW, free_W.

0.4902976::u160.
free_NW :- u160, action(change_to_right), \+ free_NE, free_SE, free_SW, free_W.

0.7908341::u161.
free_NW :- u161, action(cruise), \+ free_NE, free_SE, free_SW, free_W.

0.0105688::u162.
free_NW :- u162, action(keep), \+ free_NE, free_SE, free_SW, free_W.

0.7966805::u163.
free_NW :- u163, action(swerve_left), \+ free_NE, free_SE, free_SW, free_W.

0.7157895::u164.
free_NW :- u164, action(swerve_right), \+ free_NE, free_SE, free_SW, free_W.

0.6428138::u165.
free_NW :- u165, action(change_to_left), free_NE, free_SE, free_SW, free_W.

0.6044695::u166.
free_NW :- u166, action(change_to_right), free_NE, free_SE, free_SW, free_W.

0.6004659::u167.
free_NW :- u167, action(cruise), free_NE, free_SE, free_SW, free_W.

0.1008592::u168.
free_NW :- u168, action(keep), free_NE, free_SE, free_SW, free_W.

0.9944985::u169.
free_NW :- u169, action(swerve_left), free_NE, free_SE, free_SW, free_W.

0.9111111::u170.
free_NW :- u170, action(swerve_right), free_NE, free_SE, free_SW, free_W.

0.5058001::u171.
free_SE :- u171, action(change_to_left), \+ curr_lane, \+ free_E.

0.4922218::u172.
free_SE :- u172, action(change_to_right), \+ curr_lane, \+ free_E.

0.4893442::u173.
free_SE :- u173, action(cruise), \+ curr_lane, \+ free_E.

0.2610281::u174.
free_SE :- u174, action(keep), \+ curr_lane, \+ free_E.

0.4081633::u175.
free_SE :- u175, action(swerve_left), \+ curr_lane, \+ free_E.

0.5000000::u176.
free_SE :- u176, action(swerve_right), \+ curr_lane, \+ free_E.

0.6037142::u177.
free_SE :- u177, action(change_to_left), curr_lane, \+ free_E.

0.5158983::u178.
free_SE :- u178, action(change_to_right), curr_lane, \+ free_E.

0.6378802::u179.
free_SE :- u179, action(cruise), curr_lane, \+ free_E.

0.9932545::u180.
free_SE :- u180, action(keep), curr_lane, \+ free_E.

0.9990010::u181.
free_SE :- u181, action(swerve_left), curr_lane, \+ free_E.

0.9990010::u182.
free_SE :- u182, action(swerve_right), curr_lane, \+ free_E.

0.5209956::u183.
free_SE :- u183, action(change_to_left), \+ curr_lane, free_E.

0.3301237::u184.
free_SE :- u184, action(change_to_right), \+ curr_lane, free_E.

0.7133630::u185.
free_SE :- u185, action(cruise), \+ curr_lane, free_E.

0.3431054::u186.
free_SE :- u186, action(keep), \+ curr_lane, free_E.

0.8554779::u187.
free_SE :- u187, action(swerve_left), \+ curr_lane, free_E.

0.9990010::u188.
free_SE :- u188, action(swerve_right), \+ curr_lane, free_E.

0.6588723::u189.
free_SE :- u189, action(change_to_left), curr_lane, free_E.

0.4826530::u190.
free_SE :- u190, action(change_to_right), curr_lane, free_E.

0.8207467::u191.
free_SE :- u191, action(cruise), curr_lane, free_E.

0.7901955::u192.
free_SE :- u192, action(keep), curr_lane, free_E.

0.9723183::u193.
free_SE :- u193, action(swerve_left), curr_lane, free_E.

0.9428743::u194.
free_SE :- u194, action(swerve_right), curr_lane, free_E.

0.7701131::u195.
free_SW :- u195, \+ curr_lane.

0.6043382::u196.
free_SW :- u196, curr_lane.

