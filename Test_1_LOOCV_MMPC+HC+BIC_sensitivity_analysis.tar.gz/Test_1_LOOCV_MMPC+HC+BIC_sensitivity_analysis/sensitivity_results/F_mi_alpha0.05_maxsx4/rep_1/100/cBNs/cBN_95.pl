%%% Exogenous variables

0.1678895::u_action(change_to_left); 0.1700198::u_action(change_to_right); 0.4052846::u_action(cruise); 0.2544662::u_action(keep); 0.0014779::u_action(swerve_left); 0.0008620::u_action(swerve_right)
action(V) :- u_action(V).

0.7157495::u1.
free_W :- u1.

0.3854698::u2.
latent_collision :- u2.

0.4973933::u3.
curr_lane :- u3, action(change_to_left).

0.5158377::u4.
curr_lane :- u4, action(change_to_right).

0.6569844::u5.
curr_lane :- u5, action(cruise).

0.3665017::u6.
curr_lane :- u6, action(keep).

0.8172677::u7.
curr_lane :- u7, action(swerve_left).

0.9928656::u8.
curr_lane :- u8, action(swerve_right).

0.4667644::u9.
free_E :- u9, action(change_to_left), \+ curr_lane, \+ free_NE, \+ free_W.

0.4670788::u10.
free_E :- u10, action(change_to_right), \+ curr_lane, \+ free_NE, \+ free_W.

0.4287346::u11.
free_E :- u11, action(cruise), \+ curr_lane, \+ free_NE, \+ free_W.

0.5000000::u12.
free_E :- u12, action(keep), \+ curr_lane, \+ free_NE, \+ free_W.

0.5000000::u13.
free_E :- u13, action(swerve_left), \+ curr_lane, \+ free_NE, \+ free_W.

0.5000000::u14.
free_E :- u14, action(swerve_right), \+ curr_lane, \+ free_NE, \+ free_W.

0.5034017::u15.
free_E :- u15, action(change_to_left), curr_lane, \+ free_NE, \+ free_W.

0.5055200::u16.
free_E :- u16, action(change_to_right), curr_lane, \+ free_NE, \+ free_W.

0.5340210::u17.
free_E :- u17, action(cruise), curr_lane, \+ free_NE, \+ free_W.

0.9514621::u18.
free_E :- u18, action(keep), curr_lane, \+ free_NE, \+ free_W.

0.9990010::u19.
free_E :- u19, action(swerve_left), curr_lane, \+ free_NE, \+ free_W.

0.9459459::u20.
free_E :- u20, action(swerve_right), curr_lane, \+ free_NE, \+ free_W.

0.5000125::u21.
free_E :- u21, action(change_to_left), \+ curr_lane, free_NE, \+ free_W.

0.0109727::u22.
free_E :- u22, action(change_to_right), \+ curr_lane, free_NE, \+ free_W.

0.5006740::u23.
free_E :- u23, action(cruise), \+ curr_lane, free_NE, \+ free_W.

0.1538462::u24.
free_E :- u24, action(keep), \+ curr_lane, free_NE, \+ free_W.

0.5000000::u25.
free_E :- u25, action(swerve_left), \+ curr_lane, free_NE, \+ free_W.

0.5000000::u26.
free_E :- u26, action(swerve_right), \+ curr_lane, free_NE, \+ free_W.

0.5008610::u27.
free_E :- u27, action(change_to_left), curr_lane, free_NE, \+ free_W.

0.5001868::u28.
free_E :- u28, action(change_to_right), curr_lane, free_NE, \+ free_W.

0.9644152::u29.
free_E :- u29, action(cruise), curr_lane, free_NE, \+ free_W.

0.9990010::u30.
free_E :- u30, action(keep), curr_lane, free_NE, \+ free_W.

0.9990010::u31.
free_E :- u31, action(swerve_left), curr_lane, free_NE, \+ free_W.

0.9758065::u32.
free_E :- u32, action(swerve_right), curr_lane, free_NE, \+ free_W.

0.5397925::u33.
free_E :- u33, action(change_to_left), \+ curr_lane, \+ free_NE, free_W.

0.5138956::u34.
free_E :- u34, action(change_to_right), \+ curr_lane, \+ free_NE, free_W.

0.5951241::u35.
free_E :- u35, action(cruise), \+ curr_lane, \+ free_NE, free_W.

0.6613391::u36.
free_E :- u36, action(keep), \+ curr_lane, \+ free_NE, free_W.

0.5882353::u37.
free_E :- u37, action(swerve_left), \+ curr_lane, \+ free_NE, free_W.

0.5000000::u38.
free_E :- u38, action(swerve_right), \+ curr_lane, \+ free_NE, free_W.

0.6123730::u39.
free_E :- u39, action(change_to_left), curr_lane, \+ free_NE, free_W.

0.5018804::u40.
free_E :- u40, action(change_to_right), curr_lane, \+ free_NE, free_W.

0.5376371::u41.
free_E :- u41, action(cruise), curr_lane, \+ free_NE, free_W.

0.8865032::u42.
free_E :- u42, action(keep), curr_lane, \+ free_NE, free_W.

0.8146552::u43.
free_E :- u43, action(swerve_left), curr_lane, \+ free_NE, free_W.

0.9902913::u44.
free_E :- u44, action(swerve_right), curr_lane, \+ free_NE, free_W.

0.5045096::u45.
free_E :- u45, action(change_to_left), \+ curr_lane, free_NE, free_W.

0.6438771::u46.
free_E :- u46, action(change_to_right), \+ curr_lane, free_NE, free_W.

0.4874687::u47.
free_E :- u47, action(cruise), \+ curr_lane, free_NE, free_W.

0.0643278::u48.
free_E :- u48, action(keep), \+ curr_lane, free_NE, free_W.

0.8925831::u49.
free_E :- u49, action(swerve_left), \+ curr_lane, free_NE, free_W.

0.9990010::u50.
free_E :- u50, action(swerve_right), \+ curr_lane, free_NE, free_W.

0.5951915::u51.
free_E :- u51, action(change_to_left), curr_lane, free_NE, free_W.

0.5970609::u52.
free_E :- u52, action(change_to_right), curr_lane, free_NE, free_W.

0.9772628::u53.
free_E :- u53, action(cruise), curr_lane, free_NE, free_W.

0.9927536::u54.
free_E :- u54, action(keep), curr_lane, free_NE, free_W.

0.9990398::u55.
free_E :- u55, action(swerve_left), curr_lane, free_NE, free_W.

0.9990010::u56.
free_E :- u56, action(swerve_right), curr_lane, free_NE, free_W.

0.4907234::u57.
free_NE :- u57, action(change_to_left), \+ curr_lane.

0.5087561::u58.
free_NE :- u58, action(change_to_right), \+ curr_lane.

0.4865470::u59.
free_NE :- u59, action(cruise), \+ curr_lane.

0.1133078::u60.
free_NE :- u60, action(keep), \+ curr_lane.

0.7419355::u61.
free_NE :- u61, action(swerve_left), \+ curr_lane.

0.9990010::u62.
free_NE :- u62, action(swerve_right), \+ curr_lane.

0.4937497::u63.
free_NE :- u63, action(change_to_left), curr_lane.

0.5288068::u64.
free_NE :- u64, action(change_to_right), curr_lane.

0.8338241::u65.
free_NE :- u65, action(cruise), curr_lane.

0.0041266::u66.
free_NE :- u66, action(keep), curr_lane.

0.8879932::u67.
free_NE :- u67, action(swerve_left), curr_lane.

0.8544910::u68.
free_NE :- u68, action(swerve_right), curr_lane.

0.5344548::u69.
free_NW :- u69, action(change_to_left), \+ free_NE, \+ free_SW, \+ free_W.

0.5334329::u70.
free_NW :- u70, action(change_to_right), \+ free_NE, \+ free_SW, \+ free_W.

0.3615843::u71.
free_NW :- u71, action(cruise), \+ free_NE, \+ free_SW, \+ free_W.

0.4067548::u72.
free_NW :- u72, action(keep), \+ free_NE, \+ free_SW, \+ free_W.

0.6111111::u73.
free_NW :- u73, action(swerve_left), \+ free_NE, \+ free_SW, \+ free_W.

0.3000000::u74.
free_NW :- u74, action(swerve_right), \+ free_NE, \+ free_SW, \+ free_W.

0.5005120::u75.
free_NW :- u75, action(change_to_left), free_NE, \+ free_SW, \+ free_W.

0.4990033::u76.
free_NW :- u76, action(change_to_right), free_NE, \+ free_SW, \+ free_W.

0.5148078::u77.
free_NW :- u77, action(cruise), free_NE, \+ free_SW, \+ free_W.

0.0009990::u78.
free_NW :- u78, action(keep), free_NE, \+ free_SW, \+ free_W.

0.6666667::u79.
free_NW :- u79, action(swerve_left), free_NE, \+ free_SW, \+ free_W.

0.3225806::u80.
free_NW :- u80, action(swerve_right), free_NE, \+ free_SW, \+ free_W.

0.5016687::u81.
free_NW :- u81, action(change_to_left), \+ free_NE, free_SW, \+ free_W.

0.4964453::u82.
free_NW :- u82, action(change_to_right), \+ free_NE, free_SW, \+ free_W.

0.3404991::u83.
free_NW :- u83, action(cruise), \+ free_NE, free_SW, \+ free_W.

0.2101512::u84.
free_NW :- u84, action(keep), \+ free_NE, free_SW, \+ free_W.

0.0009990::u85.
free_NW :- u85, action(swerve_left), \+ free_NE, free_SW, \+ free_W.

0.0370370::u86.
free_NW :- u86, action(swerve_right), \+ free_NE, free_SW, \+ free_W.

0.5003872::u87.
free_NW :- u87, action(change_to_left), free_NE, free_SW, \+ free_W.

0.4984973::u88.
free_NW :- u88, action(change_to_right), free_NE, free_SW, \+ free_W.

0.4430235::u89.
free_NW :- u89, action(cruise), free_NE, free_SW, \+ free_W.

0.0140845::u90.
free_NW :- u90, action(keep), free_NE, free_SW, \+ free_W.

0.0009990::u91.
free_NW :- u91, action(swerve_left), free_NE, free_SW, \+ free_W.

0.0322581::u92.
free_NW :- u92, action(swerve_right), free_NE, free_SW, \+ free_W.

0.5028222::u93.
free_NW :- u93, action(change_to_left), \+ free_NE, \+ free_SW, free_W.

0.4989273::u94.
free_NW :- u94, action(change_to_right), \+ free_NE, \+ free_SW, free_W.

0.6203019::u95.
free_NW :- u95, action(cruise), \+ free_NE, \+ free_SW, free_W.

0.4291414::u96.
free_NW :- u96, action(keep), \+ free_NE, \+ free_SW, free_W.

0.8181818::u97.
free_NW :- u97, action(swerve_left), \+ free_NE, \+ free_SW, free_W.

0.5555556::u98.
free_NW :- u98, action(swerve_right), \+ free_NE, \+ free_SW, free_W.

0.4691869::u99.
free_NW :- u99, action(change_to_left), free_NE, \+ free_SW, free_W.

0.4882672::u100.
free_NW :- u100, action(change_to_right), free_NE, \+ free_SW, free_W.

0.3687933::u101.
free_NW :- u101, action(cruise), free_NE, \+ free_SW, free_W.

0.1769912::u102.
free_NW :- u102, action(keep), free_NE, \+ free_SW, free_W.

0.8750000::u103.
free_NW :- u103, action(swerve_left), free_NE, \+ free_SW, free_W.

0.8863636::u104.
free_NW :- u104, action(swerve_right), free_NE, \+ free_SW, free_W.

0.5341675::u105.
free_NW :- u105, action(change_to_left), \+ free_NE, free_SW, free_W.

0.4873929::u106.
free_NW :- u106, action(change_to_right), \+ free_NE, free_SW, free_W.

0.7576797::u107.
free_NW :- u107, action(cruise), \+ free_NE, free_SW, free_W.

0.0061747::u108.
free_NW :- u108, action(keep), \+ free_NE, free_SW, free_W.

0.8425926::u109.
free_NW :- u109, action(swerve_left), \+ free_NE, free_SW, free_W.

0.6903553::u110.
free_NW :- u110, action(swerve_right), \+ free_NE, free_SW, free_W.

0.5400285::u111.
free_NW :- u111, action(change_to_left), free_NE, free_SW, free_W.

0.7006195::u112.
free_NW :- u112, action(change_to_right), free_NE, free_SW, free_W.

0.5861578::u113.
free_NW :- u113, action(cruise), free_NE, free_SW, free_W.

0.0280056::u114.
free_NW :- u114, action(keep), free_NE, free_SW, free_W.

0.9947111::u115.
free_NW :- u115, action(swerve_left), free_NE, free_SW, free_W.

0.9032258::u116.
free_NW :- u116, action(swerve_right), free_NE, free_SW, free_W.

0.5031303::u117.
free_SE :- u117, action(change_to_left), \+ curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.4988813::u118.
free_SE :- u118, action(change_to_right), \+ curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.4938048::u119.
free_SE :- u119, action(cruise), \+ curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.2600557::u120.
free_SE :- u120, action(keep), \+ curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.9990010::u121.
free_SE :- u121, action(swerve_left), \+ curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.5000000::u122.
free_SE :- u122, action(swerve_right), \+ curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.5011970::u123.
free_SE :- u123, action(change_to_left), curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.5000000::u124.
free_SE :- u124, action(change_to_right), curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.5004246::u125.
free_SE :- u125, action(cruise), curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.9932980::u126.
free_SE :- u126, action(keep), curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.9990010::u127.
free_SE :- u127, action(swerve_left), curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.9990010::u128.
free_SE :- u128, action(swerve_right), curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.4323573::u129.
free_SE :- u129, action(change_to_left), \+ curr_lane, free_E, \+ free_NE, \+ free_NW.

0.4286866::u130.
free_SE :- u130, action(change_to_right), \+ curr_lane, free_E, \+ free_NE, \+ free_NW.

0.4550312::u131.
free_SE :- u131, action(cruise), \+ curr_lane, free_E, \+ free_NE, \+ free_NW.

0.3435431::u132.
free_SE :- u132, action(keep), \+ curr_lane, free_E, \+ free_NE, \+ free_NW.

0.9990010::u133.
free_SE :- u133, action(swerve_left), \+ curr_lane, free_E, \+ free_NE, \+ free_NW.

0.5000000::u134.
free_SE :- u134, action(swerve_right), \+ curr_lane, free_E, \+ free_NE, \+ free_NW.

0.5370562::u135.
free_SE :- u135, action(change_to_left), curr_lane, free_E, \+ free_NE, \+ free_NW.

0.5093585::u136.
free_SE :- u136, action(change_to_right), curr_lane, free_E, \+ free_NE, \+ free_NW.

0.5741175::u137.
free_SE :- u137, action(cruise), curr_lane, free_E, \+ free_NE, \+ free_NW.

0.7918042::u138.
free_SE :- u138, action(keep), curr_lane, free_E, \+ free_NE, \+ free_NW.

0.9677419::u139.
free_SE :- u139, action(swerve_left), curr_lane, free_E, \+ free_NE, \+ free_NW.

0.8947368::u140.
free_SE :- u140, action(swerve_right), curr_lane, free_E, \+ free_NE, \+ free_NW.

0.5000500::u141.
free_SE :- u141, action(change_to_left), \+ curr_lane, \+ free_E, free_NE, \+ free_NW.

0.4868427::u142.
free_SE :- u142, action(change_to_right), \+ curr_lane, \+ free_E, free_NE, \+ free_NW.

0.4924440::u143.
free_SE :- u143, action(cruise), \+ curr_lane, \+ free_E, free_NE, \+ free_NW.

0.2620692::u144.
free_SE :- u144, action(keep), \+ curr_lane, \+ free_E, free_NE, \+ free_NW.

0.9990010::u145.
free_SE :- u145, action(swerve_left), \+ curr_lane, \+ free_E, free_NE, \+ free_NW.

0.5000000::u146.
free_SE :- u146, action(swerve_right), \+ curr_lane, \+ free_E, free_NE, \+ free_NW.

0.5000000::u147.
free_SE :- u147, action(change_to_left), curr_lane, \+ free_E, free_NE, \+ free_NW.

0.5003742::u148.
free_SE :- u148, action(change_to_right), curr_lane, \+ free_E, free_NE, \+ free_NW.

0.9820470::u149.
free_SE :- u149, action(cruise), curr_lane, \+ free_E, free_NE, \+ free_NW.

0.9990010::u150.
free_SE :- u150, action(keep), curr_lane, \+ free_E, free_NE, \+ free_NW.

0.9990010::u151.
free_SE :- u151, action(swerve_left), curr_lane, \+ free_E, free_NE, \+ free_NW.

0.9990010::u152.
free_SE :- u152, action(swerve_right), curr_lane, \+ free_E, free_NE, \+ free_NW.

0.5001499::u153.
free_SE :- u153, action(change_to_left), \+ curr_lane, free_E, free_NE, \+ free_NW.

0.3295386::u154.
free_SE :- u154, action(change_to_right), \+ curr_lane, free_E, free_NE, \+ free_NW.

0.4969129::u155.
free_SE :- u155, action(cruise), \+ curr_lane, free_E, free_NE, \+ free_NW.

0.0095592::u156.
free_SE :- u156, action(keep), \+ curr_lane, free_E, free_NE, \+ free_NW.

0.5000000::u157.
free_SE :- u157, action(swerve_left), \+ curr_lane, free_E, free_NE, \+ free_NW.

0.5000000::u158.
free_SE :- u158, action(swerve_right), \+ curr_lane, free_E, free_NE, \+ free_NW.

0.5000250::u159.
free_SE :- u159, action(change_to_left), curr_lane, free_E, free_NE, \+ free_NW.

0.4641575::u160.
free_SE :- u160, action(change_to_right), curr_lane, free_E, free_NE, \+ free_NW.

0.8430119::u161.
free_SE :- u161, action(cruise), curr_lane, free_E, free_NE, \+ free_NW.

0.7151515::u162.
free_SE :- u162, action(keep), curr_lane, free_E, free_NE, \+ free_NW.

0.9990010::u163.
free_SE :- u163, action(swerve_left), curr_lane, free_E, free_NE, \+ free_NW.

0.8766520::u164.
free_SE :- u164, action(swerve_right), curr_lane, free_E, free_NE, \+ free_NW.

0.5158689::u165.
free_SE :- u165, action(change_to_left), \+ curr_lane, \+ free_E, \+ free_NE, free_NW.

0.4999500::u166.
free_SE :- u166, action(change_to_right), \+ curr_lane, \+ free_E, \+ free_NE, free_NW.

0.5876216::u167.
free_SE :- u167, action(cruise), \+ curr_lane, \+ free_E, \+ free_NE, free_NW.

0.7580645::u168.
free_SE :- u168, action(keep), \+ curr_lane, \+ free_E, \+ free_NE, free_NW.

0.6346154::u169.
free_SE :- u169, action(swerve_left), \+ curr_lane, \+ free_E, \+ free_NE, free_NW.

0.5000000::u170.
free_SE :- u170, action(swerve_right), \+ curr_lane, \+ free_E, \+ free_NE, free_NW.

0.6934911::u171.
free_SE :- u171, action(change_to_left), curr_lane, \+ free_E, \+ free_NE, free_NW.

0.4999750::u172.
free_SE :- u172, action(change_to_right), curr_lane, \+ free_E, \+ free_NE, free_NW.

0.5000499::u173.
free_SE :- u173, action(cruise), curr_lane, \+ free_E, \+ free_NE, free_NW.

0.9877301::u174.
free_SE :- u174, action(keep), curr_lane, \+ free_E, \+ free_NE, free_NW.

0.9990010::u175.
free_SE :- u175, action(swerve_left), curr_lane, \+ free_E, \+ free_NE, free_NW.

0.9990010::u176.
free_SE :- u176, action(swerve_right), curr_lane, \+ free_E, \+ free_NE, free_NW.

0.5587231::u177.
free_SE :- u177, action(change_to_left), \+ curr_lane, free_E, \+ free_NE, free_NW.

0.5015104::u178.
free_SE :- u178, action(change_to_right), \+ curr_lane, free_E, \+ free_NE, free_NW.

0.7851825::u179.
free_SE :- u179, action(cruise), \+ curr_lane, free_E, \+ free_NE, free_NW.

0.9510204::u180.
free_SE :- u180, action(keep), \+ curr_lane, free_E, \+ free_NE, free_NW.

0.6231884::u181.
free_SE :- u181, action(swerve_left), \+ curr_lane, free_E, \+ free_NE, free_NW.

0.5000000::u182.
free_SE :- u182, action(swerve_right), \+ curr_lane, free_E, \+ free_NE, free_NW.

0.7771675::u183.
free_SE :- u183, action(change_to_left), curr_lane, free_E, \+ free_NE, free_NW.

0.5009203::u184.
free_SE :- u184, action(change_to_right), curr_lane, free_E, \+ free_NE, free_NW.

0.5433046::u185.
free_SE :- u185, action(cruise), curr_lane, free_E, \+ free_NE, free_NW.

0.7653587::u186.
free_SE :- u186, action(keep), curr_lane, free_E, \+ free_NE, free_NW.

0.7672956::u187.
free_SE :- u187, action(swerve_left), curr_lane, free_E, \+ free_NE, free_NW.

0.9791667::u188.
free_SE :- u188, action(swerve_right), curr_lane, free_E, \+ free_NE, free_NW.

0.5035370::u189.
free_SE :- u189, action(change_to_left), \+ curr_lane, \+ free_E, free_NE, free_NW.

0.4838463::u190.
free_SE :- u190, action(change_to_right), \+ curr_lane, \+ free_E, free_NE, free_NW.

0.4056700::u191.
free_SE :- u191, action(cruise), \+ curr_lane, \+ free_E, free_NE, free_NW.

0.9024390::u192.
free_SE :- u192, action(keep), \+ curr_lane, \+ free_E, free_NE, free_NW.

0.0487805::u193.
free_SE :- u193, action(swerve_left), \+ curr_lane, \+ free_E, free_NE, free_NW.

0.5000000::u194.
free_SE :- u194, action(swerve_right), \+ curr_lane, \+ free_E, free_NE, free_NW.

0.6743731::u195.
free_SE :- u195, action(change_to_left), curr_lane, \+ free_E, free_NE, free_NW.

0.4989661::u196.
free_SE :- u196, action(change_to_right), curr_lane, \+ free_E, free_NE, free_NW.

0.9650595::u197.
free_SE :- u197, action(cruise), curr_lane, \+ free_E, free_NE, free_NW.

0.9990010::u198.
free_SE :- u198, action(keep), curr_lane, \+ free_E, free_NE, free_NW.

0.9990010::u199.
free_SE :- u199, action(swerve_left), curr_lane, \+ free_E, free_NE, free_NW.

0.5000000::u200.
free_SE :- u200, action(swerve_right), curr_lane, \+ free_E, free_NE, free_NW.

0.5133178::u201.
free_SE :- u201, action(change_to_left), \+ curr_lane, free_E, free_NE, free_NW.

0.1198926::u202.
free_SE :- u202, action(change_to_right), \+ curr_lane, free_E, free_NE, free_NW.

0.8265605::u203.
free_SE :- u203, action(cruise), \+ curr_lane, free_E, free_NE, free_NW.

0.9489051::u204.
free_SE :- u204, action(keep), \+ curr_lane, free_E, free_NE, free_NW.

0.8968481::u205.
free_SE :- u205, action(swerve_left), \+ curr_lane, free_E, free_NE, free_NW.

0.9990010::u206.
free_SE :- u206, action(swerve_right), \+ curr_lane, free_E, free_NE, free_NW.

0.7862032::u207.
free_SE :- u207, action(change_to_left), curr_lane, free_E, free_NE, free_NW.

0.4646223::u208.
free_SE :- u208, action(change_to_right), curr_lane, free_E, free_NE, free_NW.

0.8575350::u209.
free_SE :- u209, action(cruise), curr_lane, free_E, free_NE, free_NW.

0.9879518::u210.
free_SE :- u210, action(keep), curr_lane, free_E, free_NE, free_NW.

0.9879344::u211.
free_SE :- u211, action(swerve_left), curr_lane, free_E, free_NE, free_NW.

0.9557226::u212.
free_SE :- u212, action(swerve_right), curr_lane, free_E, free_NE, free_NW.

0.7764513::u213.
free_SW :- u213, \+ curr_lane.

0.5999725::u214.
free_SW :- u214, curr_lane.

