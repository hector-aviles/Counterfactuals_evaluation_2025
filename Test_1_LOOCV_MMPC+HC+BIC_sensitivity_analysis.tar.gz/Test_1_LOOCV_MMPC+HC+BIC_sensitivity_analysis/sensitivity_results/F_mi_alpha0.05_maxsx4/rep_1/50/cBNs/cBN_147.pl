%%% Exogenous variables

0.1680513::u_action(change_to_left); 0.1699444::u_action(change_to_right); 0.4051937::u_action(cruise); 0.2544779::u_action(keep); 0.0014503::u_action(swerve_left); 0.0008825::u_action(swerve_right)
action(V) :- u_action(V).

0.7157891::u1.
free_W :- u1.

0.3858237::u2.
latent_collision :- u2.

0.4888421::u3.
curr_lane :- u3, action(change_to_left).

0.5093660::u4.
curr_lane :- u4, action(change_to_right).

0.6530590::u5.
curr_lane :- u5, action(cruise).

0.3664787::u6.
curr_lane :- u6, action(keep).

0.8183746::u7.
curr_lane :- u7, action(swerve_left).

0.9941928::u8.
curr_lane :- u8, action(swerve_right).

0.5066786::u9.
free_E :- u9, action(change_to_left), \+ curr_lane, \+ free_NE, \+ free_W.

0.5011020::u10.
free_E :- u10, action(change_to_right), \+ curr_lane, \+ free_NE, \+ free_W.

0.5059542::u11.
free_E :- u11, action(cruise), \+ curr_lane, \+ free_NE, \+ free_W.

0.5000000::u12.
free_E :- u12, action(keep), \+ curr_lane, \+ free_NE, \+ free_W.

0.5000000::u13.
free_E :- u13, action(swerve_left), \+ curr_lane, \+ free_NE, \+ free_W.

0.5000000::u14.
free_E :- u14, action(swerve_right), \+ curr_lane, \+ free_NE, \+ free_W.

0.5365339::u15.
free_E :- u15, action(change_to_left), curr_lane, \+ free_NE, \+ free_W.

0.5364173::u16.
free_E :- u16, action(change_to_right), curr_lane, \+ free_NE, \+ free_W.

0.5649199::u17.
free_E :- u17, action(cruise), curr_lane, \+ free_NE, \+ free_W.

0.9510955::u18.
free_E :- u18, action(keep), curr_lane, \+ free_NE, \+ free_W.

0.9990010::u19.
free_E :- u19, action(swerve_left), curr_lane, \+ free_NE, \+ free_W.

0.9545455::u20.
free_E :- u20, action(swerve_right), curr_lane, \+ free_NE, \+ free_W.

0.4981659::u21.
free_E :- u21, action(change_to_left), \+ curr_lane, free_NE, \+ free_W.

0.0117473::u22.
free_E :- u22, action(change_to_right), \+ curr_lane, free_NE, \+ free_W.

0.5093876::u23.
free_E :- u23, action(cruise), \+ curr_lane, free_NE, \+ free_W.

0.2500000::u24.
free_E :- u24, action(keep), \+ curr_lane, free_NE, \+ free_W.

0.5000000::u25.
free_E :- u25, action(swerve_left), \+ curr_lane, free_NE, \+ free_W.

0.5000000::u26.
free_E :- u26, action(swerve_right), \+ curr_lane, free_NE, \+ free_W.

0.4998503::u27.
free_E :- u27, action(change_to_left), curr_lane, free_NE, \+ free_W.

0.5045090::u28.
free_E :- u28, action(change_to_right), curr_lane, free_NE, \+ free_W.

0.9650217::u29.
free_E :- u29, action(cruise), curr_lane, free_NE, \+ free_W.

0.9990010::u30.
free_E :- u30, action(keep), curr_lane, free_NE, \+ free_W.

0.9990010::u31.
free_E :- u31, action(swerve_left), curr_lane, free_NE, \+ free_W.

0.9672131::u32.
free_E :- u32, action(swerve_right), curr_lane, free_NE, \+ free_W.

0.5438041::u33.
free_E :- u33, action(change_to_left), \+ curr_lane, \+ free_NE, free_W.

0.5126923::u34.
free_E :- u34, action(change_to_right), \+ curr_lane, \+ free_NE, free_W.

0.5938661::u35.
free_E :- u35, action(cruise), \+ curr_lane, \+ free_NE, free_W.

0.6610767::u36.
free_E :- u36, action(keep), \+ curr_lane, \+ free_NE, free_W.

0.5921053::u37.
free_E :- u37, action(swerve_left), \+ curr_lane, \+ free_NE, free_W.

0.5000000::u38.
free_E :- u38, action(swerve_right), \+ curr_lane, \+ free_NE, free_W.

0.6170949::u39.
free_E :- u39, action(change_to_left), curr_lane, \+ free_NE, free_W.

0.5012982::u40.
free_E :- u40, action(change_to_right), curr_lane, \+ free_NE, free_W.

0.5379128::u41.
free_E :- u41, action(cruise), curr_lane, \+ free_NE, free_W.

0.8870120::u42.
free_E :- u42, action(keep), curr_lane, \+ free_NE, free_W.

0.8141593::u43.
free_E :- u43, action(swerve_left), curr_lane, \+ free_NE, free_W.

0.9990010::u44.
free_E :- u44, action(swerve_right), curr_lane, \+ free_NE, free_W.

0.5019275::u45.
free_E :- u45, action(change_to_left), \+ curr_lane, free_NE, free_W.

0.6442458::u46.
free_E :- u46, action(change_to_right), \+ curr_lane, free_NE, free_W.

0.4861269::u47.
free_E :- u47, action(cruise), \+ curr_lane, free_NE, free_W.

0.0639892::u48.
free_E :- u48, action(keep), \+ curr_lane, free_NE, free_W.

0.8839779::u49.
free_E :- u49, action(swerve_left), \+ curr_lane, free_NE, free_W.

0.9990010::u50.
free_E :- u50, action(swerve_right), \+ curr_lane, free_NE, free_W.

0.5955157::u51.
free_E :- u51, action(change_to_left), curr_lane, free_NE, free_W.

0.5965716::u52.
free_E :- u52, action(change_to_right), curr_lane, free_NE, free_W.

0.9772398::u53.
free_E :- u53, action(cruise), curr_lane, free_NE, free_W.

0.9905363::u54.
free_E :- u54, action(keep), curr_lane, free_NE, free_W.

0.9980431::u55.
free_E :- u55, action(swerve_left), curr_lane, free_NE, free_W.

0.9990010::u56.
free_E :- u56, action(swerve_right), curr_lane, free_NE, free_W.

0.4819596::u57.
free_NE :- u57, action(change_to_left), \+ curr_lane.

0.5013460::u58.
free_NE :- u58, action(change_to_right), \+ curr_lane.

0.4835593::u59.
free_NE :- u59, action(cruise), \+ curr_lane.

0.1129138::u60.
free_NE :- u60, action(keep), \+ curr_lane.

0.7042802::u61.
free_NE :- u61, action(swerve_left), \+ curr_lane.

0.9990010::u62.
free_NE :- u62, action(swerve_right), \+ curr_lane.

0.5003431::u63.
free_NE :- u63, action(change_to_left), curr_lane.

0.5360944::u64.
free_NE :- u64, action(change_to_right), curr_lane.

0.8382530::u65.
free_NE :- u65, action(cruise), curr_lane.

0.0037475::u66.
free_NE :- u66, action(keep), curr_lane.

0.8868739::u67.
free_NE :- u67, action(swerve_left), curr_lane.

0.8504673::u68.
free_NE :- u68, action(swerve_right), curr_lane.

0.5326835::u69.
free_NW :- u69, action(change_to_left), \+ free_NE, \+ free_SW, \+ free_W.

0.5346238::u70.
free_NW :- u70, action(change_to_right), \+ free_NE, \+ free_SW, \+ free_W.

0.3600849::u71.
free_NW :- u71, action(cruise), \+ free_NE, \+ free_SW, \+ free_W.

0.4130993::u72.
free_NW :- u72, action(keep), \+ free_NE, \+ free_SW, \+ free_W.

0.6666667::u73.
free_NW :- u73, action(swerve_left), \+ free_NE, \+ free_SW, \+ free_W.

0.2500000::u74.
free_NW :- u74, action(swerve_right), \+ free_NE, \+ free_SW, \+ free_W.

0.5043356::u75.
free_NW :- u75, action(change_to_left), free_NE, \+ free_SW, \+ free_W.

0.5028082::u76.
free_NW :- u76, action(change_to_right), free_NE, \+ free_SW, \+ free_W.

0.5152316::u77.
free_NW :- u77, action(cruise), free_NE, \+ free_SW, \+ free_W.

0.0009990::u78.
free_NW :- u78, action(keep), free_NE, \+ free_SW, \+ free_W.

0.7500000::u79.
free_NW :- u79, action(swerve_left), free_NE, \+ free_SW, \+ free_W.

0.2812500::u80.
free_NW :- u80, action(swerve_right), free_NE, \+ free_SW, \+ free_W.

0.5011171::u81.
free_NW :- u81, action(change_to_left), \+ free_NE, free_SW, \+ free_W.

0.4966693::u82.
free_NW :- u82, action(change_to_right), \+ free_NE, free_SW, \+ free_W.

0.3381564::u83.
free_NW :- u83, action(cruise), \+ free_NE, free_SW, \+ free_W.

0.2070840::u84.
free_NW :- u84, action(keep), \+ free_NE, free_SW, \+ free_W.

0.0009990::u85.
free_NW :- u85, action(swerve_left), \+ free_NE, free_SW, \+ free_W.

0.0009990::u86.
free_NW :- u86, action(swerve_right), \+ free_NE, free_SW, \+ free_W.

0.4949460::u87.
free_NW :- u87, action(change_to_left), free_NE, free_SW, \+ free_W.

0.4994053::u88.
free_NW :- u88, action(change_to_right), free_NE, free_SW, \+ free_W.

0.4458125::u89.
free_NW :- u89, action(cruise), free_NE, free_SW, \+ free_W.

0.0009990::u90.
free_NW :- u90, action(keep), free_NE, free_SW, \+ free_W.

0.0009990::u91.
free_NW :- u91, action(swerve_left), free_NE, free_SW, \+ free_W.

0.0009990::u92.
free_NW :- u92, action(swerve_right), free_NE, free_SW, \+ free_W.

0.5017595::u93.
free_NW :- u93, action(change_to_left), \+ free_NE, \+ free_SW, free_W.

0.5036825::u94.
free_NW :- u94, action(change_to_right), \+ free_NE, \+ free_SW, free_W.

0.6179645::u95.
free_NW :- u95, action(cruise), \+ free_NE, \+ free_SW, free_W.

0.4281791::u96.
free_NW :- u96, action(keep), \+ free_NE, \+ free_SW, free_W.

0.8888889::u97.
free_NW :- u97, action(swerve_left), \+ free_NE, \+ free_SW, free_W.

0.3333333::u98.
free_NW :- u98, action(swerve_right), \+ free_NE, \+ free_SW, free_W.

0.4661035::u99.
free_NW :- u99, action(change_to_left), free_NE, \+ free_SW, free_W.

0.4907169::u100.
free_NW :- u100, action(change_to_right), free_NE, \+ free_SW, free_W.

0.3691090::u101.
free_NW :- u101, action(cruise), free_NE, \+ free_SW, free_W.

0.2000000::u102.
free_NW :- u102, action(keep), free_NE, \+ free_SW, free_W.

0.8181818::u103.
free_NW :- u103, action(swerve_left), free_NE, \+ free_SW, free_W.

0.8461538::u104.
free_NW :- u104, action(swerve_right), free_NE, \+ free_SW, free_W.

0.5346159::u105.
free_NW :- u105, action(change_to_left), \+ free_NE, free_SW, free_W.

0.4796827::u106.
free_NW :- u106, action(change_to_right), \+ free_NE, free_SW, free_W.

0.7587861::u107.
free_NW :- u107, action(cruise), \+ free_NE, free_SW, free_W.

0.0063190::u108.
free_NW :- u108, action(keep), \+ free_NE, free_SW, free_W.

0.8128655::u109.
free_NW :- u109, action(swerve_left), \+ free_NE, free_SW, free_W.

0.6310680::u110.
free_NW :- u110, action(swerve_right), \+ free_NE, free_SW, free_W.

0.5401315::u111.
free_NW :- u111, action(change_to_left), free_NE, free_SW, free_W.

0.6986061::u112.
free_NW :- u112, action(change_to_right), free_NE, free_SW, free_W.

0.5851227::u113.
free_NW :- u113, action(cruise), free_NE, free_SW, free_W.

0.0268665::u114.
free_NW :- u114, action(keep), free_NE, free_SW, free_W.

0.9924497::u115.
free_NW :- u115, action(swerve_left), free_NE, free_SW, free_W.

0.9040248::u116.
free_NW :- u116, action(swerve_right), free_NE, free_SW, free_W.

0.5049298::u117.
free_SE :- u117, action(change_to_left), \+ curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.5022963::u118.
free_SE :- u118, action(change_to_right), \+ curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.4947828::u119.
free_SE :- u119, action(cruise), \+ curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.2577136::u120.
free_SE :- u120, action(keep), \+ curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.9990010::u121.
free_SE :- u121, action(swerve_left), \+ curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.5000000::u122.
free_SE :- u122, action(swerve_right), \+ curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.5793451::u123.
free_SE :- u123, action(change_to_left), curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.5723864::u124.
free_SE :- u124, action(change_to_right), curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.5718539::u125.
free_SE :- u125, action(cruise), curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.9934500::u126.
free_SE :- u126, action(keep), curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.5000000::u127.
free_SE :- u127, action(swerve_left), curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.9990010::u128.
free_SE :- u128, action(swerve_right), curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.5010820::u129.
free_SE :- u129, action(change_to_left), \+ curr_lane, free_E, \+ free_NE, \+ free_NW.

0.4962435::u130.
free_SE :- u130, action(change_to_right), \+ curr_lane, free_E, \+ free_NE, \+ free_NW.

0.5148575::u131.
free_SE :- u131, action(cruise), \+ curr_lane, free_E, \+ free_NE, \+ free_NW.

0.3426897::u132.
free_SE :- u132, action(keep), \+ curr_lane, free_E, \+ free_NE, \+ free_NW.

0.9990010::u133.
free_SE :- u133, action(swerve_left), \+ curr_lane, free_E, \+ free_NE, \+ free_NW.

0.5000000::u134.
free_SE :- u134, action(swerve_right), \+ curr_lane, free_E, \+ free_NE, \+ free_NW.

0.5397486::u135.
free_SE :- u135, action(change_to_left), curr_lane, free_E, \+ free_NE, \+ free_NW.

0.5109602::u136.
free_SE :- u136, action(change_to_right), curr_lane, free_E, \+ free_NE, \+ free_NW.

0.5726510::u137.
free_SE :- u137, action(cruise), curr_lane, free_E, \+ free_NE, \+ free_NW.

0.7913759::u138.
free_SE :- u138, action(keep), curr_lane, free_E, \+ free_NE, \+ free_NW.

0.9722222::u139.
free_SE :- u139, action(swerve_left), curr_lane, free_E, \+ free_NE, \+ free_NW.

0.9152542::u140.
free_SE :- u140, action(swerve_right), curr_lane, free_E, \+ free_NE, \+ free_NW.

0.4989591::u141.
free_SE :- u141, action(change_to_left), \+ curr_lane, \+ free_E, free_NE, \+ free_NW.

0.4929845::u142.
free_SE :- u142, action(change_to_right), \+ curr_lane, \+ free_E, free_NE, \+ free_NW.

0.4951046::u143.
free_SE :- u143, action(cruise), \+ curr_lane, \+ free_E, free_NE, \+ free_NW.

0.2579946::u144.
free_SE :- u144, action(keep), \+ curr_lane, \+ free_E, free_NE, \+ free_NW.

0.9990010::u145.
free_SE :- u145, action(swerve_left), \+ curr_lane, \+ free_E, free_NE, \+ free_NW.

0.5000000::u146.
free_SE :- u146, action(swerve_right), \+ curr_lane, \+ free_E, free_NE, \+ free_NW.

0.5074955::u147.
free_SE :- u147, action(change_to_left), curr_lane, \+ free_E, free_NE, \+ free_NW.

0.5026236::u148.
free_SE :- u148, action(change_to_right), curr_lane, \+ free_E, free_NE, \+ free_NW.

0.9824669::u149.
free_SE :- u149, action(cruise), curr_lane, \+ free_E, free_NE, \+ free_NW.

0.9990010::u150.
free_SE :- u150, action(keep), curr_lane, \+ free_E, free_NE, \+ free_NW.

0.9990010::u151.
free_SE :- u151, action(swerve_left), curr_lane, \+ free_E, free_NE, \+ free_NW.

0.9990010::u152.
free_SE :- u152, action(swerve_right), curr_lane, \+ free_E, free_NE, \+ free_NW.

0.4985913::u153.
free_SE :- u153, action(change_to_left), \+ curr_lane, free_E, free_NE, \+ free_NW.

0.3224649::u154.
free_SE :- u154, action(change_to_right), \+ curr_lane, free_E, free_NE, \+ free_NW.

0.4966388::u155.
free_SE :- u155, action(cruise), \+ curr_lane, free_E, free_NE, \+ free_NW.

0.0096983::u156.
free_SE :- u156, action(keep), \+ curr_lane, free_E, free_NE, \+ free_NW.

0.5000000::u157.
free_SE :- u157, action(swerve_left), \+ curr_lane, free_E, free_NE, \+ free_NW.

0.5000000::u158.
free_SE :- u158, action(swerve_right), \+ curr_lane, free_E, free_NE, \+ free_NW.

0.4986997::u159.
free_SE :- u159, action(change_to_left), curr_lane, free_E, free_NE, \+ free_NW.

0.4679816::u160.
free_SE :- u160, action(change_to_right), curr_lane, free_E, free_NE, \+ free_NW.

0.8425232::u161.
free_SE :- u161, action(cruise), curr_lane, free_E, free_NE, \+ free_NW.

0.7671233::u162.
free_SE :- u162, action(keep), curr_lane, free_E, free_NE, \+ free_NW.

0.9990010::u163.
free_SE :- u163, action(swerve_left), curr_lane, free_E, free_NE, \+ free_NW.

0.8879310::u164.
free_SE :- u164, action(swerve_right), curr_lane, free_E, free_NE, \+ free_NW.

0.5159357::u165.
free_SE :- u165, action(change_to_left), \+ curr_lane, \+ free_E, \+ free_NE, free_NW.

0.5003005::u166.
free_SE :- u166, action(change_to_right), \+ curr_lane, \+ free_E, \+ free_NE, free_NW.

0.5900510::u167.
free_SE :- u167, action(cruise), \+ curr_lane, \+ free_E, \+ free_NE, free_NW.

0.8421053::u168.
free_SE :- u168, action(keep), \+ curr_lane, \+ free_E, \+ free_NE, free_NW.

0.6666667::u169.
free_SE :- u169, action(swerve_left), \+ curr_lane, \+ free_E, \+ free_NE, free_NW.

0.5000000::u170.
free_SE :- u170, action(swerve_right), \+ curr_lane, \+ free_E, \+ free_NE, free_NW.

0.6895915::u171.
free_SE :- u171, action(change_to_left), curr_lane, \+ free_E, \+ free_NE, free_NW.

0.4957783::u172.
free_SE :- u172, action(change_to_right), curr_lane, \+ free_E, \+ free_NE, free_NW.

0.4891706::u173.
free_SE :- u173, action(cruise), curr_lane, \+ free_E, \+ free_NE, free_NW.

0.9818182::u174.
free_SE :- u174, action(keep), curr_lane, \+ free_E, \+ free_NE, free_NW.

0.9990010::u175.
free_SE :- u175, action(swerve_left), curr_lane, \+ free_E, \+ free_NE, free_NW.

0.5000000::u176.
free_SE :- u176, action(swerve_right), curr_lane, \+ free_E, \+ free_NE, free_NW.

0.5598425::u177.
free_SE :- u177, action(change_to_left), \+ curr_lane, free_E, \+ free_NE, free_NW.

0.5046757::u178.
free_SE :- u178, action(change_to_right), \+ curr_lane, free_E, \+ free_NE, free_NW.

0.7836348::u179.
free_SE :- u179, action(cruise), \+ curr_lane, free_E, \+ free_NE, free_NW.

0.9455253::u180.
free_SE :- u180, action(keep), \+ curr_lane, free_E, \+ free_NE, free_NW.

0.5897436::u181.
free_SE :- u181, action(swerve_left), \+ curr_lane, free_E, \+ free_NE, free_NW.

0.5000000::u182.
free_SE :- u182, action(swerve_right), \+ curr_lane, free_E, \+ free_NE, free_NW.

0.7758809::u183.
free_SE :- u183, action(change_to_left), curr_lane, free_E, \+ free_NE, free_NW.

0.4988005::u184.
free_SE :- u184, action(change_to_right), curr_lane, free_E, \+ free_NE, free_NW.

0.5438312::u185.
free_SE :- u185, action(cruise), curr_lane, free_E, \+ free_NE, free_NW.

0.7690734::u186.
free_SE :- u186, action(keep), curr_lane, free_E, \+ free_NE, free_NW.

0.7162162::u187.
free_SE :- u187, action(swerve_left), curr_lane, free_E, \+ free_NE, free_NW.

0.9852941::u188.
free_SE :- u188, action(swerve_right), curr_lane, free_E, \+ free_NE, free_NW.

0.5046008::u189.
free_SE :- u189, action(change_to_left), \+ curr_lane, \+ free_E, free_NE, free_NW.

0.4766130::u190.
free_SE :- u190, action(change_to_right), \+ curr_lane, \+ free_E, free_NE, free_NW.

0.4091049::u191.
free_SE :- u191, action(cruise), \+ curr_lane, \+ free_E, free_NE, free_NW.

0.9444444::u192.
free_SE :- u192, action(keep), \+ curr_lane, \+ free_E, free_NE, free_NW.

0.0009990::u193.
free_SE :- u193, action(swerve_left), \+ curr_lane, \+ free_E, free_NE, free_NW.

0.5000000::u194.
free_SE :- u194, action(swerve_right), \+ curr_lane, \+ free_E, free_NE, free_NW.

0.6650271::u195.
free_SE :- u195, action(change_to_left), curr_lane, \+ free_E, free_NE, free_NW.

0.5000000::u196.
free_SE :- u196, action(change_to_right), curr_lane, \+ free_E, free_NE, free_NW.

0.9631683::u197.
free_SE :- u197, action(cruise), curr_lane, \+ free_E, free_NE, free_NW.

0.9990010::u198.
free_SE :- u198, action(keep), curr_lane, \+ free_E, free_NE, free_NW.

0.9990010::u199.
free_SE :- u199, action(swerve_left), curr_lane, \+ free_E, free_NE, free_NW.

0.5000000::u200.
free_SE :- u200, action(swerve_right), curr_lane, \+ free_E, free_NE, free_NW.

0.5247515::u201.
free_SE :- u201, action(change_to_left), \+ curr_lane, free_E, free_NE, free_NW.

0.1180564::u202.
free_SE :- u202, action(change_to_right), \+ curr_lane, free_E, free_NE, free_NW.

0.8253458::u203.
free_SE :- u203, action(cruise), \+ curr_lane, free_E, free_NE, free_NW.

0.9238095::u204.
free_SE :- u204, action(keep), \+ curr_lane, free_E, free_NE, free_NW.

0.9062500::u205.
free_SE :- u205, action(swerve_left), \+ curr_lane, free_E, free_NE, free_NW.

0.9990010::u206.
free_SE :- u206, action(swerve_right), \+ curr_lane, free_E, free_NE, free_NW.

0.7870989::u207.
free_SE :- u207, action(change_to_left), curr_lane, free_E, free_NE, free_NW.

0.4672628::u208.
free_SE :- u208, action(change_to_right), curr_lane, free_E, free_NE, free_NW.

0.8577569::u209.
free_SE :- u209, action(cruise), curr_lane, free_E, free_NE, free_NW.

0.9886792::u210.
free_SE :- u210, action(keep), curr_lane, free_E, free_NE, free_NW.

0.9871795::u211.
free_SE :- u211, action(swerve_left), curr_lane, free_E, free_NE, free_NW.

0.9540984::u212.
free_SE :- u212, action(swerve_right), curr_lane, free_E, free_NE, free_NW.

0.7700137::u213.
free_SW :- u213, \+ curr_lane.

0.6043350::u214.
free_SW :- u214, curr_lane.

