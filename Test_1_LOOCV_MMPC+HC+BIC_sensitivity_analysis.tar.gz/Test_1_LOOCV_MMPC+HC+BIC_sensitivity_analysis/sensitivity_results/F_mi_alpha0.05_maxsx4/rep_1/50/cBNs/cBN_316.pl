%%% Exogenous variables

0.1699522::u_action(change_to_left); 0.1719046::u_action(change_to_right); 0.4105430::u_action(cruise); 0.2452104::u_action(keep); 0.0015056::u_action(swerve_left); 0.0008842::u_action(swerve_right)
action(V) :- u_action(V).

0.6740960::u1.
free_SW :- u1.

0.7082635::u2.
free_W :- u2.

0.3892796::u3.
latent_collision :- u3.

0.4226990::u4.
curr_lane :- u4, action(change_to_left), \+ free_E, \+ free_NE, \+ free_SW.

0.5055483::u5.
curr_lane :- u5, action(change_to_right), \+ free_E, \+ free_NE, \+ free_SW.

0.5219923::u6.
curr_lane :- u6, action(cruise), \+ free_E, \+ free_NE, \+ free_SW.

0.0650759::u7.
curr_lane :- u7, action(keep), \+ free_E, \+ free_NE, \+ free_SW.

0.6666667::u8.
curr_lane :- u8, action(swerve_left), \+ free_E, \+ free_NE, \+ free_SW.

0.5000000::u9.
curr_lane :- u9, action(swerve_right), \+ free_E, \+ free_NE, \+ free_SW.

0.5276539::u10.
curr_lane :- u10, action(change_to_left), free_E, \+ free_NE, \+ free_SW.

0.4986511::u11.
curr_lane :- u11, action(change_to_right), free_E, \+ free_NE, \+ free_SW.

0.4585016::u12.
curr_lane :- u12, action(cruise), free_E, \+ free_NE, \+ free_SW.

0.9863089::u13.
curr_lane :- u13, action(keep), free_E, \+ free_NE, \+ free_SW.

0.9990010::u14.
curr_lane :- u14, action(swerve_left), free_E, \+ free_NE, \+ free_SW.

0.9990010::u15.
curr_lane :- u15, action(swerve_right), free_E, \+ free_NE, \+ free_SW.

0.4395817::u16.
curr_lane :- u16, action(change_to_left), \+ free_E, free_NE, \+ free_SW.

0.5014712::u17.
curr_lane :- u17, action(change_to_right), \+ free_E, free_NE, \+ free_SW.

0.1176108::u18.
curr_lane :- u18, action(cruise), \+ free_E, free_NE, \+ free_SW.

0.0009990::u19.
curr_lane :- u19, action(keep), \+ free_E, free_NE, \+ free_SW.

0.5000000::u20.
curr_lane :- u20, action(swerve_left), \+ free_E, free_NE, \+ free_SW.

0.5000000::u21.
curr_lane :- u21, action(swerve_right), \+ free_E, free_NE, \+ free_SW.

0.5253866::u22.
curr_lane :- u22, action(change_to_left), free_E, free_NE, \+ free_SW.

0.9568478::u23.
curr_lane :- u23, action(change_to_right), free_E, free_NE, \+ free_SW.

0.9524455::u24.
curr_lane :- u24, action(cruise), free_E, free_NE, \+ free_SW.

0.2142857::u25.
curr_lane :- u25, action(keep), free_E, free_NE, \+ free_SW.

0.6666667::u26.
curr_lane :- u26, action(swerve_left), free_E, free_NE, \+ free_SW.

0.9990010::u27.
curr_lane :- u27, action(swerve_right), free_E, free_NE, \+ free_SW.

0.5019856::u28.
curr_lane :- u28, action(change_to_left), \+ free_E, \+ free_NE, free_SW.

0.4961175::u29.
curr_lane :- u29, action(change_to_right), \+ free_E, \+ free_NE, free_SW.

0.3272715::u30.
curr_lane :- u30, action(cruise), \+ free_E, \+ free_NE, free_SW.

0.1625175::u31.
curr_lane :- u31, action(keep), \+ free_E, \+ free_NE, free_SW.

0.3469388::u32.
curr_lane :- u32, action(swerve_left), \+ free_E, \+ free_NE, free_SW.

0.9990010::u33.
curr_lane :- u33, action(swerve_right), \+ free_E, \+ free_NE, free_SW.

0.4764498::u34.
curr_lane :- u34, action(change_to_left), free_E, \+ free_NE, free_SW.

0.4930823::u35.
curr_lane :- u35, action(change_to_right), free_E, \+ free_NE, free_SW.

0.3033885::u36.
curr_lane :- u36, action(cruise), free_E, \+ free_NE, free_SW.

0.4521955::u37.
curr_lane :- u37, action(keep), free_E, \+ free_NE, free_SW.

0.7037037::u38.
curr_lane :- u38, action(swerve_left), free_E, \+ free_NE, free_SW.

0.9990010::u39.
curr_lane :- u39, action(swerve_right), free_E, \+ free_NE, free_SW.

0.5388243::u40.
curr_lane :- u40, action(change_to_left), \+ free_E, free_NE, free_SW.

0.5217660::u41.
curr_lane :- u41, action(change_to_right), \+ free_E, free_NE, free_SW.

0.1624843::u42.
curr_lane :- u42, action(cruise), \+ free_E, free_NE, free_SW.

0.0004569::u43.
curr_lane :- u43, action(keep), \+ free_E, free_NE, free_SW.

0.0740741::u44.
curr_lane :- u44, action(swerve_left), \+ free_E, free_NE, free_SW.

0.5000000::u45.
curr_lane :- u45, action(swerve_right), \+ free_E, free_NE, free_SW.

0.5206052::u46.
curr_lane :- u46, action(change_to_left), free_E, free_NE, free_SW.

0.4357668::u47.
curr_lane :- u47, action(change_to_right), free_E, free_NE, free_SW.

0.8001721::u48.
curr_lane :- u48, action(cruise), free_E, free_NE, free_SW.

0.2356600::u49.
curr_lane :- u49, action(keep), free_E, free_NE, free_SW.

0.8572587::u50.
curr_lane :- u50, action(swerve_left), free_E, free_NE, free_SW.

0.9910847::u51.
curr_lane :- u51, action(swerve_right), free_E, free_NE, free_SW.

0.5001747::u52.
free_E :- u52, action(change_to_left), \+ free_NE, \+ free_W.

0.5039251::u53.
free_E :- u53, action(change_to_right), \+ free_NE, \+ free_W.

0.5229471::u54.
free_E :- u54, action(cruise), \+ free_NE, \+ free_W.

0.9495262::u55.
free_E :- u55, action(keep), \+ free_NE, \+ free_W.

0.9990010::u56.
free_E :- u56, action(swerve_left), \+ free_NE, \+ free_W.

0.9473684::u57.
free_E :- u57, action(swerve_right), \+ free_NE, \+ free_W.

0.4977241::u58.
free_E :- u58, action(change_to_left), free_NE, \+ free_W.

0.3356378::u59.
free_E :- u59, action(change_to_right), free_NE, \+ free_W.

0.9063870::u60.
free_E :- u60, action(cruise), free_NE, \+ free_W.

0.8648649::u61.
free_E :- u61, action(keep), free_NE, \+ free_W.

0.9990010::u62.
free_E :- u62, action(swerve_left), free_NE, \+ free_W.

0.9990010::u63.
free_E :- u63, action(swerve_right), free_NE, \+ free_W.

0.5723208::u64.
free_E :- u64, action(change_to_left), \+ free_NE, free_W.

0.5077890::u65.
free_E :- u65, action(change_to_right), \+ free_NE, free_W.

0.5814468::u66.
free_E :- u66, action(cruise), \+ free_NE, free_W.

0.7356795::u67.
free_E :- u67, action(keep), \+ free_NE, free_W.

0.6904762::u68.
free_E :- u68, action(swerve_left), \+ free_NE, free_W.

0.9908257::u69.
free_E :- u69, action(swerve_right), \+ free_NE, free_W.

0.5673642::u70.
free_E :- u70, action(change_to_left), free_NE, free_W.

0.6403497::u71.
free_E :- u71, action(change_to_right), free_NE, free_W.

0.8503036::u72.
free_E :- u72, action(cruise), free_NE, free_W.

0.2443988::u73.
free_E :- u73, action(keep), free_NE, free_W.

0.9786223::u74.
free_E :- u74, action(swerve_left), free_NE, free_W.

0.9990010::u75.
free_E :- u75, action(swerve_right), free_NE, free_W.

0.4857822::u76.
free_NE :- u76, action(change_to_left).

0.5095260::u77.
free_NE :- u77, action(change_to_right).

0.7120314::u78.
free_NE :- u78, action(cruise).

0.0249330::u79.
free_NE :- u79, action(keep).

0.8737060::u80.
free_NE :- u80, action(swerve_left).

0.8495887::u81.
free_NE :- u81, action(swerve_right).

0.5016731::u82.
free_NW :- u82, action(change_to_left), \+ free_NE, \+ free_SW, \+ free_W.

0.4988055::u83.
free_NW :- u83, action(change_to_right), \+ free_NE, \+ free_SW, \+ free_W.

0.3326124::u84.
free_NW :- u84, action(cruise), \+ free_NE, \+ free_SW, \+ free_W.

0.4071579::u85.
free_NW :- u85, action(keep), \+ free_NE, \+ free_SW, \+ free_W.

0.7000000::u86.
free_NW :- u86, action(swerve_left), \+ free_NE, \+ free_SW, \+ free_W.

0.3333333::u87.
free_NW :- u87, action(swerve_right), \+ free_NE, \+ free_SW, \+ free_W.

0.4978057::u88.
free_NW :- u88, action(change_to_left), free_NE, \+ free_SW, \+ free_W.

0.4978954::u89.
free_NW :- u89, action(change_to_right), free_NE, \+ free_SW, \+ free_W.

0.5187284::u90.
free_NW :- u90, action(cruise), free_NE, \+ free_SW, \+ free_W.

0.0009990::u91.
free_NW :- u91, action(keep), free_NE, \+ free_SW, \+ free_W.

0.9990010::u92.
free_NW :- u92, action(swerve_left), free_NE, \+ free_SW, \+ free_W.

0.3461538::u93.
free_NW :- u93, action(swerve_right), free_NE, \+ free_SW, \+ free_W.

0.5039150::u94.
free_NW :- u94, action(change_to_left), \+ free_NE, free_SW, \+ free_W.

0.4962305::u95.
free_NW :- u95, action(change_to_right), \+ free_NE, free_SW, \+ free_W.

0.3370414::u96.
free_NW :- u96, action(cruise), \+ free_NE, free_SW, \+ free_W.

0.2111935::u97.
free_NW :- u97, action(keep), \+ free_NE, free_SW, \+ free_W.

0.0009990::u98.
free_NW :- u98, action(swerve_left), \+ free_NE, free_SW, \+ free_W.

0.0769231::u99.
free_NW :- u99, action(swerve_right), \+ free_NE, free_SW, \+ free_W.

0.5004014::u100.
free_NW :- u100, action(change_to_left), free_NE, free_SW, \+ free_W.

0.4979165::u101.
free_NW :- u101, action(change_to_right), free_NE, free_SW, \+ free_W.

0.4446471::u102.
free_NW :- u102, action(cruise), free_NE, free_SW, \+ free_W.

0.0277778::u103.
free_NW :- u103, action(keep), free_NE, free_SW, \+ free_W.

0.0009990::u104.
free_NW :- u104, action(swerve_left), free_NE, free_SW, \+ free_W.

0.0357143::u105.
free_NW :- u105, action(swerve_right), free_NE, free_SW, \+ free_W.

0.5014748::u106.
free_NW :- u106, action(change_to_left), \+ free_NE, \+ free_SW, free_W.

0.4999498::u107.
free_NW :- u107, action(change_to_right), \+ free_NE, \+ free_SW, free_W.

0.6213053::u108.
free_NW :- u108, action(cruise), \+ free_NE, \+ free_SW, free_W.

0.4287318::u109.
free_NW :- u109, action(keep), \+ free_NE, \+ free_SW, free_W.

0.8750000::u110.
free_NW :- u110, action(swerve_left), \+ free_NE, \+ free_SW, free_W.

0.8000000::u111.
free_NW :- u111, action(swerve_right), \+ free_NE, \+ free_SW, free_W.

0.4653044::u112.
free_NW :- u112, action(change_to_left), free_NE, \+ free_SW, free_W.

0.4880130::u113.
free_NW :- u113, action(change_to_right), free_NE, \+ free_SW, free_W.

0.3662722::u114.
free_NW :- u114, action(cruise), free_NE, \+ free_SW, free_W.

0.2203390::u115.
free_NW :- u115, action(keep), free_NE, \+ free_SW, free_W.

0.6000000::u116.
free_NW :- u116, action(swerve_left), free_NE, \+ free_SW, free_W.

0.8750000::u117.
free_NW :- u117, action(swerve_right), free_NE, \+ free_SW, free_W.

0.5346756::u118.
free_NW :- u118, action(change_to_left), \+ free_NE, free_SW, free_W.

0.4862841::u119.
free_NW :- u119, action(change_to_right), \+ free_NE, free_SW, free_W.

0.7589315::u120.
free_NW :- u120, action(cruise), \+ free_NE, free_SW, free_W.

0.0063294::u121.
free_NW :- u121, action(keep), \+ free_NE, free_SW, free_W.

0.8026316::u122.
free_NW :- u122, action(swerve_left), \+ free_NE, free_SW, free_W.

0.7211538::u123.
free_NW :- u123, action(swerve_right), \+ free_NE, free_SW, free_W.

0.5779300::u124.
free_NW :- u124, action(change_to_left), free_NE, free_SW, free_W.

0.7300121::u125.
free_NW :- u125, action(change_to_right), free_NE, free_SW, free_W.

0.5958822::u126.
free_NW :- u126, action(cruise), free_NE, free_SW, free_W.

0.0824119::u127.
free_NW :- u127, action(keep), free_NE, free_SW, free_W.

0.9936407::u128.
free_NW :- u128, action(swerve_left), free_NE, free_SW, free_W.

0.9007752::u129.
free_NW :- u129, action(swerve_right), free_NE, free_SW, free_W.

0.5063656::u130.
free_SE :- u130, action(change_to_left), \+ curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.5003481::u131.
free_SE :- u131, action(change_to_right), \+ curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.4965487::u132.
free_SE :- u132, action(cruise), \+ curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.2627925::u133.
free_SE :- u133, action(keep), \+ curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.9990010::u134.
free_SE :- u134, action(swerve_left), \+ curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.5000000::u135.
free_SE :- u135, action(swerve_right), \+ curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.5053807::u136.
free_SE :- u136, action(change_to_left), curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.5040367::u137.
free_SE :- u137, action(change_to_right), curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.4980808::u138.
free_SE :- u138, action(cruise), curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.9924579::u139.
free_SE :- u139, action(keep), curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.9990010::u140.
free_SE :- u140, action(swerve_left), curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.9990010::u141.
free_SE :- u141, action(swerve_right), curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.5047250::u142.
free_SE :- u142, action(change_to_left), \+ curr_lane, free_E, \+ free_NE, \+ free_NW.

0.4957854::u143.
free_SE :- u143, action(change_to_right), \+ curr_lane, free_E, \+ free_NE, \+ free_NW.

0.5167254::u144.
free_SE :- u144, action(cruise), \+ curr_lane, free_E, \+ free_NE, \+ free_NW.

0.3443453::u145.
free_SE :- u145, action(keep), \+ curr_lane, free_E, \+ free_NE, \+ free_NW.

0.9990010::u146.
free_SE :- u146, action(swerve_left), \+ curr_lane, free_E, \+ free_NE, \+ free_NW.

0.5000000::u147.
free_SE :- u147, action(swerve_right), \+ curr_lane, free_E, \+ free_NE, \+ free_NW.

0.5384964::u148.
free_SE :- u148, action(change_to_left), curr_lane, free_E, \+ free_NE, \+ free_NW.

0.5029234::u149.
free_SE :- u149, action(change_to_right), curr_lane, free_E, \+ free_NE, \+ free_NW.

0.5719325::u150.
free_SE :- u150, action(cruise), curr_lane, free_E, \+ free_NE, \+ free_NW.

0.7923537::u151.
free_SE :- u151, action(keep), curr_lane, free_E, \+ free_NE, \+ free_NW.

0.9375000::u152.
free_SE :- u152, action(swerve_left), curr_lane, free_E, \+ free_NE, \+ free_NW.

0.9090909::u153.
free_SE :- u153, action(swerve_right), curr_lane, free_E, \+ free_NE, \+ free_NW.

0.5705889::u154.
free_SE :- u154, action(change_to_left), \+ curr_lane, \+ free_E, free_NE, \+ free_NW.

0.5731404::u155.
free_SE :- u155, action(change_to_right), \+ curr_lane, \+ free_E, free_NE, \+ free_NW.

0.5892121::u156.
free_SE :- u156, action(cruise), \+ curr_lane, \+ free_E, free_NE, \+ free_NW.

0.9897774::u157.
free_SE :- u157, action(keep), \+ curr_lane, \+ free_E, free_NE, \+ free_NW.

0.9990010::u158.
free_SE :- u158, action(swerve_left), \+ curr_lane, \+ free_E, free_NE, \+ free_NW.

0.5000000::u159.
free_SE :- u159, action(swerve_right), \+ curr_lane, \+ free_E, free_NE, \+ free_NW.

0.5022022::u160.
free_SE :- u160, action(change_to_left), curr_lane, \+ free_E, free_NE, \+ free_NW.

0.5069307::u161.
free_SE :- u161, action(change_to_right), curr_lane, \+ free_E, free_NE, \+ free_NW.

0.9821148::u162.
free_SE :- u162, action(cruise), curr_lane, \+ free_E, free_NE, \+ free_NW.

0.9990010::u163.
free_SE :- u163, action(keep), curr_lane, \+ free_E, free_NE, \+ free_NW.

0.9990010::u164.
free_SE :- u164, action(swerve_left), curr_lane, \+ free_E, free_NE, \+ free_NW.

0.5000000::u165.
free_SE :- u165, action(swerve_right), curr_lane, \+ free_E, free_NE, \+ free_NW.

0.5020214::u166.
free_SE :- u166, action(change_to_left), \+ curr_lane, free_E, free_NE, \+ free_NW.

0.3282218::u167.
free_SE :- u167, action(change_to_right), \+ curr_lane, free_E, free_NE, \+ free_NW.

0.5012531::u168.
free_SE :- u168, action(cruise), \+ curr_lane, free_E, free_NE, \+ free_NW.

0.0087623::u169.
free_SE :- u169, action(keep), \+ curr_lane, free_E, free_NE, \+ free_NW.

0.5000000::u170.
free_SE :- u170, action(swerve_left), \+ curr_lane, free_E, free_NE, \+ free_NW.

0.5000000::u171.
free_SE :- u171, action(swerve_right), \+ curr_lane, free_E, free_NE, \+ free_NW.

0.5032175::u172.
free_SE :- u172, action(change_to_left), curr_lane, free_E, free_NE, \+ free_NW.

0.4637590::u173.
free_SE :- u173, action(change_to_right), curr_lane, free_E, free_NE, \+ free_NW.

0.8435513::u174.
free_SE :- u174, action(cruise), curr_lane, free_E, free_NE, \+ free_NW.

0.7402597::u175.
free_SE :- u175, action(keep), curr_lane, free_E, free_NE, \+ free_NW.

0.9990010::u176.
free_SE :- u176, action(swerve_left), curr_lane, free_E, free_NE, \+ free_NW.

0.8738739::u177.
free_SE :- u177, action(swerve_right), curr_lane, free_E, free_NE, \+ free_NW.

0.5192451::u178.
free_SE :- u178, action(change_to_left), \+ curr_lane, \+ free_E, \+ free_NE, free_NW.

0.4986948::u179.
free_SE :- u179, action(change_to_right), \+ curr_lane, \+ free_E, \+ free_NE, free_NW.

0.5885021::u180.
free_SE :- u180, action(cruise), \+ curr_lane, \+ free_E, \+ free_NE, free_NW.

0.7058824::u181.
free_SE :- u181, action(keep), \+ curr_lane, \+ free_E, \+ free_NE, free_NW.

0.5483871::u182.
free_SE :- u182, action(swerve_left), \+ curr_lane, \+ free_E, \+ free_NE, free_NW.

0.5000000::u183.
free_SE :- u183, action(swerve_right), \+ curr_lane, \+ free_E, \+ free_NE, free_NW.

0.6925622::u184.
free_SE :- u184, action(change_to_left), curr_lane, \+ free_E, \+ free_NE, free_NW.

0.5006967::u185.
free_SE :- u185, action(change_to_right), curr_lane, \+ free_E, \+ free_NE, free_NW.

0.4990971::u186.
free_SE :- u186, action(cruise), curr_lane, \+ free_E, \+ free_NE, free_NW.

0.9937500::u187.
free_SE :- u187, action(keep), curr_lane, \+ free_E, \+ free_NE, free_NW.

0.9990010::u188.
free_SE :- u188, action(swerve_left), curr_lane, \+ free_E, \+ free_NE, free_NW.

0.5000000::u189.
free_SE :- u189, action(swerve_right), curr_lane, \+ free_E, \+ free_NE, free_NW.

0.5589579::u190.
free_SE :- u190, action(change_to_left), \+ curr_lane, free_E, \+ free_NE, free_NW.

0.4959540::u191.
free_SE :- u191, action(change_to_right), \+ curr_lane, free_E, \+ free_NE, free_NW.

0.7825505::u192.
free_SE :- u192, action(cruise), \+ curr_lane, free_E, \+ free_NE, free_NW.

0.9411765::u193.
free_SE :- u193, action(keep), \+ curr_lane, free_E, \+ free_NE, free_NW.

0.5555556::u194.
free_SE :- u194, action(swerve_left), \+ curr_lane, free_E, \+ free_NE, free_NW.

0.5000000::u195.
free_SE :- u195, action(swerve_right), \+ curr_lane, free_E, \+ free_NE, free_NW.

0.7763980::u196.
free_SE :- u196, action(change_to_left), curr_lane, free_E, \+ free_NE, free_NW.

0.5076117::u197.
free_SE :- u197, action(change_to_right), curr_lane, free_E, \+ free_NE, free_NW.

0.5440229::u198.
free_SE :- u198, action(cruise), curr_lane, free_E, \+ free_NE, free_NW.

0.7588303::u199.
free_SE :- u199, action(keep), curr_lane, free_E, \+ free_NE, free_NW.

0.8358209::u200.
free_SE :- u200, action(swerve_left), curr_lane, free_E, \+ free_NE, free_NW.

0.9634146::u201.
free_SE :- u201, action(swerve_right), curr_lane, free_E, \+ free_NE, free_NW.

0.5065450::u202.
free_SE :- u202, action(change_to_left), \+ curr_lane, \+ free_E, free_NE, free_NW.

0.4853504::u203.
free_SE :- u203, action(change_to_right), \+ curr_lane, \+ free_E, free_NE, free_NW.

0.4052994::u204.
free_SE :- u204, action(cruise), \+ curr_lane, \+ free_E, free_NE, free_NW.

0.8947368::u205.
free_SE :- u205, action(keep), \+ curr_lane, \+ free_E, free_NE, free_NW.

0.0009990::u206.
free_SE :- u206, action(swerve_left), \+ curr_lane, \+ free_E, free_NE, free_NW.

0.5000000::u207.
free_SE :- u207, action(swerve_right), \+ curr_lane, \+ free_E, free_NE, free_NW.

0.6690132::u208.
free_SE :- u208, action(change_to_left), curr_lane, \+ free_E, free_NE, free_NW.

0.5005448::u209.
free_SE :- u209, action(change_to_right), curr_lane, \+ free_E, free_NE, free_NW.

0.9621980::u210.
free_SE :- u210, action(cruise), curr_lane, \+ free_E, free_NE, free_NW.

0.9990010::u211.
free_SE :- u211, action(keep), curr_lane, \+ free_E, free_NE, free_NW.

0.9990010::u212.
free_SE :- u212, action(swerve_left), curr_lane, \+ free_E, free_NE, free_NW.

0.5000000::u213.
free_SE :- u213, action(swerve_right), curr_lane, \+ free_E, free_NE, free_NW.

0.5140051::u214.
free_SE :- u214, action(change_to_left), \+ curr_lane, free_E, free_NE, free_NW.

0.1233075::u215.
free_SE :- u215, action(change_to_right), \+ curr_lane, free_E, free_NE, free_NW.

0.8281359::u216.
free_SE :- u216, action(cruise), \+ curr_lane, free_E, free_NE, free_NW.

0.9313725::u217.
free_SE :- u217, action(keep), \+ curr_lane, free_E, free_NE, free_NW.

0.8932584::u218.
free_SE :- u218, action(swerve_left), \+ curr_lane, free_E, free_NE, free_NW.

0.9990010::u219.
free_SE :- u219, action(swerve_right), \+ curr_lane, free_E, free_NE, free_NW.

0.7894168::u220.
free_SE :- u220, action(change_to_left), curr_lane, free_E, free_NE, free_NW.

0.4619466::u221.
free_SE :- u221, action(change_to_right), curr_lane, free_E, free_NE, free_NW.

0.8574156::u222.
free_SE :- u222, action(cruise), curr_lane, free_E, free_NE, free_NW.

0.9925094::u223.
free_SE :- u223, action(keep), curr_lane, free_E, free_NE, free_NW.

0.9885823::u224.
free_SE :- u224, action(swerve_left), curr_lane, free_E, free_NE, free_NW.

0.9471947::u225.
free_SE :- u225, action(swerve_right), curr_lane, free_E, free_NE, free_NW.

