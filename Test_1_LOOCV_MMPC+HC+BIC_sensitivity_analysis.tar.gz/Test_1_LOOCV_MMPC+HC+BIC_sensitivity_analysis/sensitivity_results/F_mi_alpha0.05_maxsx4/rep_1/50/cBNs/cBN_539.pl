%%% Exogenous variables

0.1682316::u_action(change_to_left); 0.1701553::u_action(change_to_right); 0.4049272::u_action(cruise); 0.2543982::u_action(keep); 0.0014062::u_action(swerve_left); 0.0008814::u_action(swerve_right)
action(V) :- u_action(V).

0.7156883::u1.
free_W :- u1.

0.3858462::u2.
latent_collision :- u2.

0.4973925::u3.
curr_lane :- u3, action(change_to_left).

0.5138932::u4.
curr_lane :- u4, action(change_to_right).

0.6563649::u5.
curr_lane :- u5, action(cruise).

0.3668290::u6.
curr_lane :- u6, action(keep).

0.8155977::u7.
curr_lane :- u7, action(swerve_left).

0.9906977::u8.
curr_lane :- u8, action(swerve_right).

0.5020203::u9.
free_E :- u9, action(change_to_left), \+ curr_lane, \+ free_NE, \+ free_W.

0.4980322::u10.
free_E :- u10, action(change_to_right), \+ curr_lane, \+ free_NE, \+ free_W.

0.4986095::u11.
free_E :- u11, action(cruise), \+ curr_lane, \+ free_NE, \+ free_W.

0.5000000::u12.
free_E :- u12, action(keep), \+ curr_lane, \+ free_NE, \+ free_W.

0.5000000::u13.
free_E :- u13, action(swerve_left), \+ curr_lane, \+ free_NE, \+ free_W.

0.5000000::u14.
free_E :- u14, action(swerve_right), \+ curr_lane, \+ free_NE, \+ free_W.

0.5016892::u15.
free_E :- u15, action(change_to_left), curr_lane, \+ free_NE, \+ free_W.

0.5136076::u16.
free_E :- u16, action(change_to_right), curr_lane, \+ free_NE, \+ free_W.

0.5323438::u17.
free_E :- u17, action(cruise), curr_lane, \+ free_NE, \+ free_W.

0.9506360::u18.
free_E :- u18, action(keep), curr_lane, \+ free_NE, \+ free_W.

0.9990010::u19.
free_E :- u19, action(swerve_left), curr_lane, \+ free_NE, \+ free_W.

0.9615385::u20.
free_E :- u20, action(swerve_right), curr_lane, \+ free_NE, \+ free_W.

0.5338929::u21.
free_E :- u21, action(change_to_left), \+ curr_lane, free_NE, \+ free_W.

0.0125919::u22.
free_E :- u22, action(change_to_right), \+ curr_lane, free_NE, \+ free_W.

0.5764746::u23.
free_E :- u23, action(cruise), \+ curr_lane, free_NE, \+ free_W.

0.9990010::u24.
free_E :- u24, action(keep), \+ curr_lane, free_NE, \+ free_W.

0.5000000::u25.
free_E :- u25, action(swerve_left), \+ curr_lane, free_NE, \+ free_W.

0.5000000::u26.
free_E :- u26, action(swerve_right), \+ curr_lane, free_NE, \+ free_W.

0.5013438::u27.
free_E :- u27, action(change_to_left), curr_lane, free_NE, \+ free_W.

0.4997507::u28.
free_E :- u28, action(change_to_right), curr_lane, free_NE, \+ free_W.

0.9634978::u29.
free_E :- u29, action(cruise), curr_lane, free_NE, \+ free_W.

0.9990010::u30.
free_E :- u30, action(keep), curr_lane, free_NE, \+ free_W.

0.9990010::u31.
free_E :- u31, action(swerve_left), curr_lane, free_NE, \+ free_W.

0.9682540::u32.
free_E :- u32, action(swerve_right), curr_lane, free_NE, \+ free_W.

0.5337402::u33.
free_E :- u33, action(change_to_left), \+ curr_lane, \+ free_NE, free_W.

0.5098096::u34.
free_E :- u34, action(change_to_right), \+ curr_lane, \+ free_NE, free_W.

0.5938852::u35.
free_E :- u35, action(cruise), \+ curr_lane, \+ free_NE, free_W.

0.6612430::u36.
free_E :- u36, action(keep), \+ curr_lane, \+ free_NE, free_W.

0.5238095::u37.
free_E :- u37, action(swerve_left), \+ curr_lane, \+ free_NE, free_W.

0.5000000::u38.
free_E :- u38, action(swerve_right), \+ curr_lane, \+ free_NE, free_W.

0.6113878::u39.
free_E :- u39, action(change_to_left), curr_lane, \+ free_NE, free_W.

0.5024314::u40.
free_E :- u40, action(change_to_right), curr_lane, \+ free_NE, free_W.

0.5325930::u41.
free_E :- u41, action(cruise), curr_lane, \+ free_NE, free_W.

0.8876125::u42.
free_E :- u42, action(keep), curr_lane, \+ free_NE, free_W.

0.8039216::u43.
free_E :- u43, action(swerve_left), curr_lane, \+ free_NE, free_W.

0.9903846::u44.
free_E :- u44, action(swerve_right), curr_lane, \+ free_NE, free_W.

0.5029533::u45.
free_E :- u45, action(change_to_left), \+ curr_lane, free_NE, free_W.

0.6444516::u46.
free_E :- u46, action(change_to_right), \+ curr_lane, free_NE, free_W.

0.4872471::u47.
free_E :- u47, action(cruise), \+ curr_lane, free_NE, free_W.

0.0680799::u48.
free_E :- u48, action(keep), \+ curr_lane, free_NE, free_W.

0.8894737::u49.
free_E :- u49, action(swerve_left), \+ curr_lane, free_NE, free_W.

0.9990010::u50.
free_E :- u50, action(swerve_right), \+ curr_lane, free_NE, free_W.

0.5935638::u51.
free_E :- u51, action(change_to_left), curr_lane, free_NE, free_W.

0.6002062::u52.
free_E :- u52, action(change_to_right), curr_lane, free_NE, free_W.

0.9773112::u53.
free_E :- u53, action(cruise), curr_lane, free_NE, free_W.

0.9944444::u54.
free_E :- u54, action(keep), curr_lane, free_NE, free_W.

0.9989930::u55.
free_E :- u55, action(swerve_left), curr_lane, free_NE, free_W.

0.9990010::u56.
free_E :- u56, action(swerve_right), curr_lane, free_NE, free_W.

0.4730054::u57.
free_NE :- u57, action(change_to_left), \+ curr_lane.

0.4942133::u58.
free_NE :- u58, action(change_to_right), \+ curr_lane.

0.4779800::u59.
free_NE :- u59, action(cruise), \+ curr_lane.

0.1134703::u60.
free_NE :- u60, action(keep), \+ curr_lane.

0.7509881::u61.
free_NE :- u61, action(swerve_left), \+ curr_lane.

0.9990010::u62.
free_NE :- u62, action(swerve_right), \+ curr_lane.

0.4927366::u63.
free_NE :- u63, action(change_to_left), curr_lane.

0.5306101::u64.
free_NE :- u64, action(change_to_right), curr_lane.

0.8336007::u65.
free_NE :- u65, action(cruise), curr_lane.

0.0043053::u66.
free_NE :- u66, action(keep), curr_lane.

0.8900804::u67.
free_NE :- u67, action(swerve_left), curr_lane.

0.8474178::u68.
free_NE :- u68, action(swerve_right), curr_lane.

0.5018970::u69.
free_NW :- u69, action(change_to_left), \+ free_NE, \+ free_SW, \+ free_W.

0.5011759::u70.
free_NW :- u70, action(change_to_right), \+ free_NE, \+ free_SW, \+ free_W.

0.3345511::u71.
free_NW :- u71, action(cruise), \+ free_NE, \+ free_SW, \+ free_W.

0.4082157::u72.
free_NW :- u72, action(keep), \+ free_NE, \+ free_SW, \+ free_W.

0.5000000::u73.
free_NW :- u73, action(swerve_left), \+ free_NE, \+ free_SW, \+ free_W.

0.1428571::u74.
free_NW :- u74, action(swerve_right), \+ free_NE, \+ free_SW, \+ free_W.

0.4965673::u75.
free_NW :- u75, action(change_to_left), free_NE, \+ free_SW, \+ free_W.

0.4987053::u76.
free_NW :- u76, action(change_to_right), free_NE, \+ free_SW, \+ free_W.

0.5145870::u77.
free_NW :- u77, action(cruise), free_NE, \+ free_SW, \+ free_W.

0.0009990::u78.
free_NW :- u78, action(keep), free_NE, \+ free_SW, \+ free_W.

0.9990010::u79.
free_NW :- u79, action(swerve_left), free_NE, \+ free_SW, \+ free_W.

0.3333333::u80.
free_NW :- u80, action(swerve_right), free_NE, \+ free_SW, \+ free_W.

0.5002234::u81.
free_NW :- u81, action(change_to_left), \+ free_NE, free_SW, \+ free_W.

0.4952692::u82.
free_NW :- u82, action(change_to_right), \+ free_NE, free_SW, \+ free_W.

0.3427018::u83.
free_NW :- u83, action(cruise), \+ free_NE, free_SW, \+ free_W.

0.2110223::u84.
free_NW :- u84, action(keep), \+ free_NE, free_SW, \+ free_W.

0.0009990::u85.
free_NW :- u85, action(swerve_left), \+ free_NE, free_SW, \+ free_W.

0.0526316::u86.
free_NW :- u86, action(swerve_right), \+ free_NE, free_SW, \+ free_W.

0.5326116::u87.
free_NW :- u87, action(change_to_left), free_NE, free_SW, \+ free_W.

0.5414131::u88.
free_NW :- u88, action(change_to_right), free_NE, free_SW, \+ free_W.

0.4568948::u89.
free_NW :- u89, action(cruise), free_NE, free_SW, \+ free_W.

0.0312500::u90.
free_NW :- u90, action(keep), free_NE, free_SW, \+ free_W.

0.0009990::u91.
free_NW :- u91, action(swerve_left), free_NE, free_SW, \+ free_W.

0.0740741::u92.
free_NW :- u92, action(swerve_right), free_NE, free_SW, \+ free_W.

0.5045128::u93.
free_NW :- u93, action(change_to_left), \+ free_NE, \+ free_SW, free_W.

0.5003263::u94.
free_NW :- u94, action(change_to_right), \+ free_NE, \+ free_SW, free_W.

0.6177300::u95.
free_NW :- u95, action(cruise), \+ free_NE, \+ free_SW, free_W.

0.4333147::u96.
free_NW :- u96, action(keep), \+ free_NE, \+ free_SW, free_W.

0.8260870::u97.
free_NW :- u97, action(swerve_left), \+ free_NE, \+ free_SW, free_W.

0.3333333::u98.
free_NW :- u98, action(swerve_right), \+ free_NE, \+ free_SW, free_W.

0.4728919::u99.
free_NW :- u99, action(change_to_left), free_NE, \+ free_SW, free_W.

0.4873056::u100.
free_NW :- u100, action(change_to_right), free_NE, \+ free_SW, free_W.

0.3678400::u101.
free_NW :- u101, action(cruise), free_NE, \+ free_SW, free_W.

0.2241379::u102.
free_NW :- u102, action(keep), free_NE, \+ free_SW, free_W.

0.9000000::u103.
free_NW :- u103, action(swerve_left), free_NE, \+ free_SW, free_W.

0.8421053::u104.
free_NW :- u104, action(swerve_right), free_NE, \+ free_SW, free_W.

0.5298383::u105.
free_NW :- u105, action(change_to_left), \+ free_NE, free_SW, free_W.

0.4862054::u106.
free_NW :- u106, action(change_to_right), \+ free_NE, free_SW, free_W.

0.7578194::u107.
free_NW :- u107, action(cruise), \+ free_NE, free_SW, free_W.

0.0061988::u108.
free_NW :- u108, action(keep), \+ free_NE, free_SW, free_W.

0.8309859::u109.
free_NW :- u109, action(swerve_left), \+ free_NE, free_SW, free_W.

0.6732673::u110.
free_NW :- u110, action(swerve_right), \+ free_NE, free_SW, free_W.

0.5387340::u111.
free_NW :- u111, action(change_to_left), free_NE, free_SW, free_W.

0.7004648::u112.
free_NW :- u112, action(change_to_right), free_NE, free_SW, free_W.

0.5873740::u113.
free_NW :- u113, action(cruise), free_NE, free_SW, free_W.

0.0298335::u114.
free_NW :- u114, action(keep), free_NE, free_SW, free_W.

0.9948849::u115.
free_NW :- u115, action(swerve_left), free_NE, free_SW, free_W.

0.9074074::u116.
free_NW :- u116, action(swerve_right), free_NE, free_SW, free_W.

0.5088769::u117.
free_SE :- u117, action(change_to_left), \+ curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.4976850::u118.
free_SE :- u118, action(change_to_right), \+ curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.4922969::u119.
free_SE :- u119, action(cruise), \+ curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.2581992::u120.
free_SE :- u120, action(keep), \+ curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.9990010::u121.
free_SE :- u121, action(swerve_left), \+ curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.5000000::u122.
free_SE :- u122, action(swerve_right), \+ curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.4962510::u123.
free_SE :- u123, action(change_to_left), curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.4950505::u124.
free_SE :- u124, action(change_to_right), curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.4985539::u125.
free_SE :- u125, action(cruise), curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.9928604::u126.
free_SE :- u126, action(keep), curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.9990010::u127.
free_SE :- u127, action(swerve_left), curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.9990010::u128.
free_SE :- u128, action(swerve_right), curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.5070089::u129.
free_SE :- u129, action(change_to_left), \+ curr_lane, free_E, \+ free_NE, \+ free_NW.

0.4957110::u130.
free_SE :- u130, action(change_to_right), \+ curr_lane, free_E, \+ free_NE, \+ free_NW.

0.5158633::u131.
free_SE :- u131, action(cruise), \+ curr_lane, free_E, \+ free_NE, \+ free_NW.

0.3432566::u132.
free_SE :- u132, action(keep), \+ curr_lane, free_E, \+ free_NE, \+ free_NW.

0.9990010::u133.
free_SE :- u133, action(swerve_left), \+ curr_lane, free_E, \+ free_NE, \+ free_NW.

0.5000000::u134.
free_SE :- u134, action(swerve_right), \+ curr_lane, free_E, \+ free_NE, \+ free_NW.

0.5394359::u135.
free_SE :- u135, action(change_to_left), curr_lane, free_E, \+ free_NE, \+ free_NW.

0.5091858::u136.
free_SE :- u136, action(change_to_right), curr_lane, free_E, \+ free_NE, \+ free_NW.

0.5771182::u137.
free_SE :- u137, action(cruise), curr_lane, free_E, \+ free_NE, \+ free_NW.

0.7897349::u138.
free_SE :- u138, action(keep), curr_lane, free_E, \+ free_NE, \+ free_NW.

0.9705882::u139.
free_SE :- u139, action(swerve_left), curr_lane, free_E, \+ free_NE, \+ free_NW.

0.9137931::u140.
free_SE :- u140, action(swerve_right), curr_lane, free_E, \+ free_NE, \+ free_NW.

0.4289773::u141.
free_SE :- u141, action(change_to_left), \+ curr_lane, \+ free_E, free_NE, \+ free_NW.

0.4163720::u142.
free_SE :- u142, action(change_to_right), \+ curr_lane, \+ free_E, free_NE, \+ free_NW.

0.4278714::u143.
free_SE :- u143, action(cruise), \+ curr_lane, \+ free_E, free_NE, \+ free_NW.

0.2657907::u144.
free_SE :- u144, action(keep), \+ curr_lane, \+ free_E, free_NE, \+ free_NW.

0.5000000::u145.
free_SE :- u145, action(swerve_left), \+ curr_lane, \+ free_E, free_NE, \+ free_NW.

0.5000000::u146.
free_SE :- u146, action(swerve_right), \+ curr_lane, \+ free_E, free_NE, \+ free_NW.

0.4934250::u147.
free_SE :- u147, action(change_to_left), curr_lane, \+ free_E, free_NE, \+ free_NW.

0.4981468::u148.
free_SE :- u148, action(change_to_right), curr_lane, \+ free_E, free_NE, \+ free_NW.

0.9806822::u149.
free_SE :- u149, action(cruise), curr_lane, \+ free_E, free_NE, \+ free_NW.

0.9990010::u150.
free_SE :- u150, action(keep), curr_lane, \+ free_E, free_NE, \+ free_NW.

0.9990010::u151.
free_SE :- u151, action(swerve_left), curr_lane, \+ free_E, free_NE, \+ free_NW.

0.9990010::u152.
free_SE :- u152, action(swerve_right), curr_lane, \+ free_E, free_NE, \+ free_NW.

0.5005999::u153.
free_SE :- u153, action(change_to_left), \+ curr_lane, free_E, free_NE, \+ free_NW.

0.3224843::u154.
free_SE :- u154, action(change_to_right), \+ curr_lane, free_E, free_NE, \+ free_NW.

0.4974136::u155.
free_SE :- u155, action(cruise), \+ curr_lane, free_E, free_NE, \+ free_NW.

0.0090634::u156.
free_SE :- u156, action(keep), \+ curr_lane, free_E, free_NE, \+ free_NW.

0.5000000::u157.
free_SE :- u157, action(swerve_left), \+ curr_lane, free_E, free_NE, \+ free_NW.

0.5000000::u158.
free_SE :- u158, action(swerve_right), \+ curr_lane, free_E, free_NE, \+ free_NW.

0.4984380::u159.
free_SE :- u159, action(change_to_left), curr_lane, free_E, free_NE, \+ free_NW.

0.4651573::u160.
free_SE :- u160, action(change_to_right), curr_lane, free_E, free_NE, \+ free_NW.

0.8429144::u161.
free_SE :- u161, action(cruise), curr_lane, free_E, free_NE, \+ free_NW.

0.7261905::u162.
free_SE :- u162, action(keep), curr_lane, free_E, free_NE, \+ free_NW.

0.9990010::u163.
free_SE :- u163, action(swerve_left), curr_lane, free_E, free_NE, \+ free_NW.

0.8909091::u164.
free_SE :- u164, action(swerve_right), curr_lane, free_E, free_NE, \+ free_NW.

0.5140030::u165.
free_SE :- u165, action(change_to_left), \+ curr_lane, \+ free_E, \+ free_NE, free_NW.

0.5053497::u166.
free_SE :- u166, action(change_to_right), \+ curr_lane, \+ free_E, \+ free_NE, free_NW.

0.5850288::u167.
free_SE :- u167, action(cruise), \+ curr_lane, \+ free_E, \+ free_NE, free_NW.

0.5862069::u168.
free_SE :- u168, action(keep), \+ curr_lane, \+ free_E, \+ free_NE, free_NW.

0.5714286::u169.
free_SE :- u169, action(swerve_left), \+ curr_lane, \+ free_E, \+ free_NE, free_NW.

0.5000000::u170.
free_SE :- u170, action(swerve_right), \+ curr_lane, \+ free_E, \+ free_NE, free_NW.

0.6926280::u171.
free_SE :- u171, action(change_to_left), curr_lane, \+ free_E, \+ free_NE, free_NW.

0.4985861::u172.
free_SE :- u172, action(change_to_right), curr_lane, \+ free_E, \+ free_NE, free_NW.

0.4938405::u173.
free_SE :- u173, action(cruise), curr_lane, \+ free_E, \+ free_NE, free_NW.

0.9813665::u174.
free_SE :- u174, action(keep), curr_lane, \+ free_E, \+ free_NE, free_NW.

0.9990010::u175.
free_SE :- u175, action(swerve_left), curr_lane, \+ free_E, \+ free_NE, free_NW.

0.9990010::u176.
free_SE :- u176, action(swerve_right), curr_lane, \+ free_E, \+ free_NE, free_NW.

0.5545462::u177.
free_SE :- u177, action(change_to_left), \+ curr_lane, free_E, \+ free_NE, free_NW.

0.5008432::u178.
free_SE :- u178, action(change_to_right), \+ curr_lane, free_E, \+ free_NE, free_NW.

0.7831427::u179.
free_SE :- u179, action(cruise), \+ curr_lane, free_E, \+ free_NE, free_NW.

0.9508929::u180.
free_SE :- u180, action(keep), \+ curr_lane, free_E, \+ free_NE, free_NW.

0.6296296::u181.
free_SE :- u181, action(swerve_left), \+ curr_lane, free_E, \+ free_NE, free_NW.

0.5000000::u182.
free_SE :- u182, action(swerve_right), \+ curr_lane, free_E, \+ free_NE, free_NW.

0.7774624::u183.
free_SE :- u183, action(change_to_left), curr_lane, free_E, \+ free_NE, free_NW.

0.4947516::u184.
free_SE :- u184, action(change_to_right), curr_lane, free_E, \+ free_NE, free_NW.

0.5408072::u185.
free_SE :- u185, action(cruise), curr_lane, free_E, \+ free_NE, free_NW.

0.7588201::u186.
free_SE :- u186, action(keep), curr_lane, free_E, \+ free_NE, free_NW.

0.8405797::u187.
free_SE :- u187, action(swerve_left), curr_lane, free_E, \+ free_NE, free_NW.

0.9990010::u188.
free_SE :- u188, action(swerve_right), curr_lane, free_E, \+ free_NE, free_NW.

0.5052411::u189.
free_SE :- u189, action(change_to_left), \+ curr_lane, \+ free_E, free_NE, free_NW.

0.4743297::u190.
free_SE :- u190, action(change_to_right), \+ curr_lane, \+ free_E, free_NE, free_NW.

0.4073046::u191.
free_SE :- u191, action(cruise), \+ curr_lane, \+ free_E, free_NE, free_NW.

0.8461538::u192.
free_SE :- u192, action(keep), \+ curr_lane, \+ free_E, free_NE, free_NW.

0.0476190::u193.
free_SE :- u193, action(swerve_left), \+ curr_lane, \+ free_E, free_NE, free_NW.

0.5000000::u194.
free_SE :- u194, action(swerve_right), \+ curr_lane, \+ free_E, free_NE, free_NW.

0.6742192::u195.
free_SE :- u195, action(change_to_left), curr_lane, \+ free_E, free_NE, free_NW.

0.4962488::u196.
free_SE :- u196, action(change_to_right), curr_lane, \+ free_E, free_NE, free_NW.

0.9655172::u197.
free_SE :- u197, action(cruise), curr_lane, \+ free_E, free_NE, free_NW.

0.9990010::u198.
free_SE :- u198, action(keep), curr_lane, \+ free_E, free_NE, free_NW.

0.5000000::u199.
free_SE :- u199, action(swerve_left), curr_lane, \+ free_E, free_NE, free_NW.

0.5000000::u200.
free_SE :- u200, action(swerve_right), curr_lane, \+ free_E, free_NE, free_NW.

0.5132804::u201.
free_SE :- u201, action(change_to_left), \+ curr_lane, free_E, free_NE, free_NW.

0.1180772::u202.
free_SE :- u202, action(change_to_right), \+ curr_lane, free_E, free_NE, free_NW.

0.8262643::u203.
free_SE :- u203, action(cruise), \+ curr_lane, free_E, free_NE, free_NW.

0.9459459::u204.
free_SE :- u204, action(keep), \+ curr_lane, free_E, free_NE, free_NW.

0.9112426::u205.
free_SE :- u205, action(swerve_left), \+ curr_lane, free_E, free_NE, free_NW.

0.9990010::u206.
free_SE :- u206, action(swerve_right), \+ curr_lane, free_E, free_NE, free_NW.

0.7865642::u207.
free_SE :- u207, action(change_to_left), curr_lane, free_E, free_NE, free_NW.

0.4646867::u208.
free_SE :- u208, action(change_to_right), curr_lane, free_E, free_NE, free_NW.

0.8569068::u209.
free_SE :- u209, action(cruise), curr_lane, free_E, free_NE, free_NW.

0.9869281::u210.
free_SE :- u210, action(keep), curr_lane, free_E, free_NE, free_NW.

0.9908815::u211.
free_SE :- u211, action(swerve_left), curr_lane, free_E, free_NE, free_NW.

0.9524590::u212.
free_SE :- u212, action(swerve_right), curr_lane, free_E, free_NE, free_NW.

0.7684384::u213.
free_SW :- u213, \+ curr_lane.

0.6001772::u214.
free_SW :- u214, curr_lane.

