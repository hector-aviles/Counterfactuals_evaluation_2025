%%% Exogenous variables

0.1674917::u_action(change_to_left); 0.1701060::u_action(change_to_right); 0.4062074::u_action(cruise); 0.2539358::u_action(keep); 0.0014300::u_action(swerve_left); 0.0008291::u_action(swerve_right)
action(V) :- u_action(V).

0.7147406::u1.
free_W :- u1.

0.3868969::u2.
latent_collision :- u2.

0.4971949::u3.
curr_lane :- u3, action(change_to_left).

0.5174989::u4.
curr_lane :- u4, action(change_to_right).

0.6537924::u5.
curr_lane :- u5, action(cruise).

0.3660139::u6.
curr_lane :- u6, action(keep).

0.8110236::u7.
curr_lane :- u7, action(swerve_left).

0.9888889::u8.
curr_lane :- u8, action(swerve_right).

0.5027470::u9.
free_E :- u9, action(change_to_left), \+ curr_lane, \+ free_NE, \+ free_W.

0.4998253::u10.
free_E :- u10, action(change_to_right), \+ curr_lane, \+ free_NE, \+ free_W.

0.5005464::u11.
free_E :- u11, action(cruise), \+ curr_lane, \+ free_NE, \+ free_W.

0.5000000::u12.
free_E :- u12, action(keep), \+ curr_lane, \+ free_NE, \+ free_W.

0.5000000::u13.
free_E :- u13, action(swerve_left), \+ curr_lane, \+ free_NE, \+ free_W.

0.5000000::u14.
free_E :- u14, action(swerve_right), \+ curr_lane, \+ free_NE, \+ free_W.

0.5037037::u15.
free_E :- u15, action(change_to_left), curr_lane, \+ free_NE, \+ free_W.

0.5042427::u16.
free_E :- u16, action(change_to_right), curr_lane, \+ free_NE, \+ free_W.

0.5320294::u17.
free_E :- u17, action(cruise), curr_lane, \+ free_NE, \+ free_W.

0.9510204::u18.
free_E :- u18, action(keep), curr_lane, \+ free_NE, \+ free_W.

0.9990010::u19.
free_E :- u19, action(swerve_left), curr_lane, \+ free_NE, \+ free_W.

0.9990010::u20.
free_E :- u20, action(swerve_right), curr_lane, \+ free_NE, \+ free_W.

0.5314277::u21.
free_E :- u21, action(change_to_left), \+ curr_lane, free_NE, \+ free_W.

0.0106110::u22.
free_E :- u22, action(change_to_right), \+ curr_lane, free_NE, \+ free_W.

0.5042360::u23.
free_E :- u23, action(cruise), \+ curr_lane, free_NE, \+ free_W.

0.2857143::u24.
free_E :- u24, action(keep), \+ curr_lane, free_NE, \+ free_W.

0.5000000::u25.
free_E :- u25, action(swerve_left), \+ curr_lane, free_NE, \+ free_W.

0.5000000::u26.
free_E :- u26, action(swerve_right), \+ curr_lane, free_NE, \+ free_W.

0.4994773::u27.
free_E :- u27, action(change_to_left), curr_lane, free_NE, \+ free_W.

0.4977259::u28.
free_E :- u28, action(change_to_right), curr_lane, free_NE, \+ free_W.

0.9635222::u29.
free_E :- u29, action(cruise), curr_lane, free_NE, \+ free_W.

0.9990010::u30.
free_E :- u30, action(keep), curr_lane, free_NE, \+ free_W.

0.9990010::u31.
free_E :- u31, action(swerve_left), curr_lane, free_NE, \+ free_W.

0.9692308::u32.
free_E :- u32, action(swerve_right), curr_lane, free_NE, \+ free_W.

0.5361396::u33.
free_E :- u33, action(change_to_left), \+ curr_lane, \+ free_NE, free_W.

0.5138068::u34.
free_E :- u34, action(change_to_right), \+ curr_lane, \+ free_NE, free_W.

0.5945179::u35.
free_E :- u35, action(cruise), \+ curr_lane, \+ free_NE, free_W.

0.6604743::u36.
free_E :- u36, action(keep), \+ curr_lane, \+ free_NE, free_W.

0.5970149::u37.
free_E :- u37, action(swerve_left), \+ curr_lane, \+ free_NE, free_W.

0.5000000::u38.
free_E :- u38, action(swerve_right), \+ curr_lane, \+ free_NE, free_W.

0.6096145::u39.
free_E :- u39, action(change_to_left), curr_lane, \+ free_NE, free_W.

0.4993536::u40.
free_E :- u40, action(change_to_right), curr_lane, \+ free_NE, free_W.

0.5350805::u41.
free_E :- u41, action(cruise), curr_lane, \+ free_NE, free_W.

0.8875316::u42.
free_E :- u42, action(keep), curr_lane, \+ free_NE, free_W.

0.8333333::u43.
free_E :- u43, action(swerve_left), curr_lane, \+ free_NE, free_W.

0.9888889::u44.
free_E :- u44, action(swerve_right), curr_lane, \+ free_NE, free_W.

0.5047285::u45.
free_E :- u45, action(change_to_left), \+ curr_lane, free_NE, free_W.

0.6419478::u46.
free_E :- u46, action(change_to_right), \+ curr_lane, free_NE, free_W.

0.4863036::u47.
free_E :- u47, action(cruise), \+ curr_lane, free_NE, free_W.

0.0630515::u48.
free_E :- u48, action(keep), \+ curr_lane, free_NE, free_W.

0.9035533::u49.
free_E :- u49, action(swerve_left), \+ curr_lane, free_NE, free_W.

0.9990010::u50.
free_E :- u50, action(swerve_right), \+ curr_lane, free_NE, free_W.

0.5959486::u51.
free_E :- u51, action(change_to_left), curr_lane, free_NE, free_W.

0.5967151::u52.
free_E :- u52, action(change_to_right), curr_lane, free_NE, free_W.

0.9777610::u53.
free_E :- u53, action(cruise), curr_lane, free_NE, free_W.

0.9943662::u54.
free_E :- u54, action(keep), curr_lane, free_NE, free_W.

0.9990010::u55.
free_E :- u55, action(swerve_left), curr_lane, free_NE, free_W.

0.9990010::u56.
free_E :- u56, action(swerve_right), curr_lane, free_NE, free_W.

0.4759763::u57.
free_NE :- u57, action(change_to_left), \+ curr_lane.

0.4927478::u58.
free_NE :- u58, action(change_to_right), \+ curr_lane.

0.4806315::u59.
free_NE :- u59, action(cruise), \+ curr_lane.

0.1138939::u60.
free_NE :- u60, action(keep), \+ curr_lane.

0.7462121::u61.
free_NE :- u61, action(swerve_left), \+ curr_lane.

0.9990010::u62.
free_NE :- u62, action(swerve_right), \+ curr_lane.

0.4944994::u63.
free_NE :- u63, action(change_to_left), curr_lane.

0.5304364::u64.
free_NE :- u64, action(change_to_right), curr_lane.

0.8337978::u65.
free_NE :- u65, action(cruise), curr_lane.

0.0042952::u66.
free_NE :- u66, action(keep), curr_lane.

0.8879082::u67.
free_NE :- u67, action(swerve_left), curr_lane.

0.8664170::u68.
free_NE :- u68, action(swerve_right), curr_lane.

0.5042261::u69.
free_NW :- u69, action(change_to_left), \+ free_NE, \+ free_SW, \+ free_W.

0.5026495::u70.
free_NW :- u70, action(change_to_right), \+ free_NE, \+ free_SW, \+ free_W.

0.3271968::u71.
free_NW :- u71, action(cruise), \+ free_NE, \+ free_SW, \+ free_W.

0.4021692::u72.
free_NW :- u72, action(keep), \+ free_NE, \+ free_SW, \+ free_W.

0.3333333::u73.
free_NW :- u73, action(swerve_left), \+ free_NE, \+ free_SW, \+ free_W.

0.2857143::u74.
free_NW :- u74, action(swerve_right), \+ free_NE, \+ free_SW, \+ free_W.

0.4634277::u75.
free_NW :- u75, action(change_to_left), free_NE, \+ free_SW, \+ free_W.

0.4503037::u76.
free_NW :- u76, action(change_to_right), free_NE, \+ free_SW, \+ free_W.

0.5153643::u77.
free_NW :- u77, action(cruise), free_NE, \+ free_SW, \+ free_W.

0.0009990::u78.
free_NW :- u78, action(keep), free_NE, \+ free_SW, \+ free_W.

0.6666667::u79.
free_NW :- u79, action(swerve_left), free_NE, \+ free_SW, \+ free_W.

0.3142857::u80.
free_NW :- u80, action(swerve_right), free_NE, \+ free_SW, \+ free_W.

0.5033264::u81.
free_NW :- u81, action(change_to_left), \+ free_NE, free_SW, \+ free_W.

0.4959846::u82.
free_NW :- u82, action(change_to_right), \+ free_NE, free_SW, \+ free_W.

0.3371386::u83.
free_NW :- u83, action(cruise), \+ free_NE, free_SW, \+ free_W.

0.2113657::u84.
free_NW :- u84, action(keep), \+ free_NE, free_SW, \+ free_W.

0.0009990::u85.
free_NW :- u85, action(swerve_left), \+ free_NE, free_SW, \+ free_W.

0.1000000::u86.
free_NW :- u86, action(swerve_right), \+ free_NE, free_SW, \+ free_W.

0.4985254::u87.
free_NW :- u87, action(change_to_left), free_NE, free_SW, \+ free_W.

0.4999341::u88.
free_NW :- u88, action(change_to_right), free_NE, free_SW, \+ free_W.

0.4430874::u89.
free_NW :- u89, action(cruise), free_NE, free_SW, \+ free_W.

0.0009990::u90.
free_NW :- u90, action(keep), free_NE, free_SW, \+ free_W.

0.0009990::u91.
free_NW :- u91, action(swerve_left), free_NE, free_SW, \+ free_W.

0.0009990::u92.
free_NW :- u92, action(swerve_right), free_NE, free_SW, \+ free_W.

0.5014971::u93.
free_NW :- u93, action(change_to_left), \+ free_NE, \+ free_SW, free_W.

0.4989961::u94.
free_NW :- u94, action(change_to_right), \+ free_NE, \+ free_SW, free_W.

0.6190387::u95.
free_NW :- u95, action(cruise), \+ free_NE, \+ free_SW, free_W.

0.4266080::u96.
free_NW :- u96, action(keep), \+ free_NE, \+ free_SW, free_W.

0.7600000::u97.
free_NW :- u97, action(swerve_left), \+ free_NE, \+ free_SW, free_W.

0.7500000::u98.
free_NW :- u98, action(swerve_right), \+ free_NE, \+ free_SW, free_W.

0.4680930::u99.
free_NW :- u99, action(change_to_left), free_NE, \+ free_SW, free_W.

0.4891741::u100.
free_NW :- u100, action(change_to_right), free_NE, \+ free_SW, free_W.

0.3701211::u101.
free_NW :- u101, action(cruise), free_NE, \+ free_SW, free_W.

0.2000000::u102.
free_NW :- u102, action(keep), free_NE, \+ free_SW, free_W.

0.8888889::u103.
free_NW :- u103, action(swerve_left), free_NE, \+ free_SW, free_W.

0.9333333::u104.
free_NW :- u104, action(swerve_right), free_NE, \+ free_SW, free_W.

0.5377613::u105.
free_NW :- u105, action(change_to_left), \+ free_NE, free_SW, free_W.

0.4860311::u106.
free_NW :- u106, action(change_to_right), \+ free_NE, free_SW, free_W.

0.7556228::u107.
free_NW :- u107, action(cruise), \+ free_NE, free_SW, free_W.

0.0060910::u108.
free_NW :- u108, action(keep), \+ free_NE, free_SW, free_W.

0.8397436::u109.
free_NW :- u109, action(swerve_left), \+ free_NE, free_SW, free_W.

0.7325581::u110.
free_NW :- u110, action(swerve_right), \+ free_NE, free_SW, free_W.

0.5415005::u111.
free_NW :- u111, action(change_to_left), free_NE, free_SW, free_W.

0.7020977::u112.
free_NW :- u112, action(change_to_right), free_NE, free_SW, free_W.

0.5860568::u113.
free_NW :- u113, action(cruise), free_NE, free_SW, free_W.

0.0282325::u114.
free_NW :- u114, action(keep), free_NE, free_SW, free_W.

0.9949537::u115.
free_NW :- u115, action(swerve_left), free_NE, free_SW, free_W.

0.9101124::u116.
free_NW :- u116, action(swerve_right), free_NE, free_SW, free_W.

0.5041642::u117.
free_SE :- u117, action(change_to_left), \+ curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.5055699::u118.
free_SE :- u118, action(change_to_right), \+ curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.4965625::u119.
free_SE :- u119, action(cruise), \+ curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.2611169::u120.
free_SE :- u120, action(keep), \+ curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.9990010::u121.
free_SE :- u121, action(swerve_left), \+ curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.5000000::u122.
free_SE :- u122, action(swerve_right), \+ curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.5042547::u123.
free_SE :- u123, action(change_to_left), curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.4998506::u124.
free_SE :- u124, action(change_to_right), curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.4975639::u125.
free_SE :- u125, action(cruise), curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.9935109::u126.
free_SE :- u126, action(keep), curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.9990010::u127.
free_SE :- u127, action(swerve_left), curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.5000000::u128.
free_SE :- u128, action(swerve_right), curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.5022707::u129.
free_SE :- u129, action(change_to_left), \+ curr_lane, free_E, \+ free_NE, \+ free_NW.

0.4940527::u130.
free_SE :- u130, action(change_to_right), \+ curr_lane, free_E, \+ free_NE, \+ free_NW.

0.5112697::u131.
free_SE :- u131, action(cruise), \+ curr_lane, free_E, \+ free_NE, \+ free_NW.

0.3439859::u132.
free_SE :- u132, action(keep), \+ curr_lane, free_E, \+ free_NE, \+ free_NW.

0.9990010::u133.
free_SE :- u133, action(swerve_left), \+ curr_lane, free_E, \+ free_NE, \+ free_NW.

0.5000000::u134.
free_SE :- u134, action(swerve_right), \+ curr_lane, free_E, \+ free_NE, \+ free_NW.

0.5371258::u135.
free_SE :- u135, action(change_to_left), curr_lane, free_E, \+ free_NE, \+ free_NW.

0.5078422::u136.
free_SE :- u136, action(change_to_right), curr_lane, free_E, \+ free_NE, \+ free_NW.

0.5744752::u137.
free_SE :- u137, action(cruise), curr_lane, free_E, \+ free_NE, \+ free_NW.

0.7912919::u138.
free_SE :- u138, action(keep), curr_lane, free_E, \+ free_NE, \+ free_NW.

0.9687500::u139.
free_SE :- u139, action(swerve_left), curr_lane, free_E, \+ free_NE, \+ free_NW.

0.9210526::u140.
free_SE :- u140, action(swerve_right), curr_lane, free_E, \+ free_NE, \+ free_NW.

0.5002504::u141.
free_SE :- u141, action(change_to_left), \+ curr_lane, \+ free_E, free_NE, \+ free_NW.

0.4833791::u142.
free_SE :- u142, action(change_to_right), \+ curr_lane, \+ free_E, free_NE, \+ free_NW.

0.4877676::u143.
free_SE :- u143, action(cruise), \+ curr_lane, \+ free_E, free_NE, \+ free_NW.

0.2682418::u144.
free_SE :- u144, action(keep), \+ curr_lane, \+ free_E, free_NE, \+ free_NW.

0.5000000::u145.
free_SE :- u145, action(swerve_left), \+ curr_lane, \+ free_E, free_NE, \+ free_NW.

0.5000000::u146.
free_SE :- u146, action(swerve_right), \+ curr_lane, \+ free_E, free_NE, \+ free_NW.

0.4956617::u147.
free_SE :- u147, action(change_to_left), curr_lane, \+ free_E, free_NE, \+ free_NW.

0.4992121::u148.
free_SE :- u148, action(change_to_right), curr_lane, \+ free_E, free_NE, \+ free_NW.

0.9839009::u149.
free_SE :- u149, action(cruise), curr_lane, \+ free_E, free_NE, \+ free_NW.

0.9990010::u150.
free_SE :- u150, action(keep), curr_lane, \+ free_E, free_NE, \+ free_NW.

0.9990010::u151.
free_SE :- u151, action(swerve_left), curr_lane, \+ free_E, free_NE, \+ free_NW.

0.9990010::u152.
free_SE :- u152, action(swerve_right), curr_lane, \+ free_E, free_NE, \+ free_NW.

0.4993525::u153.
free_SE :- u153, action(change_to_left), \+ curr_lane, free_E, free_NE, \+ free_NW.

0.3351818::u154.
free_SE :- u154, action(change_to_right), \+ curr_lane, free_E, free_NE, \+ free_NW.

0.4950163::u155.
free_SE :- u155, action(cruise), \+ curr_lane, free_E, free_NE, \+ free_NW.

0.0096878::u156.
free_SE :- u156, action(keep), \+ curr_lane, free_E, free_NE, \+ free_NW.

0.5000000::u157.
free_SE :- u157, action(swerve_left), \+ curr_lane, free_E, free_NE, \+ free_NW.

0.5000000::u158.
free_SE :- u158, action(swerve_right), \+ curr_lane, free_E, free_NE, \+ free_NW.

0.5022872::u159.
free_SE :- u159, action(change_to_left), curr_lane, free_E, free_NE, \+ free_NW.

0.4605905::u160.
free_SE :- u160, action(change_to_right), curr_lane, free_E, free_NE, \+ free_NW.

0.8425025::u161.
free_SE :- u161, action(cruise), curr_lane, free_E, free_NE, \+ free_NW.

0.7906977::u162.
free_SE :- u162, action(keep), curr_lane, free_E, free_NE, \+ free_NW.

0.9990010::u163.
free_SE :- u163, action(swerve_left), curr_lane, free_E, free_NE, \+ free_NW.

0.8715596::u164.
free_SE :- u164, action(swerve_right), curr_lane, free_E, free_NE, \+ free_NW.

0.5156412::u165.
free_SE :- u165, action(change_to_left), \+ curr_lane, \+ free_E, \+ free_NE, free_NW.

0.5040496::u166.
free_SE :- u166, action(change_to_right), \+ curr_lane, \+ free_E, \+ free_NE, free_NW.

0.5838590::u167.
free_SE :- u167, action(cruise), \+ curr_lane, \+ free_E, \+ free_NE, free_NW.

0.8000000::u168.
free_SE :- u168, action(keep), \+ curr_lane, \+ free_E, \+ free_NE, free_NW.

0.6250000::u169.
free_SE :- u169, action(swerve_left), \+ curr_lane, \+ free_E, \+ free_NE, free_NW.

0.5000000::u170.
free_SE :- u170, action(swerve_right), \+ curr_lane, \+ free_E, \+ free_NE, free_NW.

0.6961933::u171.
free_SE :- u171, action(change_to_left), curr_lane, \+ free_E, \+ free_NE, free_NW.

0.5024308::u172.
free_SE :- u172, action(change_to_right), curr_lane, \+ free_E, \+ free_NE, free_NW.

0.5025855::u173.
free_SE :- u173, action(cruise), curr_lane, \+ free_E, \+ free_NE, free_NW.

0.9824561::u174.
free_SE :- u174, action(keep), curr_lane, \+ free_E, \+ free_NE, free_NW.

0.9990010::u175.
free_SE :- u175, action(swerve_left), curr_lane, \+ free_E, \+ free_NE, free_NW.

0.9990010::u176.
free_SE :- u176, action(swerve_right), curr_lane, \+ free_E, \+ free_NE, free_NW.

0.5577889::u177.
free_SE :- u177, action(change_to_left), \+ curr_lane, free_E, \+ free_NE, free_NW.

0.4972797::u178.
free_SE :- u178, action(change_to_right), \+ curr_lane, free_E, \+ free_NE, free_NW.

0.7867600::u179.
free_SE :- u179, action(cruise), \+ curr_lane, free_E, \+ free_NE, free_NW.

0.9621849::u180.
free_SE :- u180, action(keep), \+ curr_lane, free_E, \+ free_NE, free_NW.

0.6666667::u181.
free_SE :- u181, action(swerve_left), \+ curr_lane, free_E, \+ free_NE, free_NW.

0.5000000::u182.
free_SE :- u182, action(swerve_right), \+ curr_lane, free_E, \+ free_NE, free_NW.

0.7694185::u183.
free_SE :- u183, action(change_to_left), curr_lane, free_E, \+ free_NE, free_NW.

0.5036504::u184.
free_SE :- u184, action(change_to_right), curr_lane, free_E, \+ free_NE, free_NW.

0.5454136::u185.
free_SE :- u185, action(cruise), curr_lane, free_E, \+ free_NE, free_NW.

0.7618839::u186.
free_SE :- u186, action(keep), curr_lane, free_E, \+ free_NE, free_NW.

0.7631579::u187.
free_SE :- u187, action(swerve_left), curr_lane, free_E, \+ free_NE, free_NW.

0.9558824::u188.
free_SE :- u188, action(swerve_right), curr_lane, free_E, \+ free_NE, free_NW.

0.5711241::u189.
free_SE :- u189, action(change_to_left), \+ curr_lane, \+ free_E, free_NE, free_NW.

0.5527056::u190.
free_SE :- u190, action(change_to_right), \+ curr_lane, \+ free_E, free_NE, free_NW.

0.4076824::u191.
free_SE :- u191, action(cruise), \+ curr_lane, \+ free_E, free_NE, free_NW.

0.8571429::u192.
free_SE :- u192, action(keep), \+ curr_lane, \+ free_E, free_NE, free_NW.

0.0526316::u193.
free_SE :- u193, action(swerve_left), \+ curr_lane, \+ free_E, free_NE, free_NW.

0.5000000::u194.
free_SE :- u194, action(swerve_right), \+ curr_lane, \+ free_E, free_NE, free_NW.

0.6768308::u195.
free_SE :- u195, action(change_to_left), curr_lane, \+ free_E, free_NE, free_NW.

0.4961445::u196.
free_SE :- u196, action(change_to_right), curr_lane, \+ free_E, free_NE, free_NW.

0.9615086::u197.
free_SE :- u197, action(cruise), curr_lane, \+ free_E, free_NE, free_NW.

0.5000000::u198.
free_SE :- u198, action(keep), curr_lane, \+ free_E, free_NE, free_NW.

0.5000000::u199.
free_SE :- u199, action(swerve_left), curr_lane, \+ free_E, free_NE, free_NW.

0.5000000::u200.
free_SE :- u200, action(swerve_right), curr_lane, \+ free_E, free_NE, free_NW.

0.5079225::u201.
free_SE :- u201, action(change_to_left), \+ curr_lane, free_E, free_NE, free_NW.

0.1212876::u202.
free_SE :- u202, action(change_to_right), \+ curr_lane, free_E, free_NE, free_NW.

0.8248365::u203.
free_SE :- u203, action(cruise), \+ curr_lane, free_E, free_NE, free_NW.

0.9554455::u204.
free_SE :- u204, action(keep), \+ curr_lane, free_E, free_NE, free_NW.

0.9044944::u205.
free_SE :- u205, action(swerve_left), \+ curr_lane, free_E, free_NE, free_NW.

0.9990010::u206.
free_SE :- u206, action(swerve_right), \+ curr_lane, free_E, free_NE, free_NW.

0.7910024::u207.
free_SE :- u207, action(change_to_left), curr_lane, free_E, free_NE, free_NW.

0.4670349::u208.
free_SE :- u208, action(change_to_right), curr_lane, free_E, free_NE, free_NW.

0.8577746::u209.
free_SE :- u209, action(cruise), curr_lane, free_E, free_NE, free_NW.

0.9900662::u210.
free_SE :- u210, action(keep), curr_lane, free_E, free_NE, free_NW.

0.9849398::u211.
free_SE :- u211, action(swerve_left), curr_lane, free_E, free_NE, free_NW.

0.9536878::u212.
free_SE :- u212, action(swerve_right), curr_lane, free_E, free_NE, free_NW.

0.7740968::u213.
free_SW :- u213, \+ curr_lane.

0.6008600::u214.
free_SW :- u214, curr_lane.

