%%% Exogenous variables

0.1680354::u_action(change_to_left); 0.1699273::u_action(change_to_right); 0.4045931::u_action(cruise); 0.2550553::u_action(keep); 0.0015057::u_action(swerve_left); 0.0008833::u_action(swerve_right)
action(V) :- u_action(V).

0.7110000::u1.
free_W :- u1.

0.3871780::u2.
latent_collision :- u2.

0.4977507::u3.
curr_lane :- u3, action(change_to_left).

0.5171051::u4.
curr_lane :- u4, action(change_to_right).

0.6605750::u5.
curr_lane :- u5, action(cruise).

0.3667550::u6.
curr_lane :- u6, action(keep).

0.8028649::u7.
curr_lane :- u7, action(swerve_left).

0.9872093::u8.
curr_lane :- u8, action(swerve_right).

0.4968650::u9.
free_E :- u9, action(change_to_left), \+ curr_lane, \+ free_NE, \+ free_W.

0.4983422::u10.
free_E :- u10, action(change_to_right), \+ curr_lane, \+ free_NE, \+ free_W.

0.5006993::u11.
free_E :- u11, action(cruise), \+ curr_lane, \+ free_NE, \+ free_W.

0.5000000::u12.
free_E :- u12, action(keep), \+ curr_lane, \+ free_NE, \+ free_W.

0.5000000::u13.
free_E :- u13, action(swerve_left), \+ curr_lane, \+ free_NE, \+ free_W.

0.5000000::u14.
free_E :- u14, action(swerve_right), \+ curr_lane, \+ free_NE, \+ free_W.

0.5030035::u15.
free_E :- u15, action(change_to_left), curr_lane, \+ free_NE, \+ free_W.

0.5051985::u16.
free_E :- u16, action(change_to_right), curr_lane, \+ free_NE, \+ free_W.

0.5328686::u17.
free_E :- u17, action(cruise), curr_lane, \+ free_NE, \+ free_W.

0.9524402::u18.
free_E :- u18, action(keep), curr_lane, \+ free_NE, \+ free_W.

0.9990010::u19.
free_E :- u19, action(swerve_left), curr_lane, \+ free_NE, \+ free_W.

0.9130435::u20.
free_E :- u20, action(swerve_right), curr_lane, \+ free_NE, \+ free_W.

0.4987450::u21.
free_E :- u21, action(change_to_left), \+ curr_lane, free_NE, \+ free_W.

0.0123420::u22.
free_E :- u22, action(change_to_right), \+ curr_lane, free_NE, \+ free_W.

0.5029122::u23.
free_E :- u23, action(cruise), \+ curr_lane, free_NE, \+ free_W.

0.2222222::u24.
free_E :- u24, action(keep), \+ curr_lane, free_NE, \+ free_W.

0.5000000::u25.
free_E :- u25, action(swerve_left), \+ curr_lane, free_NE, \+ free_W.

0.5000000::u26.
free_E :- u26, action(swerve_right), \+ curr_lane, free_NE, \+ free_W.

0.5035688::u27.
free_E :- u27, action(change_to_left), curr_lane, free_NE, \+ free_W.

0.5018632::u28.
free_E :- u28, action(change_to_right), curr_lane, free_NE, \+ free_W.

0.9649301::u29.
free_E :- u29, action(cruise), curr_lane, free_NE, \+ free_W.

0.9990010::u30.
free_E :- u30, action(keep), curr_lane, free_NE, \+ free_W.

0.9990010::u31.
free_E :- u31, action(swerve_left), curr_lane, free_NE, \+ free_W.

0.9838710::u32.
free_E :- u32, action(swerve_right), curr_lane, free_NE, \+ free_W.

0.5713760::u33.
free_E :- u33, action(change_to_left), \+ curr_lane, \+ free_NE, free_W.

0.5454874::u34.
free_E :- u34, action(change_to_right), \+ curr_lane, \+ free_NE, free_W.

0.6275102::u35.
free_E :- u35, action(cruise), \+ curr_lane, \+ free_NE, free_W.

0.6612847::u36.
free_E :- u36, action(keep), \+ curr_lane, \+ free_NE, free_W.

0.6133333::u37.
free_E :- u37, action(swerve_left), \+ curr_lane, \+ free_NE, free_W.

0.5000000::u38.
free_E :- u38, action(swerve_right), \+ curr_lane, \+ free_NE, free_W.

0.6125969::u39.
free_E :- u39, action(change_to_left), curr_lane, \+ free_NE, free_W.

0.4994787::u40.
free_E :- u40, action(change_to_right), curr_lane, \+ free_NE, free_W.

0.5365797::u41.
free_E :- u41, action(cruise), curr_lane, \+ free_NE, free_W.

0.8849274::u42.
free_E :- u42, action(keep), curr_lane, \+ free_NE, free_W.

0.8363636::u43.
free_E :- u43, action(swerve_left), curr_lane, \+ free_NE, free_W.

0.9908257::u44.
free_E :- u44, action(swerve_right), curr_lane, \+ free_NE, free_W.

0.5064605::u45.
free_E :- u45, action(change_to_left), \+ curr_lane, free_NE, free_W.

0.6432473::u46.
free_E :- u46, action(change_to_right), \+ curr_lane, free_NE, free_W.

0.4879093::u47.
free_E :- u47, action(cruise), \+ curr_lane, free_NE, free_W.

0.0622995::u48.
free_E :- u48, action(keep), \+ curr_lane, free_NE, free_W.

0.9065421::u49.
free_E :- u49, action(swerve_left), \+ curr_lane, free_NE, free_W.

0.9990010::u50.
free_E :- u50, action(swerve_right), \+ curr_lane, free_NE, free_W.

0.5952819::u51.
free_E :- u51, action(change_to_left), curr_lane, free_NE, free_W.

0.5956234::u52.
free_E :- u52, action(change_to_right), curr_lane, free_NE, free_W.

0.9772886::u53.
free_E :- u53, action(cruise), curr_lane, free_NE, free_W.

0.9890710::u54.
free_E :- u54, action(keep), curr_lane, free_NE, free_W.

0.9990010::u55.
free_E :- u55, action(swerve_left), curr_lane, free_NE, free_W.

0.9990010::u56.
free_E :- u56, action(swerve_right), curr_lane, free_NE, free_W.

0.4910735::u57.
free_NE :- u57, action(change_to_left), \+ curr_lane.

0.5084237::u58.
free_NE :- u58, action(change_to_right), \+ curr_lane.

0.4920088::u59.
free_NE :- u59, action(cruise), \+ curr_lane.

0.1130520::u60.
free_NE :- u60, action(keep), \+ curr_lane.

0.7404844::u61.
free_NE :- u61, action(swerve_left), \+ curr_lane.

0.9990010::u62.
free_NE :- u62, action(swerve_right), \+ curr_lane.

0.4927611::u63.
free_NE :- u63, action(change_to_left), curr_lane.

0.5284966::u64.
free_NE :- u64, action(change_to_right), curr_lane.

0.8333404::u65.
free_NE :- u65, action(cruise), curr_lane.

0.0043260::u66.
free_NE :- u66, action(keep), curr_lane.

0.8912489::u67.
free_NE :- u67, action(swerve_left), curr_lane.

0.8445230::u68.
free_NE :- u68, action(swerve_right), curr_lane.

0.5003977::u69.
free_NW :- u69, action(change_to_left), \+ free_NE, \+ free_SW, \+ free_W.

0.4990753::u70.
free_NW :- u70, action(change_to_right), \+ free_NE, \+ free_SW, \+ free_W.

0.3291139::u71.
free_NW :- u71, action(cruise), \+ free_NE, \+ free_SW, \+ free_W.

0.4072250::u72.
free_NW :- u72, action(keep), \+ free_NE, \+ free_SW, \+ free_W.

0.5000000::u73.
free_NW :- u73, action(swerve_left), \+ free_NE, \+ free_SW, \+ free_W.

0.4285714::u74.
free_NW :- u74, action(swerve_right), \+ free_NE, \+ free_SW, \+ free_W.

0.4996739::u75.
free_NW :- u75, action(change_to_left), free_NE, \+ free_SW, \+ free_W.

0.5034794::u76.
free_NW :- u76, action(change_to_right), free_NE, \+ free_SW, \+ free_W.

0.5158009::u77.
free_NW :- u77, action(cruise), free_NE, \+ free_SW, \+ free_W.

0.0009990::u78.
free_NW :- u78, action(keep), free_NE, \+ free_SW, \+ free_W.

0.9990010::u79.
free_NW :- u79, action(swerve_left), free_NE, \+ free_SW, \+ free_W.

0.3548387::u80.
free_NW :- u80, action(swerve_right), free_NE, \+ free_SW, \+ free_W.

0.5018635::u81.
free_NW :- u81, action(change_to_left), \+ free_NE, free_SW, \+ free_W.

0.4992287::u82.
free_NW :- u82, action(change_to_right), \+ free_NE, free_SW, \+ free_W.

0.3382922::u83.
free_NW :- u83, action(cruise), \+ free_NE, free_SW, \+ free_W.

0.2089411::u84.
free_NW :- u84, action(keep), \+ free_NE, free_SW, \+ free_W.

0.0009990::u85.
free_NW :- u85, action(swerve_left), \+ free_NE, free_SW, \+ free_W.

0.0625000::u86.
free_NW :- u86, action(swerve_right), \+ free_NE, free_SW, \+ free_W.

0.5016484::u87.
free_NW :- u87, action(change_to_left), free_NE, free_SW, \+ free_W.

0.4931389::u88.
free_NW :- u88, action(change_to_right), free_NE, free_SW, \+ free_W.

0.4435881::u89.
free_NW :- u89, action(cruise), free_NE, free_SW, \+ free_W.

0.0009990::u90.
free_NW :- u90, action(keep), free_NE, free_SW, \+ free_W.

0.0009990::u91.
free_NW :- u91, action(swerve_left), free_NE, free_SW, \+ free_W.

0.0009990::u92.
free_NW :- u92, action(swerve_right), free_NE, free_SW, \+ free_W.

0.4690926::u93.
free_NW :- u93, action(change_to_left), \+ free_NE, \+ free_SW, free_W.

0.4628387::u94.
free_NW :- u94, action(change_to_right), \+ free_NE, \+ free_SW, free_W.

0.5681356::u95.
free_NW :- u95, action(cruise), \+ free_NE, \+ free_SW, free_W.

0.4387262::u96.
free_NW :- u96, action(keep), \+ free_NE, \+ free_SW, free_W.

0.8000000::u97.
free_NW :- u97, action(swerve_left), \+ free_NE, \+ free_SW, free_W.

0.5000000::u98.
free_NW :- u98, action(swerve_right), \+ free_NE, \+ free_SW, free_W.

0.4712570::u99.
free_NW :- u99, action(change_to_left), free_NE, \+ free_SW, free_W.

0.4909907::u100.
free_NW :- u100, action(change_to_right), free_NE, \+ free_SW, free_W.

0.3691055::u101.
free_NW :- u101, action(cruise), free_NE, \+ free_SW, free_W.

0.2203390::u102.
free_NW :- u102, action(keep), free_NE, \+ free_SW, free_W.

0.9990010::u103.
free_NW :- u103, action(swerve_left), free_NE, \+ free_SW, free_W.

0.9130435::u104.
free_NW :- u104, action(swerve_right), free_NE, \+ free_SW, free_W.

0.5326339::u105.
free_NW :- u105, action(change_to_left), \+ free_NE, free_SW, free_W.

0.4898435::u106.
free_NW :- u106, action(change_to_right), \+ free_NE, free_SW, free_W.

0.7575287::u107.
free_NW :- u107, action(cruise), \+ free_NE, free_SW, free_W.

0.0062409::u108.
free_NW :- u108, action(keep), \+ free_NE, free_SW, free_W.

0.8181818::u109.
free_NW :- u109, action(swerve_left), \+ free_NE, free_SW, free_W.

0.7238095::u110.
free_NW :- u110, action(swerve_right), \+ free_NE, free_SW, free_W.

0.5388251::u111.
free_NW :- u111, action(change_to_left), free_NE, free_SW, free_W.

0.7017226::u112.
free_NW :- u112, action(change_to_right), free_NE, free_SW, free_W.

0.5859054::u113.
free_NW :- u113, action(cruise), free_NE, free_SW, free_W.

0.0283802::u114.
free_NW :- u114, action(keep), free_NE, free_SW, free_W.

0.9967974::u115.
free_NW :- u115, action(swerve_left), free_NE, free_SW, free_W.

0.9066874::u116.
free_NW :- u116, action(swerve_right), free_NE, free_SW, free_W.

0.5017713::u117.
free_SE :- u117, action(change_to_left), \+ curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.4994506::u118.
free_SE :- u118, action(change_to_right), \+ curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.4939514::u119.
free_SE :- u119, action(cruise), \+ curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.2596844::u120.
free_SE :- u120, action(keep), \+ curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.9990010::u121.
free_SE :- u121, action(swerve_left), \+ curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.5000000::u122.
free_SE :- u122, action(swerve_right), \+ curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.5037436::u123.
free_SE :- u123, action(change_to_left), curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.4956088::u124.
free_SE :- u124, action(change_to_right), curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.5067681::u125.
free_SE :- u125, action(cruise), curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.9942035::u126.
free_SE :- u126, action(keep), curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.9990010::u127.
free_SE :- u127, action(swerve_left), curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.9990010::u128.
free_SE :- u128, action(swerve_right), curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.5103784::u129.
free_SE :- u129, action(change_to_left), \+ curr_lane, free_E, \+ free_NE, \+ free_NW.

0.4947037::u130.
free_SE :- u130, action(change_to_right), \+ curr_lane, free_E, \+ free_NE, \+ free_NW.

0.5137094::u131.
free_SE :- u131, action(cruise), \+ curr_lane, free_E, \+ free_NE, \+ free_NW.

0.3433610::u132.
free_SE :- u132, action(keep), \+ curr_lane, free_E, \+ free_NE, \+ free_NW.

0.9990010::u133.
free_SE :- u133, action(swerve_left), \+ curr_lane, free_E, \+ free_NE, \+ free_NW.

0.5000000::u134.
free_SE :- u134, action(swerve_right), \+ curr_lane, free_E, \+ free_NE, \+ free_NW.

0.5343195::u135.
free_SE :- u135, action(change_to_left), curr_lane, free_E, \+ free_NE, \+ free_NW.

0.5068827::u136.
free_SE :- u136, action(change_to_right), curr_lane, free_E, \+ free_NE, \+ free_NW.

0.5787408::u137.
free_SE :- u137, action(cruise), curr_lane, free_E, \+ free_NE, \+ free_NW.

0.7922483::u138.
free_SE :- u138, action(keep), curr_lane, free_E, \+ free_NE, \+ free_NW.

0.9729730::u139.
free_SE :- u139, action(swerve_left), curr_lane, free_E, \+ free_NE, \+ free_NW.

0.9166667::u140.
free_SE :- u140, action(swerve_right), curr_lane, free_E, \+ free_NE, \+ free_NW.

0.5044221::u141.
free_SE :- u141, action(change_to_left), \+ curr_lane, \+ free_E, free_NE, \+ free_NW.

0.4846265::u142.
free_SE :- u142, action(change_to_right), \+ curr_lane, \+ free_E, free_NE, \+ free_NW.

0.4915316::u143.
free_SE :- u143, action(cruise), \+ curr_lane, \+ free_E, free_NE, \+ free_NW.

0.2642960::u144.
free_SE :- u144, action(keep), \+ curr_lane, \+ free_E, free_NE, \+ free_NW.

0.5000000::u145.
free_SE :- u145, action(swerve_left), \+ curr_lane, \+ free_E, free_NE, \+ free_NW.

0.5000000::u146.
free_SE :- u146, action(swerve_right), \+ curr_lane, \+ free_E, free_NE, \+ free_NW.

0.5038176::u147.
free_SE :- u147, action(change_to_left), curr_lane, \+ free_E, free_NE, \+ free_NW.

0.5056269::u148.
free_SE :- u148, action(change_to_right), curr_lane, \+ free_E, free_NE, \+ free_NW.

0.9817906::u149.
free_SE :- u149, action(cruise), curr_lane, \+ free_E, free_NE, \+ free_NW.

0.9990010::u150.
free_SE :- u150, action(keep), curr_lane, \+ free_E, free_NE, \+ free_NW.

0.5000000::u151.
free_SE :- u151, action(swerve_left), curr_lane, \+ free_E, free_NE, \+ free_NW.

0.9990010::u152.
free_SE :- u152, action(swerve_right), curr_lane, \+ free_E, free_NE, \+ free_NW.

0.5017593::u153.
free_SE :- u153, action(change_to_left), \+ curr_lane, free_E, free_NE, \+ free_NW.

0.3349383::u154.
free_SE :- u154, action(change_to_right), \+ curr_lane, free_E, free_NE, \+ free_NW.

0.5020511::u155.
free_SE :- u155, action(cruise), \+ curr_lane, free_E, free_NE, \+ free_NW.

0.0110497::u156.
free_SE :- u156, action(keep), \+ curr_lane, free_E, free_NE, \+ free_NW.

0.5000000::u157.
free_SE :- u157, action(swerve_left), \+ curr_lane, free_E, free_NE, \+ free_NW.

0.5000000::u158.
free_SE :- u158, action(swerve_right), \+ curr_lane, free_E, free_NE, \+ free_NW.

0.5049286::u159.
free_SE :- u159, action(change_to_left), curr_lane, free_E, free_NE, \+ free_NW.

0.4690864::u160.
free_SE :- u160, action(change_to_right), curr_lane, free_E, free_NE, \+ free_NW.

0.8446197::u161.
free_SE :- u161, action(cruise), curr_lane, free_E, free_NE, \+ free_NW.

0.6888889::u162.
free_SE :- u162, action(keep), curr_lane, free_E, free_NE, \+ free_NW.

0.9990010::u163.
free_SE :- u163, action(swerve_left), curr_lane, free_E, free_NE, \+ free_NW.

0.9017857::u164.
free_SE :- u164, action(swerve_right), curr_lane, free_E, free_NE, \+ free_NW.

0.4454644::u165.
free_SE :- u165, action(change_to_left), \+ curr_lane, \+ free_E, \+ free_NE, free_NW.

0.4259512::u166.
free_SE :- u166, action(change_to_right), \+ curr_lane, \+ free_E, \+ free_NE, free_NW.

0.4991801::u167.
free_SE :- u167, action(cruise), \+ curr_lane, \+ free_E, \+ free_NE, free_NW.

0.7500000::u168.
free_SE :- u168, action(keep), \+ curr_lane, \+ free_E, \+ free_NE, free_NW.

0.6923077::u169.
free_SE :- u169, action(swerve_left), \+ curr_lane, \+ free_E, \+ free_NE, free_NW.

0.5000000::u170.
free_SE :- u170, action(swerve_right), \+ curr_lane, \+ free_E, \+ free_NE, free_NW.

0.6927865::u171.
free_SE :- u171, action(change_to_left), curr_lane, \+ free_E, \+ free_NE, free_NW.

0.5007459::u172.
free_SE :- u172, action(change_to_right), curr_lane, \+ free_E, \+ free_NE, free_NW.

0.4980611::u173.
free_SE :- u173, action(cruise), curr_lane, \+ free_E, \+ free_NE, free_NW.

0.9875776::u174.
free_SE :- u174, action(keep), curr_lane, \+ free_E, \+ free_NE, free_NW.

0.9990010::u175.
free_SE :- u175, action(swerve_left), curr_lane, \+ free_E, \+ free_NE, free_NW.

0.9990010::u176.
free_SE :- u176, action(swerve_right), curr_lane, \+ free_E, \+ free_NE, free_NW.

0.5562946::u177.
free_SE :- u177, action(change_to_left), \+ curr_lane, free_E, \+ free_NE, free_NW.

0.5081951::u178.
free_SE :- u178, action(change_to_right), \+ curr_lane, free_E, \+ free_NE, free_NW.

0.7846895::u179.
free_SE :- u179, action(cruise), \+ curr_lane, free_E, \+ free_NE, free_NW.

0.9294118::u180.
free_SE :- u180, action(keep), \+ curr_lane, free_E, \+ free_NE, free_NW.

0.6097561::u181.
free_SE :- u181, action(swerve_left), \+ curr_lane, free_E, \+ free_NE, free_NW.

0.5000000::u182.
free_SE :- u182, action(swerve_right), \+ curr_lane, free_E, \+ free_NE, free_NW.

0.7801832::u183.
free_SE :- u183, action(change_to_left), curr_lane, free_E, \+ free_NE, free_NW.

0.4996507::u184.
free_SE :- u184, action(change_to_right), curr_lane, free_E, \+ free_NE, free_NW.

0.5411985::u185.
free_SE :- u185, action(cruise), curr_lane, free_E, \+ free_NE, free_NW.

0.7675496::u186.
free_SE :- u186, action(keep), curr_lane, free_E, \+ free_NE, free_NW.

0.7671233::u187.
free_SE :- u187, action(swerve_left), curr_lane, free_E, \+ free_NE, free_NW.

0.9876543::u188.
free_SE :- u188, action(swerve_right), curr_lane, free_E, \+ free_NE, free_NW.

0.5120927::u189.
free_SE :- u189, action(change_to_left), \+ curr_lane, \+ free_E, free_NE, free_NW.

0.4798661::u190.
free_SE :- u190, action(change_to_right), \+ curr_lane, \+ free_E, free_NE, free_NW.

0.4041693::u191.
free_SE :- u191, action(cruise), \+ curr_lane, \+ free_E, free_NE, free_NW.

0.8571429::u192.
free_SE :- u192, action(keep), \+ curr_lane, \+ free_E, free_NE, free_NW.

0.0500000::u193.
free_SE :- u193, action(swerve_left), \+ curr_lane, \+ free_E, free_NE, free_NW.

0.5000000::u194.
free_SE :- u194, action(swerve_right), \+ curr_lane, \+ free_E, free_NE, free_NW.

0.6761448::u195.
free_SE :- u195, action(change_to_left), curr_lane, \+ free_E, free_NE, free_NW.

0.4962488::u196.
free_SE :- u196, action(change_to_right), curr_lane, \+ free_E, free_NE, free_NW.

0.9618933::u197.
free_SE :- u197, action(cruise), curr_lane, \+ free_E, free_NE, free_NW.

0.9990010::u198.
free_SE :- u198, action(keep), curr_lane, \+ free_E, free_NE, free_NW.

0.5000000::u199.
free_SE :- u199, action(swerve_left), curr_lane, \+ free_E, free_NE, free_NW.

0.5000000::u200.
free_SE :- u200, action(swerve_right), curr_lane, \+ free_E, free_NE, free_NW.

0.5104489::u201.
free_SE :- u201, action(change_to_left), \+ curr_lane, free_E, free_NE, free_NW.

0.1212121::u202.
free_SE :- u202, action(change_to_right), \+ curr_lane, free_E, free_NE, free_NW.

0.8251940::u203.
free_SE :- u203, action(cruise), \+ curr_lane, free_E, free_NE, free_NW.

0.9558824::u204.
free_SE :- u204, action(keep), \+ curr_lane, free_E, free_NE, free_NW.

0.9072165::u205.
free_SE :- u205, action(swerve_left), \+ curr_lane, free_E, free_NE, free_NW.

0.9990010::u206.
free_SE :- u206, action(swerve_right), \+ curr_lane, free_E, free_NE, free_NW.

0.7862570::u207.
free_SE :- u207, action(change_to_left), curr_lane, free_E, free_NE, free_NW.

0.4744621::u208.
free_SE :- u208, action(change_to_right), curr_lane, free_E, free_NE, free_NW.

0.8593047::u209.
free_SE :- u209, action(cruise), curr_lane, free_E, free_NE, free_NW.

0.9833333::u210.
free_SE :- u210, action(keep), curr_lane, free_E, free_NE, free_NW.

0.9865643::u211.
free_SE :- u211, action(swerve_left), curr_lane, free_E, free_NE, free_NW.

0.9486755::u212.
free_SE :- u212, action(swerve_right), curr_lane, free_E, free_NE, free_NW.

0.7806714::u213.
free_SW :- u213, \+ curr_lane.

0.5995049::u214.
free_SW :- u214, curr_lane.

