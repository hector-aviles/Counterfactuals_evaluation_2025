%%% Exogenous variables

0.1679106::u_action(change_to_left); 0.1700363::u_action(change_to_right); 0.4048135::u_action(cruise); 0.2548638::u_action(keep); 0.0015067::u_action(swerve_left); 0.0008691::u_action(swerve_right)
action(V) :- u_action(V).

0.7115994::u1.
free_W :- u1.

0.3852158::u2.
latent_collision :- u2.

0.4981077::u3.
curr_lane :- u3, action(change_to_left).

0.5161483::u4.
curr_lane :- u4, action(change_to_right).

0.6573528::u5.
curr_lane :- u5, action(cruise).

0.3659034::u6.
curr_lane :- u6, action(keep).

0.8210884::u7.
curr_lane :- u7, action(swerve_left).

0.9941038::u8.
curr_lane :- u8, action(swerve_right).

0.5006257::u9.
free_E :- u9, action(change_to_left), \+ curr_lane, \+ free_NE, \+ free_W.

0.4991326::u10.
free_E :- u10, action(change_to_right), \+ curr_lane, \+ free_NE, \+ free_W.

0.5006044::u11.
free_E :- u11, action(cruise), \+ curr_lane, \+ free_NE, \+ free_W.

0.5000000::u12.
free_E :- u12, action(keep), \+ curr_lane, \+ free_NE, \+ free_W.

0.5000000::u13.
free_E :- u13, action(swerve_left), \+ curr_lane, \+ free_NE, \+ free_W.

0.5000000::u14.
free_E :- u14, action(swerve_right), \+ curr_lane, \+ free_NE, \+ free_W.

0.5038833::u15.
free_E :- u15, action(change_to_left), curr_lane, \+ free_NE, \+ free_W.

0.5049158::u16.
free_E :- u16, action(change_to_right), curr_lane, \+ free_NE, \+ free_W.

0.5323534::u17.
free_E :- u17, action(cruise), curr_lane, \+ free_NE, \+ free_W.

0.9523536::u18.
free_E :- u18, action(keep), curr_lane, \+ free_NE, \+ free_W.

0.9990010::u19.
free_E :- u19, action(swerve_left), curr_lane, \+ free_NE, \+ free_W.

0.9523810::u20.
free_E :- u20, action(swerve_right), curr_lane, \+ free_NE, \+ free_W.

0.5009547::u21.
free_E :- u21, action(change_to_left), \+ curr_lane, free_NE, \+ free_W.

0.0111881::u22.
free_E :- u22, action(change_to_right), \+ curr_lane, free_NE, \+ free_W.

0.5000000::u23.
free_E :- u23, action(cruise), \+ curr_lane, free_NE, \+ free_W.

0.2000000::u24.
free_E :- u24, action(keep), \+ curr_lane, free_NE, \+ free_W.

0.5000000::u25.
free_E :- u25, action(swerve_left), \+ curr_lane, free_NE, \+ free_W.

0.5000000::u26.
free_E :- u26, action(swerve_right), \+ curr_lane, free_NE, \+ free_W.

0.5003730::u27.
free_E :- u27, action(change_to_left), curr_lane, free_NE, \+ free_W.

0.5004974::u28.
free_E :- u28, action(change_to_right), curr_lane, free_NE, \+ free_W.

0.9650713::u29.
free_E :- u29, action(cruise), curr_lane, free_NE, \+ free_W.

0.9990010::u30.
free_E :- u30, action(keep), curr_lane, free_NE, \+ free_W.

0.9990010::u31.
free_E :- u31, action(swerve_left), curr_lane, free_NE, \+ free_W.

0.9687500::u32.
free_E :- u32, action(swerve_right), curr_lane, free_NE, \+ free_W.

0.5133062::u33.
free_E :- u33, action(change_to_left), \+ curr_lane, \+ free_NE, free_W.

0.4802734::u34.
free_E :- u34, action(change_to_right), \+ curr_lane, \+ free_NE, free_W.

0.5870359::u35.
free_E :- u35, action(cruise), \+ curr_lane, \+ free_NE, free_W.

0.6626988::u36.
free_E :- u36, action(keep), \+ curr_lane, \+ free_NE, free_W.

0.5593220::u37.
free_E :- u37, action(swerve_left), \+ curr_lane, \+ free_NE, free_W.

0.5000000::u38.
free_E :- u38, action(swerve_right), \+ curr_lane, \+ free_NE, free_W.

0.6121680::u39.
free_E :- u39, action(change_to_left), curr_lane, \+ free_NE, free_W.

0.5003478::u40.
free_E :- u40, action(change_to_right), curr_lane, \+ free_NE, free_W.

0.5385083::u41.
free_E :- u41, action(cruise), curr_lane, \+ free_NE, free_W.

0.8879937::u42.
free_E :- u42, action(keep), curr_lane, \+ free_NE, free_W.

0.8461538::u43.
free_E :- u43, action(swerve_left), curr_lane, \+ free_NE, free_W.

0.9910714::u44.
free_E :- u44, action(swerve_right), curr_lane, \+ free_NE, free_W.

0.5048197::u45.
free_E :- u45, action(change_to_left), \+ curr_lane, free_NE, free_W.

0.6460139::u46.
free_E :- u46, action(change_to_right), \+ curr_lane, free_NE, free_W.

0.4891727::u47.
free_E :- u47, action(cruise), \+ curr_lane, free_NE, free_W.

0.0629775::u48.
free_E :- u48, action(keep), \+ curr_lane, free_NE, free_W.

0.8970588::u49.
free_E :- u49, action(swerve_left), \+ curr_lane, free_NE, free_W.

0.9990010::u50.
free_E :- u50, action(swerve_right), \+ curr_lane, free_NE, free_W.

0.5943721::u51.
free_E :- u51, action(change_to_left), curr_lane, free_NE, free_W.

0.5965498::u52.
free_E :- u52, action(change_to_right), curr_lane, free_NE, free_W.

0.9772938::u53.
free_E :- u53, action(cruise), curr_lane, free_NE, free_W.

0.9941860::u54.
free_E :- u54, action(keep), curr_lane, free_NE, free_W.

0.9990010::u55.
free_E :- u55, action(swerve_left), curr_lane, free_NE, free_W.

0.9990010::u56.
free_E :- u56, action(swerve_right), curr_lane, free_NE, free_W.

0.4906048::u57.
free_NE :- u57, action(change_to_left), \+ curr_lane.

0.5080540::u58.
free_NE :- u58, action(change_to_right), \+ curr_lane.

0.4874237::u59.
free_NE :- u59, action(cruise), \+ curr_lane.

0.1129207::u60.
free_NE :- u60, action(keep), \+ curr_lane.

0.7756654::u61.
free_NE :- u61, action(swerve_left), \+ curr_lane.

0.9990010::u62.
free_NE :- u62, action(swerve_right), \+ curr_lane.

0.4920407::u63.
free_NE :- u63, action(change_to_left), curr_lane.

0.5286060::u64.
free_NE :- u64, action(change_to_right), curr_lane.

0.8348355::u65.
free_NE :- u65, action(cruise), curr_lane.

0.0040775::u66.
free_NE :- u66, action(keep), curr_lane.

0.8873239::u67.
free_NE :- u67, action(swerve_left), curr_lane.

0.8422301::u68.
free_NE :- u68, action(swerve_right), curr_lane.

0.4960258::u69.
free_NW :- u69, action(change_to_left), \+ free_NE, \+ free_SW, \+ free_W.

0.5026355::u70.
free_NW :- u70, action(change_to_right), \+ free_NE, \+ free_SW, \+ free_W.

0.3330487::u71.
free_NW :- u71, action(cruise), \+ free_NE, \+ free_SW, \+ free_W.

0.4048203::u72.
free_NW :- u72, action(keep), \+ free_NE, \+ free_SW, \+ free_W.

0.7000000::u73.
free_NW :- u73, action(swerve_left), \+ free_NE, \+ free_SW, \+ free_W.

0.4285714::u74.
free_NW :- u74, action(swerve_right), \+ free_NE, \+ free_SW, \+ free_W.

0.5010030::u75.
free_NW :- u75, action(change_to_left), free_NE, \+ free_SW, \+ free_W.

0.5000000::u76.
free_NW :- u76, action(change_to_right), free_NE, \+ free_SW, \+ free_W.

0.5122356::u77.
free_NW :- u77, action(cruise), free_NE, \+ free_SW, \+ free_W.

0.0009990::u78.
free_NW :- u78, action(keep), free_NE, \+ free_SW, \+ free_W.

0.5000000::u79.
free_NW :- u79, action(swerve_left), free_NE, \+ free_SW, \+ free_W.

0.3666667::u80.
free_NW :- u80, action(swerve_right), free_NE, \+ free_SW, \+ free_W.

0.5030406::u81.
free_NW :- u81, action(change_to_left), \+ free_NE, free_SW, \+ free_W.

0.4937457::u82.
free_NW :- u82, action(change_to_right), \+ free_NE, free_SW, \+ free_W.

0.3430441::u83.
free_NW :- u83, action(cruise), \+ free_NE, free_SW, \+ free_W.

0.2104726::u84.
free_NW :- u84, action(keep), \+ free_NE, free_SW, \+ free_W.

0.0009990::u85.
free_NW :- u85, action(swerve_left), \+ free_NE, free_SW, \+ free_W.

0.0009990::u86.
free_NW :- u86, action(swerve_right), \+ free_NE, free_SW, \+ free_W.

0.4984306::u87.
free_NW :- u87, action(change_to_left), free_NE, free_SW, \+ free_W.

0.4968313::u88.
free_NW :- u88, action(change_to_right), free_NE, free_SW, \+ free_W.

0.4419126::u89.
free_NW :- u89, action(cruise), free_NE, free_SW, \+ free_W.

0.0009990::u90.
free_NW :- u90, action(keep), free_NE, free_SW, \+ free_W.

0.0009990::u91.
free_NW :- u91, action(swerve_left), free_NE, free_SW, \+ free_W.

0.0294118::u92.
free_NW :- u92, action(swerve_right), free_NE, free_SW, \+ free_W.

0.5348501::u93.
free_NW :- u93, action(change_to_left), \+ free_NE, \+ free_SW, free_W.

0.5323963::u94.
free_NW :- u94, action(change_to_right), \+ free_NE, \+ free_SW, free_W.

0.6549961::u95.
free_NW :- u95, action(cruise), \+ free_NE, \+ free_SW, free_W.

0.4281379::u96.
free_NW :- u96, action(keep), \+ free_NE, \+ free_SW, free_W.

0.7142857::u97.
free_NW :- u97, action(swerve_left), \+ free_NE, \+ free_SW, free_W.

0.6000000::u98.
free_NW :- u98, action(swerve_right), \+ free_NE, \+ free_SW, free_W.

0.4686554::u99.
free_NW :- u99, action(change_to_left), free_NE, \+ free_SW, free_W.

0.4882054::u100.
free_NW :- u100, action(change_to_right), free_NE, \+ free_SW, free_W.

0.3699330::u101.
free_NW :- u101, action(cruise), free_NE, \+ free_SW, free_W.

0.1800000::u102.
free_NW :- u102, action(keep), free_NE, \+ free_SW, free_W.

0.7500000::u103.
free_NW :- u103, action(swerve_left), free_NE, \+ free_SW, free_W.

0.8571429::u104.
free_NW :- u104, action(swerve_right), free_NE, \+ free_SW, free_W.

0.5316919::u105.
free_NW :- u105, action(change_to_left), \+ free_NE, free_SW, free_W.

0.4880174::u106.
free_NW :- u106, action(change_to_right), \+ free_NE, free_SW, free_W.

0.7595928::u107.
free_NW :- u107, action(cruise), \+ free_NE, free_SW, free_W.

0.0060893::u108.
free_NW :- u108, action(keep), \+ free_NE, free_SW, free_W.

0.8387097::u109.
free_NW :- u109, action(swerve_left), \+ free_NE, free_SW, free_W.

0.7196262::u110.
free_NW :- u110, action(swerve_right), \+ free_NE, free_SW, free_W.

0.5405018::u111.
free_NW :- u111, action(change_to_left), free_NE, free_SW, free_W.

0.7011656::u112.
free_NW :- u112, action(change_to_right), free_NE, free_SW, free_W.

0.5853836::u113.
free_NW :- u113, action(cruise), free_NE, free_SW, free_W.

0.0285177::u114.
free_NW :- u114, action(keep), free_NE, free_SW, free_W.

0.9928797::u115.
free_NW :- u115, action(swerve_left), free_NE, free_SW, free_W.

0.8984127::u116.
free_NW :- u116, action(swerve_right), free_NE, free_SW, free_W.

0.4997519::u117.
free_SE :- u117, action(change_to_left), \+ curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.5029551::u118.
free_SE :- u118, action(change_to_right), \+ curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.4967111::u119.
free_SE :- u119, action(cruise), \+ curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.2607589::u120.
free_SE :- u120, action(keep), \+ curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.9990010::u121.
free_SE :- u121, action(swerve_left), \+ curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.5000000::u122.
free_SE :- u122, action(swerve_right), \+ curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.5092893::u123.
free_SE :- u123, action(change_to_left), curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.5002490::u124.
free_SE :- u124, action(change_to_right), curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.4954873::u125.
free_SE :- u125, action(cruise), curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.9937207::u126.
free_SE :- u126, action(keep), curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.9990010::u127.
free_SE :- u127, action(swerve_left), curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.9990010::u128.
free_SE :- u128, action(swerve_right), curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.5766580::u129.
free_SE :- u129, action(change_to_left), \+ curr_lane, free_E, \+ free_NE, \+ free_NW.

0.5634430::u130.
free_SE :- u130, action(change_to_right), \+ curr_lane, free_E, \+ free_NE, \+ free_NW.

0.5827338::u131.
free_SE :- u131, action(cruise), \+ curr_lane, free_E, \+ free_NE, \+ free_NW.

0.3451222::u132.
free_SE :- u132, action(keep), \+ curr_lane, free_E, \+ free_NE, \+ free_NW.

0.9990010::u133.
free_SE :- u133, action(swerve_left), \+ curr_lane, free_E, \+ free_NE, \+ free_NW.

0.5000000::u134.
free_SE :- u134, action(swerve_right), \+ curr_lane, free_E, \+ free_NE, \+ free_NW.

0.5447701::u135.
free_SE :- u135, action(change_to_left), curr_lane, free_E, \+ free_NE, \+ free_NW.

0.5172953::u136.
free_SE :- u136, action(change_to_right), curr_lane, free_E, \+ free_NE, \+ free_NW.

0.5754589::u137.
free_SE :- u137, action(cruise), curr_lane, free_E, \+ free_NE, \+ free_NW.

0.7922198::u138.
free_SE :- u138, action(keep), curr_lane, free_E, \+ free_NE, \+ free_NW.

0.9722222::u139.
free_SE :- u139, action(swerve_left), curr_lane, free_E, \+ free_NE, \+ free_NW.

0.8775510::u140.
free_SE :- u140, action(swerve_right), curr_lane, free_E, \+ free_NE, \+ free_NW.

0.5087437::u141.
free_SE :- u141, action(change_to_left), \+ curr_lane, \+ free_E, free_NE, \+ free_NW.

0.4838926::u142.
free_SE :- u142, action(change_to_right), \+ curr_lane, \+ free_E, free_NE, \+ free_NW.

0.4926157::u143.
free_SE :- u143, action(cruise), \+ curr_lane, \+ free_E, free_NE, \+ free_NW.

0.2583568::u144.
free_SE :- u144, action(keep), \+ curr_lane, \+ free_E, free_NE, \+ free_NW.

0.9990010::u145.
free_SE :- u145, action(swerve_left), \+ curr_lane, \+ free_E, free_NE, \+ free_NW.

0.5000000::u146.
free_SE :- u146, action(swerve_right), \+ curr_lane, \+ free_E, free_NE, \+ free_NW.

0.5037228::u147.
free_SE :- u147, action(change_to_left), curr_lane, \+ free_E, free_NE, \+ free_NW.

0.5009484::u148.
free_SE :- u148, action(change_to_right), curr_lane, \+ free_E, free_NE, \+ free_NW.

0.9809613::u149.
free_SE :- u149, action(cruise), curr_lane, \+ free_E, free_NE, \+ free_NW.

0.5000000::u150.
free_SE :- u150, action(keep), curr_lane, \+ free_E, free_NE, \+ free_NW.

0.5000000::u151.
free_SE :- u151, action(swerve_left), curr_lane, \+ free_E, free_NE, \+ free_NW.

0.9990010::u152.
free_SE :- u152, action(swerve_right), curr_lane, \+ free_E, free_NE, \+ free_NW.

0.4951466::u153.
free_SE :- u153, action(change_to_left), \+ curr_lane, free_E, free_NE, \+ free_NW.

0.3237582::u154.
free_SE :- u154, action(change_to_right), \+ curr_lane, free_E, free_NE, \+ free_NW.

0.4926852::u155.
free_SE :- u155, action(cruise), \+ curr_lane, free_E, free_NE, \+ free_NW.

0.0065646::u156.
free_SE :- u156, action(keep), \+ curr_lane, free_E, free_NE, \+ free_NW.

0.5000000::u157.
free_SE :- u157, action(swerve_left), \+ curr_lane, free_E, free_NE, \+ free_NW.

0.5000000::u158.
free_SE :- u158, action(swerve_right), \+ curr_lane, free_E, free_NE, \+ free_NW.

0.5069814::u159.
free_SE :- u159, action(change_to_left), curr_lane, free_E, free_NE, \+ free_NW.

0.4620769::u160.
free_SE :- u160, action(change_to_right), curr_lane, free_E, free_NE, \+ free_NW.

0.8429109::u161.
free_SE :- u161, action(cruise), curr_lane, free_E, free_NE, \+ free_NW.

0.6621622::u162.
free_SE :- u162, action(keep), curr_lane, free_E, free_NE, \+ free_NW.

0.9990010::u163.
free_SE :- u163, action(swerve_left), curr_lane, free_E, free_NE, \+ free_NW.

0.9316239::u164.
free_SE :- u164, action(swerve_right), curr_lane, free_E, free_NE, \+ free_NW.

0.5166177::u165.
free_SE :- u165, action(change_to_left), \+ curr_lane, \+ free_E, \+ free_NE, free_NW.

0.4972475::u166.
free_SE :- u166, action(change_to_right), \+ curr_lane, \+ free_E, \+ free_NE, free_NW.

0.5857025::u167.
free_SE :- u167, action(cruise), \+ curr_lane, \+ free_E, \+ free_NE, free_NW.

0.7812500::u168.
free_SE :- u168, action(keep), \+ curr_lane, \+ free_E, \+ free_NE, free_NW.

0.7200000::u169.
free_SE :- u169, action(swerve_left), \+ curr_lane, \+ free_E, \+ free_NE, free_NW.

0.5000000::u170.
free_SE :- u170, action(swerve_right), \+ curr_lane, \+ free_E, \+ free_NE, free_NW.

0.6885813::u171.
free_SE :- u171, action(change_to_left), curr_lane, \+ free_E, \+ free_NE, free_NW.

0.4976582::u172.
free_SE :- u172, action(change_to_right), curr_lane, \+ free_E, \+ free_NE, free_NW.

0.5034291::u173.
free_SE :- u173, action(cruise), curr_lane, \+ free_E, \+ free_NE, free_NW.

0.9937500::u174.
free_SE :- u174, action(keep), curr_lane, \+ free_E, \+ free_NE, free_NW.

0.9990010::u175.
free_SE :- u175, action(swerve_left), curr_lane, \+ free_E, \+ free_NE, free_NW.

0.9990010::u176.
free_SE :- u176, action(swerve_right), curr_lane, \+ free_E, \+ free_NE, free_NW.

0.5579669::u177.
free_SE :- u177, action(change_to_left), \+ curr_lane, free_E, \+ free_NE, free_NW.

0.5017270::u178.
free_SE :- u178, action(change_to_right), \+ curr_lane, free_E, \+ free_NE, free_NW.

0.7880493::u179.
free_SE :- u179, action(cruise), \+ curr_lane, free_E, \+ free_NE, free_NW.

0.9527897::u180.
free_SE :- u180, action(keep), \+ curr_lane, free_E, \+ free_NE, free_NW.

0.6785714::u181.
free_SE :- u181, action(swerve_left), \+ curr_lane, free_E, \+ free_NE, free_NW.

0.5000000::u182.
free_SE :- u182, action(swerve_right), \+ curr_lane, free_E, \+ free_NE, free_NW.

0.7740461::u183.
free_SE :- u183, action(change_to_left), curr_lane, free_E, \+ free_NE, free_NW.

0.5000497::u184.
free_SE :- u184, action(change_to_right), curr_lane, free_E, \+ free_NE, free_NW.

0.5418156::u185.
free_SE :- u185, action(cruise), curr_lane, free_E, \+ free_NE, free_NW.

0.7671213::u186.
free_SE :- u186, action(keep), curr_lane, free_E, \+ free_NE, free_NW.

0.7195122::u187.
free_SE :- u187, action(swerve_left), curr_lane, free_E, \+ free_NE, free_NW.

0.9878049::u188.
free_SE :- u188, action(swerve_right), curr_lane, free_E, \+ free_NE, free_NW.

0.5078202::u189.
free_SE :- u189, action(change_to_left), \+ curr_lane, \+ free_E, free_NE, free_NW.

0.4852219::u190.
free_SE :- u190, action(change_to_right), \+ curr_lane, \+ free_E, free_NE, free_NW.

0.4043048::u191.
free_SE :- u191, action(cruise), \+ curr_lane, \+ free_E, free_NE, free_NW.

0.9000000::u192.
free_SE :- u192, action(keep), \+ curr_lane, \+ free_E, free_NE, free_NW.

0.1000000::u193.
free_SE :- u193, action(swerve_left), \+ curr_lane, \+ free_E, free_NE, free_NW.

0.5000000::u194.
free_SE :- u194, action(swerve_right), \+ curr_lane, \+ free_E, free_NE, free_NW.

0.6785538::u195.
free_SE :- u195, action(change_to_left), curr_lane, \+ free_E, free_NE, free_NW.

0.5010810::u196.
free_SE :- u196, action(change_to_right), curr_lane, \+ free_E, free_NE, free_NW.

0.9645914::u197.
free_SE :- u197, action(cruise), curr_lane, \+ free_E, free_NE, free_NW.

0.9990010::u198.
free_SE :- u198, action(keep), curr_lane, \+ free_E, free_NE, free_NW.

0.5000000::u199.
free_SE :- u199, action(swerve_left), curr_lane, \+ free_E, free_NE, free_NW.

0.5000000::u200.
free_SE :- u200, action(swerve_right), curr_lane, \+ free_E, free_NE, free_NW.

0.5153487::u201.
free_SE :- u201, action(change_to_left), \+ curr_lane, free_E, free_NE, free_NW.

0.1180689::u202.
free_SE :- u202, action(change_to_right), \+ curr_lane, free_E, free_NE, free_NW.

0.8284827::u203.
free_SE :- u203, action(cruise), \+ curr_lane, free_E, free_NE, free_NW.

0.9423077::u204.
free_SE :- u204, action(keep), \+ curr_lane, free_E, free_NE, free_NW.

0.8907104::u205.
free_SE :- u205, action(swerve_left), \+ curr_lane, free_E, free_NE, free_NW.

0.9990010::u206.
free_SE :- u206, action(swerve_right), \+ curr_lane, free_E, free_NE, free_NW.

0.7927621::u207.
free_SE :- u207, action(change_to_left), curr_lane, free_E, free_NE, free_NW.

0.4626043::u208.
free_SE :- u208, action(change_to_right), curr_lane, free_E, free_NE, free_NW.

0.8574438::u209.
free_SE :- u209, action(cruise), curr_lane, free_E, free_NE, free_NW.

0.9898305::u210.
free_SE :- u210, action(keep), curr_lane, free_E, free_NE, free_NW.

0.9886686::u211.
free_SE :- u211, action(swerve_left), curr_lane, free_E, free_NE, free_NW.

0.9560068::u212.
free_SE :- u212, action(swerve_right), curr_lane, free_E, free_NE, free_NW.

0.7761583::u213.
free_SW :- u213, \+ curr_lane.

0.6002143::u214.
free_SW :- u214, curr_lane.

