%%% Exogenous variables

0.1675717::u_action(change_to_left); 0.1699710::u_action(change_to_right); 0.4053351::u_action(cruise); 0.2547761::u_action(keep); 0.0014656::u_action(swerve_left); 0.0008804::u_action(swerve_right)
action(V) :- u_action(V).

0.7159582::u1.
free_W :- u1.

0.3854660::u2.
latent_collision :- u2.

0.4970672::u3.
curr_lane :- u3, action(change_to_left).

0.5183010::u4.
curr_lane :- u4, action(change_to_right).

0.6561613::u5.
curr_lane :- u5, action(cruise).

0.3662307::u6.
curr_lane :- u6, action(keep).

0.8118881::u7.
curr_lane :- u7, action(swerve_left).

0.9953434::u8.
curr_lane :- u8, action(swerve_right).

0.4629551::u9.
free_E :- u9, action(change_to_left), \+ curr_lane, \+ free_NE, \+ free_W.

0.4629480::u10.
free_E :- u10, action(change_to_right), \+ curr_lane, \+ free_NE, \+ free_W.

0.4334393::u11.
free_E :- u11, action(cruise), \+ curr_lane, \+ free_NE, \+ free_W.

0.5000000::u12.
free_E :- u12, action(keep), \+ curr_lane, \+ free_NE, \+ free_W.

0.5000000::u13.
free_E :- u13, action(swerve_left), \+ curr_lane, \+ free_NE, \+ free_W.

0.5000000::u14.
free_E :- u14, action(swerve_right), \+ curr_lane, \+ free_NE, \+ free_W.

0.5091631::u15.
free_E :- u15, action(change_to_left), curr_lane, \+ free_NE, \+ free_W.

0.5035336::u16.
free_E :- u16, action(change_to_right), curr_lane, \+ free_NE, \+ free_W.

0.5331439::u17.
free_E :- u17, action(cruise), curr_lane, \+ free_NE, \+ free_W.

0.9497906::u18.
free_E :- u18, action(keep), curr_lane, \+ free_NE, \+ free_W.

0.9990010::u19.
free_E :- u19, action(swerve_left), curr_lane, \+ free_NE, \+ free_W.

0.9333333::u20.
free_E :- u20, action(swerve_right), curr_lane, \+ free_NE, \+ free_W.

0.5041434::u21.
free_E :- u21, action(change_to_left), \+ curr_lane, free_NE, \+ free_W.

0.0103428::u22.
free_E :- u22, action(change_to_right), \+ curr_lane, free_NE, \+ free_W.

0.5014967::u23.
free_E :- u23, action(cruise), \+ curr_lane, free_NE, \+ free_W.

0.2000000::u24.
free_E :- u24, action(keep), \+ curr_lane, free_NE, \+ free_W.

0.5000000::u25.
free_E :- u25, action(swerve_left), \+ curr_lane, free_NE, \+ free_W.

0.5000000::u26.
free_E :- u26, action(swerve_right), \+ curr_lane, free_NE, \+ free_W.

0.4985526::u27.
free_E :- u27, action(change_to_left), curr_lane, free_NE, \+ free_W.

0.4982097::u28.
free_E :- u28, action(change_to_right), curr_lane, free_NE, \+ free_W.

0.9647503::u29.
free_E :- u29, action(cruise), curr_lane, free_NE, \+ free_W.

0.9990010::u30.
free_E :- u30, action(keep), curr_lane, free_NE, \+ free_W.

0.9990010::u31.
free_E :- u31, action(swerve_left), curr_lane, free_NE, \+ free_W.

0.9661017::u32.
free_E :- u32, action(swerve_right), curr_lane, free_NE, \+ free_W.

0.5406924::u33.
free_E :- u33, action(change_to_left), \+ curr_lane, \+ free_NE, free_W.

0.5182104::u34.
free_E :- u34, action(change_to_right), \+ curr_lane, \+ free_NE, free_W.

0.5936128::u35.
free_E :- u35, action(cruise), \+ curr_lane, \+ free_NE, free_W.

0.6606084::u36.
free_E :- u36, action(keep), \+ curr_lane, \+ free_NE, free_W.

0.5890411::u37.
free_E :- u37, action(swerve_left), \+ curr_lane, \+ free_NE, free_W.

0.5000000::u38.
free_E :- u38, action(swerve_right), \+ curr_lane, \+ free_NE, free_W.

0.6132093::u39.
free_E :- u39, action(change_to_left), curr_lane, \+ free_NE, free_W.

0.5010937::u40.
free_E :- u40, action(change_to_right), curr_lane, \+ free_NE, free_W.

0.5360294::u41.
free_E :- u41, action(cruise), curr_lane, \+ free_NE, free_W.

0.8864621::u42.
free_E :- u42, action(keep), curr_lane, \+ free_NE, free_W.

0.8541667::u43.
free_E :- u43, action(swerve_left), curr_lane, \+ free_NE, free_W.

0.9990010::u44.
free_E :- u44, action(swerve_right), curr_lane, \+ free_NE, free_W.

0.5030020::u45.
free_E :- u45, action(change_to_left), \+ curr_lane, free_NE, free_W.

0.6439175::u46.
free_E :- u46, action(change_to_right), \+ curr_lane, free_NE, free_W.

0.4862544::u47.
free_E :- u47, action(cruise), \+ curr_lane, free_NE, free_W.

0.0614172::u48.
free_E :- u48, action(keep), \+ curr_lane, free_NE, free_W.

0.9081633::u49.
free_E :- u49, action(swerve_left), \+ curr_lane, free_NE, free_W.

0.9990010::u50.
free_E :- u50, action(swerve_right), \+ curr_lane, free_NE, free_W.

0.5959857::u51.
free_E :- u51, action(change_to_left), curr_lane, free_NE, free_W.

0.5968289::u52.
free_E :- u52, action(change_to_right), curr_lane, free_NE, free_W.

0.9774067::u53.
free_E :- u53, action(cruise), curr_lane, free_NE, free_W.

0.9851190::u54.
free_E :- u54, action(keep), curr_lane, free_NE, free_W.

0.9990431::u55.
free_E :- u55, action(swerve_left), curr_lane, free_NE, free_W.

0.9990010::u56.
free_E :- u56, action(swerve_right), curr_lane, free_NE, free_W.

0.4887021::u57.
free_NE :- u57, action(change_to_left), \+ curr_lane.

0.5082369::u58.
free_NE :- u58, action(change_to_right), \+ curr_lane.

0.4864577::u59.
free_NE :- u59, action(cruise), \+ curr_lane.

0.1136134::u60.
free_NE :- u60, action(keep), \+ curr_lane.

0.7286245::u61.
free_NE :- u61, action(swerve_left), \+ curr_lane.

0.9990010::u62.
free_NE :- u62, action(swerve_right), \+ curr_lane.

0.4942106::u63.
free_NE :- u63, action(change_to_left), curr_lane.

0.5289108::u64.
free_NE :- u64, action(change_to_right), curr_lane.

0.8334207::u65.
free_NE :- u65, action(cruise), curr_lane.

0.0040203::u66.
free_NE :- u66, action(keep), curr_lane.

0.9043928::u67.
free_NE :- u67, action(swerve_left), curr_lane.

0.8596491::u68.
free_NE :- u68, action(swerve_right), curr_lane.

0.5336970::u69.
free_NW :- u69, action(change_to_left), \+ free_NE, \+ free_SW, \+ free_W.

0.5338218::u70.
free_NW :- u70, action(change_to_right), \+ free_NE, \+ free_SW, \+ free_W.

0.3560376::u71.
free_NW :- u71, action(cruise), \+ free_NE, \+ free_SW, \+ free_W.

0.3916226::u72.
free_NW :- u72, action(keep), \+ free_NE, \+ free_SW, \+ free_W.

0.8000000::u73.
free_NW :- u73, action(swerve_left), \+ free_NE, \+ free_SW, \+ free_W.

0.2500000::u74.
free_NW :- u74, action(swerve_right), \+ free_NE, \+ free_SW, \+ free_W.

0.5036083::u75.
free_NW :- u75, action(change_to_left), free_NE, \+ free_SW, \+ free_W.

0.4998674::u76.
free_NW :- u76, action(change_to_right), free_NE, \+ free_SW, \+ free_W.

0.5152347::u77.
free_NW :- u77, action(cruise), free_NE, \+ free_SW, \+ free_W.

0.0009990::u78.
free_NW :- u78, action(keep), free_NE, \+ free_SW, \+ free_W.

0.5000000::u79.
free_NW :- u79, action(swerve_left), free_NE, \+ free_SW, \+ free_W.

0.2500000::u80.
free_NW :- u80, action(swerve_right), free_NE, \+ free_SW, \+ free_W.

0.4998265::u81.
free_NW :- u81, action(change_to_left), \+ free_NE, free_SW, \+ free_W.

0.4967495::u82.
free_NW :- u82, action(change_to_right), \+ free_NE, free_SW, \+ free_W.

0.3437151::u83.
free_NW :- u83, action(cruise), \+ free_NE, free_SW, \+ free_W.

0.2116706::u84.
free_NW :- u84, action(keep), \+ free_NE, free_SW, \+ free_W.

0.0009990::u85.
free_NW :- u85, action(swerve_left), \+ free_NE, free_SW, \+ free_W.

0.0009990::u86.
free_NW :- u86, action(swerve_right), \+ free_NE, free_SW, \+ free_W.

0.4987571::u87.
free_NW :- u87, action(change_to_left), free_NE, free_SW, \+ free_W.

0.4965749::u88.
free_NW :- u88, action(change_to_right), free_NE, free_SW, \+ free_W.

0.4404691::u89.
free_NW :- u89, action(cruise), free_NE, free_SW, \+ free_W.

0.0009990::u90.
free_NW :- u90, action(keep), free_NE, free_SW, \+ free_W.

0.0009990::u91.
free_NW :- u91, action(swerve_left), free_NE, free_SW, \+ free_W.

0.0322581::u92.
free_NW :- u92, action(swerve_right), free_NE, free_SW, \+ free_W.

0.5019482::u93.
free_NW :- u93, action(change_to_left), \+ free_NE, \+ free_SW, free_W.

0.4981036::u94.
free_NW :- u94, action(change_to_right), \+ free_NE, \+ free_SW, free_W.

0.6221507::u95.
free_NW :- u95, action(cruise), \+ free_NE, \+ free_SW, free_W.

0.4223342::u96.
free_NW :- u96, action(keep), \+ free_NE, \+ free_SW, free_W.

0.7692308::u97.
free_NW :- u97, action(swerve_left), \+ free_NE, \+ free_SW, free_W.

0.5000000::u98.
free_NW :- u98, action(swerve_right), \+ free_NE, \+ free_SW, free_W.

0.4671291::u99.
free_NW :- u99, action(change_to_left), free_NE, \+ free_SW, free_W.

0.4870880::u100.
free_NW :- u100, action(change_to_right), free_NE, \+ free_SW, free_W.

0.3716900::u101.
free_NW :- u101, action(cruise), free_NE, \+ free_SW, free_W.

0.1791045::u102.
free_NW :- u102, action(keep), free_NE, \+ free_SW, free_W.

0.9990010::u103.
free_NW :- u103, action(swerve_left), free_NE, \+ free_SW, free_W.

0.9990010::u104.
free_NW :- u104, action(swerve_right), free_NE, \+ free_SW, free_W.

0.5358151::u105.
free_NW :- u105, action(change_to_left), \+ free_NE, free_SW, free_W.

0.4855202::u106.
free_NW :- u106, action(change_to_right), \+ free_NE, free_SW, free_W.

0.7596440::u107.
free_NW :- u107, action(cruise), \+ free_NE, free_SW, free_W.

0.0061474::u108.
free_NW :- u108, action(keep), \+ free_NE, free_SW, free_W.

0.8397436::u109.
free_NW :- u109, action(swerve_left), \+ free_NE, free_SW, free_W.

0.7326733::u110.
free_NW :- u110, action(swerve_right), \+ free_NE, free_SW, free_W.

0.5401792::u111.
free_NW :- u111, action(change_to_left), free_NE, free_SW, free_W.

0.6992325::u112.
free_NW :- u112, action(change_to_right), free_NE, free_SW, free_W.

0.5858170::u113.
free_NW :- u113, action(cruise), free_NE, free_SW, free_W.

0.0265375::u114.
free_NW :- u114, action(keep), free_NE, free_SW, free_W.

0.9935170::u115.
free_NW :- u115, action(swerve_left), free_NE, free_SW, free_W.

0.9018127::u116.
free_NW :- u116, action(swerve_right), free_NE, free_SW, free_W.

0.5022629::u117.
free_SE :- u117, action(change_to_left), \+ curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.5020096::u118.
free_SE :- u118, action(change_to_right), \+ curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.4909494::u119.
free_SE :- u119, action(cruise), \+ curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.2621078::u120.
free_SE :- u120, action(keep), \+ curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.9990010::u121.
free_SE :- u121, action(swerve_left), \+ curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.5000000::u122.
free_SE :- u122, action(swerve_right), \+ curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.4998987::u123.
free_SE :- u123, action(change_to_left), curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.4979204::u124.
free_SE :- u124, action(change_to_right), curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.5020064::u125.
free_SE :- u125, action(cruise), curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.9928163::u126.
free_SE :- u126, action(keep), curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.9990010::u127.
free_SE :- u127, action(swerve_left), curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.9990010::u128.
free_SE :- u128, action(swerve_right), curr_lane, \+ free_E, \+ free_NE, \+ free_NW.

0.4308797::u129.
free_SE :- u129, action(change_to_left), \+ curr_lane, free_E, \+ free_NE, \+ free_NW.

0.4250920::u130.
free_SE :- u130, action(change_to_right), \+ curr_lane, free_E, \+ free_NE, \+ free_NW.

0.4464923::u131.
free_SE :- u131, action(cruise), \+ curr_lane, free_E, \+ free_NE, \+ free_NW.

0.3437391::u132.
free_SE :- u132, action(keep), \+ curr_lane, free_E, \+ free_NE, \+ free_NW.

0.9990010::u133.
free_SE :- u133, action(swerve_left), \+ curr_lane, free_E, \+ free_NE, \+ free_NW.

0.5000000::u134.
free_SE :- u134, action(swerve_right), \+ curr_lane, free_E, \+ free_NE, \+ free_NW.

0.5389254::u135.
free_SE :- u135, action(change_to_left), curr_lane, free_E, \+ free_NE, \+ free_NW.

0.5059323::u136.
free_SE :- u136, action(change_to_right), curr_lane, free_E, \+ free_NE, \+ free_NW.

0.5748282::u137.
free_SE :- u137, action(cruise), curr_lane, free_E, \+ free_NE, \+ free_NW.

0.7929498::u138.
free_SE :- u138, action(keep), curr_lane, free_E, \+ free_NE, \+ free_NW.

0.9990010::u139.
free_SE :- u139, action(swerve_left), curr_lane, free_E, \+ free_NE, \+ free_NW.

0.8809524::u140.
free_SE :- u140, action(swerve_right), curr_lane, free_E, \+ free_NE, \+ free_NW.

0.5019008::u141.
free_SE :- u141, action(change_to_left), \+ curr_lane, \+ free_E, free_NE, \+ free_NW.

0.4877793::u142.
free_SE :- u142, action(change_to_right), \+ curr_lane, \+ free_E, free_NE, \+ free_NW.

0.4942611::u143.
free_SE :- u143, action(cruise), \+ curr_lane, \+ free_E, free_NE, \+ free_NW.

0.2602193::u144.
free_SE :- u144, action(keep), \+ curr_lane, \+ free_E, free_NE, \+ free_NW.

0.9990010::u145.
free_SE :- u145, action(swerve_left), \+ curr_lane, \+ free_E, free_NE, \+ free_NW.

0.5000000::u146.
free_SE :- u146, action(swerve_right), \+ curr_lane, \+ free_E, free_NE, \+ free_NW.

0.5084864::u147.
free_SE :- u147, action(change_to_left), curr_lane, \+ free_E, free_NE, \+ free_NW.

0.5021336::u148.
free_SE :- u148, action(change_to_right), curr_lane, \+ free_E, free_NE, \+ free_NW.

0.9829932::u149.
free_SE :- u149, action(cruise), curr_lane, \+ free_E, free_NE, \+ free_NW.

0.9990010::u150.
free_SE :- u150, action(keep), curr_lane, \+ free_E, free_NE, \+ free_NW.

0.5000000::u151.
free_SE :- u151, action(swerve_left), curr_lane, \+ free_E, free_NE, \+ free_NW.

0.9990010::u152.
free_SE :- u152, action(swerve_right), curr_lane, \+ free_E, free_NE, \+ free_NW.

0.4988383::u153.
free_SE :- u153, action(change_to_left), \+ curr_lane, free_E, free_NE, \+ free_NW.

0.3307229::u154.
free_SE :- u154, action(change_to_right), \+ curr_lane, free_E, free_NE, \+ free_NW.

0.5031930::u155.
free_SE :- u155, action(cruise), \+ curr_lane, free_E, free_NE, \+ free_NW.

0.0088106::u156.
free_SE :- u156, action(keep), \+ curr_lane, free_E, free_NE, \+ free_NW.

0.5000000::u157.
free_SE :- u157, action(swerve_left), \+ curr_lane, free_E, free_NE, \+ free_NW.

0.5000000::u158.
free_SE :- u158, action(swerve_right), \+ curr_lane, free_E, free_NE, \+ free_NW.

0.5068727::u159.
free_SE :- u159, action(change_to_left), curr_lane, free_E, free_NE, \+ free_NW.

0.4657751::u160.
free_SE :- u160, action(change_to_right), curr_lane, free_E, free_NE, \+ free_NW.

0.8416586::u161.
free_SE :- u161, action(cruise), curr_lane, free_E, free_NE, \+ free_NW.

0.7051282::u162.
free_SE :- u162, action(keep), curr_lane, free_E, free_NE, \+ free_NW.

0.9990010::u163.
free_SE :- u163, action(swerve_left), curr_lane, free_E, free_NE, \+ free_NW.

0.8508772::u164.
free_SE :- u164, action(swerve_right), curr_lane, free_E, free_NE, \+ free_NW.

0.5157031::u165.
free_SE :- u165, action(change_to_left), \+ curr_lane, \+ free_E, \+ free_NE, free_NW.

0.5016495::u166.
free_SE :- u166, action(change_to_right), \+ curr_lane, \+ free_E, \+ free_NE, free_NW.

0.5869107::u167.
free_SE :- u167, action(cruise), \+ curr_lane, \+ free_E, \+ free_NE, free_NW.

0.7142857::u168.
free_SE :- u168, action(keep), \+ curr_lane, \+ free_E, \+ free_NE, free_NW.

0.7037037::u169.
free_SE :- u169, action(swerve_left), \+ curr_lane, \+ free_E, \+ free_NE, free_NW.

0.5000000::u170.
free_SE :- u170, action(swerve_right), \+ curr_lane, \+ free_E, \+ free_NE, free_NW.

0.6938700::u171.
free_SE :- u171, action(change_to_left), curr_lane, \+ free_E, \+ free_NE, free_NW.

0.5017903::u172.
free_SE :- u172, action(change_to_right), curr_lane, \+ free_E, \+ free_NE, free_NW.

0.5061084::u173.
free_SE :- u173, action(cruise), curr_lane, \+ free_E, \+ free_NE, free_NW.

0.9875776::u174.
free_SE :- u174, action(keep), curr_lane, \+ free_E, \+ free_NE, free_NW.

0.9990010::u175.
free_SE :- u175, action(swerve_left), curr_lane, \+ free_E, \+ free_NE, free_NW.

0.5000000::u176.
free_SE :- u176, action(swerve_right), curr_lane, \+ free_E, \+ free_NE, free_NW.

0.5544322::u177.
free_SE :- u177, action(change_to_left), \+ curr_lane, free_E, \+ free_NE, free_NW.

0.5099594::u178.
free_SE :- u178, action(change_to_right), \+ curr_lane, free_E, \+ free_NE, free_NW.

0.7853160::u179.
free_SE :- u179, action(cruise), \+ curr_lane, free_E, \+ free_NE, free_NW.

0.9600000::u180.
free_SE :- u180, action(keep), \+ curr_lane, free_E, \+ free_NE, free_NW.

0.6486486::u181.
free_SE :- u181, action(swerve_left), \+ curr_lane, free_E, \+ free_NE, free_NW.

0.5000000::u182.
free_SE :- u182, action(swerve_right), \+ curr_lane, free_E, \+ free_NE, free_NW.

0.7732500::u183.
free_SE :- u183, action(change_to_left), curr_lane, free_E, \+ free_NE, free_NW.

0.5053645::u184.
free_SE :- u184, action(change_to_right), curr_lane, free_E, \+ free_NE, free_NW.

0.5455034::u185.
free_SE :- u185, action(cruise), curr_lane, free_E, \+ free_NE, free_NW.

0.7625345::u186.
free_SE :- u186, action(keep), curr_lane, free_E, \+ free_NE, free_NW.

0.7500000::u187.
free_SE :- u187, action(swerve_left), curr_lane, free_E, \+ free_NE, free_NW.

0.9740260::u188.
free_SE :- u188, action(swerve_right), curr_lane, free_E, \+ free_NE, free_NW.

0.5086908::u189.
free_SE :- u189, action(change_to_left), \+ curr_lane, \+ free_E, free_NE, free_NW.

0.4911186::u190.
free_SE :- u190, action(change_to_right), \+ curr_lane, \+ free_E, free_NE, free_NW.

0.4053530::u191.
free_SE :- u191, action(cruise), \+ curr_lane, \+ free_E, free_NE, free_NW.

0.8823529::u192.
free_SE :- u192, action(keep), \+ curr_lane, \+ free_E, free_NE, free_NW.

0.0009990::u193.
free_SE :- u193, action(swerve_left), \+ curr_lane, \+ free_E, free_NE, free_NW.

0.5000000::u194.
free_SE :- u194, action(swerve_right), \+ curr_lane, \+ free_E, free_NE, free_NW.

0.6696068::u195.
free_SE :- u195, action(change_to_left), curr_lane, \+ free_E, free_NE, free_NW.

0.4983879::u196.
free_SE :- u196, action(change_to_right), curr_lane, \+ free_E, free_NE, free_NW.

0.9628165::u197.
free_SE :- u197, action(cruise), curr_lane, \+ free_E, free_NE, free_NW.

0.9990010::u198.
free_SE :- u198, action(keep), curr_lane, \+ free_E, free_NE, free_NW.

0.9990010::u199.
free_SE :- u199, action(swerve_left), curr_lane, \+ free_E, free_NE, free_NW.

0.5000000::u200.
free_SE :- u200, action(swerve_right), curr_lane, \+ free_E, free_NE, free_NW.

0.5139789::u201.
free_SE :- u201, action(change_to_left), \+ curr_lane, free_E, free_NE, free_NW.

0.1182356::u202.
free_SE :- u202, action(change_to_right), \+ curr_lane, free_E, free_NE, free_NW.

0.8270813::u203.
free_SE :- u203, action(cruise), \+ curr_lane, free_E, free_NE, free_NW.

0.9427083::u204.
free_SE :- u204, action(keep), \+ curr_lane, free_E, free_NE, free_NW.

0.9325843::u205.
free_SE :- u205, action(swerve_left), \+ curr_lane, free_E, free_NE, free_NW.

0.9990010::u206.
free_SE :- u206, action(swerve_right), \+ curr_lane, free_E, free_NE, free_NW.

0.7849892::u207.
free_SE :- u207, action(change_to_left), curr_lane, free_E, free_NE, free_NW.

0.4627829::u208.
free_SE :- u208, action(change_to_right), curr_lane, free_E, free_NE, free_NW.

0.8572545::u209.
free_SE :- u209, action(cruise), curr_lane, free_E, free_NE, free_NW.

0.9964664::u210.
free_SE :- u210, action(keep), curr_lane, free_E, free_NE, free_NW.

0.9894027::u211.
free_SE :- u211, action(swerve_left), curr_lane, free_E, free_NE, free_NW.

0.9499192::u212.
free_SE :- u212, action(swerve_right), curr_lane, free_E, free_NE, free_NW.

0.7771419::u213.
free_SW :- u213, \+ curr_lane.

0.5998865::u214.
free_SW :- u214, curr_lane.

