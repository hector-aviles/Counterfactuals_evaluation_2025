%%% Exogenous variables

0.1692512::u_action(change_to_left); 0.1700701::u_action(change_to_right); 0.4044219::u_action(cruise); 0.2539536::u_action(keep); 0.0017913::u_action(swerve_left); 0.0005118::u_action(swerve_right)
action(V) :- u_action(V).

0.5305799::u1.
curr_lane :- u1.

0.5546228::u2.
free_E :- u2, \+ curr_lane.

0.7877882::u3.
free_E :- u3, curr_lane.

0.4867150::u4.
free_NE :- u4, action(change_to_left), \+ curr_lane.

0.4978672::u5.
free_NE :- u5, action(change_to_right), \+ curr_lane.

0.4876429::u6.
free_NE :- u6, action(cruise), \+ curr_lane.

0.1082964::u7.
free_NE :- u7, action(keep), \+ curr_lane.

0.8333333::u8.
free_NE :- u8, action(swerve_left), \+ curr_lane.

0.5000000::u9.
free_NE :- u9, action(swerve_right), \+ curr_lane.

0.4839491::u10.
free_NE :- u10, action(change_to_left), curr_lane.

0.5398335::u11.
free_NE :- u11, action(change_to_right), curr_lane.

0.8370256::u12.
free_NE :- u12, action(cruise), curr_lane.

0.0033259::u13.
free_NE :- u13, action(keep), curr_lane.

0.9310345::u14.
free_NE :- u14, action(swerve_left), curr_lane.

0.7000000::u15.
free_NE :- u15, action(swerve_right), curr_lane.

0.5019655::u16.
free_NW :- u16, action(change_to_left).

0.5425820::u17.
free_NW :- u17, action(change_to_right).

0.5256897::u18.
free_NW :- u18, action(cruise).

0.0330512::u19.
free_NW :- u19, action(keep).

0.9990010::u20.
free_NW :- u20, action(swerve_left).

0.9000000::u21.
free_NW :- u21, action(swerve_right).

0.4538814::u22.
free_SE :- u22, \+ curr_lane.

0.7276936::u23.
free_SE :- u23, curr_lane.

0.5290739::u24.
free_SW :- u24, action(change_to_left), \+ free_SE.

0.6236142::u25.
free_SW :- u25, action(change_to_right), \+ free_SE.

0.7625658::u26.
free_SW :- u26, action(cruise), \+ free_SE.

0.9956761::u27.
free_SW :- u27, action(keep), \+ free_SE.

0.9990010::u28.
free_SW :- u28, action(swerve_left), \+ free_SE.

0.5000000::u29.
free_SW :- u29, action(swerve_right), \+ free_SE.

0.5391850::u30.
free_SW :- u30, action(change_to_left), free_SE.

0.5233706::u31.
free_SW :- u31, action(change_to_right), free_SE.

0.5561672::u32.
free_SW :- u32, action(cruise), free_SE.

0.9474773::u33.
free_SW :- u33, action(keep), free_SE.

0.9696970::u34.
free_SW :- u34, action(swerve_left), free_SE.

0.9000000::u35.
free_SW :- u35, action(swerve_right), free_SE.

0.5034775::u36.
free_W :- u36, action(change_to_left).

0.5862173::u37.
free_W :- u37, action(change_to_right).

0.7195647::u38.
free_W :- u38, action(cruise).

0.9195889::u39.
free_W :- u39, action(keep).

0.9990010::u40.
free_W :- u40, action(swerve_left).

0.9000000::u41.
free_W :- u41, action(swerve_right).

0.9860365::u42.
latent_collision :- u42, \+ free_E, \+ free_SW, \+ free_W.

0.5826625::u43.
latent_collision :- u43, free_E, \+ free_SW, \+ free_W.

0.9416961::u44.
latent_collision :- u44, \+ free_E, free_SW, \+ free_W.

0.4746803::u45.
latent_collision :- u45, free_E, free_SW, \+ free_W.

0.8618619::u46.
latent_collision :- u46, \+ free_E, \+ free_SW, free_W.

0.3162328::u47.
latent_collision :- u47, free_E, \+ free_SW, free_W.

0.2935154::u48.
latent_collision :- u48, \+ free_E, free_SW, free_W.

0.1488971::u49.
latent_collision :- u49, free_E, free_SW, free_W.

