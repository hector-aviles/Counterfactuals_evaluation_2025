%%% Exogenous variables

0.1722845::u_action(change_to_left); 0.1662214::u_action(change_to_right); 0.4047374::u_action(cruise); 0.2539307::u_action(keep); 0.0020039::u_action(swerve_left); 0.0008221::u_action(swerve_right)
action(V) :- u_action(V).

0.5230706::u1.
curr_lane :- u1.

0.5372764::u2.
free_E :- u2, \+ curr_lane.

0.7897839::u3.
free_E :- u3, curr_lane.

0.5000000::u4.
free_NE :- u4, action(change_to_left), \+ curr_lane, \+ free_E.

0.4817150::u5.
free_NE :- u5, action(change_to_right), \+ curr_lane, \+ free_E.

0.5333333::u6.
free_NE :- u6, action(cruise), \+ curr_lane, \+ free_E.

0.2585292::u7.
free_NE :- u7, action(keep), \+ curr_lane, \+ free_E.

0.5000000::u8.
free_NE :- u8, action(swerve_left), \+ curr_lane, \+ free_E.

0.5000000::u9.
free_NE :- u9, action(swerve_right), \+ curr_lane, \+ free_E.

0.4733045::u10.
free_NE :- u10, action(change_to_left), curr_lane, \+ free_E.

0.5084967::u11.
free_NE :- u11, action(change_to_right), curr_lane, \+ free_E.

0.2258065::u12.
free_NE :- u12, action(cruise), curr_lane, \+ free_E.

0.0009990::u13.
free_NE :- u13, action(keep), curr_lane, \+ free_E.

0.5000000::u14.
free_NE :- u14, action(swerve_left), curr_lane, \+ free_E.

0.9990010::u15.
free_NE :- u15, action(swerve_right), curr_lane, \+ free_E.

0.4446953::u16.
free_NE :- u16, action(change_to_left), \+ curr_lane, free_E.

0.4924623::u17.
free_NE :- u17, action(change_to_right), \+ curr_lane, free_E.

0.4380623::u18.
free_NE :- u18, action(cruise), \+ curr_lane, free_E.

0.0199569::u19.
free_NE :- u19, action(keep), \+ curr_lane, free_E.

0.8333333::u20.
free_NE :- u20, action(swerve_left), \+ curr_lane, free_E.

0.5000000::u21.
free_NE :- u21, action(swerve_right), \+ curr_lane, free_E.

0.5022321::u22.
free_NE :- u22, action(change_to_left), curr_lane, free_E.

0.5720772::u23.
free_NE :- u23, action(change_to_right), curr_lane, free_E.

0.9030447::u24.
free_NE :- u24, action(cruise), curr_lane, free_E.

0.0006313::u25.
free_NE :- u25, action(keep), curr_lane, free_E.

0.8787879::u26.
free_NE :- u26, action(swerve_left), curr_lane, free_E.

0.7333333::u27.
free_NE :- u27, action(swerve_right), curr_lane, free_E.

0.5073069::u28.
free_NW :- u28, action(change_to_left).

0.5496136::u29.
free_NW :- u29, action(change_to_right).

0.5249460::u30.
free_NW :- u30, action(cruise).

0.0198300::u31.
free_NW :- u31, action(keep).

0.9230769::u32.
free_NW :- u32, action(swerve_left).

0.7500000::u33.
free_NW :- u33, action(swerve_right).

0.4583064::u34.
free_SE :- u34, \+ curr_lane.

0.7270138::u35.
free_SE :- u35, curr_lane.

0.5276989::u36.
free_SW :- u36, action(change_to_left), \+ free_SE.

0.6132404::u37.
free_SW :- u37, action(change_to_right), \+ free_SE.

0.7652495::u38.
free_SW :- u38, action(cruise), \+ free_SE.

0.9976096::u39.
free_SW :- u39, action(keep), \+ free_SE.

0.9990010::u40.
free_SW :- u40, action(swerve_left), \+ free_SE.

0.9990010::u41.
free_SW :- u41, action(swerve_right), \+ free_SE.

0.5100257::u42.
free_SW :- u42, action(change_to_left), free_SE.

0.5161930::u43.
free_SW :- u43, action(change_to_right), free_SE.

0.5410467::u44.
free_SW :- u44, action(cruise), free_SE.

0.9498355::u45.
free_SW :- u45, action(keep), free_SE.

0.9990010::u46.
free_SW :- u46, action(swerve_left), free_SE.

0.9990010::u47.
free_SW :- u47, action(swerve_right), free_SE.

0.5213242::u48.
free_W :- u48, action(change_to_left).

0.5777434::u49.
free_W :- u49, action(change_to_right).

0.7248953::u50.
free_W :- u50, action(cruise).

0.9312019::u51.
free_W :- u51, action(keep).

0.9487179::u52.
free_W :- u52, action(swerve_left).

0.8750000::u53.
free_W :- u53, action(swerve_right).

0.9822485::u54.
latent_collision :- u54, \+ free_E, \+ free_SW, \+ free_W.

0.5707102::u55.
latent_collision :- u55, free_E, \+ free_SW, \+ free_W.

0.9459459::u56.
latent_collision :- u56, \+ free_E, free_SW, \+ free_W.

0.4717295::u57.
latent_collision :- u57, free_E, free_SW, \+ free_W.

0.8481625::u58.
latent_collision :- u58, \+ free_E, \+ free_SW, free_W.

0.3263757::u59.
latent_collision :- u59, free_E, \+ free_SW, free_W.

0.2899819::u60.
latent_collision :- u60, \+ free_E, free_SW, free_W.

0.1514935::u61.
latent_collision :- u61, free_E, free_SW, free_W.

