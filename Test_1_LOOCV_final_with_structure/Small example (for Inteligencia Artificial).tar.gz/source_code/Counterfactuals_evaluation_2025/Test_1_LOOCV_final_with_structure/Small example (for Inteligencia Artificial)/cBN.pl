%%%%%%%%%%%%%%%%%%%%%%%%%%
% Exogenous variables
%%%%%%%%%%%%%%%%%%%%%%%%%%

0.4701183::u1.
free_NE :- u1.

0.7393943::u2.
free_W :- u2.

0.4628995::u3(change_to_left); 0.3253425::u3(cruise); 0.2117580::u3(keep).
action(V) :- u3(V), \+ free_NE, \+ free_W.

0.3477199::u4(change_to_left); 0.6518730::u4(cruise); 0.0004072::u4(keep).
action(V) :- u4(V), free_NE, \+ free_W.

0.1246326::u5(change_to_left); 0.2522046::u5(cruise); 0.6231628::u5(keep).
action(V) :- u5(V), \+ free_NE, free_W.

0.1592989::u6(change_to_left); 0.7684518::u6(cruise); 0.0722493::u6(keep).
action(V) :- u6(V), free_NE, free_W.

0.9990010::u7.
latent_collision :- u7, action(change_to_left), \+ free_NE, \+ free_W.

0.9990010::u8.
latent_collision :- u8, action(cruise), \+ free_NE, \+ free_W.

0.0009990::u9.
latent_collision :- u9, action(keep), \+ free_NE, \+ free_W.

0.9990010::u10.
latent_collision :- u10, action(change_to_left), free_NE, \+ free_W.

0.1267958::u11.
latent_collision :- u11, action(cruise), free_NE, \+ free_W.

0.0009990::u12.
latent_collision :- u12, action(keep), free_NE, \+ free_W.

0.7511792::u13.
latent_collision :- u13, action(change_to_left), \+ free_NE, free_W.

0.4358974::u14.
latent_collision :- u14, action(cruise), \+ free_NE, free_W.

0.0009990::u15.
latent_collision :- u15, action(keep), \+ free_NE, free_W.

0.7640587::u16.
latent_collision :- u16, action(change_to_left), free_NE, free_W.

0.0663964::u17.
latent_collision :- u17, action(cruise), free_NE, free_W.

0.0009990::u18.
latent_collision :- u18, action(keep), free_NE, free_W.

